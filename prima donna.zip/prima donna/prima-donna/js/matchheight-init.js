jQuery(function( $ ){

	$('.front-page .featured-content .entry, .category-index .featured-content .entry, .front-page-1 .featured-content .entry-header').matchHeight();

});