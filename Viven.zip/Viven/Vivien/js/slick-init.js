jQuery(document).ready(function($) {

	$(".home-carousel .items-wrapper").slick({
		arrows: false,
		autoplay: true,
		autoplaySpeed: 0,
		speed: 15000,
		cssEase: 'linear',
		variableWidth: true,
		draggable: false,
		pauseOnHover: false,
		centerMode: true,
	});

});
