<?php
/*
* Plugin Name: SuperCPT
* Description: Insanely easy and attractive custom post types, custom post meta, and custom taxonomies
*/
require_once get_stylesheet_directory() . '/includes/cpt/class/scpt-helpers.php';
require_once get_stylesheet_directory() . '/includes/cpt/class/class-scpt-markup.php';
require_once get_stylesheet_directory() . '/includes/cpt/class/class-super-custom-post-meta.php';
require_once get_stylesheet_directory() . '/includes/cpt/class/class-super-custom-post-type.php';
require_once get_stylesheet_directory() . '/includes/cpt/class/class-super-custom-taxonomy.php';
class Super_CPT {
	/**
	 * Initialize the plugin and call the appropriate hook method
	 */
	function __construct() {
		if ( is_admin() )
			add_action( 'init', array( &$this, 'admin_hooks' ) );
	}
	/**
	 * Setup appropriate hooks for wp-admin
	 *
	 * @uses SCPT_Admin
	 * @return void
	 */
	function admin_hooks() {
		add_action( 'admin_enqueue_scripts', array( &$this, 'load_js_and_css' ) );
	}
	/**
	 * Add supercpt.css to the doc head
	 *
	 * @return void
	 */
	function load_js_and_css() {
		wp_register_style( 'supercpt.css', get_stylesheet_directory_uri() . '/includes/cpt/css/supercpt.css', array('wp-color-picker'), '1.3' );
		wp_register_script( 'supercpt.js', get_stylesheet_directory_uri() . '/includes/cpt/js/supercpt.js', array( 'jquery', 'jquery-ui-core', 'jquery-ui-datepicker', 'wp-color-picker' ), '1.1' );
		wp_enqueue_style( 'supercpt.css' );
	
	
	}
}
$scpt_plugin = new Super_CPT;
do_action( 'supercpt_loaded' );