<?php
/**
 * @package      Prima Donna
 */

//* Add archive body class to the head
add_filter( 'body_class', 'primadonna_add_archive_body_class' );
function primadonna_add_archive_body_class( $classes ) {
   $classes[] = 'primadonna-archive';
   return $classes;
}

// Add Fullwidth and Boxed Slider widget areas on blog page

add_action( 'genesis_after_header', 'primadonna_blog_slider'  ); 
function primadonna_blog_slider() {

	$sliderfull = get_theme_mod( 'primadonna_featured_layout_setting', 'none' );
	if ( $sliderfull === 'full' ) {
		get_template_part('lib/featured/featured-full');
	}

	$slidercarousel = get_theme_mod( 'primadonna_featured_layout_setting', 'none' );
	if ( $sliderfull === 'carousel' ) {
		get_template_part('lib/featured/featured-carousel');
	}

	genesis_widget_area( 'blog-page-1', array(
		'before' => '<div class="blog-page-1 widget-area">',
		'after'  => '</div>',
    ) );

    $slider = get_theme_mod( 'primadonna_featured_layout_setting', 'none' );
	if ( $slider === 'boxed' ) {
		get_template_part('lib/featured/featured');
	}

	echo '<div class="wrap">';

	genesis_widget_area( 'blog-page-left', array(
		'before' => '<div class="blog-page-left widget-area">',
		'after'  => '</div>',
    ) );

	$slider = get_theme_mod( 'primadonna_featured_layout_setting', 'none' );
	if ( $slider === 'split' ) {
		get_template_part('lib/featured/featured-two-thirds');
	}

	genesis_widget_area( 'blog-page-right', array(
		'before' => '<div class="blog-page-right widget-area">',
		'after'  => '</div></div>',
    	) );

	echo '</div>';

    genesis_widget_area( 'blog-page-2', array(
		'before' => '<div class="blog-page-2 widget-area">',
		'after'  => '</div>',
    ) );

    $promo = get_theme_mod( 'primadonna_promo_setting', 'none' );
	if ( $promo === '2boxes' ) {
		get_template_part('lib/promo/promo2');
	}

    $promo = get_theme_mod( 'primadonna_promo_setting', 'none' );
	if ( $promo === '3boxes' ) {
		get_template_part('lib/promo/promo3');
	}

	$promo = get_theme_mod( 'primadonna_promo_setting', 'none' );
	if ( $promo === '4boxes' ) {
		get_template_part('lib/promo/promo4');
	}

	genesis_widget_area( 'blog-page-3', array(
		'before' => '<div class="blog-page-3 widget-area">',
		'after'  => '</div>',
    ) );
}

//* Hooks Slider Above Blog Content and Add Posts Wrap
add_action( 'genesis_before_loop', 'primadonna_above_blog_slider'  ); 
function primadonna_above_blog_slider() {	
    
    genesis_widget_area( 'above-blog-slider', array(
		'before' => '<div class="above-blog-slider widget-area">',
		'after'  => '</div><div class="posts-wrap">',
    ) );
}
add_action( 'genesis_after_content', 'primadonna_post_wrap'  );
function primadonna_post_wrap() {
	return '</div>';
}


//* Reposition Featured Images - Moves FI above title
$filayout = get_theme_mod( 'primadonna_fi_setting', 'true' );
if ( $filayout === 'false' ) {
 remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
 add_action( 'genesis_entry_header', 'genesis_do_post_image', 5 );
}

//* Make sure content limit (if set in Theme Settings) doesn't apply
add_filter( 'genesis_pre_get_option_content_archive_limit', 'primadonna_no_content_limit' );
function primadonna_no_content_limit() {
	return '0';
}

//* Blog Layout *//


//** Grid Layout **//
$gridlayout = get_theme_mod( 'primadonna_bloglayout_setting', 'full' );
if ( $gridlayout === 'grid' ) {

add_filter( 'body_class', 'primadonna_grid_body_class' );
function primadonna_grid_body_class( $classes ) {
	
	$classes[] = 'grid';
	return $classes;
	
}
//* Remove Featured image (if set in Theme Settings)
add_filter( 'genesis_pre_get_option_content_archive_thumbnail', 'primadonna_no_post_image' );
function primadonna_no_post_image() {
	return '0';
}
//* Display centered wide featured image for First Post 
add_action( 'genesis_entry_header', 'primadonna_show_featured_image', 8 );
function primadonna_show_featured_image() {
	if ( ! has_post_thumbnail() ) {
		return;
	}
		$image_args = array(
			'size' => 'horizontal-entry-image',
			'attr' => array(
				'class' => 'alignnone',
			),
		);

	$image = genesis_get_image( $image_args );

	echo '<div class="home-featured-image"><a href="' . get_permalink() . '">' . $image .'</a></div>';
}
//* Show Excerpts regardless of Theme Settings
add_filter( 'genesis_pre_get_option_content_archive', 'primadonna_show_excerpts' );
function primadonna_show_excerpts() {
	return 'excerpts';
}

//* Modify the length of post excerpts
add_filter( 'excerpt_length', 'primadonna_excerpt_length' );
function primadonna_excerpt_length( $length ) {
	return 35; // pull first 35 words
}
add_filter('excerpt_more', 'primadonna_grid_excerpt_more');
function primadonna_grid_excerpt_more($more) {
	$readmore = get_theme_mod( 'primadonna_read_more_setting', 'continue reading' );
	return '... <a class="more-link" href="' . get_permalink() . '">[' . $readmore . ']</a>';
}

$fullgridlayout = get_theme_mod( 'primadonna_column_setting', '2col' );
if ( $fullgridlayout === '2col' ) {
function primadonna_grid_post_class( $classes ) {
	// Don't run on single posts or pages
	if( is_singular() )
		return $classes;
	$classes[] = 'one-half';
	global $wp_query;
	if( 0 == $wp_query->current_post || 0 == $wp_query->current_post % 2 )
		$classes[] = 'first';
	return $classes;
}
}

$fullgridlayout = get_theme_mod( 'primadonna_column_setting', '2col' );
if ( $fullgridlayout === '3col' ) {
function primadonna_grid_post_class( $classes ) {
	// Don't run on single posts or pages
	if( is_singular() )
		return $classes;
	$classes[] = 'one-third';
	global $wp_query;
	if( 0 == $wp_query->current_post || 0 == $wp_query->current_post % 3 )
		$classes[] = 'first';
	return $classes;
}
}

add_filter( 'post_class', 'primadonna_grid_post_class' );
}


//** First Full then Grid Layout **//
$fullgridlayout = get_theme_mod( 'primadonna_bloglayout_setting', 'full' );
if ( $fullgridlayout === 'full_grid' ) {

add_filter( 'body_class', 'primadonna_grid_body_class' );
function primadonna_grid_body_class( $classes ) {
	
	$classes[] = 'full-grid';
	return $classes;
	
}
//* Remove Featured image (if set in Theme Settings)
add_filter( 'genesis_pre_get_option_content_archive_thumbnail', 'primadonna_no_post_image' );
function primadonna_no_post_image() {
	return '0';
}
//* Display centered wide featured image for First Post and left aligned thumbnail for the next five
add_action( 'genesis_entry_header', 'primadonna_show_featured_image', 8 );
function primadonna_show_featured_image() {
	if ( ! has_post_thumbnail() ) {
		return;
	}

	global $wp_query;

	if( ( $wp_query->current_post <= 0 ) ) {
		$image_args = array(
			'size' => 'full-thumbnail',
			'attr' => array(
				'class' => 'aligncenter',
			),
		);
	
	} else {
		$image_args = array(
			'size' => 'horizontal-entry-image',
			'attr' => array(
				'class' => 'alignnone',
			),
		);
	}

	$image = genesis_get_image( $image_args );

	echo '<div class="home-featured-image"><a href="' . get_permalink() . '">' . $image .'</a></div>';
}
//* Show Excerpts regardless of Theme Settings
add_filter( 'genesis_pre_get_option_content_archive', 'primadonna_show_excerpts' );
function primadonna_show_excerpts() {
	return 'excerpts';
}

//* Modify the length of post excerpts
add_filter( 'excerpt_length', 'primadonna_excerpt_length' );
function primadonna_excerpt_length( $length ) {
	return 35; // pull first 35 words
}
add_filter('excerpt_more', 'primadonna_grid_excerpt_more');
function primadonna_grid_excerpt_more($more) {
	$readmore = get_theme_mod( 'primadonna_read_more_setting', 'continue reading' );
	return '... <a class="more-link" href="' . get_permalink() . '">[' . $readmore . ']</a>';
}
$fullgridlayout = get_theme_mod( 'primadonna_column_setting', '2col' );
if ( $fullgridlayout === '2col' ) {
function primadonna_grid_post_class( $classes ) {
	// Don't run on single posts or pages
	if( is_singular() )
		return $classes;
	$classes[] = 'one-half';
	global $wp_query;
	if( 0 == $wp_query->current_post)
		$classes[] = 'first-post';
	if(  1 == $wp_query->current_post % 2)
		$classes[] = 'first';
	return $classes;
}
}
$fullgridlayout = get_theme_mod( 'primadonna_column_setting', '2col' );
if ( $fullgridlayout === '3col' ) {
function primadonna_grid_post_class( $classes ) {
	// Don't run on single posts or pages
	if( is_singular() )
		return $classes;
	$classes[] = 'one-third';
	global $wp_query;
	if( 0 == $wp_query->current_post)
		$classes[] = 'first-post';
	if(  1 == $wp_query->current_post % 3)
		$classes[] = 'first';
	return $classes;
}
}
add_filter( 'post_class', 'primadonna_grid_post_class' );
}


//** List Layout **/
$listlayout = get_theme_mod( 'primadonna_bloglayout_setting', 'full' );
if ( $listlayout === 'list' ) {

add_filter( 'body_class', 'primadonna_list_body_class' );
function primadonna_list_body_class( $classes ) {
	
	$classes[] = 'list';
	return $classes;
	
}
//* Remove Featured image (if set in Theme Settings)
add_filter( 'genesis_pre_get_option_content_archive_thumbnail', 'primadonna_no_post_image' );
function primadonna_no_post_image() {
	return '0';
}

//* Show Excerpts regardless of Theme Settings
add_filter( 'genesis_pre_get_option_content_archive', 'primadonna_show_excerpts' );
function primadonna_show_excerpts() {
	return 'excerpts';
}

//* Modify the length of post excerpts
add_filter( 'excerpt_length', 'primadonna_excerpt_length' );
function primadonna_excerpt_length( $length ) {
	return 45; // pull first 45 words
}

add_filter('excerpt_more', 'primadonna_list_excerpt_more');
function primadonna_list_excerpt_more($more) {
	$readmore = get_theme_mod( 'primadonna_read_more_setting', 'continue reading' );
	return '... <a class="more-link" href="' . get_permalink() . '">[' . $readmore . ']</a>';
}

//* Display centered wide featured image for First Post and left aligned thumbnail for the next five
add_action( 'genesis_entry_header', 'primadonna_show_featured_image', 8 );
function primadonna_show_featured_image() {
	if ( ! has_post_thumbnail() ) {
		return;
	}
		$image_args = array(
			'size' => 'square-entry-image',
			'attr' => array(
				'class' => 'alignleft',
			),
		);

	$image = genesis_get_image( $image_args );

	echo '<div class="home-featured-image"><a href="' . get_permalink() . '">' . $image .'</a></div>';
}

}


//** 1st Full Then List Layout **/
$fulllistlayout = get_theme_mod( 'primadonna_bloglayout_setting', 'full' );
if ( $fulllistlayout === 'full_list' ) {

add_filter( 'body_class', 'primadonna_list_body_class' );
function primadonna_list_body_class( $classes ) {
	
	$classes[] = 'list-full';
	return $classes;
	
}
//* Remove Featured image (if set in Theme Settings)
add_filter( 'genesis_pre_get_option_content_archive_thumbnail', 'primadonna_no_post_image' );
function primadonna_no_post_image() {
	return '0';
}

//* Show Excerpts regardless of Theme Settings
add_filter( 'genesis_pre_get_option_content_archive', 'primadonna_show_excerpts' );
function primadonna_show_excerpts() {
	return 'excerpts';
}

//* Modify the length of post excerpts
add_filter( 'excerpt_length', 'primadonna_excerpt_length' );
function primadonna_excerpt_length( $length ) {
	return 45; // pull first 45 words
}

add_filter('excerpt_more', 'primadonna_list_excerpt_more');
function primadonna_list_excerpt_more($more) {
	$readmore = get_theme_mod( 'primadonna_read_more_setting', 'continue reading' );
	return '... <a class="more-link" href="' . get_permalink() . '">[' . $readmore . ']</a>';
}

//* Display centered wide featured image for First Post and left aligned thumbnail for the next five
add_action( 'genesis_entry_header', 'primadonna_show_featured_image', 8 );
function primadonna_show_featured_image() {
	if ( ! has_post_thumbnail() ) {
		return;
	}

	global $wp_query;

	if( ( $wp_query->current_post <= 0 ) ) {
		$image_args = array(
			'size' => 'full-thumbnail',
			'attr' => array(
				'class' => 'aligncenter',
			),
		);
	
	} else {
		$image_args = array(
			'size' => 'square-entry-image',
			'attr' => array(
				'class' => 'alignleft',
			),
		);
	}

	$image = genesis_get_image( $image_args );

	echo '<div class="home-featured-image"><a href="' . get_permalink() . '">' . $image .'</a></div>';
}
}

//** Masonry Layout **//
$masonrylayout = get_theme_mod( 'primadonna_bloglayout_setting', 'full' );
if ( $masonrylayout === 'masonry' ) {

//Add Masonry body class
add_filter( 'body_class', 'primadonna_blog_masonry_body_class' );
function primadonna_blog_masonry_body_class( $classes ) {
	
	$classes[] = 'masonry-posts';
	return $classes;	
}
add_action( 'wp_enqueue_scripts', 'primadonna_blog_masonry_enqueue_scripts' );
function primadonna_blog_masonry_enqueue_scripts() {
wp_enqueue_script( 'masonry' );
wp_enqueue_script( 'masonry-init', get_stylesheet_directory_uri() . '/js/masonry-init.js', array( 'jquery-masonry' ) ); 
}

//* Remove Featured image (if set in Theme Settings)
add_filter( 'genesis_pre_get_option_content_archive_thumbnail', 'primadonna_no_post_image' );
function primadonna_no_post_image() {
	return '0';
}
//* Display centered wide featured image for First Post and left aligned thumbnail for the next five
add_action( 'genesis_entry_header', 'primadonna_show_featured_image', 8 );
function primadonna_show_featured_image() {
	if ( ! has_post_thumbnail() ) {
		return;
	}
		$image_args = array(
			'size' => 'full-thumbnail',
			'attr' => array(
				'class' => 'alignnone',
			),
		);

	$image = genesis_get_image( $image_args );

	echo '<div class="home-featured-image"><a href="' . get_permalink() . '">' . $image .'</a></div>';
}

//* Show Excerpts regardless of Theme Settings
add_filter( 'genesis_pre_get_option_content_archive', 'primadonna_show_excerpts' );
function primadonna_show_excerpts() {
	return 'excerpts';
}

//* Modify the length of post excerpts
add_filter( 'excerpt_length', 'primadonna_excerpt_length' );
function primadonna_excerpt_length( $length ) {
	return 45; // pull first 65 words
}
add_filter('excerpt_more', 'primadonna_list_excerpt_more');
function primadonna_list_excerpt_more($more) {
	$readmore = get_theme_mod( 'primadonna_read_more_setting', 'continue reading' );
	return '... <a class="more-link" href="' . get_permalink() . '">[' . $readmore . ']</a>';
}



}

//** First Full then Masonry Layout **//
$fullmasonrylayout = get_theme_mod( 'primadonna_bloglayout_setting', 'full' );
if ( $fullmasonrylayout === 'full_masonry' ) {

//Add Masonry body class
add_filter( 'body_class', 'primadonna_masonry_body_class' );
function primadonna_masonry_body_class( $classes ) {
	
	$classes[] = 'masonry-posts-full';
	return $classes;	
}
add_action( 'wp_enqueue_scripts', 'primadonna_masonry_enqueue_scripts' );
function primadonna_masonry_enqueue_scripts() {
wp_enqueue_script( 'masonry' );
wp_enqueue_script( 'masonry-init', get_stylesheet_directory_uri() . '/js/masonry-init-full.js', array( 'jquery-masonry' ) ); 
}
//* Remove Featured image (if set in Theme Settings)
add_filter( 'genesis_pre_get_option_content_archive_thumbnail', 'primadonna_no_post_image' );
function primadonna_no_post_image() {
	return '0';
}
//* Display centered wide featured image for First Post and left aligned thumbnail for the next five
add_action( 'genesis_entry_header', 'primadonna_show_featured_image', 8 );
function primadonna_show_featured_image() {
	if ( ! has_post_thumbnail() ) {
		return;
	}
		$image_args = array(
			'size' => 'full-thumbnail',
			'attr' => array(
				'class' => 'alignnone',
			),
		);

	$image = genesis_get_image( $image_args );

	echo '<div class="home-featured-image"><a href="' . get_permalink() . '">' . $image .'</a></div>';
}

//* Show Excerpts regardless of Theme Settings
add_filter( 'genesis_pre_get_option_content_archive', 'primadonna_show_excerpts' );
function primadonna_show_excerpts() {
	return 'excerpts';
}

//* Modify the length of post excerpts
add_filter( 'excerpt_length', 'primadonna_excerpt_length' );
function primadonna_excerpt_length( $length ) {
	return 45; // pull first 45 words
}
add_filter('excerpt_more', 'primadonna_list_excerpt_more');
function primadonna_list_excerpt_more($more) {
	$readmore = get_theme_mod( 'primadonna_read_more_setting', 'continue reading' );
	return '... <a class="more-link" href="' . get_permalink() . '">[' . $readmore . ']</a>';
}
}


//* Remove entry meta
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

// Force full page layout if sidebar disabled
$disablesidebar = get_theme_mod( 'primadonna_sidebar_setting', 'false' );
if ( $disablesidebar === 'true' ) {
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
}

genesis();