<?php

/* Dar de alta el custom post type de Portafolio */
add_action ('init', 'hd_portafolio', 1);
function hd_portafolio() {
	$portafolio = get_field('portafolio', 'option');
	if(empty($portafolio)){
		$portafolio = 'si';
		update_field('portafolio', $portafolio, 'options');
	}
	if($portafolio == 'no')
		$ver_portafolio = false;
	else
		$ver_portafolio = true;
	$labels_portafolio = array (
						'name' 					=> __('Portfolio', 'flamingo_theme'),					 
						'singular_name' 		=> __('Project', 'flamingo_theme'),				
						'menu_name' 			=> __('Portfolio', 'flamingo_theme'),							
						'add_new' 				=> __('Add new', 'flamingo_theme'),			
						'all_items'				=> __('All projects', 'flamingo_theme'),	
						'add_new_item' 		=> __('Add new', 'flamingo_theme'),
						'edit_item' 				=> __('Edit', 'flamingo_theme'),
						'new_item' 			=> __('New', 'flamingo_theme'),
						'view_item' 			=> __('View', 'flamingo_theme'),
						'search_items' 			=> __('Search project', 'flamingo_theme'),
						'not_found' 			=> __('Project not found', 'flamingo_theme'),
						'not_found_in_trash'	=> __('Project not found in trash', 'flamingo_theme'),
	);
	$args_portafolio = array(
					'labels' 					=> $labels_portafolio,
					'public' 				=> true,
					'show_ui' 				=> $ver_portafolio,
					'publicly_queryable'	=> true,
					'query_var' 			=> true,
					'rewrite' 				=> true,
					'hierarchical' 			=> false,
					'menu_position' 		=> 5,
					'has_archive' 			=> false,
					'capability_type' 		=> 'post',
					'supports' 				=> array('title', 'excerpt', 'editor', 'thumbnail', 'revisions'),
					'menu_icon' 			=> 'dashicons-portfolio'
	);
	register_post_type('portafolio', $args_portafolio); 											
}


/* Dar de alta las categorías de Portafolio */
add_action ('init', 'hd_tax_portafolio', 1);
function hd_tax_portafolio() {
	$args_tx_portafolio = array ('label' 				=> __('Category', 'flamingo_theme'),				
							'labels' 						=> array( 'name' => __('Categories', 'flamingo_theme'),'singular_name' => __('Category', 'flamingo_theme')),
							'public'						=> true,
							'hierarchical' 				=> true,
							'show_ui'					=> true,
							'show_in_nav_menus'		=> false,
							'show_admin_column'	=> true,
							'query_var'					=> true,
							'publicly_queryable'	 	=> true,
							'rewrite'					=> true,
	);
	register_taxonomy('cat-portafolio', 'portafolio', $args_tx_portafolio);									
}

?>