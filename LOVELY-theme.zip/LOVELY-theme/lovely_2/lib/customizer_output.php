<?php
/* replace old color */
function skyandstars_customizer_head_styles() {
?>
<style type="text/css">

<?php
	// HEADER LOGO HEIGHT
	$header_logo_height = get_theme_mod( 'header_logo_height' ); 
	if ( $header_logo_height != '180' ) :
	?>
		
			.header-image .site-title > a {
				min-height: <?php echo $header_logo_height; ?>px;
			}
		
	<?php
	endif;

	// Background Color
	$bgx_color = get_theme_mod( 'bgx_color' ); 
	if ( $bgx_color != '#ffffff' ) :
	?>
		
			body {
				background-color: <?php echo $bgx_color; ?>;
			}
		
	<?php
	endif;

	// TOP MENU BACKGROUND
	$menu_bg_color = get_theme_mod( 'menu_bg_color' ); 
	if ( $menu_bg_color != '#000000' ) :
	?>
			#menu,
			.nav-primary, 
			.genesis-nav-menu .sub-menu a,
			.genesis-nav-menu .sub-menu a:hover,
			button.menu-toggle, button.sub-menu-toggle,
			.genesis-nav-menu .menu-item,
			.nav-primary .genesis-nav-menu {
				background-color: <?php echo $menu_bg_color; ?>;
			}
		
	<?php
	endif;
	
	// MENU LINK
	$menu_link_color = get_theme_mod( 'menu_link_color' ); 
	if ( $menu_link_color != '#ffffff' ) :
	?>

			.nav-primary .genesis-nav-menu a,
			.genesis-nav-menu .sub-menu a,
			.nav-primary .genesis-nav-menu .sub-menu a, 
			.nav-primary .genesis-nav-menu .current-menu-item > a{
				color: <?php echo $menu_link_color; ?>;
			}
			button.menu-toggle, 
			button.sub-menu-toggle {
				color: <?php echo $menu_link_color; ?>!important;
			}
		
	<?php
	endif;
	
	// MENU LINK HOVER text
	$menu_link_hvrcolor = get_theme_mod( 'menu_link_hvrcolor' ); 
	if ( $menu_link_color != '#ffcccc' ) :
	?>

			.nav-primary .genesis-nav-menu a:hover, 
			#menu #socmedicons a:hover,
			.nav-primary .genesis-nav-menu .sub-menu a:hover,
			.nav-primary .genesis-nav-menu .sub-menu .current-menu-item > a:hover,
			.nav-primary .genesis-nav-menu .sub-menu li a:hover {
				color: <?php echo $menu_link_hvrcolor; ?>!important;
			}
		
	<?php
	endif;

	// TEXT COLOR
	$text_color = get_theme_mod( 'text_color' ); 
	if ( $text_color != '#333333' ) :
	?>
		
			body {
				color: <?php echo $text_color; ?>;
			}
		
	<?php
	endif;
	
	// POST TITLE COLOR
	$posttitle_color = get_theme_mod( 'posttitle_color' ); 
	if ( $posttitle_color != '#3d3d3d' ) :
	?>
			.entry-title a {
				color: <?php echo $posttitle_color; ?>!important;
			}

	<?php
	endif;

	// POST TITLE HOVER COLOR
	$posttitle_hvrcolor = get_theme_mod( 'posttitle_hvrcolor' ); 
	if ( $posttitle_hvrcolor != '#ffcccc' ) :
	?>
			.entry-title a:hover  {
				color: <?php echo $posttitle_hvrcolor; ?>!important;
			}

	<?php
	endif;
	
	// LINK COLOR
	$content_link_color = get_theme_mod( 'content_link_color' ); 
	if ( $content_link_color != '#a2a2a2' ) :
	?>
			a,
			.entry-content p a {
				color: <?php echo $content_link_color; ?>;
			}
		
	<?php
	endif;

	// HOVER COLOR
	$link_hvrcolor = get_theme_mod( 'link_hvrcolor' ); 
	if ( $link_hvrcolor != '#ffcccc' ) :
	?>

			a:hover,
			a:focus,
			.sidebar .widget-title a,
			.sidebar .widget a:hover,
			.sidebar #socmedicons a:hover,
			.tagcloud a:hover,
			.prevnext-post a:hover,
			.related-post a:hover,
			.sidebar .featured-content  .entry-content a.more-link:hover,
			.site-footer a:hover {
				color: <?php echo $link_hvrcolor; ?>!important;
			}
			.entry-content p a:hover {
				color: <?php echo $link_hvrcolor; ?>;
			}

		
	<?php
	endif;
	
	
	// Read More Button

	// BUTTON COLOR
	$rmbtn_color = get_theme_mod( 'rmbtn_color' ); 
	if ( $rmbtn_color != '#ffcccc' ) :
	?>
			.entry-content p a.autoreadmore,
			.more-link {
				background-color: <?php echo $rmbtn_color; ?>;
			}
		
	<?php
	endif;
	
	// BUTTON TEXT COLOR
	$rmbtn_txt_color = get_theme_mod( 'rmbtn_txt_color' ); 
	if ( $rmbtn_txt_color != '#ffffff' ) :
	?>
			.autoreadmore,
			.more-link {
				color: <?php echo $rmbtn_txt_color; ?>!important;
			}

	<?php
	endif;
	
	// BUTTON HOVER COLOR
	$rmbtn_hvrcolor = get_theme_mod( 'rmbtn_hvrcolor' ); 
	if ( $rmbtn_hvrcolor != '#f8b4b3' ) :
	?>
			
			.entry-content p a.autoreadmore:hover,
			.more-link:hover,
			.archive-pagination .active a,
			.archive-pagination li a:hover,
			.archive-pagination a:hover,
			.archive-pagination .active a:hover {
				background-color: <?php echo $rmbtn_hvrcolor; ?>;
			}
			
	<?php
	endif;
	
	
	
	// BUTTON TEXT HOVER COLOR
	$rmbtntxt_hvrcolor = get_theme_mod( 'rmbtntxt_hvrcolor' ); 
	if ( $rmbtntxt_hvrcolor != '#ffffff' ) :
	?>		
			
			.entry-content p a.autoreadmore:hover,
			.more-link:hover,
			.archive-pagination .active a,
			.archive-pagination a:hover,
			.archive-pagination .active a:hover {
				color: <?php echo $rmbtntxt_hvrcolor; ?>!important;
			}
			
	<?php
	endif;

	/* end read more */

	
	// BUTTON COLOR
	$btn_color = get_theme_mod( 'btn_color' ); 
	if ( $btn_color != '#000000' ) :
	?>
			.social-page .socpage-widgets .menu a,
			.enews-widget input[type="submit"] {
				background-color: <?php echo $btn_color; ?>;
			}
			.comment-respond input[type="submit"],
			.social-page .socpage-widgets .menu a {
				background-color: <?php echo $btn_color; ?>;
			}
			
			.site-inner button, 
			input[type="button"], 
			input[type="reset"], 
			input[type="submit"], 
			.button,
			.search-form input[type="submit"] {
				background-color: <?php echo $btn_color; ?>;
			}

			div.wpforms-container-full .wpforms-form input[type=submit], 
			div.wpforms-container-full .wpforms-form button[type=submit], 
			div.wpforms-container-full .wpforms-form .wpforms-page-button {
				background-color: <?php echo $btn_color; ?>!important;
			}
		
	<?php
	endif;
	
	// BUTTON TEXT COLOR
	$btn_txt_color = get_theme_mod( 'btn_txt_color' ); 
	if ( $btn_txt_color != '#ffffff' ) :
	?>
			.social-page .socpage-widgets .menu a,
			.enews-widget input[type="submit"],
			.social-page .socpage-widgets .menu a {
				color: <?php echo $btn_txt_color; ?>!important;
			}
			.comment-respond input[type="submit"] {
				color: <?php echo $btn_txt_color; ?>!important;
			}
			.site-inner button, 
			input[type="button"], 
			input[type="reset"], 
			input[type="submit"], 
			.button,
			.search-form input[type="submit"] {
			    color: <?php echo $btn_txt_color; ?>!important;
			}
			
			.page .entry-content button, 
			.page .entry-content input[type="button"], 
			.page .entry-content input[type="reset"], 
			.page .entry-content input[type="submit"], 
			.page .entry-content .button {
				color: <?php echo $btn_txt_color; ?>!important;
			}
			div.wpforms-container-full .wpforms-form input[type=submit], 
			div.wpforms-container-full .wpforms-form button[type=submit], 
			div.wpforms-container-full .wpforms-form .wpforms-page-button {
				color: <?php echo $btn_txt_color; ?>!important;
			}
			
	<?php
	endif;
	
	// BUTTON HOVER COLOR
	$btn_hvrcolor = get_theme_mod( 'btn_hvrcolor' ); 
	if ( $btn_hvrcolor != '#ffcccc' ) :
	?>
			.social-page .socpage-widgets .menu a:hover,
			.enews-widget input[type="submit"]:hover {
				background-color: <?php echo $btn_hvrcolor; ?>;
			}
			.comment-respond input[type="submit"]:hover,
			.social-page .socpage-widgets .menu a:hover {
				background-color: <?php echo $btn_hvrcolor; ?>;
			}
			.site-inner button:hover, 
			input[type="button"]:hover, 
			input[type="reset"]:hover, 
			input[type="submit"]:hover, 
			.button:hover,
			.search-form input[type="submit"]:hover {
			    background-color: <?php echo $btn_hvrcolor; ?>;
			}
		
			div.wpforms-container-full .wpforms-form input[type=submit]:hover, 
			div.wpforms-container-full .wpforms-form button[type=submit]:hover, 
			div.wpforms-container-full .wpforms-form .wpforms-page-button:hover {
				background-color: <?php echo $btn_hvrcolor; ?>!important;
			}

	<?php
	endif;
	
	
	
	// BUTTON TEXT HOVER COLOR
	$btntxt_hvrcolor = get_theme_mod( 'btntxt_hvrcolor' ); 
	if ( $btntxt_hvrcolor != '#ffffff' ) :
	?>		
			.social-page .socpage-widgets .menu a:hover,
			.enews-widget input[type="submit"]:hover {
				color: <?php echo $btntxt_hvrcolor; ?>!important;
			}
			.comment-respond input[type="submit"]:hover,
			.social-page .socpage-widgets .menu a:hover {
				color: <?php echo $btntxt_hvrcolor; ?>!important;
			}
			.site-inner button:hover, 
			input[type="button"]:hover, 
			input[type="reset"]:hover, 
			input[type="submit"]:hover, 
			.button:hover,
			.search-form input[type="submit"]:hover {
			    color: <?php echo $btntxt_hvrcolor; ?>!important;
			}
			
			.page .entry-content button:hover, .page .entry-content input[type="button"]:hover, .page .entry-content input[type="reset"]:hover, .page .entry-content input[type="submit"]:hover, .page .entry-content .button:hover {
				color: <?php echo $btntxt_hvrcolor; ?>!important;
			}
			div.wpforms-container-full .wpforms-form input[type=submit]:hover, 
			div.wpforms-container-full .wpforms-form button[type=submit]:hover, 
			div.wpforms-container-full .wpforms-form .wpforms-page-button:hover {
				color: <?php echo $btntxt_hvrcolor; ?>!important;
			}
	<?php
	endif;

	// WIDGET TEXT COLOR
	$widgettxt_color = get_theme_mod( 'widgettxt_color' ); 
	if ( $widgettxt_color != '#000000' ) :
	?>
			.widget-title, 
			aside .widget-title, 
			.footer-widgets .widget-title {
				color: <?php echo $widgettxt_color; ?>;
			}
		
	<?php
	endif;
	

	// Footer background
	$footer_bgolor = get_theme_mod( 'footer_bgolor' ); 
	if ( $footer_bgolor != '#f6f6f6' ) :
	?>
			.footer-widgets,
			.site-footer {
				background-color: <?php echo $footer_bgolor; ?>!important;
			}
			
	<?php
	endif;

	?>
</style>
<?php
}
add_action( 'wp_head', 'skyandstars_customizer_head_styles' );
?>