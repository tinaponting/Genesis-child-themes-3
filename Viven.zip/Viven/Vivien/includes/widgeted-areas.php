<?php
/**
* @package     Vivien Theme
* @subpackage  Genesis
*/
//* Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;

}

add_action( 'genesis_before', 'vivien_before_header' );

/**
 * Load an ad section before .site-inner.
 *
 * @since   1.0.0
 *
 * @return  null if the before-header sidebar isn't active.

 */

function vivien_before_header() {


	//* Return early if we have no ad.
	if ( ! is_active_sidebar( 'before-header' ) ) {
		return;

	}

	echo '<div class="before-header">';
		dynamic_sidebar( 'before-header' );
	echo '</div>';

}


add_action( 'genesis_before_comments', 'vivien_after_entry' );



//* Load an after entry section before .entry-comments on single entries.



function vivien_after_entry() {

	//* Return early if we have no ad.
	if ( ! is_active_sidebar( 'after-entry' ) ) {
		return;

	}



	echo '<div class="after-entry">';
		dynamic_sidebar( 'after-entry' );
	echo '</div>';

}

//* Register widget areas.

genesis_register_sidebar( array(
	'id'          => 'utility-bar-left',
	'name'        => __( 'Utility Bar Left', 'vivien' ),
	'description' => __( 'This is the left utility bar above the header.', 'vivien' ),

) );

genesis_register_sidebar( array(
	'id'          => 'utility-bar-right',
	'name'        => __( 'Utility Bar Right', 'vivien' ),
	'description' => __( 'This is the right utility bar above the header.', 'vivien' ),

) );


genesis_register_sidebar( array(

	'id'          => 'column-header-left',
	'name'        => __( 'Widget Header Left', 'vivien' ),
	'description' => __( 'This is the section on the header to the left.', 'vivien' ),

) );

genesis_register_sidebar( array(
	'id'          => 'column-header-right',
	'name'        => __( 'Widget Header Right', 'vivien' ),
	'description' => __( 'This is the section on the header to the right.', 'vivien' ),

) );

genesis_register_sidebar( array(
	'id'            => 'home-carousel',
	'name'          => __( 'Front Page Carousel', 'vivien' ),
	'description'   => __( 'This is the home carousel widget area', 'vivien' ),

) );

genesis_register_sidebar( array(
	'id'          => 'carousel-cta',
	'name'        => __( 'Carousel Call to Action', 'vivien' ),
	'description' => __( 'Place your Call to Action over the slider', 'vivien' ),
) );

genesis_register_sidebar( array(
	'id'          => 'front-page-image-1',
	'name'        => __( 'Front Page Image 1', 'vivien' ),
	'description' => __( 'This is the front page 1 section with background image.', 'vivien' ),

) );

genesis_register_sidebar( array(
	'id'          => 'front-page-2',
	'name'        => __( 'Front Page 2', 'vivien' ),
	'description' => __( 'This is the front page 2 section.', 'vivien' ),

) );

genesis_register_sidebar( array(
	'id'          => 'front-page-image-3',
	'name'        => __( 'Front Page Image 3', 'vivien' ),
	'description' => __( 'This is the front page 3 section with background image.', 'vivien' ),

) );

genesis_register_sidebar( array(
	'id'          => 'front-page-4',
	'name'        => __( 'Front Page 4', 'vivien' ),
	'description' => __( 'This is the front page 4 section.', 'vivien' ),

) );

genesis_register_sidebar( array(
	'id'          => 'front-page-image-5',
	'name'        => __( 'Front Page Image 5', 'vivien' ),
	'description' => __( 'This is the front page 5 section with background image.', 'vivien' ),

) );

genesis_register_sidebar( array(
	'id'          => 'front-page-6',
	'name'        => __( 'Front Page 6', 'vivien' ),
	'description' => __( 'This is the front page 6 section.', 'vivien' ),

) );

genesis_register_sidebar( array(
	'id'          => 'front-page-image-7',
	'name'        => __( 'Front Page Image 7', 'vivien' ),
	'description' => __( 'This is the front page 7 section with background image.', 'vivien' ),

) );

genesis_register_sidebar( array(
	'id'          => 'front-page-8',
	'name'        => __( 'Front Page 8', 'vivien' ),
	'description' => __( 'This is the front page 8 section.', 'vivien' ),

) );

genesis_register_sidebar( array(
	'id'			=> 'categories-top',
	'name'			=> __( 'Categories Top', 'vivien' ),
	'description'	=> __( 'This is the categories top section.', 'vivien' ),

) );

genesis_register_sidebar( array(
	'id'			=> 'categories-bottom',
	'name'			=> __( 'Categories Bottom', 'vivien' ),
	'description'	=> __( 'This is the categories bottom section.', 'vivien' ),

) );

genesis_register_sidebar( array(
    'id'            => 'woo_primary_sidebar',
    'name'          => __( 'Shop Sidebar', 'vivien' ),
    'description' => __( 'This is the WooCommerce webshop sidebar', 'vivien' ),

) );

genesis_register_sidebar( array(
	'id'			=> 'after-entry',
	'name'			=> __( 'Widget Post Bottom', 'vivien' ),
	'description'	=> __( 'This is the after entry section.', 'vivien' ),

) );

genesis_register_sidebar( array(
	'id'          => 'above-footers',
	'name'        => __( 'Widget Above Footers', 'vivien' ),
	'description' => __( 'This is the full width Social Bar above the footer.', 'vivien' ),
) );

genesis_register_sidebar( array(
	'id'          	=> 'above-blog-slider',
	'name'        	=> __( 'Widget Above Blog', 'vivien' ),
	'description' 	=> __( 'This is the above blog slider section of the home or blog page.', 'vivien' ),
) );

genesis_register_sidebar( array(
	'id'            => 'widget-above-content',
	'name'          => __( 'Widget Above Content', 'vivien' ),
	'description'   => __( 'This widget area appears on top of pages and posts', 'vivien' ),
) );









