<?php
function skyandstars_customizer_head_styles() {
?>
<style type="text/css">

<?php

	// HEADER LOGO HEIGHT
	$header_logo_height = get_theme_mod( 'header_logo_height' ); 
	if ( $header_logo_height != '150' ) :
	?>
		
			.header-image .site-title > a {
				min-height: <?php echo $header_logo_height; ?>px;
			}
		
	<?php
	endif;

	
	?>
</style>
<?php
}
add_action( 'wp_head', 'skyandstars_customizer_head_styles' );
?>