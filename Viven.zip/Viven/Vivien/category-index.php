<?php
/**
 * Template Name: Category Index
 * @package     Vivien Theme
 * @subpackage  Genesis
 */

add_action( 'genesis_meta', 'vivien_category_genesis_meta' );
/**
 * Add widget support for categories page.
 */
function vivien_category_genesis_meta() {
	if ( is_active_sidebar( 'categories-top' ) || is_active_sidebar( 'categories-bottom' ) ) {
		// Remove the default Genesis loop.
		remove_action( 'genesis_loop', 'genesis_do_loop' );
		// Add a custom loop for the home page.
		add_action( 'genesis_loop', 'vivien_category_loop_helper' );
	}
}

/**
 * Display the category page widgeted sections.
 *
 * @since 1.0.0
 */
function vivien_category_loop_helper() {
	genesis_widget_area( 'categories-top',  array(
		'before' => '<div class="widget-area categories-top">',
		'after'  => '</div> <!-- end .categories-top -->',
	) );

	genesis_widget_area( 'categories-bottom', array(
		'before' => '<div class="widget-area categories-bottom">',
		'after'  => '</div> <!-- end .categories-bottom -->',
	) );
}

genesis();
