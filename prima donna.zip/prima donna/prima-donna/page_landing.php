<?php
/**
 * This file adds the Landing Page Template to the Prima Donna Theme.
 * @package      Prima Donna
 */
 
//* This theme contains intellectual property owned by Restored 316 LLC, including trademarks, copyrights, proprietary information, and other intellectual property. You may not modify, publish, transmit, participate in the transfer or sale of, create derivative works from, distribute, reproduce or perform, or in any way exploit in any format whatsoever any of this theme or intellectual property, in whole or in part, without our prior written consent.
 
/*
Template Name: Landing
*/

//* Add custom body class to the head
add_filter( 'body_class', 'primadonna_add_body_class' );
function primadonna_add_body_class( $classes ) {

   $classes[] = 'primadonna-landing';
   return $classes;
   
}

//* Force full width content layout
add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );

//* Remove site header elements
remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_header', 'genesis_do_header' );
remove_action( 'genesis_header', 'genesis_header_markup_close', 15 );

//* Remove navigation
remove_action( 'genesis_before_header', 'genesis_do_nav', 7 );
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
remove_action( 'genesis_before_footer', 'primadonna_footer_menu', 7 );

//* Remove site footer widgets
remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );

//* Remove widget above content
remove_action( 'genesis_after_header', 'primadonna_widget_above_content' );

//* Remove widget above footer
remove_action( 'genesis_before_footer', 'primadonna_widget_above_footer', 10 ); 

//* Remove site footer elements
remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );

//* Run the Genesis loop
genesis();
