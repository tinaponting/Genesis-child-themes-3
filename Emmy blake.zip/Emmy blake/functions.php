<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Setup Theme
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );

//* Set Localization (do not remove)
load_child_theme_textdomain( 'emmy', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/languages', 'emmy' ) );


//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', __( 'Emmy Blake Theme', 'emmy' ) );
define( 'CHILD_THEME_VERSION', '1.0' );

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Enqueue Scripts
add_action( 'wp_enqueue_scripts', 'emmy_load_scripts' );
function emmy_load_scripts() {
	
	wp_enqueue_script( 'emmy-responsive-menu', get_bloginfo( 'stylesheet_directory' ) . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0' );
	
	wp_enqueue_style( 'dashicons' );
	
	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Raleway:700|Mr+De+Haviland', array(), CHILD_THEME_VERSION );
	
}

//* Add new image sizes
add_image_size( 'home-large', 634, 360, TRUE );
add_image_size( 'home-small', 266, 160, TRUE );

//* woocommerce
add_theme_support( 'genesis-connect-woocommerce' );

//* Add WooCommerce Gallery Options
add_action( 'after_setup_theme', 'emmy_woo_gallery' );
function emmy_woo_gallery() {
add_theme_support( 'wc-product-gallery-zoom' );
add_theme_support( 'wc-product-gallery-lightbox' );
add_theme_support( 'wc-product-gallery-slider' );
}

//* Remove Widgets
function remove_some_widgets(){

     // Unregsiter some of the TwentyTen sidebars
     unregister_sidebar( 'header-right' );
     unregister_sidebar( 'home-top' );
     unregister_sidebar( 'home-middle' );
     unregister_sidebar( 'home-bottom-left' );
     unregister_sidebar( 'home-bottom-right' );
     unregister_sidebar( 'sidebar-alt' );
}
add_action( 'widgets_init', 'remove_some_widgets', 11 );

//* Unregister Layouts
genesis_unregister_layout( 'content-sidebar-sidebar' ); 
genesis_unregister_layout( 'sidebar-sidebar-content' ); 
genesis_unregister_layout( 'sidebar-content-sidebar' );

//* Remove Nav Extras
add_action( 'genesis_theme_settings_metaboxes', 'child_remove_metaboxes' );
	function child_remove_metaboxes( $_genesis_theme_settings ) {
   	remove_meta_box( 'genesis-theme-settings-nav', $_genesis_theme_settings, 'main' );
}

//* Customize the credits
add_filter( 'genesis_footer_creds_text', 'sp_footer_creds_text' );
function sp_footer_creds_text() {
	echo '<div class="creds"><p>';
	echo ' Theme Design By <a href="https://exempel.se" title="Exempel">Exempel blabla</a> &middot; ';
	echo 'Copyright &copy; ';
	echo date('Y');
	echo '</p></div>';
}


//* Customize the post info function
add_filter( 'genesis_post_info', 'post_info_filter' );
function post_info_filter($post_info) {
	$post_info = '[post_date] [post_edit]';
	return $post_info;
}

//* Remove the post info function
remove_action( 'genesis_before_post_content', 'genesis_post_info' );


//* Customize the post meta function
add_filter( 'genesis_post_meta', 'post_meta_filter' );
function post_meta_filter($post_meta) {
	$post_meta = '[post_comments] [post_edit] <br /> [post_categories before="Filed Under: "][post_tags before="Tagged: "]';
	return $post_meta;
}

//* Add support for custom background
add_theme_support( 'custom-background', array(
	'default-color' => 'ffffff',
) );

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'header_image'    => '',
	'header-selector' => '.site-title a',
	'header-text'     => false,
) );

//* Add support for additional color style options
add_theme_support( 'genesis-style-selector', array(
	'emmy-pro-blue'    => __( 'Emmy Pro Blue', 'emmy' ),
	'emmy-pro-green'   => __( 'Emmy Pro Green', 'emmy' ),
	'emmy-pro-gold' => __( 'Emmy Pro Gold', 'emmy' ),
	'emmy-pro-purple'  => __( 'Emmy Pro Purple', 'emmy' ),
	'emmy-pro-black'     => __( 'Emmy Pro Black', 'emmy' ),
) );

//* Unregister secondary navigation menu
add_theme_support( 'genesis-menus', array( 'primary' => __( 'Primary Navigation Menu', 'genesis' ) ) );

//* Modify the size of the Gravatar in the author box
add_filter( 'genesis_author_box_gravatar_size', 'emmy_author_box_gravatar' );
function emmy_author_box_gravatar( $size ) {

	return 96;
		
}

//* Modify the size of the Gravatar in the entry comments
add_filter( 'genesis_comment_list_args', 'emmy_comments_gravatar' );
function emmy_comments_gravatar( $args ) {

	$args['avatar_size'] = 60;
	return $args;
	
}

//* Remove comment form allowed tags
add_filter( 'comment_form_defaults', 'emmy_remove_comment_form_allowed_tags' );
function emmy_remove_comment_form_allowed_tags( $defaults ) {
	
	$defaults['comment_notes_after'] = '';
	return $defaults;

}

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );


//* Register widget areas
genesis_register_sidebar( array(
	'id'          => 'home-top',
	'name'        => __( 'Home - Top', 'emmy' ),
	'description' => __( 'This is the top section of the homepage.', 'emmy' ),
) );
genesis_register_sidebar( array(
	'id'          => 'home-middle',
	'name'        => __( 'Home - Middle', 'emmy' ),
	'description' => __( 'This is the middle section of the homepage.', 'emmy' ),
) );
genesis_register_sidebar( array(
	'id'          => 'home-bottom-left',
	'name'        => __( 'Home - Bottom Left', 'emmy' ),
	'description' => __( 'This is the bottom left section of the homepage.', 'emmy' ),
) );
genesis_register_sidebar( array(
	'id'          => 'home-bottom-right',
	'name'        => __( 'Home - Bottom Right', 'emmy' ),
	'description' => __( 'This is the bottom right section of the homepage.', 'emmy' ),
) );