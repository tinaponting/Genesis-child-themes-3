<?php
add_action( 'customize_register', 'primadonna_customize_register' );
function primadonna_customize_register($wp_customize) {

	class Customize_Number_Control extends WP_Customize_Control {
		public $type = 'number';
	 
		public function render_content() {
			?>
			<label>
			<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			<input type="number" name="quantity" <?php $this->link(); ?> value="<?php echo esc_textarea( $this->value() ); ?>" style="width:70px;">
			</label>
			<?php
		}
	}
	
	class Customize_CustomCss_Control extends WP_Customize_Control {
		public $type = 'custom_css';
	 
		public function render_content() {
			?>
			<label>
			<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			<textarea style="width:100%; height:150px;" <?php $this->link(); ?>><?php echo $this->value(); ?></textarea>
			</label>
			<?php
		}
	}

    class Google_Font_Dropdown_Custom_Control extends WP_Customize_Control{
    private $fonts = false;
    public function __construct($manager, $id, $args = array(), $options = array()){
        $this->fonts = $this->get_google_fonts();
        parent::__construct( $manager, $id, $args );
    }
 
    public function render_content(){
        ?>
            <label class="customize_dropdown_input">
                <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
                <select id="<?php echo esc_attr($this->id); ?>" name="<?php echo esc_attr($this->id); ?>" data-customize-setting-link="<?php echo esc_attr($this->id); ?>">
                    <?php
                        foreach ( $this->fonts as $k => $v ){
                            echo '<option value="'.$v['family'].'" ' . selected( $this->value(), $v['family'], false ) . '>'.$v['family'].'</option>';
                        }
                    ?>
                </select>
            </label>
        <?php
    }
 
    public function get_google_fonts(){
        if (get_transient('primadonna_google_font_list')) {
            $content = get_transient('primadonna_google_font_list');
        } else {
            $googleApi = 'https://www.googleapis.com/webfonts/v1/webfonts?sort=alpha&key=AIzaSyAs8eOR8DRBG9t5yuDZSbtTd8LXJkoP36E';
            $fontContent = wp_remote_get( $googleApi, array('sslverify'   => false) );
            $content = json_decode($fontContent['body'], true);
            set_transient( 'primadonna_google_font_list', $content, 0 );
        }
 
        return $content['items'];
    }
 
}

		//Divider
    class Primadonna_Divider extends WP_Customize_Control {
         public function render_content() {
            echo '<hr style="margin: 15px 0;border-top: 1px dashed #919191;" />';
         }
    }
    //Titles
    class Primadonna_Info extends WP_Customize_Control {
        public $type = 'info';
        public $label = '';
        public function render_content() {
        ?>
            <h3 style="margin-top:25px;margin-bottom: 0;color:#ffffff;padding:12px;background-color:#58719E;text-transform:uppercase;"><?php echo esc_html( $this->label ); ?></h3>
        <?php
        }
    }    
    //Titles
    class Primadonna_Theme_Info extends WP_Customize_Control {
        public $type = 'info';
        public $label = '';
        public function render_content() {
        ?>
            <h3><?php echo esc_html( $this->label ); ?></h3>
        <?php
        }
    }

}

if (class_exists('WP_Customize_Control')) {
    class WP_Customize_Category_Control extends WP_Customize_Control {
        /**
         * Render the control's content.
         *
         * @since 3.4.0
         */
        public function render_content() {
            $dropdown = wp_dropdown_categories(
                array(
                    'name'              => '_customize-dropdown-categories-' . $this->id,
                    'echo'              => 0,
                    'show_option_none'  => __( '&mdash; Select &mdash;', 'primadonna' ),
                    'option_none_value' => '0',
                    'selected'          => $this->value(),
                )
            );
 
            // Hackily add in the data link parameter.
            $dropdown = str_replace( '<select', '<select ' . $this->get_link(), $dropdown );
 
            printf(
                '<label class="customize-control-select"><span class="customize-control-title">%s</span> %s</label>',
                $this->label,
                $dropdown
            );
        }
    }
}




?>