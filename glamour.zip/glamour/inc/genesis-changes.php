<?php
/**
 * BloomBlogShop
 * @package      BloomBlogShop
 */

/**
 * Theme Supports
 */

add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery' ) );
add_theme_support( 'genesis-responsive-viewport' );
add_theme_support( 'genesis-structural-wraps', array( 'header', 'nav', 'subnav', 'inner', 'footer' ) );

/**
 * Header
 *
 */

remove_action( 'genesis_site_description', 'genesis_seo_site_description' );


/**
 * Menus
 *
 */

remove_theme_support ( 'genesis-menus' );
// add_theme_support( 'genesis-menus', [
// 	'primary' 	=> __( 'Primary Navigation Menu', 'genesis' ),
// 	'secondary' => __( 'Secondary Navigation Menu', 'genesis' ),
// 	'tertiary' => __( 'Tertiary Navigation Menu', 'genesis' )
// ]);

// Reposition the primary navigation menu
// remove_action( 'genesis_after_header', 'genesis_do_nav' );
// add_action( 'genesis_before_header', 'genesis_do_nav' );


/**
 * Filter menu items, appending either a search form or today's date.
 *
 * @param string   $menu HTML string of list items.
 * @param stdClass $args Menu arguments.
 *
 * @return string Amended HTML string of list items.
 */
function jt_menu_extras( $menu, $args ) {

	//* Change 'primary' to 'secondary' to add extras to the secondary navigation menu
	if ( 'header' !== $args->theme_location )
		return $menu;

	// Add a search form to the navigation menu
	ob_start(); ?>

	<!-- Add Here -->

	<?php
	$output = ob_get_clean();
	$menu  .= $output;

	return $menu;
}
// add_filter( 'wp_nav_menu_items', 'jt_menu_extras', 10, 2 );

/**
 * Page Layouts
 *
 */
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
// genesis_unregister_layout( 'sidebar-content' );

/**
 * Posts
 *
 */

// add_action( 'genesis_entry_footer', 'genesis_prev_next_post_nav' );
add_filter( 'genesis_edit_post_link', '__return_false' );

function jt_post_info_filter($post_info) {
	if ( !is_page() ) {
		$post_info = '[post_date]';
		return $post_info;
	}
}
add_filter( 'genesis_post_info', 'jt_post_info_filter' );

function jt_post_meta_filter($post_meta) {
	$post_meta = '[post_categories before=""] [post_tags]';
	return $post_meta;
}
add_filter( 'genesis_post_meta', 'jt_post_meta_filter' );


/**
 * Sidebars
 *
 */

// unregister_sidebar( 'sidebar' );
unregister_sidebar( 'sidebar-alt' );
// genesis_register_widget_area( array( 'id' => 'blog-sidebar', 'name' => 'Blog Sidebar' ) );

// Remove header-right widget area if genesis-header-nav plugin is active
if( class_exists( '\\Gamajo\\GenesisHeaderNav\\Plugin' ) )
	unregister_sidebar( 'header-right' );


/**
 * Widgets
 *
 */
add_theme_support( 'genesis-footer-widgets', 1 );

/**
 * Excerpt More
 *
 */
function jt_excerpt_more( $more ) {
	$more = '&hellip;';
    return $more;
}
add_filter( 'excerpt_more', 'jt_excerpt_more' );