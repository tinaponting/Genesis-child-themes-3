<?php
/**
 * This file adds the required CSS for the Customizer to the Prima Donna Theme.
 * @package      Prima Donna
 */
 
//////////////////////////////////////////////////////////////////
// Customizer - Add CSS
//////////////////////////////////////////////////////////////////
function primadonna_customizer_css() {

    ?>

    <style type="text/css">

        /* Header BG Color */
    	.site-header {
    		background-color:<?php echo get_theme_mod( 'primadonna_header_background_color' ); ?>;
    	}

    	 /* Boxed Header BG Color */
    	.site-header .wrap {
    		background-color:<?php echo get_theme_mod( 'primadonna_boxed_header_background_color' ); ?>;
    	}

    	/* Body BG Color */
    	body {
    		background-color:<?php echo get_theme_mod( 'primadonna_body_background_color' ); ?>;
    	}

    	/* Content BG Color */
    	.post,
    	.page .content,
    	.product {
    		background-color:<?php echo get_theme_mod( 'primadonna_content_background_color' ); ?>;
    	}

    	/* Content Padding */
    	<?php if(get_theme_mod('primadonna_content_padding_setting') == 'true') : ?>
		.post .entry-header {
			padding: 20px 20px 0;
		}
		.post .entry-content {
			padding: 0 20px;
		}
		.grid .post .entry-header {
			padding: 0;
		}
		.full-grid .post .entry-header {
			padding: 0;
		}
		.list-full .post:first-child .entry-header {
			padding: 0;
		}
		.masonry-posts .post .entry-header,
		.masonry-posts-archive .content .post .entry-header {
			padding: 0;
		}
		.masonry-posts-full .post .entry-header,
		.masonry-posts-full-archive .masonry-wrap .post .entry-header {
			padding: 0;
		}
		.page .content,
		.product {
			padding: 20px;
		}
    	<?php endif; ?>

    	/* Sidebar BG Color */
    	.sidebar-primary .widget-wrap {
    		background-color:<?php echo get_theme_mod( 'primadonna_sidebar_background_color' ); ?>;
    	}

    	/* Sidebar Padding */
    	<?php if(get_theme_mod('primadonna_sidebar_padding_setting') == 'true') : ?>
    	.sidebar-primary .widget-wrap {
			padding: 20px;
		}
		<?php endif; ?>


    	/* Accent Color */
    	.entry-header .entry-title:after,
    	ul.filter a:hover,
    	ul.filter a.active,
    	.portfolio-overlay h3:after,
    	.tagcloud a:hover,
    	a.comment-edit-link:hover,
    	a.comment-reply-link:hover,
    	#cancel-comment-reply-link,
    	.woocommerce span.onsale,
    	.woocommerce a.button:hover,
    	.woocommerce button.button:hover,
    	.woocommerce input.button:hover,
    	.backtotop:hover,
    	.search-div .search-form input[type="submit"] {
    		background-color:<?php echo get_theme_mod( 'primadonna_accent_color' ); ?> !important;
    	}

    	.related-list li a:hover,
    	.adjacent-entry-pagination a:hover,
    	.woocommerce ul.products li.product .price,
    	.woocommerce div.product p.price,    	
    	.woocommerce .woocommerce-message::before,
		.woocommerce .woocommerce-info::before,
		.woocommerce div.product p.price,
		.woocommerce div.product span.price,
		.woocommerce ul.products li.product .price,
		.woocommerce form .form-row .required,
		.widget-postlist-primadonna .postlist-title a:hover,
		.side-text h5 a:hover,
		#owl-demo .item .feat-overlay h3 a:hover,
		#owl-demo .item .feat-overlay .cat a:hover,
		#genesis-responsive-slider h2 a:hover,
		.woocommerce .product-title:hover,
		.null-instagram-feed p a:hover  {
    		color:<?php echo get_theme_mod( 'primadonna_accent_color' ); ?> !important;
    	}

    	.woocommerce a.button,
    	.woocommerce a.button:hover,
    	.woocommerce button.button,
    	.woocommerce button.button:hover,
    	.woocommerce .woocommerce-message,
    	.woocommerce input.button,
    	.woocommerce input.button:hover,
    	.woocommerce .woocommerce-info,
    	.backtotop:hover {
    		border-color:<?php echo get_theme_mod( 'primadonna_accent_color' ); ?> !important; 
    	}

    	/* Link Color */
    	a  { 
    		color:<?php echo get_theme_mod( 'primadonna_link_color' ); ?>;
    	}

    	a:hover  { 
    		color:<?php echo get_theme_mod( 'primadonna_link_hover_color' ); ?>;
    	}


    	/* Category Index widgets bg */
    	.category-index-top {
    		background-color:<?php echo get_theme_mod( 'primadonna_index_widgets_color' ); ?>;
    	}

    	/* Breadcrumbs bg */
    	.breadcrumb {
    		background-color:<?php echo get_theme_mod( 'primadonna_breadcrumbs_color' ); ?>;
    	}

	   	/* Custom Buttons */

	   	/* Small Buttons */
	   	<?php if(get_theme_mod('primadonna_small_button_setting')) : ?> 
	   		.feat-more,
	    	a.more-link,
	    	#genesis-responsive-slider a.more-link,
	    	#genesis-responsive-slider a.more-link:hover,
	    	.more-from-category a,
	    	.wpcf7-form input[type="submit"],
	    	.wpcf7-form input[type="submit"]:hover,
	    	button,
			input[type="button"],
			input[type="reset"],
			input[type="submit"],
			.button,
			button:hover,
			input:hover[type="button"],
			input:hover[type="reset"],
			input:hover[type="submit"],
			.button:hover {
				background-image: url(<?php echo get_theme_mod('primadonna_small_button_setting') ?> ); }
		<?php endif; ?>

		<?php if(!get_theme_mod('primadonna_small_button_setting')) : ?> 
			.feat-more,
	    	a.more-link,
	    	#genesis-responsive-slider a.more-link,
	    	#genesis-responsive-slider a.more-link:hover,
	    	.more-from-category a,
	    	.wpcf7-form input[type="submit"],
	    	.wpcf7-form input[type="submit"]:hover,
	    	button,
			input[type="button"],
			input[type="reset"],
			input[type="submit"],
			.button,
			button:hover,
			input:hover[type="button"],
			input:hover[type="reset"],
			input:hover[type="submit"],
			.button:hover {
				background-image: url(<?php echo get_stylesheet_directory_uri() . '/images/button.png'; ?> ); }
		<?php endif; ?>

		<?php if(get_theme_mod('primadonna_button_bg_setting')) : ?> 
			.feat-more,
	    	a.more-link,
	    	#genesis-responsive-slider a.more-link,
	    	#genesis-responsive-slider a.more-link:hover,
	    	.more-from-category a,
	    	.wpcf7-form input[type="submit"],
	    	.wpcf7-form input[type="submit"]:hover,
	    	button,
			input[type="button"],
			input[type="reset"],
			input[type="submit"],
			.button,
			button:hover,
			input:hover[type="button"],
			input:hover[type="reset"],
			input:hover[type="submit"],
			.button:hover {
				background-image: none !important; }
		<?php endif; ?>

		/* Large Buttons */
		<?php if(get_theme_mod('primadonna_large_button_setting')) : ?> 
	   		.sidebar .widget.nsu_widget input[type="submit"],
	    	.sidebar .widget.nsu_widget input[type="submit"]:hover,
	    	.enews #subbutton,
	    	.enews #subbutton:hover {
				background-image: url(<?php echo get_theme_mod('primadonna_large_button_setting') ?> ); }
		<?php endif; ?>

		<?php if(!get_theme_mod('primadonna_large_button_setting')) : ?> 
		.sidebar .widget.nsu_widget input[type="submit"],
    	.sidebar .widget.nsu_widget input[type="submit"]:hover,
    	.enews #subbutton,
    	.enews #subbutton:hover  {
				background-image: url(<?php echo get_stylesheet_directory_uri() . '/images/custom-button.png'; ?> ); }
		<?php endif; ?>

		<?php if(get_theme_mod('primadonna_button_bg_setting')) : ?> 
		.sidebar .widget.nsu_widget input[type="submit"],
    	.sidebar .widget.nsu_widget input[type="submit"]:hover,
    	.enews #subbutton,
    	.enews #subbutton:hover  {
				background-image: none !important; }
		<?php endif; ?>

		/* Small Button Height */
			.feat-more,
	    	a.more-link,
	    	#genesis-responsive-slider a.more-link,
	    	#genesis-responsive-slider a.more-link:hover,
	    	.more-from-category a,
	    	.wpcf7-form input[type="submit"],
	    	.wpcf7-form input[type="submit"]:hover,
	    	button,
			input[type="button"],
			input[type="reset"],
			input[type="submit"],
			.button,
			button:hover,
			input:hover[type="button"],
			input:hover[type="reset"],
			input:hover[type="submit"],
			.button:hover {
				height:<?php echo get_theme_mod( 'primadonna_small_button_height_setting' ); ?>px;
				line-height:<?php echo get_theme_mod( 'primadonna_small_button_height_setting' ); ?>px;
			}

		/* Small Button Width */
			.feat-more,
	    	a.more-link,
	    	#genesis-responsive-slider a.more-link,
	    	#genesis-responsive-slider a.more-link:hover,
	    	.more-from-category a,
	    	.wpcf7-form input[type="submit"],
	    	.wpcf7-form input[type="submit"]:hover,
	    	button,
			input[type="button"],
			input[type="reset"],
			input[type="submit"],
			.button,
			button:hover,
			input:hover[type="button"],
			input:hover[type="reset"],
			input:hover[type="submit"],
			.button:hover {
				width:<?php echo get_theme_mod( 'primadonna_small_button_width_setting' ); ?>px;
			}

		/* Large Button Height */
			.sidebar .widget.nsu_widget input[type="submit"],
	    	.sidebar .widget.nsu_widget input[type="submit"]:hover,
	    	.enews #subbutton,
	    	.enews #subbutton:hover {
				height:<?php echo get_theme_mod( 'primadonna_large_button_height_setting' ); ?>px;
				line-height:<?php echo get_theme_mod( 'primadonna_large_button_height_setting' ); ?>px;
			}

		/* Large Button Width */
			.sidebar .widget.nsu_widget input[type="submit"],
	    	.sidebar .widget.nsu_widget input[type="submit"]:hover,
	    	.enews #subbutton,
	    	.enews #subbutton:hover {
				width:<?php echo get_theme_mod( 'primadonna_large_button_width_setting' ); ?>px !important;
			}

		@media only screen and (max-width: 1200px) {
			.sidebar .widget.nsu_widget input[type="submit"],
	    	.sidebar .widget.nsu_widget input[type="submit"]:hover,
	    	.sidebar .enews #subbutton,
	    	.sidebar .enews #subbutton:hover {
				width: 220px !important;
				height: 56px !important;
				line-height: 56px;
				background-size: 100%;
			}
		}

		/* Standard Buttons Styles */

		/* Background */
			.feat-more,
	    	a.more-link,
	    	#genesis-responsive-slider a.more-link,
	    	.more-from-category a,
	    	.wpcf7-form input[type="submit"],
	    	button,
			input[type="button"],
			input[type="reset"],
			input[type="submit"],
			.button,
			.sidebar .widget.nsu_widget input[type="submit"],
			.enews #subbutton { 
			background-color:<?php echo get_theme_mod( 'primadonna_button_bg_setting' ); ?>; 
		}

		/* Background Hover */
			.feat-more:hover,
	    	a.more-link:hover,
	    	#genesis-responsive-slider a.more-link:hover,
	    	.more-from-category a:hover,
	    	.wpcf7-form input[type="submit"]:hover,
	    	button:hover,
			input[type="button"]:hover,
			input[type="reset"]:hover,
			input[type="submit"]:hover,
			.button:hover,
			.sidebar .widget.nsu_widget input[type="submit"]:hover,
			.enews #subbutton:hover { 
			background-color:<?php echo get_theme_mod( 'primadonna_button_hover_bg_setting' ); ?>; 
		}

		/* Button Text Color */
		.feat-more,
    	a.more-link,
    	#genesis-responsive-slider a.more-link,
    	.more-from-category a,
    	.wpcf7-form input[type="submit"],
    	button,
		input[type="button"],
		input[type="reset"],
		input[type="submit"],
		.button,
		.sidebar .widget.nsu_widget input[type="submit"],
    	.enews #subbutton {
				color:<?php echo get_theme_mod( 'primadonna_button_color_setting' ); ?>;
		}

		/* Button Hover Text Color */
		.feat-more:hover,
    	a.more-link:hover,
    	#genesis-responsive-slider a.more-link:hover,
    	.more-from-category a:hover,
    	.wpcf7-form input[type="submit"]:hover,
    	button:hover,
		input[type="button"]:hover,
		input[type="reset"]:hover,
		input[type="submit"]:hover,
		.button:hover,
		.sidebar .widget.nsu_widget input[type="submit"]:hover,
    	.enews #subbutton:hover {
				color:<?php echo get_theme_mod( 'primadonna_button_hover_color_setting' ); ?>;
		}

		/* Button fonts */
		<?php if(get_theme_mod( 'buttons_google_font_list' )) : ?>
    	.more-from-category a,
    	.wpcf7-form input[type="submit"],
    	button,
		input[type="button"],
		input[type="reset"],
		input[type="submit"],
		.button,
		.sidebar .widget.nsu_widget input[type="submit"],
    	.enews #subbutton { font-family:"<?php echo get_theme_mod( 'buttons_google_font_list' ); ?>"; }
    	<?php endif; ?>

    	.more-from-category a,
    	.wpcf7-form input[type="submit"],
    	button,
		input[type="button"],
		input[type="reset"],
		input[type="submit"],
		.button,
		.sidebar .widget.nsu_widget input[type="submit"],
    	.enews #subbutton  { font-weight:<?php echo get_theme_mod( 'buttons_google_font_weight' ); ?>; }

    	.more-from-category a,
    	.wpcf7-form input[type="submit"],
    	button,
		input[type="button"],
		input[type="reset"],
		input[type="submit"],
		.button,
		.sidebar .widget.nsu_widget input[type="submit"],
    	.enews #subbutton { letter-spacing:<?php echo get_theme_mod( 'buttons_google_font_spacing' ); ?>px; }

    	.more-from-category a,
    	.wpcf7-form input[type="submit"],
    	button,
		input[type="button"],
		input[type="reset"],
		input[type="submit"],
		.button,
		.sidebar .widget.nsu_widget input[type="submit"],
    	.enews #subbutton { text-transform:<?php echo get_theme_mod( 'buttons_google_font_transform' ); ?>; }


    	/* Logo */
    	.site-title a img {
    		max-height:<?php echo get_theme_mod( 'primadonna_logo_height_setting' ); ?>px;
    	}

    	.title-area { 
			padding-top:<?php echo get_theme_mod( 'primadonna_logo_padding_top_setting' ); ?>px; 
			padding-bottom:<?php echo get_theme_mod( 'primadonna_logo_padding_bottom_setting' ); ?>px; 
		}

		.site-header { 
			padding-top:<?php echo get_theme_mod( 'primadonna_header_padding_top_setting' ); ?>px; 
		}

		/* Front Page Featured Slider */

    	<?php if(get_theme_mod('primadonna_front_featured_overlay_setting') == 'true' ) : ?>
    		.front-page .featured-area .feat-overlay,
    		.front-page .featured-area-full .feat-overlay,
    		.front-page .featured-area-carousel .feat-overlay {
    			display: none;
    		}

    	<?php endif; ?>

    	<?php if(get_theme_mod('primadonna_front_featured_overlay_cats_setting') == 'true' ) : ?>
    		.front-page .featured-area #owl-demo .item .feat-overlay .cat,
    		.front-page .featured-area-full #owl-demo .item .feat-overlay .cat,
    		.front-page .featured-area-carousel #owl-demo .item .feat-overlay .cat {
    			display: none;
    		}

    	<?php endif; ?>

    	/* Blog Featured Slider */

    	<?php if(get_theme_mod('primadonna_featured_overlay_setting') == 'true' ) : ?>
    		.blog .featured-area .feat-overlay,
    		.blog .featured-area-full .feat-overlay,
    		.blog .featured-area-carousel .feat-overlay {
    			display: none;
    		}

    	<?php endif; ?>

    	<?php if(get_theme_mod('primadonna_featured_overlay_cats_setting') == 'true' ) : ?>
    		.blog .featured-area #owl-demo .item .feat-overlay .cat,
    		.blog .featured-area-full #owl-demo .item .feat-overlay .cat,
    		.blog .featured-area-carousel #owl-demo .item .feat-overlay .cat {
    			display: none;
    		}

    	<?php endif; ?>

		/* Promo Box Height */
		.home.blog .promo-item {
    		height:<?php echo get_theme_mod( 'primadonna_promo_height_setting' ); ?>px;
    	}
    	.front-page .promo-item {
    		height:<?php echo get_theme_mod( 'primadonna_front_promo_height_setting' ); ?>px;
    	}


    	/* Posts */
		/* Hide Featured Image */
		<?php if(get_theme_mod('primadonna_hide_fi_setting') == 'true' ) : ?>
			.single img.wp-post-image {
				display: none;
			}

		<?php endif; ?>

		/* Hide Category */
		<?php if(get_theme_mod('primadonna_post_category_setting') == 'true' ) : ?>
			.entry-categories,
			.full-grid .one-half.post.first-post .entry-header .entry-categories {
				display: none;
			}

		<?php endif; ?>

		/* Hide Date */
		<?php if(get_theme_mod('primadonna_post_date_setting') == 'true' ) : ?>
			.entry-meta .entry-time,
			.entry-header .entry-meta .entry-time:after {
				display: none;
			}

		<?php endif; ?>

		/* Hide Tags */
		<?php if(get_theme_mod('primadonna_post_tags_setting') == 'true' ) : ?>
			.entry-tags {
				display: none;
			}

		<?php endif; ?>

		/* Hide Author Link */
		<?php if(get_theme_mod('primadonna_post_author_link_setting') == 'true' ) : ?>
			.post-footer-line-1 {
				display: none;
			}
			.post-footer-line-2 {
				border-left: 1px solid #eee;
			}

		<?php endif; ?>

		/* Hide Comment Link */
		<?php if(get_theme_mod('primadonna_post_comment_setting') == 'true' ) : ?>
			.post-footer-line-2 {
				display: none;
			}

		<?php endif; ?>

		/* Hide Social Sharing */
		<?php if(get_theme_mod('primadonna_post_social_setting') == 'true' ) : ?>
			.post-footer-line-3 {
				display: none;
			}

		<?php endif; ?>

		/* Hide Author Profile */
		<?php if(get_theme_mod('primadonna_post_author_setting') == 'true' ) : ?>
			.author-box {
				display: none;
			}

		<?php endif; ?>

		/* Hide Related Posts */
		<?php if(get_theme_mod('primadonna_post_related_setting') == 'true' ) : ?>
			.related-posts {
				display: none;
			}

		<?php endif; ?>

		/* Masonry Layout Settings */

    	<?php if(get_theme_mod('primadonna_column_setting') == '3col' ) : ?>
    		.masonry-posts .content {
				-moz-column-count: 3;
				-webkit-column-count: 3;
				column-count: 3;
				-moz-column-gap: 30px;
				-webkit-column-gap: 30px;
				column-gap: 30px;
			}
			.masonry-posts .content .entry:nth-child(3) {
				
			}

			.masonry-posts-full .masonry-wrap {
				-moz-column-count: 3;
				-webkit-column-count: 3;
				column-count: 3;
				-moz-column-gap: 30px;
				-webkit-column-gap: 30px;
				column-gap: 30px;
			}

    	<?php endif; ?>

    	<?php if(get_theme_mod('primadonna_archive_column_setting') == '3col' ) : ?>
    		.masonry-posts-archive .content {
				-moz-column-count: 3;
				-webkit-column-count: 3;
				column-count: 3;
				-moz-column-gap: 30px;
				-webkit-column-gap: 30px;
				column-gap: 30px;
			}
			.masonry-posts-archive .content .entry:nth-child(3) {
				margin-bottom: 0;
			}

			.masonry-posts-full-archive .masonry-wrap {
				-moz-column-count: 3;
				-webkit-column-count: 3;
				column-count: 3;
				-moz-column-gap: 30px;
				-webkit-column-gap: 30px;
				column-gap: 30px;
			}

    	<?php endif; ?>

    	/* Fonts & Colors */

    	/* Top Bar */
    	.nav-primary { background-color:<?php echo get_theme_mod( 'topbar_bg_color' ); ?>; }
    	.search a.icon-search:before { font-size:<?php echo get_theme_mod( 'topbar_search_font_size' ); ?>px; }
    	.search a.icon-search { color:<?php echo get_theme_mod( 'topbar_search_color' ); ?>; }
    	.search a.icon-search:hover { color:<?php echo get_theme_mod( 'topbar_search_color_hover' ); ?>; }

    	/* Primary Menu */
    	<?php if(get_theme_mod( 'primarymenu_google_font_list' )) : ?>
    	body .nav-primary .genesis-nav-menu > li > a { font-family:"<?php echo get_theme_mod( 'primarymenu_google_font_list' ); ?>"; }
    	<?php endif; ?>
    	.nav-primary .genesis-nav-menu > li > a  { font-size:<?php echo get_theme_mod( 'primarymenu_google_font_size' ); ?>px; }
    	.nav-primary .genesis-nav-menu > li > a  { font-weight:<?php echo get_theme_mod( 'primarymenu_google_font_weight' ); ?>; }
    	.nav-primary .genesis-nav-menu > li > a { letter-spacing:<?php echo get_theme_mod( 'primarymenu_google_font_spacing' ); ?>px; }
    	.nav-primary .genesis-nav-menu > li > a { text-transform:<?php echo get_theme_mod( 'primarymenu_google_font_transform' ); ?>; }
    	.nav-primary .genesis-nav-menu > li,
    	.nav-primary .genesis-nav-menu > li a,
    	.nav-primary .responsive-menu-icon::before { color:<?php echo get_theme_mod( 'primarymenu_google_font_color' ); ?>; }
    	.nav-primary .genesis-nav-menu > li:hover,
    	.nav-primary .genesis-nav-menu > li a:hover,
    	.nav-primary .responsive-menu-icon:hover:before,
    	.nav-primary .genesis-nav-menu .current-menu-item > a { color:<?php echo get_theme_mod( 'primarymenu_google_font_color_hover' ); ?>; }

    	/* Primary Drop Downs */
    	<?php if(get_theme_mod( 'primarymenu_dd_google_font_list' )) : ?>
    	.nav-primary .genesis-nav-menu .sub-menu a { font-family:"<?php echo get_theme_mod( 'primarymenu_dd_google_font_list' ); ?>"; }
    	<?php endif; ?>
    	.nav-primary .genesis-nav-menu .sub-menu a  { font-size:<?php echo get_theme_mod( 'primarymenu_dd_google_font_size' ); ?>px; }
    	.nav-primary .genesis-nav-menu .sub-menu a  { font-weight:<?php echo get_theme_mod( 'primarymenu_dd_google_font_weight' ); ?>; }
    	.nav-primary .genesis-nav-menu .sub-menu a   { letter-spacing:<?php echo get_theme_mod( 'primarymenu_dd_google_font_spacing' ); ?>px; }
    	.nav-primary .genesis-nav-menu .sub-menu a { text-transform:<?php echo get_theme_mod( 'primarymenu_dd_google_font_transform' ); ?>; }
    	.nav-primary .genesis-nav-menu .sub-menu { background-color:<?php echo get_theme_mod( 'primarymenu_dd_bg_google_font_color' ); ?>; }
    	.nav-primary .genesis-nav-menu .sub-menu a,
    	.nav-primary .genesis-nav-menu.responsive-menu .sub-menu a { color:<?php echo get_theme_mod( 'primarymenu_dd_google_font_color' ); ?>; }
    	.nav-primary .genesis-nav-menu .sub-menu a:hover,
    	.nav-primary .genesis-nav-menu.responsive-menu .sub-menu a:hover { color:<?php echo get_theme_mod( 'primarymenu_dd_google_font_color_hover' ); ?>; }

    	/* Site Title */
    	<?php if(get_theme_mod( 'sitetitle_google_font_list' )) : ?>
    	.site-title a { font-family:"<?php echo get_theme_mod( 'sitetitle_google_font_list' ); ?>"; }
    	<?php endif; ?>
    	.site-title a  { font-size:<?php echo get_theme_mod( 'sitetitle_google_font_size' ); ?>px; }
    	.site-title a  { font-weight:<?php echo get_theme_mod( 'sitetitle_google_font_weight' ); ?>; }
    	.site-title a  { letter-spacing:<?php echo get_theme_mod( 'sitetitle_google_font_spacing' ); ?>px; }
    	.site-title a  { text-transform:<?php echo get_theme_mod( 'sitetitle_google_font_transform' ); ?>; }
    	.title-area { text-align:<?php echo get_theme_mod( 'sitetitle_google_font_align' ); ?>; }
    	.site-title a { color:<?php echo get_theme_mod( 'sitetitle_google_font_color' ); ?>; }
    	.site-title a:hover { color:<?php echo get_theme_mod( 'sitetitle_google_font_color_hover' ); ?>; }

    	/* Site Description */
    	<?php if(get_theme_mod( 'sitedesc_google_font_list' )) : ?>
    	.site-description { font-family:"<?php echo get_theme_mod( 'sitedesc_google_font_list' ); ?>"; }
    	<?php endif; ?>
    	.site-description  { font-size:<?php echo get_theme_mod( 'sitedesc_google_font_size' ); ?>px; }
    	.site-description { font-weight:<?php echo get_theme_mod( 'sitedesc_google_font_weight' ); ?>; }
    	.site-description { letter-spacing:<?php echo get_theme_mod( 'sitedesc_google_font_spacing' ); ?>px; }
    	.site-description  { text-transform:<?php echo get_theme_mod( 'sitedesc_google_font_transform' ); ?>; }
    	.site-description { text-align:<?php echo get_theme_mod( 'sitedesc_google_font_align' ); ?>; }
    	.site-description { color:<?php echo get_theme_mod( 'sitedesc_google_font_color' ); ?>; }

    	/* Header Right Menu */
    	<?php if(get_theme_mod( 'headermenu_google_font_list' )) : ?>
    	.nav-header .genesis-nav-menu > li > a { font-family:"<?php echo get_theme_mod( 'headermenu_google_font_list' ); ?>"; }
    	<?php endif; ?>
    	.nav-header .genesis-nav-menu > li > a { font-size:<?php echo get_theme_mod( 'headermenu_google_font_size' ); ?>px; }
    	.nav-header .genesis-nav-menu > li > a { font-weight:<?php echo get_theme_mod( 'headermenu_google_font_weight' ); ?>; }
    	.nav-header .genesis-nav-menu > li > a { letter-spacing:<?php echo get_theme_mod( 'headermenu_google_font_spacing' ); ?>px; }
    	.nav-header .genesis-nav-menu > li > a { text-transform:<?php echo get_theme_mod( 'headermenu_google_font_transform' ); ?>; }
    	.nav-header .genesis-nav-menu > li,
    	.nav-header .genesis-nav-menu > li a,
    	.nav-header .responsive-menu-icon::before { color:<?php echo get_theme_mod( 'headermenu_google_font_color' ); ?>; }
    	.nav-header .genesis-nav-menu > li:hover,
    	.nav-header .genesis-nav-menu > li a:hover,
    	.nav-header .responsive-menu-icon:hover:before,
    	.nav-header .genesis-nav-menu .current-menu-item > a { color:<?php echo get_theme_mod( 'headermenu_google_font_color_hover' ); ?>; }

    	/* Header Right Drop Downs */
    	<?php if(get_theme_mod( 'headermenu_dd_google_font_list' )) : ?>
    	.nav-header .genesis-nav-menu .sub-menu a { font-family:"<?php echo get_theme_mod( 'headermenu_dd_google_font_list' ); ?>"; }
    	<?php endif; ?>
    	.nav-header .genesis-nav-menu .sub-menu a  { font-size:<?php echo get_theme_mod( 'headermenu_dd_google_font_size' ); ?>px; }
    	.nav-header .genesis-nav-menu .sub-menu a  { font-weight:<?php echo get_theme_mod( 'headermenu_dd_google_font_weight' ); ?>; }
    	.nav-header .genesis-nav-menu .sub-menu a   { letter-spacing:<?php echo get_theme_mod( 'headermenu_dd_google_font_spacing' ); ?>px; }
    	.nav-header .genesis-nav-menu .sub-menu a { text-transform:<?php echo get_theme_mod( 'headermenu_dd_google_font_transform' ); ?>; }
    	.nav-header .genesis-nav-menu .sub-menu { background-color:<?php echo get_theme_mod( 'headermenu_dd_bg_google_font_color' ); ?>; }
    	.nav-header .genesis-nav-menu .sub-menu a,
    	.nav-header .genesis-nav-menu.responsive-menu .sub-menu a  { color:<?php echo get_theme_mod( 'headermenu_dd_google_font_color' ); ?>; }
    	.nav-header .genesis-nav-menu .sub-menu a:hover,
    	.nav-header .genesis-nav-menu.responsive-menu .sub-menu a:hover { color:<?php echo get_theme_mod( 'headermenu_dd_google_font_color_hover' ); ?>; }

    	/* Secondary Menu */
		.menu-secondary { background-color:<?php echo get_theme_mod( 'secmenu_bg_color' ); ?>; }
		.menu-secondary { border-color:<?php echo get_theme_mod( 'secmenu_border_color' ); ?>; }
    	<?php if(get_theme_mod( 'secmenu_google_font_list' )) : ?>
    	.nav-secondary .genesis-nav-menu > li > a { font-family:"<?php echo get_theme_mod( 'secmenu_google_font_list' ); ?>"; }
    	<?php endif; ?>
    	.nav-secondary .genesis-nav-menu > li > a  { font-size:<?php echo get_theme_mod( 'secmenu_google_font_size' ); ?>px; }
    	.nav-secondary .genesis-nav-menu > li > a  { font-weight:<?php echo get_theme_mod( 'secmenu_google_font_weight' ); ?>; }
    	.nav-secondary .genesis-nav-menu > li > a { letter-spacing:<?php echo get_theme_mod( 'secmenu_google_font_spacing' ); ?>px; }
    	.nav-secondary .genesis-nav-menu > li > a { text-transform:<?php echo get_theme_mod( 'secmenu_google_font_transform' ); ?>; }
    	.nav-secondary .genesis-nav-menu > li,
    	.nav-secondary .genesis-nav-menu > li a,
    	.nav-secondary .responsive-menu-icon::before { color:<?php echo get_theme_mod( 'secmenu_google_font_color' ); ?>; }
    	.nav-secondary .genesis-nav-menu > li:hover,
    	.nav-secondary .genesis-nav-menu > li a:hover,
    	.nav-secondary .responsive-menu-icon:hover:before,
    	.nav-secondary .genesis-nav-menu .current-menu-item > a { color:<?php echo get_theme_mod( 'secmenu_google_font_color_hover' ); ?>; }

    	/* Secondary Drop Downs */
    	<?php if(get_theme_mod( 'secmenu_dd_google_font_list' )) : ?>
    	.nav-secondary .genesis-nav-menu .sub-menu a { font-family:"<?php echo get_theme_mod( 'secmenu_dd_google_font_list' ); ?>"; }
    	<?php endif; ?>
    	.nav-secondary .genesis-nav-menu .sub-menu a  { font-size:<?php echo get_theme_mod( 'secmenu_dd_google_font_size' ); ?>px; }
    	.nav-secondary .genesis-nav-menu .sub-menu a  { font-weight:<?php echo get_theme_mod( 'secmenu_dd_google_font_weight' ); ?>; }
    	.nav-secondary .genesis-nav-menu .sub-menu a   { letter-spacing:<?php echo get_theme_mod( 'secmenu_dd_google_font_spacing' ); ?>px; }
    	.nav-secondary .genesis-nav-menu .sub-menu a { text-transform:<?php echo get_theme_mod( 'secmenu_dd_google_font_transform' ); ?>; }
    	.nav-secondary .genesis-nav-menu .sub-menu { background-color:<?php echo get_theme_mod( 'secmenu_dd_bg_google_font_color' ); ?>; }
    	.nav-secondary .genesis-nav-menu .sub-menu a,
    	.nav-secondary .genesis-nav-menu.responsive-menu .sub-menu a { color:<?php echo get_theme_mod( 'secmenu_dd_google_font_color' ); ?>; }
    	.nav-secondary .genesis-nav-menu .sub-menu a:hover,
    	.nav-secondary .genesis-nav-menu.responsive-menu .sub-menu a:hover { color:<?php echo get_theme_mod( 'secmenu_dd_google_font_color_hover' ); ?>; }

    	/* Slider */
    	#genesis-responsive-slider .slide-excerpt,
    	#owl-demo .item .feat-overlay .feat-text { background-color:<?php echo get_theme_mod( 'slider_overlay_bg' ); ?>; }
    	#owl-demo .item .feat-overlay .cat a { color:<?php echo get_theme_mod( 'slider_category_color' ); ?>; }
    	#owl-demo .item .feat-overlay .cat a:hover { color:<?php echo get_theme_mod( 'slider_category_color_hover' ); ?>; }
    	#owl-demo .item .feat-overlay h3 a,
    	#genesis-responsive-slider h2 a { color:<?php echo get_theme_mod( 'slider_post_title_color' ); ?>; }
    	#owl-demo .item .feat-overlay h3 a:hover,
    	#genesis-responsive-slider h2 a:hover { color:<?php echo get_theme_mod( 'slider_post_title_color_hover' ); ?>; }
    	#genesis-responsive-slider p { color:<?php echo get_theme_mod( 'slider_post_excerpt_color' ); ?>; }

    	/* Promo Boxes */
    	.promo-overlay h4 { background-color:<?php echo get_theme_mod( 'promo_overlay_bg' ); ?>; }
    	.promo-overlay h4 { color:<?php echo get_theme_mod( 'promo_overlay_color' ); ?>; }
    	.promo-overlay h4 { font-size:<?php echo get_theme_mod( 'promo_google_font_size' ); ?>px; }

    	/* Headings */
    	<?php if(get_theme_mod( 'headings_google_font_list' )) : ?>
    	h1, 
    	h2, 
    	h3, 
    	h4, 
    	h5, 
    	h6,
    	.related-list li a,
    	.widget-postlist-primadonna .postlist-title a,
    	.side-text h5 a { font-family:"<?php echo get_theme_mod( 'headings_google_font_list' ); ?>"; }
    	<?php endif; ?>

        h1, 
    	h2, 
    	h3, 
    	h4, 
    	h5, 
    	h6,
    	.related-list li a  { font-weight:<?php echo get_theme_mod( 'headings_google_font_weight' ); ?>; }

    	h1, 
    	h2, 
    	h3, 
    	h4, 
    	h5, 
    	h6,
    	.related-list li a { letter-spacing:<?php echo get_theme_mod( 'headings_google_font_spacing' ); ?>px; }

    	h1, 
    	h2, 
    	h3, 
    	h4, 
    	h5, 
    	h6,
    	.related-list li a { text-transform:<?php echo get_theme_mod( 'headings_google_font_transform' ); ?>; }

    	h1, 
    	h2, 
    	h3, 
    	h4, 
    	h5, 
    	h6,
    	h1 a,
    	h2 a,
    	h3 a,
    	h4 a,
    	h5 a,
    	h6 a,
    	.related-list li a { color:<?php echo get_theme_mod( 'headings_google_font_color' ); ?>; }

    	h1 { font-size:<?php echo get_theme_mod( 'h1_headings_google_font_size' ); ?>px; }
    	h2 { font-size:<?php echo get_theme_mod( 'h2_headings_google_font_size' ); ?>px; }
    	h3 { font-size:<?php echo get_theme_mod( 'h3_headings_google_font_size' ); ?>px; }
    	h4 { font-size:<?php echo get_theme_mod( 'h4_headings_google_font_size' ); ?>px; }
    	h5 { font-size:<?php echo get_theme_mod( 'h5_headings_google_font_size' ); ?>px; }
    	h6 { font-size:<?php echo get_theme_mod( 'h6_headings_google_font_size' ); ?>px; }

    	/* General fonts - body font */
		<?php if(get_theme_mod( 'body_google_font_list' )) : ?>
    	body { font-family:"<?php echo get_theme_mod( 'body_google_font_list' ); ?>"; }
    	<?php endif; ?>
    	body,
    	.masonry-posts a.more-link,
		.masonry-posts-archive .content a.more-link,
		.list-full a.more-link,
		.list a.more-link,
		.full-grid a.more-link,
		.masonry-posts-full a.more-link,
		.masonry-posts-full-archive a.more-link,
		.masonry-posts-full-archive .masonry-wrap a.more-link { font-size:<?php echo get_theme_mod( 'body_google_font_size' ); ?>px; }
    	body { font-weight:<?php echo get_theme_mod( 'body_google_font_weight' ); ?>; }
    	body { line-height:<?php echo get_theme_mod( 'body_google_font_lh' ); ?>px; }
    	body,
    	.side-meta a,
    	.null-instagram-feed p a,
    	.backtotop { color:<?php echo get_theme_mod( 'body_google_font_color' ); ?> !important; }

    	.backtotop { border-color:<?php echo get_theme_mod( 'body_google_font_color' ); ?> !important; }

    	/* Post Title */
    	.entry-title,
    	.list-full .post:first-child .entry-header .entry-title,
    	.masonry-posts-full .post:first-child .entry-header .entry-title,
		.masonry-posts-full-archive .post:first-child .entry-header .entry-title { font-size:<?php echo get_theme_mod( 'posttitle_google_font_size' ); ?>px; }
    	.entry-title { font-weight:<?php echo get_theme_mod( 'posttitle_google_font_weight' ); ?>; }
    	.entry-title   { letter-spacing:<?php echo get_theme_mod( 'posttitle_google_font_spacing' ); ?>px; }
    	.entry-title { text-transform:<?php echo get_theme_mod( 'posttitle_google_font_transform' ); ?>; }
    	.entry-title, 
    	.entry-title a { color:<?php echo get_theme_mod( 'posttitle_google_font_color' ); ?>; }
    	.entry-title a:hover { color:<?php echo get_theme_mod( 'posttitle_google_font_color_hover' ); ?>; }

    	/* Post Meta */
    	<?php if(get_theme_mod( 'postmeta_google_font_list' )) : ?>
    	.entry-header .entry-categories,
    	.entry-header .entry-categories a,
    	.entry-meta { font-family:"<?php echo get_theme_mod( 'postmeta_google_font_list' ); ?>"; }
    	<?php endif; ?>
    	.entry-header .entry-categories,
    	.entry-header .entry-categories a,
    	.entry-meta { font-weight:<?php echo get_theme_mod( 'postmeta_google_font_weight' ); ?>; }
    	.entry-header .entry-categories,
    	.entry-header .entry-categories a,
    	.entry-meta   { letter-spacing:<?php echo get_theme_mod( 'postmeta_google_font_spacing' ); ?>px; }
    	.entry-header .entry-categories,
    	.entry-header .entry-categories a,
    	.entry-meta,
    	#owl-demo .item .feat-overlay .cat a,
    	.side-meta a,
    	.widget-postlist-primadonna .postlist-date,
    	.primadonna-postcarousel .entry-header-postcarousel .side-meta a { text-transform:<?php echo get_theme_mod( 'postmeta_google_font_transform' ); ?>; }

    	/* Post Categories */
    	.entry-header .entry-categories,
    	.entry-header .entry-categories a { font-size:<?php echo get_theme_mod( 'postcats_google_font_size' ); ?>px; }
    	.entry-header .entry-categories,
    	.entry-header .entry-categories a,
    	.side-meta a, .page-template-page_blog.grid .post .entry-header .entry-categories a,
		.page-template-page_blog.grid .post .entry-meta { color:<?php echo get_theme_mod( 'postcats_google_font_color' ); ?>; }


    	/* Post Date */
    	.entry-header .entry-meta { font-size:<?php echo get_theme_mod( 'postdate_google_font_size' ); ?>px; }
    	.entry-header .entry-meta,
    	.widget-postlist-primadonna .postlist-date { color:<?php echo get_theme_mod( 'postdate_google_font_color' ); ?>; }

    	/* Post tags */
    	.entry-tags a { font-size:<?php echo get_theme_mod( 'postlabels_google_font_size' ); ?>px; }
    	.entry-tags a { font-weight:<?php echo get_theme_mod( 'postlabels_google_font_weight' ); ?>; }
    	.entry-tags a   { letter-spacing:<?php echo get_theme_mod( 'postlabels_google_font_spacing' ); ?>px; }
    	.entry-tags a { text-transform:<?php echo get_theme_mod( 'postlabels_google_font_transform' ); ?>; }
    	.entry-tags a { color:<?php echo get_theme_mod( 'postlabels_google_font_color' ); ?>; }
    	.entry-tags a:hover { color:<?php echo get_theme_mod( 'postlabels_google_font_color_hover' ); ?>; }
    	.entry-tags a { background-color:<?php echo get_theme_mod( 'postlabels_bg_google_font_color' ); ?>; }
    	.entry-tags a:hover { background-color:<?php echo get_theme_mod( 'postlabels_bg_google_font_color_hover' ); ?>; }

    	/* Read More */
    	.feat-more,
	    a.more-link,
    	#genesis-responsive-slider a.more-link,
    	.more-from-category a { background-color:<?php echo get_theme_mod( 'readmore_bg_google_font_color' ); ?>; }

    	.feat-more:hover,
	    a.more-link:hover,
    	#genesis-responsive-slider a.more-link:hover,
    	.more-from-category a:hover { background-color:<?php echo get_theme_mod( 'readmore_bg_hover_google_font_color' ); ?>; }

    	.feat-more,
	    .read-more a.more-link,
    	#genesis-responsive-slider a.more-link,
    	.more-from-category a { color:<?php echo get_theme_mod( 'readmore_google_font_color' ); ?>; }

    	.feat-more:hover,
	    a.more-link:hover,
    	#genesis-responsive-slider a.more-link:hover,
    	.more-from-category a:hover { color:<?php echo get_theme_mod( 'readmore_hover_google_font_color' ); ?> !important; }

    	<?php if(get_theme_mod( 'readmore_google_font_list' )) : ?>
    	.feat-more,
	    a.more-link,
    	#genesis-responsive-slider a.more-link,
    	.more-from-category a  { font-family:"<?php echo get_theme_mod( 'readmore_google_font_list' ); ?>"; }
    	<?php endif; ?>

    	.feat-more,
	    a.more-link,
    	#genesis-responsive-slider a.more-link,
    	.more-from-category a  { font-size:<?php echo get_theme_mod( 'readmore_google_font_size' ); ?>px; }

    	.feat-more,
	    a.more-link,
    	#genesis-responsive-slider a.more-link,
    	.more-from-category a  { font-weight:<?php echo get_theme_mod( 'readmore_google_font_weight' ); ?>; }

    	.feat-more,
	    a.more-link,
    	#genesis-responsive-slider a.more-link,
    	.more-from-category a  { letter-spacing:<?php echo get_theme_mod( 'readmore_google_font_spacing' ); ?>px; }

    	.feat-more,
	    a.more-link,
    	#genesis-responsive-slider a.more-link,
    	.more-from-category a  { text-transform:<?php echo get_theme_mod( 'readmore_google_font_transform' ); ?>; }


    	/* Footer Meta */
    	.post-footer-line-1,
    	.post-footer-line-2,
    	.post-footer-line-3 { border-color:<?php echo get_theme_mod( 'post_footer_border_color' ); ?>; }

    	.grid .post-footer-line-3:after,
    	.full-grid .post-footer-line-3:after,
    	.list .post-footer-line-3:after,
    	.list-full .post-footer-line-3:after,
    	.masonry-posts .post-footer-line-3:after,
		.masonry-posts-archive .content .post-footer-line-3:after,
		.masonry-posts-full .post-footer-line-3:after,
		.masonry-posts-full-archive .masonry-wrap .post-footer-line-3:after { background-color:<?php echo get_theme_mod( 'post_footer_border_color' ); ?>; }

    	<?php if(get_theme_mod( 'footermeta_google_font_list' )) : ?>
    	.post-footer-line-1,
    	.post-footer-line-2 { font-family:"<?php echo get_theme_mod( 'footermeta_google_font_list' ); ?>"; }
    	<?php endif; ?>

    	.post-footer-line-1,
    	.post-footer-line-2,
    	.entry-author-name,
    	.entry-comments-link a { font-size:<?php echo get_theme_mod( 'postfooter_google_font_size' ); ?>px; }
    	.post-footer-line-1,
    	.post-footer-line-2,
    	.entry-author-name,
    	.entry-comments-link a  { font-weight:<?php echo get_theme_mod( 'postfooter_google_font_weight' ); ?>; }
    	.entry-author-name,
    	.entry-comments-link a,
    	.post-footer-line-1,
    	.post-footer-line-2 { text-transform:<?php echo get_theme_mod( 'postfooter_google_font_transform' ); ?>; }
    	.post-footer-line-1,
    	.post-footer-line-2,
    	.entry-author-name,
    	.entry-comments-link a { color:<?php echo get_theme_mod( 'postfooter_google_font_color' ); ?>; }

    	/* Post Shares */
    	.fa-post-footer,
    	.social-links i  { color:<?php echo get_theme_mod( 'postshares_google_font_color' ); ?>; }
    	.fa-post-footer:hover,
    	.social-links i:hover  { color:<?php echo get_theme_mod( 'postshares_google_font_color_hover' ); ?>; }
    	.fa-post-footer,
    	.social-links i  { font-size:<?php echo get_theme_mod( 'postshares_google_font_size' ); ?>px !important; }

    	/* Post Separator */
    	.author-box,
    	.related-posts,
    	.adjacent-entry-pagination { border-color:<?php echo get_theme_mod( 'post_separator_color' ); ?>; }

    	/* Posts: Comments */
    	.comment-author a { color:<?php echo get_theme_mod( 'comments_author_color' ); ?>; }
    	.reply { color:<?php echo get_theme_mod( 'comments_border_color' ); ?>; }
    	a.comment-edit-link,
    	a.comment-reply-link { background-color:<?php echo get_theme_mod( 'comments_reply_bg_color' ); ?>; }
    	.comment-respond { border-color:<?php echo get_theme_mod( 'comments_border_color' ); ?>; }

    	/* Sidebar */

    	/* Widget Titles */
    	.sidebar-primary .widget-title { color:<?php echo get_theme_mod( 'sidebar_title_color' ); ?>; }
    	.sidebar-primary .widget-title { border-bottom-color:<?php echo get_theme_mod( 'sidebar_border_color' ); ?>; }
    	.sidebar-primary .widget-title { background-color:<?php echo get_theme_mod( 'sidebar_bg_color' ); ?>; }
    	.sidebar-primary .widget-title:after { border-top-color:<?php echo get_theme_mod( 'sidebar_arrow_color' ); ?>; }

    	<?php if(get_theme_mod( 'sidebar_google_font_list' )) : ?>
    	.sidebar-primary .widget-title { font-family:"<?php echo get_theme_mod( 'sidebar_google_font_list' ); ?>"; }
    	<?php endif; ?>

    	.sidebar-primary .widget-title { font-size:<?php echo get_theme_mod( 'sidebar_google_font_size' ); ?>px; }
    	.sidebar-primary .widget-title { font-weight:<?php echo get_theme_mod( 'sidebar_google_font_weight' ); ?>; }
    	.sidebar-primary .widget-title { letter-spacing:<?php echo get_theme_mod( 'sidebar_google_font_spacing' ); ?>px; }
    	.sidebar-primary .widget-title { text-transform:<?php echo get_theme_mod( 'sidebar_google_font_transform' ); ?>; }

    	/* Newsletter Widget */
    	.sidebar .widget.nsu_widget .widget-title,
    	.sidebar .enews-widget .widget-title { color:<?php echo get_theme_mod( 'newsletter_title_color' ); ?>; }
    	.sidebar .widget.nsu_widget,
    	.sidebar .enews-widget,
    	.sidebar .enews-widget .widget-wrap { background-color:<?php echo get_theme_mod( 'newsletter_bg_color' ); ?>; }
    	.sidebar .enews p,
    	.sidebar .widget.nsu_widget .nsu-text-before-form,
    	.sidebar .widget.nsu_widget .nsu-text-after-form { color:<?php echo get_theme_mod( 'newsletter_text_color' ); ?>; }

    	.sidebar .enews #subbutton { background-color:<?php echo get_theme_mod( 'newsletter_buttonbg_color' ); ?>; }
    	.sidebar .enews #subbutton:hover { background-color:<?php echo get_theme_mod( 'newsletter_buttonbg_hover_color' ); ?>; }
    	.sidebar .enews #subbutton { color:<?php echo get_theme_mod( 'newsletter_button_text_color' ); ?>; }
    	.sidebar .enews #subbutton:hover { color:<?php echo get_theme_mod( 'newsletter_button_text_hover_color' ); ?>; }

    	/* Tag Cloud Widget */
    	.tagcloud a { color:<?php echo get_theme_mod( 'tagcloud_text_color' ); ?>; }
    	.tagcloud a { background-color:<?php echo get_theme_mod( 'tagcloud_bg_color' ); ?>; }

    	/* Footer Menu */
    	.nav-footer { background-color:<?php echo get_theme_mod( 'footer_menu_bg_color' ); ?>; }

    	<?php if(get_theme_mod( 'footer_menu_google_font_list' )) : ?>
    	.nav-footer .genesis-nav-menu > li > a { font-family:"<?php echo get_theme_mod( 'footer_menu_google_font_list' ); ?>"; }
    	<?php endif; ?>

    	.nav-footer .genesis-nav-menu > li > a  { font-size:<?php echo get_theme_mod( 'footer_menu_google_font_size' ); ?>px; }
    	.nav-footer .genesis-nav-menu > li > a  { font-weight:<?php echo get_theme_mod( 'footer_menu_google_font_weight' ); ?>; }
    	.nav-footer .genesis-nav-menu > li > a { letter-spacing:<?php echo get_theme_mod( 'footer_menu_google_font_spacing' ); ?>px; }
    	.nav-footer .genesis-nav-menu > li > a { text-transform:<?php echo get_theme_mod( 'footer_menu_google_font_transform' ); ?>; }
    	.nav-footer .genesis-nav-menu > li a { color:<?php echo get_theme_mod( 'footer_menu_google_font_color' ); ?>; }
    	.nav-footer .genesis-nav-menu > li a:hover { color:<?php echo get_theme_mod( 'footer_menu_google_font_color_hover' ); ?>; }

    	/* Footer */
    	.footer-widgets { background-color:<?php echo get_theme_mod( 'footer_bg_color' ); ?>; }
    	.footer-widgets { color:<?php echo get_theme_mod( 'footer_text_color' ); ?>; }

    	<?php if(get_theme_mod( 'footer_google_font_list' )) : ?>
    	.footer-widgets .widget-title,
    	.front-page .footer-widgets h4.widget-title { font-family:"<?php echo get_theme_mod( 'footer_google_font_list' ); ?>"; }
    	<?php endif; ?>

    	.footer-widgets .widget-title,
    	.front-page .footer-widgets h4.widget-title  { font-size:<?php echo get_theme_mod( 'footer_google_font_size' ); ?>px; }
    	.footer-widgets .widget-title { font-weight:<?php echo get_theme_mod( 'footer_google_font_weight' ); ?>; }
    	.footer-widgets .widget-title { letter-spacing:<?php echo get_theme_mod( 'footer_google_font_spacing' ); ?>px; }
    	.footer-widgets .widget-title,
    	.front-page .footer-widgets h4.widget-title  { text-transform:<?php echo get_theme_mod( 'footer_google_font_transform' ); ?>; }
    	.footer-widgets .widget-title,
    	.front-page .footer-widgets h4.widget-title  { color:<?php echo get_theme_mod( 'footer_widget_title_color' ); ?>; }

    	.footer-widgets .enews #subbutton,
    	.front-page .footer-widgets .enews #subbutton { background-color:<?php echo get_theme_mod( 'footer_newsletter_buttonbg_color' ); ?>; }
    	.footer-widgets .enews #subbutton:hover,
    	.front-page .footer-widgets .enews #subbutton:hover { background-color:<?php echo get_theme_mod( 'footer_newsletter_buttonbg_hover_color' ); ?>; }
    	.footer-widgets .enews #subbutton,
    	.front-page .footer-widgets .enews #subbutton { color:<?php echo get_theme_mod( 'footer_newsletter_button_text_color' ); ?>; }
    	.footer-widgets .enews #subbutton:hover,
    	.front-page .footer-widgets .enews #subbutton:hover { color:<?php echo get_theme_mod( 'footer_newsletter_button_text_hover_color' ); ?>; }

    	/* Footer Copyright */
    	.site-footer,
    	.widget-below-footer { background-color:<?php echo get_theme_mod( 'footer_copyright_bg_color' ); ?>; }
    	.site-footer .creds p,
    	.site-footer .creds p a,
    	.widget-below-footer { color:<?php echo get_theme_mod( 'footer_copyright_font_color' ); ?>; }

    	/* Home Page */
		<?php if(get_theme_mod( 'homepage_widget_google_font_list' )) : ?>
    	.front-page h4.widget-title { font-family:"<?php echo get_theme_mod( 'homepage_widget_google_font_list' ); ?>"; }
    	<?php endif; ?>

    	.front-page h4.widget-title  { font-size:<?php echo get_theme_mod( 'homepage_widget_google_font_size' ); ?>px; }
    	.front-page h4.widget-title { font-weight:<?php echo get_theme_mod( 'homepage_widget_google_font_weight' ); ?>; }
    	.front-page h4.widget-title { letter-spacing:<?php echo get_theme_mod( 'homepage_widget_google_font_spacing' ); ?>px; }
    	.front-page h4.widget-title { text-transform:<?php echo get_theme_mod( 'homepage_widget_google_font_transform' ); ?>; }
    	.front-page h4.widget-title  { color:<?php echo get_theme_mod( 'homepage_widget_title_color' ); ?>; } 

    	.front-page #genesis-responsive-slider h2 a,
    	.front-page #owl-demo .item .feat-overlay h3 a  { font-size:<?php echo get_theme_mod( 'hp_slider_google_font_size' ); ?>px; }

    	.front-page #owl-demo .item .feat-overlay .cat a  { font-size:<?php echo get_theme_mod( 'hp_slidercats_google_font_size' ); ?>px; }

    	.front-page #genesis-responsive-slider .slide-excerpt p { font-size:<?php echo get_theme_mod( 'hp_sliderex_google_font_size' ); ?>px; }

    	.flexible-widgets .enews-widget,
    	.home-alt-wrap .front-page-2 .enews-widget { background-color:<?php echo get_theme_mod( 'homepage_newsletter_bg_color' ); ?>; }
    	.flexible-widgets .enews-widget,
    	.home-alt-wrap .front-page-2 .enews-widget { border-color:<?php echo get_theme_mod( 'homepage_newsletter_border_color' ); ?> !important; }
    	.flexible-widgets .enews-widget h4.widget-title,
    	.home-alt-wrap .front-page-2 .enews-widget h4.widget-title { color:<?php echo get_theme_mod( 'homepage_newsletter_title_color' ); ?>; }
    	.flexible-widgets .enews-widget p,
    	.home-alt-wrap .front-page-2 .enews-widget p { color:<?php echo get_theme_mod( 'homepage_newsletter_text_color' ); ?>; }

    	.flexible-widgets .enews-widget input[type="submit"],
    	.flexible-widgets .enews #subbutton,
    	.home-alt-wrap .enews-widget input[type="submit"],
    	.home-alt-wrap .enews #subbutton { background-color:<?php echo get_theme_mod( 'homepage_newsletter_buttonbg_color' ); ?>; }
    	.flexible-widgets .enews-widget input[type="submit"]:hover,
    	.flexible-widgets .enews #subbutton:hover,
    	.home-alt-wrap .enews-widget input[type="submit"]:hover,
    	.home-alt-wrap .enews #subbutton:hover { background-color:<?php echo get_theme_mod( 'homepage_newsletter_buttonbg_hover_color' ); ?>; }
    	.flexible-widgets .enews-widget input[type="submit"],
    	.flexible-widgets .enews #subbutton,
    	.home-alt-wrap .enews-widget input[type="submit"],
    	.home-alt-wrap .enews #subbutton { color:<?php echo get_theme_mod( 'homepage_newsletter_button_text_color' ); ?>; }
		.flexible-widgets .enews-widget input[type="submit"]:hover,
    	.flexible-widgets .enews #subbutton:hover,
    	.home-alt-wrap .enews-widget input[type="submit"]:hover,
    	.home-alt-wrap .enews #subbutton:hover { color:<?php echo get_theme_mod( 'homepage_newsletter_button_text_hover_color' ); ?>; }

    	/* Blog Page */
    	.blog #genesis-responsive-slider h2 a,
    	.blog #owl-demo .item .feat-overlay h3 a  { font-size:<?php echo get_theme_mod( 'blog_slider_google_font_size' ); ?>px; }

    	.blog #owl-demo .item .feat-overlay .cat a  { font-size:<?php echo get_theme_mod( 'blog_slidercats_google_font_size' ); ?>px; }

    	.blog #genesis-responsive-slider .slide-excerpt p { font-size:<?php echo get_theme_mod( 'blog_sliderex_google_font_size' ); ?>px; }

    	.blog-page-2 .enews-widget,
    	.blog-page-3 .enews-widget,
    	.blog-page-right .enews-widget { background-color:<?php echo get_theme_mod( 'blog_newsletter_bg_color' ); ?>; }
    	.blog-page-2 .enews-widget,
    	.blog-page-3 .enews-widget,
    	.blog-page-right .enews-widget { border-color:<?php echo get_theme_mod( 'blog_newsletter_border_color' ); ?> !important; }
    	.blog-page-2 .enews-widget h4.widget-title,
    	.blog-page-3 .enews-widget h4.widget-title,
    	.blog-page-right .enews-widget h4.widget-title { color:<?php echo get_theme_mod( 'blog_newsletter_title_color' ); ?>; }
    	.blog-page-2 .enews-widget p,
    	.blog-page-3 .enews-widget p,
    	.blog-page-right .enews-widget p { color:<?php echo get_theme_mod( 'blog_newsletter_text_color' ); ?>; }

    	.blog-page-2 .enews-widget input[type="submit"],
    	.blog-page-2 .enews #subbutton,
    	.blog-page-3 .enews-widget input[type="submit"],
    	.blog-page-3 .enews #subbutton,
    	.blog-page-right .enews-widget input[type="submit"],
    	.blog-page-right .enews #subbutton { background-color:<?php echo get_theme_mod( 'blog_newsletter_buttonbg_color' ); ?>; }
    	.blog-page-2 .enews-widget input[type="submit"]:hover,
    	.blog-page-2 .enews #subbutton:hover,
    	.blog-page-3 .enews-widget input[type="submit"]:hover,
    	.blog-page-3 .enews #subbutton:hover,
    	.blog-page-right .enews-widget input[type="submit"]:hover,
    	.blog-page-right .enews #subbutton:hover { background-color:<?php echo get_theme_mod( 'blog_newsletter_buttonbg_hover_color' ); ?>; }
    	.blog-page-2 .enews-widget input[type="submit"],
    	.blog-page-2 .enews #subbutton,
    	.blog-page-3 .enews-widget input[type="submit"],
    	.blog-page-3 .enews #subbutton,
    	.blog-page-right .enews-widget input[type="submit"],
    	.blog-page-right .enews #subbutton { color:<?php echo get_theme_mod( 'blog_newsletter_button_text_color' ); ?>; }
		.blog-page-2 .enews-widget input[type="submit"]:hover,
    	.blog-page-2 .enews #subbutton:hover,
    	.blog-page-3 .enews-widget input[type="submit"]:hover,
    	.blog-page-3 .enews #subbutton:hover,
    	.blog-page-right .enews-widget input[type="submit"]:hover,
    	.blog-page-right .enews #subbutton:hover { color:<?php echo get_theme_mod( 'blog_newsletter_button_text_hover_color' ); ?>; }

    	/* Post Title Font Size - Grid, List & Masonry */

    	/* Grid */
    	.grid .post .entry-header .entry-title,
    	.full-grid .post .entry-header .entry-title  { font-size:<?php echo get_theme_mod( 'blog_grid_google_font_size' ); ?>px; }

    	.list .post .entry-header .entry-title,
    	.list-full .post:not(:first-child) .entry-header .entry-title { font-size:<?php echo get_theme_mod( 'blog_list_google_font_size' ); ?>px; }

    	.masonry-posts .post .entry-header .entry-title,
    	.masonry-posts-archive .content .post .entry-header .entry-title,
    	.masonry-posts-full .masonry-wrap .post .entry-header .entry-title,
		.masonry-posts-full-archive .masonry-wrap .post .entry-header .entry-title { font-size:<?php echo get_theme_mod( 'blog_masonry_google_font_size' ); ?>px; }

		<?php if(get_theme_mod( 'primadonna_custom_css' )) : ?>
		<?php echo get_theme_mod( 'primadonna_custom_css' ); ?>
		<?php endif; ?>


    </style>


    <?php
}
add_action( 'wp_head', 'primadonna_customizer_css' );

?>
