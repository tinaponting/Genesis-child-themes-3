<?php
/**
 * Ellie Jane.
 * @package Ellie Jane
 */

add_filter( 'woocommerce_enqueue_styles', 'ellie_woocommerce_styles' );
/**
 * Enqueue the theme's custom WooCommerce styles to the WooCommerce plugin.
 *
 * @since 3.2.0
 *
 * @return array Required values for the theme's WooCommerce stylesheet.
 */
function ellie_woocommerce_styles( $enqueue_styles ) {

	$enqueue_styles['ellie-woocommerce-styles'] = array(
		'src'     => get_stylesheet_directory_uri() . '/lib/woocommerce/ellie-woocommerce.css',
		'deps'    => '',
		'version' => CHILD_THEME_VERSION,
		'media'   => 'screen',
	);

	return $enqueue_styles;

}

add_action( 'wp_enqueue_scripts', 'ellie_woocommerce_css' );
/**
 * Add the themes's custom CSS to the WooCommerce stylesheet.
 *
 * @since 3.2.0
 *
 * @return string CSS tag with custom CSS for inline styles.
 */
function ellie_woocommerce_css() {

	// If WooCommerce isn't installed, exit early.
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}

	$color_link = get_theme_mod( 'ellie_link_color', ellie_customizer_get_default_link_color() );
	$color_accent = get_theme_mod( 'ellie_accent_color', ellie_customizer_get_default_accent_color() );
	$color_main = get_theme_mod( 'ellie_main_color', ellie_customizer_get_default_main_color() );
	$color_white = get_theme_mod( 'ellie_white_color', ellie_customizer_get_default_white_color() );
	$color_body = get_theme_mod( 'ellie_body_font_color', ellie_customizer_get_default_body_font_color() );
	$color_entry = get_theme_mod( 'ellie_entry_title_color', ellie_customizer_get_default_entry_title_color() );

	$woo_css = '';

	$woo_css .= ( ellie_customizer_get_default_link_color() !== $color_link ) ? sprintf( '

		.woocommerce div.product .woocommerce-tabs ul.tabs li a:hover,
		.woocommerce div.product .woocommerce-tabs ul.tabs li a:focus,
		.woocommerce ul.products li.product h3:hover,
		.woocommerce .woocommerce-breadcrumb a:hover,
		.woocommerce .woocommerce-breadcrumb a:focus,
		.woocommerce .widget_layered_nav ul li.chosen a::before,
		.woocommerce .widget_layered_nav_filters ul li a::before {
			color: 1%s;
		}

	', $color_link ) : '';

	$woo_css .= ( ellie_customizer_get_default_accent_color() !== $color_accent ) ? sprintf( '

		.woocommerce-error,
		.woocommerce-info,
		.woocommerce-message {
			border-top-color: %1$s;
		}

		.woocommerce-error::before,
		.woocommerce-info::before,
		.woocommerce-message::before {
			color: %1$s;
		}

	', $color_accent ) : '';
	
	$woo_css .= ( ellie_customizer_get_default_main_color() !== $color_main ) ? sprintf( '
	
		.woocommerce #respond input#submit,
		.woocommerce #respond input#submit.alt,
		.woocommerce a.button,
		.woocommerce a.button.alt,
		.woocommerce button.button,
		.woocommerce button.button.alt,
		.woocommerce input.button,
		.woocommerce input.button.alt,
		.woocommerce input.button[type="submit"], 
		.woocommerce span.onsale, 
		.woocommerce.widget_price_filter .ui-slider .ui-slider-handle, 
		.woocommerce.widget_price_filter .ui-slider .ui-slider-range {
			background: %1$s;
		}
		
		.woocommerce a.button:focus,
		.woocommerce a.button:hover,
		.woocommerce a.button.alt:focus,
		.woocommerce a.button.alt:hover,
		.woocommerce button.button:focus,
		.woocommerce button.button:hover,
		.woocommerce button.button.alt:focus,
		.woocommerce button.button.alt:hover,
		.woocommerce input.button:focus,
		.woocommerce input.button:hover,
		.woocommerce input.button.alt:focus,
		.woocommerce input.button.alt:hover,
		.woocommerce input[type="submit"]:focus,
		.woocommerce input[type="submit"]:hover,
		.woocommerce #respond input#submit:focus,
		.woocommerce #respond input#submit:hover,
		.woocommerce #respond input#submit.alt:focus,
		.woocommerce #respond input#submit.alt:hover {
			background-color: %1$s;
		}
	
	', $color_main ) : '';
	
	$woo_css .= ( ellie_customizer_get_default_white_color() !== $color_white ) ? sprintf( '
	
		.woocommerce #respond input#submit, 
		.woocommerce #respond input#submit.alt,
		.woocommerce a.button, 
		.woocommerce a.button.alt,
		.woocommerce button.button, 
		.woocommerce button.button.alt,
		.woocommerce input.button,
		.woocommerce input.button.alt,
		.woocommerce input.button[type="submit"], 
		.woocommerce span.onsale, 
		.woocommerce.widget_price_filter .ui-slider .ui-slider-handle, 
		.woocommerce.widget_price_filter .ui-slider .ui-slider-range {
			color: %1$s;
		}	
		
		.woocommerce a.button:focus,
		.woocommerce a.button:hover,
		.woocommerce a.button.alt:focus,
		.woocommerce a.button.alt:hover,
		.woocommerce button.button:focus,
		.woocommerce button.button:hover,
		.woocommerce button.button.alt:focus,
		.woocommerce button.button.alt:hover,
		.woocommerce input.button:focus,
		.woocommerce input.button:hover,
		.woocommerce input.button.alt:focus,
		.woocommerce input.button.alt:hover,
		.woocommerce input[type="submit"]:focus,
		.woocommerce input[type="submit"]:hover,
		.woocommerce #respond input#submit:focus,
		.woocommerce #respond input#submit:hover,
		.woocommerce #respond input#submit.alt:focus,
		.woocommerce #respond input#submit.alt:hover {
			color: %1$s;
		}
	
	', $color_white ) : '';
	
	$woo_css .= ( ellie_customizer_get_default_body_font_color() !== $color_body ) ? sprintf( '
	
		.woocommerce ul.products li.product .price,
		.woocommerce div.product p.price, 
		.woocommerce div.product span.price {
			color: %1$s;	
		}
	
	', $color_body ) : '';
	
	$woo_css .= ( ellie_customizer_get_default_entry_title_color() !== $color_entry ) ? sprintf( '
	
		.woocommerce ul.products li.product h3 {
			color: %1$s;
		}
	
	', $color_entry ) : '';

	if ( $woo_css ) {
		wp_add_inline_style( 'ellie-woocommerce-styles', $woo_css );
	}

}
