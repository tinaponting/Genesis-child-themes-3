<?php

/**
 * 
 * Template Name: Xposure Portfolio
 * 
 */


/* Add template specific body class */
add_filter( 'body_class', 'xpos_portfolio_template_body_class' );

function xpos_portfolio_template_body_class( $classes ) {
	$classes[] = 'fullscreen-portfolio';
	return $classes;
}

/* Remove Genesis loop */
remove_action( 'genesis_loop', 'genesis_do_loop' );
 
/* Remove Above Footer widget area */
remove_action( 'wp_head', 'xpos_widget_areas', 5 );

/* Remove the Genesis Footer Widgets */
remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );

/* Remove site footer */
remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'lander_do_nav_footer', 5 );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );

/* Hook the Envoke Supersized slider for this template */
if ( in_array( 'envoke-supersized/envoke_supersized.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	add_filter( 'enss-enabled', '__return_true' );
}

/* Remove the distracting edit link on front page for the template */
add_filter( 'edit_post_link', '__return_false' );

genesis();