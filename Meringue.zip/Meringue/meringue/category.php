<?php
/**
 * Custom Category Template
**/
// Remove default loop
//remove_action( 'genesis_loop', 'genesis_do_loop' );
function meringue_category_loop_args() {
	return array(
		'category_name' => get_query_var( 'category_name' ),
		'paged'         => get_query_var( 'paged' ),
	);
}
add_action( 'genesis_loop', 'meringue_category_do_loop_intro', 5 );
/**
 * Custom Loop Intro
 *
 */
function meringue_category_do_loop_intro() {
	
	$args = wp_parse_args( array( 'tag_id' => 12, 'no_found_rows' => true, 'update_post_term_cache' => false, 'update_post_meta_cache' => false, 'showposts' => 2,  ), meringue_category_loop_args() );
	
	$query = new WP_Query( $args );
	if( $query->have_posts() ): 
		while( $query->have_posts() ): $query->the_post(); global $post;
			echo '<h1 id="category-title" class="category title">';
				the_title();
			echo '</h1>';
			the_content();
		endwhile;
		// If you want pagination for pt 1
		//genesis_posts_nav();
	endif;
}
// Remove Title
remove_action( 'genesis_post_title ', 'genesis_do_post_title' );
remove_action( 'genesis_post_content ', 'genesis_do_post_content' );
add_action( 'genesis_post_content', 'meringue_category_do_post_content' );
/**
 * Custom Content
 *
 */
function meringue_category_do_post_content() {
	// Moved this to pre_get_posts
	//$args = wp_parse_args( array( 'tag__not_in' => 12, 'meringue_category_query' => true, ), meringue_category_loop_args() );
	
	echo '<div class="category-item">';
		the_post_thumbnail('thumbnail'); 
		echo '<div class="post-content">';
			printf( '<h2>%s</h2>', get_the_title() );
			the_content();
			printf( '<a href="%s">%s</a>', get_permalink(), __( 'View Details', 'text-domain' ) );
		echo '</div>';
	echo '</div>';
}
 
genesis();
?>