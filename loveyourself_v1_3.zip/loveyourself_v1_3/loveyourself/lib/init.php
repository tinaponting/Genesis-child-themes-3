//* Child theme
define( 'CHILD_THEME_NAME', 'LoveYourself Theme' );
define( 'CHILD_THEME_URL', 'http://skyandstars.etsy.com' );
define( 'CHILD_THEME_VERSION', '1.3 );

add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );
add_theme_support( 'genesis-responsive-viewport' );
add_theme_support( 'genesis-menus', array( 'primary' => __( 'Primary Navigation Menu', 'genesis' ) ) );
