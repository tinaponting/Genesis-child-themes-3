<?php 
function zp_custom_post_type() {
    if ( ! class_exists( 'Super_CPT' ) )
        return;
				
/*----------------------------------------------------*/
// Add Portfolio Custom Post Type
/*---------------------------------------------------*/
	$portfolio_custom_default = array(
		'supports' => array( 'title', 'editor', 'thumbnail', 'revisions', 'excerpt'),	
		'menu_icon' =>  get_stylesheet_directory_uri().'/includes/cpt/images/portfolio.png',
	);
	// register portfolio post type
	$portfolio = new Super_Custom_Post_Type( 'portfolio', 'Portfolio', 'Portfolio',  $portfolio_custom_default );
	$portfolio_category = new Super_Custom_Taxonomy( 'portfolio_category' ,'Portfolio Category', 'Portfolio Categories', 'cat' );
	connect_types_and_taxes( $portfolio, array( $portfolio_category ) );
	// Portfolio meta boxes
	 
	
	$portfolio->add_meta_box( array(
		'id' => 'portfolio-metaItem',
		'context' => 'normal',
		'priority' => 'high',
		'fields' => array(
			'zp_portfolio_meta_item_value' => array( 'label' =>__( 'Include Portfolio MetaItem','vivien'), 'type' => 'select', 'options' => array('true' => 'True','false' => 'False'), 'data-zp_desc' => __('Select True to include meta on portfolio single page.','vivien') ),

			'zp_client_label_value' => array( 'label' => __('Client Label','vivien'), 'type' => 'text', 'data-zp_desc' => __('Define client label','vivien') ),
			'zp_client_value' => array( 'label' => __('Client Value','vivien'), 'type' => 'text', 'data-zp_desc' => __('Define client Value','vivien')  ),		
				
			'zp_date_label_value' => array( 'label' => __('Date Label','vivien'), 'type' => 'text' , 'data-zp_desc' => __('Define date label','vivien') ),	
			'zp_date_value' => array( 'label' => __('Date Value','vivien'), 'type' => 'text', 'data-zp_desc' =>  __('Define date label','vivien')  ),				
			
			'zp_category_label_value' => array( 'label' =>__( 'Category Label','vivien'), 'type' => 'text', 'data-zp_desc' => __('Define category label' ,'vivien') ),	
			'zp_category_value' => array( 'label' => __('Category Value','vivien'), 'type' => 'text', 'data-zp_desc' => __('Define category value','vivien')  ),	

			'zp_visit_project_label_value' => array( 'label' => __('Visit Project Label','eshop'), 'type' => 'text', 'data-zp_desc' => __('Define visit project label','eshop')  ),	
			'zp_visit_project_value' => array( 'label' => __('Visit Project Link','eshop'), 'type' => 'text', 'data-zp_desc' => __('Define visit project link','eshop')  ),			
			
			'zp_backto_label_value' => array( 'label' => __('Porfolio Label','vivien'), 'type' => 'text', 'data-zp_desc' => __('Define portfolio label','vivien')  ),	
			'zp_backto_value' => array( 'label' => __('Portfolio Value','vivien'), 'type' => 'text', 'data-zp_desc' => __('Define portfolio value','vivien')  ),				
		)
	) );
	$portfolio->add_meta_box( array(
		'id' => 'portfolio-images',
		'context' => 'normal',
		'priority' => 'high',
		'fields' => array(
			'portfolio_images' => array( 'label' => __( 'Upload/Attach an image to this portfolio item. Images attached in here will be shown in the single portfolio page as a slider','vivien'), 'type' => 'multiple_media' , 'data-zp_desc' => __( 'Attach images to this portfolio item','vivien' )),														
		)
	) );
	$portfolio->add_meta_box( array(
		'id' => 'portfolio-videos',
		'context' => 'normal',
		'priority' => 'high',
		'fields' => array(
			'zp_video_url_value' => array( 'label' => __('Youtube or Vimeo URL','vivien'), 'type' => 'text', 'data-zp_desc' => __('Place here the video url. Example video url: YOUTUBE: http://www.youtube.com/watch?v=Sv5iEK-IEzw and VIMEO: http://vimeo.com/7585127','vivien') ),		
			'zp_video_embed_value' => array( 'label' => __('Embed Code','vivien'), 'type' => 'text' , 'data-zp_desc' => __('If you are using anything else other than YouTube or Vimeo, paste the embed code here. This field will override anything from the above.','vivien') ),	
			'zp_height_value' => array( 'label' => __('Video Height','vivien'), 'type' => 'text', 'data-zp_desc' => __('Please input your video height. Example: 300','vivien') )
												
		)
	) );		
	
	
	// manage portfolio columns 
	function zp_add_portfolio_columns($columns) {
		return array(
			'cb' => '<input type="checkbox" />',
			'title' => __('Title', 'vivien'),
			'portfolio_category' => __('Portfolio Category', 'vivien'),
			'author' =>__( 'Author', 'vivien'),
			'date' => __('Date', 'vivien'),			
		);
	}
	add_filter('manage_portfolio_posts_columns' , 'zp_add_portfolio_columns');
	function zp_custom_portfolio_columns( $column, $post_id ) {
		switch ( $column ) {
		case 'portfolio_category' :
			$terms = get_the_term_list( $post_id , 'portfolio_category' , '' , ',' , '' );
			if ( is_string( $terms ) )
				echo $terms;
			else
				_e( 'Unable to get author(s)', 'vivien' );
			break;
		}
	}
	add_action( 'manage_posts_custom_column' , 'zp_custom_portfolio_columns', 10, 2 );
	
/*----------------------------------------------------*/
// Add Page Custom Meta
/*---------------------------------------------------*/
	$page_meta = new Super_Custom_Post_Meta( 'page' );
	
	$page_meta->add_meta_box( array(
		'id' => 'portfolio-page-settings',
		'context' => 'side',
		'priority' => 'high',
		'fields' => array(
			'column_number_value' => array( 'label' => __('Number of Columns','vivien'), 'type' => 'select' , 'options' => array('2' => 'Two Columns','3' => 'Three Columns', '4' => 'Four Columns'), 'data-zp_desc' => __('Choose the portfolio page columns.','vivien'))
		)
	) );	
		
		
}
add_action( 'after_setup_theme', 'zp_custom_post_type' );