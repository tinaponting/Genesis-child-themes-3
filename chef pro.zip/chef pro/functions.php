<?php
/**
 * Chef Pro.
 * @package Chef
 */

// Start the engine.
include_once( get_template_directory() . '/lib/init.php' );

// Setup Theme.
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );

// Set Localization (do not remove).
add_action( 'after_setup_theme', 'chef_pro_localization_setup' );
function chef_pro_localization_setup(){
	load_child_theme_textdomain( 'chef-pro', get_stylesheet_directory() . '/languages' );
}

// Add the helper functions.
include_once( get_stylesheet_directory() . '/lib/helper-functions.php' );

// Add Image upload and Color select to WordPress Theme Customizer.
require_once( get_stylesheet_directory() . '/lib/customize.php' );

// Include Customizer CSS.
include_once( get_stylesheet_directory() . '/lib/output.php' );

// Child theme (do not remove).
define( 'CHILD_THEME_NAME', __( 'Chef Pro', 'chef' ) );
define( 'CHILD_THEME_URL', 'https://minimalgenesis.com/themes/chef-pro/' );
define( 'CHILD_THEME_VERSION', '1.0.0' );

// Enqueue scripts and styles.
add_action( 'wp_enqueue_scripts', 'chef_pro_enqueue_scripts_styles' );
function chef_pro_enqueue_scripts_styles() {
	wp_enqueue_style( 'chef-pro-fonts', '//fonts.googleapis.com/css?family=Crimson+Text:400,400i,600,600i', array(), CHILD_THEME_VERSION );
	wp_enqueue_style( 'dashicons' );
	$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
	wp_enqueue_script( 'chef-pro-responsive-menu', get_stylesheet_directory_uri() . "/js/responsive-menus{$suffix}.js", array( 'jquery' ), CHILD_THEME_VERSION, true );
	wp_localize_script(
		'chef-pro-responsive-menu',
		'genesis_responsive_menu',
		chef_pro_responsive_menu_settings()
	);
}

// Enqueue Genesis child theme style sheet at higher priority.
remove_action( 'genesis_meta', 'genesis_load_stylesheet' );
add_action( 'wp_enqueue_scripts', 'genesis_enqueue_main_stylesheet', 15 );

// Define our responsive menu settings.
function chef_pro_responsive_menu_settings() {
	$settings = array(
		'mainMenu'          => __( 'Menu', 'chef-pro' ),
		'menuIconClass'     => 'dashicons-before dashicons-menu',
		'subMenu'           => __( 'Submenu', 'chef-pro' ),
		'subMenuIconsClass' => 'dashicons-before dashicons-arrow-down-alt2',
		'menuClasses'       => array(
			'combine' => array(
				'.nav-header',
				'.nav-primary',
			),
			'others'  => array(),
		),
	);
	return $settings;
}

// Add HTML5 markup structure.
add_theme_support( 'html5', array( 'caption', 'comment-form', 'comment-list', 'gallery', 'search-form' ) );

// Add Accessibility support.
add_theme_support( 'genesis-accessibility', array( '404-page', 'drop-down-menu', 'headings', 'rems', 'search-form', 'skip-links' ) );

// Add viewport meta tag for mobile browsers.
add_theme_support( 'genesis-responsive-viewport' );

// Add support for custom logo.
add_theme_support( 'custom-logo', array(
	'width'       => 600,
	'height'      => 180,
	'flex-width' => true,
	'flex-height' => true,
) );

// Displays custom logo.
add_action( 'genesis_site_title', 'the_custom_logo', 0 );

// Add support for Gutenberg wide images.
add_theme_support( 'align-wide' );

// Adds theme colors to Gutenberg editor.
add_theme_support( 'gutenberg', array(
	'colors' => array(
		'#f9f9f9',
		'#999999',
		'#333333',
		get_theme_mod( 'chef_pro_link_color', chef_pro_customizer_get_default_link_color() ),
		get_theme_mod( 'chef_pro_accent_color', chef_pro_customizer_get_default_accent_color() ),
	),
) );

// Remove the secondary sidebar.
unregister_sidebar( 'sidebar-alt' );

// Unregister layout settings.
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );

// Register new narrow width content layout.
function chef_pro_create_archive_layout() {
	 genesis_register_layout( 'narrow-width-content', array(
		'label' => __('Narrow Width Content', 'chef-pro'),
		'img' => get_bloginfo('stylesheet_directory') . '/images/narrow-width-content.gif'
	) );
}
add_action( 'init', 'chef_pro_create_archive_layout' );

// Remove the sidebars on narrow width content layout.
add_action( 'genesis_after_header', 'chef_pro_remove_sidebars' );
function chef_pro_remove_sidebars() {
    $site_layout = genesis_site_layout();
    if ( 'narrow-width-content' == $site_layout ) {
			remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
			remove_action( 'genesis_sidebar_alt', 'genesis_do_sidebar_alt' );
		}
}

// Add support for custom background.
add_theme_support( 'custom-background' );

// Add support for after entry widget.
add_theme_support( 'genesis-after-entry-widget-area' );

// Add support for 3-column footer widgets.
add_theme_support( 'genesis-footer-widgets', 3 );

// Add Image Sizes.
add_image_size( 'featured-single', 700, 9999, FALSE );
add_image_size( 'featured-square', 700, 700, TRUE );

// Rename primary and secondary navigation menus.
add_theme_support( 'genesis-menus', array( 'primary' => __( 'After Header Menu', 'chef-pro' ), 'secondary' => __( 'Footer Menu', 'chef-pro' ) ) );

// Reposition the secondary navigation menu.
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_footer', 'genesis_do_subnav', 5 );

// Reduce the secondary navigation menu to one level depth.
add_filter( 'wp_nav_menu_args', 'chef_pro_secondary_menu_args' );
function chef_pro_secondary_menu_args( $args ) {
	if ( 'secondary' != $args['theme_location'] ) {
		return $args;
	}
	$args['depth'] = 1;
	return $args;
}

// Remove the author box on single posts.
remove_action( 'genesis_after_entry', 'genesis_do_author_box_single', 8 );

// Modify size of the Gravatar in the entry comments.
add_filter( 'genesis_comment_list_args', 'chef_pro_comments_gravatar' );
function chef_pro_comments_gravatar( $args ) {
	$args['avatar_size'] = 60;
	return $args;
}

// Customize search form input box text
add_filter( 'genesis_search_text', 'chef_pro_search_text' );
function chef_pro_search_text( $text ) {
	return esc_attr( 'Search...' );
}

// Display posts in a 3 column grid.
function chef_pro_archive_post_class( $classes ) {
	global $wp_query;
	if( ! $wp_query->is_main_query() || is_singular() )
		return $classes;
		$classes[] = 'one-third';
	if( 0 == $wp_query->current_post % 3 )
		$classes[] = 'first';
		return $classes;
}
add_filter( 'post_class', 'chef_pro_archive_post_class' );

// Remove entry content on blog and archives.
add_action ( 'genesis_before_entry' , 'chef_pro_remove_entry_content_archives' );
function chef_pro_remove_entry_content_archives() {
	if (is_home() || is_archive() || is_search() )
		remove_action( 'genesis_entry_content', 'genesis_do_post_content' );
}

// Display featured image after single entry header.
add_action( 'genesis_entry_header', 'featured_post_image', 15 );
function featured_post_image() {
  if ( ! is_singular( 'post' ) )  return;
	the_post_thumbnail('featured-single');
}

// Move featured image above post title in archives.
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
add_action( 'genesis_entry_header', 'genesis_do_post_image', 8 );

// Customize read more text.
add_filter( 'excerpt_more', 'chef_pro_read_more_link' );
add_filter( 'get_the_content_more_link', 'chef_pro_read_more_link' );
add_filter( 'the_content_more_link', 'chef_pro_read_more_link' );
function chef_pro_read_more_link() {
	return '... <a href="'. get_permalink() .'" class="more-link">Read More</a>';
}

// Customize the previous link.
add_filter( 'genesis_prev_link_text', 'modify_previous_link_text' );
function modify_previous_link_text($text) {
        $text = '←';
        return $text;
}

// Customize the next link.
add_filter( 'genesis_next_link_text', 'chef_pro_next_link_text' );
function chef_pro_next_link_text($text) {
        $text = '→';
        return $text;
}

// Change WooCommerce number of products per row to 3
add_filter('loop_shop_columns', 'loop_columns');
if (!function_exists('loop_columns')) {
	function loop_columns() {
		return 3; // 3 products per row
	}
}

// Change WooCommerce number of related products to 3
function woo_related_products_limit() {
  global $product;
	$args['posts_per_page'] = 3;
	return $args;
}
add_filter( 'woocommerce_output_related_products_args', 'chef_pro_related_products_args' );
  function chef_pro_related_products_args( $args ) {
	$args['posts_per_page'] = 3; // 3 related products
	$args['columns'] = 3; // arranged in 3 columns
	return $args;
}

// Add WooCommerce image gallery support.
add_action( 'after_setup_theme', 'chef_pro_setup' );
function chef_pro_setup() {
    add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );
}

// Register top bar.
genesis_register_sidebar( array(
    'id'    => 'top-bar',
    'name'    => __( 'Top Bar', 'chef-pro' ),
    'description'    => __( 'This is the top bar area.', 'chef-pro' ),
) );

// Add the top bar.
add_action( 'genesis_before_header', 'add_top_bar' );
function add_top_bar() {
   genesis_widget_area( 'top-bar', array(
	'before' => '<div class="top-bar"><div class="wrap">',
	'after' => '</div></div>',
   ) );
}

// Register front page hero area.
genesis_register_sidebar( array(
    'id'    => 'front-page-hero',
    'name'    => __( 'Front Page Hero', 'chef-pro' ),
    'description'    => __( 'This is the front page hero area.', 'chef-pro' ),
) );

// Add the front page hero area.
add_action( 'genesis_after_header', 'chef_pro_front_page_hero' );
function chef_pro_front_page_hero() {
if ( ! is_front_page() )
 return;
   genesis_widget_area( 'front-page-hero', array(
	'before' => '<div class="front-page-hero full-width widget-area">',
	'after' => '</div>',
   ) );
}

// Register archive widgets area.
genesis_register_sidebar( array(
    'id'    => 'archive-widgets',
    'name'    => __( 'Archive Widgets', 'chef-pro' ),
    'description'    => __( 'This is the archive widgets area.', 'chef-pro' ),
) );

// Add the archive widgets area.
add_action( 'genesis_loop', 'chef_pro_archive_widgets', 1 );
function chef_pro_archive_widgets() {
	if ( !is_archive() )
 return;
   genesis_widget_area( 'archive-widgets', array(
	'before' => '<div class="archive-widgets widget-area">',
	'after' => '</div>',
   ) );
}

// Register before footer widgets area.
genesis_register_sidebar( array(
    'id'    => 'before-footer-widgets',
    'name'    => __( 'Before Footer Widgets', 'chef-pro' ),
    'description'    => __( 'This is the before footer widgets area.', 'chef-pro' ),
) );

// Add the before footer widgets area.
add_action( 'genesis_before_footer', 'chef_pro_before_footer_widgets', 1 );
function chef_pro_before_footer_widgets() {
   genesis_widget_area( 'before-footer-widgets', array(
	'before' => '<div class="before-footer-widgets full-width widget-area">',
	'after' => '</div>',
   ) );
}

// Register after footer widgets area.
genesis_register_sidebar( array(
    'id'    => 'after-footer-widgets',
    'name'    => __( 'After Footer Widgets', 'chef-pro' ),
    'description'    => __( 'This is the after footer widgets area.', 'chef-pro' ),
) );

// Add the after footer  widgets area.
add_action( 'genesis_before_footer', 'chef_pro_after_footer_widgets', 15 );
function chef_pro_after_footer_widgets() {
   genesis_widget_area( 'after-footer-widgets', array(
	'before' => '<div class="after-footer-widgets full-width widget-area">',
	'after' => '</div>',
   ) );
}