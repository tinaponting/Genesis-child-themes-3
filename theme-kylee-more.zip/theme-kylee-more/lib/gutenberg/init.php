<?php
/**
 * Gutenberg theme support.
 * @package Kylee More
 */

add_action( 'wp_enqueue_scripts', 'kylee_more_enqueue_gutenberg_frontend_styles' );
/**
 * Enqueues Gutenberg front-end styles.
 *
 * @since 1.2.0
 */
function kylee_more_enqueue_gutenberg_frontend_styles() {

	wp_enqueue_style(
		'kylee-more-gutenberg',
		get_stylesheet_directory_uri() . '/lib/gutenberg/front-end.css',
		array( 'kylee-more' ),
		CHILD_THEME_VERSION
	);

}

add_action( 'enqueue_block_editor_assets', 'kylee_more_block_editor_styles' );
/**
 * Enqueues Gutenberg admin editor fonts and styles.
 *
 * @since 1.2.0
 */
function kylee_more_block_editor_styles() {

	wp_enqueue_style(
		'kylee-more-gutenberg-fonts',
		'https://fonts.googleapis.com/css?family=Prata|Poppins:400,700',
		array(),
		CHILD_THEME_VERSION
	);

}

// Add support for editor styles.
add_theme_support( 'editor-styles' );

// Enqueue editor styles.
add_editor_style( '/lib/gutenberg/style-editor.css' );

// Adds support for block alignments.
add_theme_support( 'align-wide' );

// Make media embeds responsive.
add_theme_support( 'responsive-embeds' );

// Adds support for editor font sizes.
add_theme_support(
	'editor-font-sizes',
	array(
		array(
			'name'      => __( 'Small', 'kylee-more' ),
			'shortName' => __( 'S', 'kylee-more' ),
			'size'      => 13,
			'slug'      => 'small',
		),
		array(
			'name'      => __( 'Normal', 'kylee-more' ),
			'shortName' => __( 'M', 'kylee-more' ),
			'size'      => 15,
			'slug'      => 'normal',
		),
		array(
			'name'      => __( 'Large', 'kylee-more' ),
			'shortName' => __( 'L', 'kylee-more' ),
			'size'      => 17,
			'slug'      => 'large',
		),
		array(
			'name'      => __( 'Larger', 'kylee-more' ),
			'shortName' => __( 'XL', 'kylee-more' ),
			'size'      => 23,
			'slug'      => 'larger',
		),
	)
);

// Adds support for editor color palette.
add_theme_support(
	'editor-color-palette', array(
		array(
			'name'  => __( 'Accent Color', 'kylee-more' ),
			'slug'  => 'accent',
			'color' => get_theme_mod( 'kylee_accent_color', kylee_customizer_get_default_accent_color() ),
		),
	)
);

require_once get_stylesheet_directory() . '/lib/gutenberg/inline-styles.php';

add_action( 'after_setup_theme', 'kylee_more_content_width', 0 );
/**
 * Set content width to match the “wide” Gutenberg block width.
 */
function kylee_more_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'kylee_more_content_width', 1020 );
}
