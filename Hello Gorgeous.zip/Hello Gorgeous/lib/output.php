<?php
/*
 * Adds the required CSS to the front end.
 */

add_action( 'wp_enqueue_scripts', 'hyd_css' );
/**
* Checks the settings for the images and background colors for each image
* If any of these value are set the appropriate CSS is output
*
* @since 1.0
*/
function hyd_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';

	$color_mintcolor = get_theme_mod( 'hyd_mintcolor_color', hyd_customizer_get_default_mintcolor_color() );
	$color_navlink = get_theme_mod( 'hyd_navlink_color', hyd_customizer_get_default_navlink_color() );
	$color_navhover = get_theme_mod( 'hyd_navhover_color', hyd_customizer_get_default_navhover_color() );
	$color_linkcolor = get_theme_mod( 'hyd_linkcolor_color', hyd_customizer_get_default_linkcolor_color() );
	$color_hovercolor = get_theme_mod( 'hyd_hovercolor_color', hyd_customizer_get_default_hovercolor_color() );
	$color_gridsection = get_theme_mod( 'hyd_gridsection_color', hyd_customizer_get_default_gridsection_color() );
	$color_gridfont = get_theme_mod( 'hyd_gridfont_color', hyd_customizer_get_default_gridfont_color() );
	$color_gridlink = get_theme_mod( 'hyd_gridlink_color', hyd_customizer_get_default_gridlink_color() );
	$color_gridhover = get_theme_mod( 'hyd_gridhover_color', hyd_customizer_get_default_gridhover_color() );
	$color_services = get_theme_mod( 'hyd_services_color', hyd_customizer_get_default_services_color() );
	$color_button = get_theme_mod( 'hyd_button_color', hyd_customizer_get_default_button_color() );
	$color_rose = get_theme_mod( 'hyd_rose_color', hyd_customizer_get_default_rose_color() );
  $color_navy = get_theme_mod( 'hyd_navy_color', hyd_customizer_get_default_navy_color() );
	$color_sharelinks = get_theme_mod( 'hyd_sharelinks_color', hyd_customizer_get_default_sharelinks_color() );

	$css .= ( hyd_customizer_get_default_mintcolor_color() !== $color_mintcolor ) ? sprintf( '
	.site-footer,
	.sticky-wrap {
				background-color: %1$s;
		}

		', $color_mintcolor ) : '';

		$css .= ( hyd_customizer_get_default_navlink_color() !== $color_navlink ) ? sprintf( '

			.nav-sticky .genesis-nav-menu a {
					color: %1$s;
			}

			.site-title a, .site-title a:hover,
			.nav-sticky .simple-social-icons ul li a {
				color: %1$s !important;
			}


			', $color_navlink ) : '';

			$css .= ( hyd_customizer_get_default_navhover_color() !== $color_navhover ) ? sprintf( '

			  .nav-sticky .genesis-nav-menu a:hover {
						color: %1$s;
				}

				.nav-sticky .simple-social-icons ul li a:hover {
					color: %1$s !important;
				}


				', $color_navhover ) : '';

				$css .= ( hyd_customizer_get_default_linkcolor_color() !== $color_linkcolor ) ? sprintf( '
				.genesis-nav-menu a,
				.genesis-nav-menu li.highlight a:hover:before,
				.genesis-nav-menu > .right,
				.responsive-menu-icon::before,
				a,
				.prev-next-navigation a {
							color: %1$s;
					}


					', $color_linkcolor ) : '';

					$css .= ( hyd_customizer_get_default_hovercolor_color() !== $color_hovercolor ) ? sprintf( '

					.genesis-nav-menu a:hover,
			    .genesis-nav-menu .sub-menu a:hover,
					  a:hover,
					 .prev-next-navigation a:hover {
								color: %1$s;
						}


						', $color_hovercolor ) : '';

					$css .= ( hyd_customizer_get_default_gridsection_color() !== $color_gridsection ) ? sprintf( '

					.right-medium,
					.right-small,
					.left-medium {
						 background-color: %1$s;
					}

          .testimonial_rotator_wrap,
					.soliloquy-caption-inside,
					.sidebar .enews-widget {
						outline: 7px solid %1$s !important;
					}
          ul.filter a:hover, ul.filter a.active,
          .imagetitle {
                  background-color: %1$s;
          }
					.front-section .widget .entry,
					.portfolio-content .entry .item-hover {
                  background-color: %1$s !important;
          }

						', $color_gridsection ) : '';

						$css .= ( hyd_customizer_get_default_gridfont_color() !== $color_gridfont ) ? sprintf( '

						.right-medium,
						.right-small,
						.left-medium {
								color: %1$s;
						}

							', $color_gridfont ) : '';

							$css .= ( hyd_customizer_get_default_gridlink_color() !== $color_gridlink ) ? sprintf( '

							.right-medium a,
							.right-small a,
							.left-medium a {
									color: %1$s;
							}

								', $color_gridlink ) : '';

								$css .= ( hyd_customizer_get_default_gridhover_color() !== $color_gridhover ) ? sprintf( '

								.right-medium a:hover,
								.right-small a:hover,
								.left-medium a:hover {
										color: %1$s;
								}

									', $color_gridhover ) : '';

									$css .= ( hyd_customizer_get_default_services_color() !== $color_services ) ? sprintf( '

									.home-services .widget {
										border: 10px double %1$s;
									}

								', $color_services ) : '';									

									$css .= ( hyd_customizer_get_default_button_color() !== $color_button ) ? sprintf( '

									.front-page input:focus,
									.front-page textarea:focus, {
											border: 1px solid %1$s;
									}

									.woocommerce #respond input#submit,
									.woocommerce a.button,
									.woocommerce button.button,
									.woocommerce input.button,
									.woocommerce #respond input#submit:hover,
									.woocommerce a.button:hover,
									.woocommerce button.button:hover,
									.woocommerce input.button:hover,
									.soliloquy-container .soliloquy-caption a.soliloquy-button,
									.soliloquy-container .soliloquy-caption a.soliloquy-button:hover   {
											border: 1px solid %1$s !important;
									}

									button,
									input[type="button"],
									input[type="reset"],
									input[type="submit"],
									.button,
									.widget .button,
									button:hover,
									input:hover[type="button"],
									input:hover[type="reset"],
									input:hover[type="submit"],
									.button.clear:hover,
									.button:hover,
									.footer-widgets button,
									.footer-widgets input[type="button"],
									.footer-widgets input[type="reset"],
									.footer-widgets input[type="submit"],
									.footer-widgets .widget .button,
									.widget .button:hover,
									.widget .button.clear:hover,
									.widget .button.clear,
									.footer-widgets button:hover,
									.footer-widgets input:hover[type="button"],
									.footer-widgets input:hover[type="reset"],
									.footer-widgets input:hover[type="submit"],
									.footer-widgets .widget .button:hover,
                  .pricing-table a.button,
                  .pricing-table a.button:hover   {
											 border: 1px solid %1$s;
									}

									.footer-widgets button,
									.footer-widgets input[type="button"],
									.footer-widgets input[type="reset"],
									.footer-widgets input[type="submit"],
									.footer-widgets .widget .button,
									button:disabled,
									button:disabled:hover,
									input:disabled,
									input:disabled:hover,
									input[type="button"]:disabled,
									input[type="button"]:disabled:hover,
									input[type="reset"]:disabled,
									input[type="reset"]:disabled:hover,
									input[type="submit"]:disabled,
									input[type="submit"]:disabled:hover,
									.archive-pagination li a:hover,
									.archive-pagination .active a,
                  .pricing-table a.button,
									button, input[type="button"],
									input[type="reset"],
									input[type="submit"],
									.button,
									.widget .button {
												 background-color: %1$s;
									}

									div.easyrecipe div.ERSSavePrint .ERSPrintBtnSpan .ERSPrintBtn,
									div.easyrecipe div.ERSSavePrint .ERSSaveBtnSpan .ERSSaveBtn,
									.woocommerce #respond input#submit:hover,
									.woocommerce a.button:hover,
									.woocommerce button.button:hover,
									.woocommerce input.button:hover,
									.soliloquy-container .soliloquy-caption a.soliloquy-button   {
												 background-color: %1$s !important;
									}

									button:disabled,
									button:disabled:hover,
									input:disabled,
									input:disabled:hover,
									input[type="button"]:disabled,
									input[type="button"]:disabled:hover,
									input[type="reset"]:disabled,
									input[type="reset"]:disabled:hover,
									input[type="submit"]:disabled,
									input[type="submit"]:disabled:hover {
											 border-color: %1$s;
									}

									.widget .button.clear,
									.footer-widgets button:hover,
									.footer-widgets input:hover[type="button"],
									.footer-widgets input:hover[type="reset"],
									.footer-widgets input:hover[type="submit"],
									.footer-widgets .widget .button:hover,
                  .pricing-table a.button:hover,
									button:disabled,
									button:disabled:hover,
									input:disabled,
									input:disabled:hover,
									input[type="button"]:disabled,
									input[type="button"]:disabled:hover,
									input[type="reset"]:disabled,
									input[type="reset"]:disabled:hover,
									input[type="submit"]:disabled,
									input[type="submit"]:disabled:hover {
										color: %1$s;
									}

									.woocommerce #respond input#submit,
									.woocommerce a.button,
									.woocommerce button.button,
									.woocommerce input.button,
									.soliloquy-container .soliloquy-caption a.soliloquy-button:hover {
										color: %1$s !important;
									}


										', $color_button ) : '';

$css .= ( hyd_customizer_get_default_rose_color() !== $color_rose ) ? sprintf( '

			.description,
			rose {
					color: %1$s;
		}
', $color_rose ) : '';

	$css .= ( hyd_customizer_get_default_navy_color() !== $color_navy ) ? sprintf( '

			.name,
			navy {
					 color: %1$s;
			}
', $color_navy ) : '';

										$css .= ( hyd_customizer_get_default_sharelinks_color() !== $color_sharelinks ) ? sprintf( '

										.share-after:before,
										.sharrre .share,
										.sharrre:hover .share,
										.content .share-filled .facebook .count,
										.content .share-filled .facebook .count:hover,
										.content .share-filled .googlePlus .count,
										.content .share-filled .googlePlus .count:hover,
										.content .share-filled .linkedin .count,
										.content .share-filled .linkedin .count:hover,
										.content .share-filled .pinterest .count,
										.content .share-filled .pinterest .count:hover,
										.content .share-filled .stumbleupon .count,
										.content .share-filled .stumbleupon .count:hover,
										.content .share-filled .twitter .count,
										.content .share-filled .twitter .count:hover  {
												color: %1$s;
										}

										.content .share-filled .facebook .count,
										.content .share-filled .facebook .count:hover,
										.content .share-filled .googlePlus .count,
										.content .share-filled .googlePlus .count:hover,
										.content .share-filled .linkedin .count,
										.content .share-filled .linkedin .count:hover,
										.content .share-filled .pinterest .count,
										.content .share-filled .pinterest .count:hover,
										.content .share-filled .stumbleupon .count,
										.content .share-filled .stumbleupon .count:hover,
										.content .share-filled .twitter .count,
										.content .share-filled .twitter .count:hover {
											border: 1px solid %1$s;
										}

											', $color_sharelinks ) : '';


	if( $css ){
		wp_add_inline_style( $handle, $css );
	}

}
