<?php

add_action( 'genesis_meta', 'elise_home_genesis_meta' );
/**
 * Add widget support for homepage.
 *
 */
function elise_home_genesis_meta() {

	if ( is_active_sidebar( 'home-slider' )) {

		add_action( 'genesis_before_loop', 'elise_home_loop_helper' );

	}
}

/**
 * Display widget content for home slider section
 *
 */
function elise_home_loop_helper() {

	if ( is_active_sidebar( 'home-slider' )) {

		echo '<div id="home-slider">';
		echo '<div class="home-slider">';
		dynamic_sidebar( 'home-slider' );
		echo '</div><!-- end .slider -->';
	        echo '</div><!-- end #slider -->';

	}

}

genesis();