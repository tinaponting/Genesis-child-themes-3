<?php
/**
 * Sweets.
 * @package      Hello Sweets
 */

//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Add Color Selection to WordPress Theme Customizer
require_once( get_stylesheet_directory() . '/lib/customize.php' );


//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'hello_sweets' );
define( 'CHILD_THEME_VERSION', '1.0.0' );

//* Loads Responsive Menu, Google Fonts, and Dashicons
add_action( 'wp_enqueue_scripts', 'sweets_enqueue_scripts' );
function sweets_enqueue_scripts() {

	wp_enqueue_script( 'global-script', get_bloginfo( 'stylesheet_directory' ) . '/js/global.js', array( 'jquery' ), '1.0.0' );
	wp_enqueue_script( 'localScroll', get_stylesheet_directory_uri() . '/js/jquery.localScroll.min.js', array( 'scrollTo' ), '1.2.8b', true );
	wp_enqueue_script( 'scrollTo', get_stylesheet_directory_uri() . '/js/jquery.scrollTo.min.js', array( 'jquery' ), '1.4.5-beta', true );
	wp_enqueue_style( 'google-font', '//fonts.googleapis.com/css?family=Quattrocento:400,700|Oswald:400,700,300|Roboto+Condensed:400,700', array() );
	wp_enqueue_style( 'dashicons' );
	wp_enqueue_script( 'sticky-nav', get_bloginfo( 'stylesheet_directory' ) . '/js/sticky-nav.js', array( 'jquery' ), '', true );

}

//* Add HTML5 markup structure
add_theme_support( 'html5' );

//* Add new image sizes
add_image_size( 'large-featured',  775, 450, TRUE );
add_image_size( 'small-featured',  560, 350, TRUE );
add_image_size( 'square-featured', 275, 275, TRUE );
add_image_size( 'home-top-right', 315, 270, TRUE );

//* Unregister layout settings
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );

//* Unregister secondary sidebar
unregister_sidebar( 'sidebar-alt' );

//* Remove the header right widget area
unregister_sidebar( 'header-right' );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'width'           => 700,
	'height'          => 350,
	'header-selector' => '.site-title a',
	'header-text'     => false,
) );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Add support for after entry widget
add_theme_support( 'genesis-after-entry-widget-area' );


//* Reposition the primary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_header', 'genesis_do_nav', 12 );

//* Reposition the secondary navigation
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before', 'genesis_do_subnav' );

//* Navigation Search and Social Icons
add_filter( 'genesis_search_button_text', 'sweets_search_button_text' );
function sweets_search_button_text( $text ) {

	return esc_attr( '&#xf179;' );

}
add_filter( 'genesis_nav_items', 'sweets_social_icons', 10, 2 );
add_filter( 'wp_nav_menu_items', 'sweets_social_icons', 10, 2 );

function sweets_social_icons($menu, $args) {
	$args = (array)$args;
	if ( 'secondary' !== $args['theme_location'] )
		return $menu;
	ob_start();
	genesis_widget_area('nav-social-menu');
	$social = ob_get_clean();
	return $menu . $social;
}

//* Customize search form input box text
add_filter( 'genesis_search_text', 'sweets_search_text' );
function sweets_search_text( $text ) {

	return esc_attr( 'search' );

}

//* Hooks widget area above header
add_action( 'genesis_before_content', 'sweets_widget_above_content'  );
function sweets_widget_above_content() {
	if ( ! is_front_page() ) {

    genesis_widget_area( 'widget-above-content', array(
		'before' => '<div class="widget-above-content widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );

}}

//* Modify the size of the Gravatar in the entry comments
add_filter( 'genesis_comment_list_args', 'sweets_comments_gravatar' );
function sweets_comments_gravatar( $args ) {

	$args['avatar_size'] = 120;
	return $args;

}

//* Modify the size of the Gravatar in the author box
add_filter( 'genesis_author_box_gravatar_size', 'sweets_author_box_gravatar' );
function sweets_author_box_gravatar( $size ) {

	return 120;

}

//* Customize the entry meta
add_filter( 'genesis_post_info', 'sweets_post_info_filter' );
function sweets_post_info_filter($post_info) {
	$post_info = '[post_date] by [post_author_posts_link] [post_comments] [post_edit]';
	return $post_info;
}


//* Remove comment form allowed tags
add_filter( 'comment_form_defaults', 'sweets_remove_comment_form_allowed_tags' );
function sweets_remove_comment_form_allowed_tags( $defaults ) {

	$defaults['comment_notes_after'] = '';
	return $defaults;

}

//* Hooks widget area before footer
add_action( 'genesis_before_footer', 'sweets_social_bar', 5  );
function sweets_social_bar() {{

    genesis_widget_area( 'social-bar', array(
		'before' => '<div class="social-bar widget-area"><div class="social-wrap">',
		'after'  => '</div></div>',
    ) );

}}

//* Add Author Box Widget
add_filter( 'genesis_author_box', 'sweets_author_box', 10, 6 );
function sweets_author_box( $output, $context, $pattern, $gravatar, $title, $description ) {
	if ( is_active_sidebar( 'author-box-custom' ) ) {
		ob_start();
		genesis_widget_area( 'author-box-custom', array( 'before' => '<div class="author-box-custom">', 'after' => '</div>', ) );
		$description .= ob_get_contents();
		ob_end_clean();
	}
	$output = sprintf( $pattern, $gravatar, $title, $description );
	return $output;
}

//* Genesis Previous/Next Post Post Navigation
add_action( 'genesis_before_comments', 'sweets_prev_next_post_nav' );

function sweets_prev_next_post_nav() {

	if ( is_single() ) {

		echo '<div class="prev-next-navigation">';
		previous_post_link( '<div class="previous">%link</div>', '%title' );
		next_post_link( '<div class="next">%link</div>', '%title' );
		echo '</div><!-- .prev-next-navigation -->';
	}
}

//* Add Read More Link for Custom Excerpts
function excerpt_read_more_link($output) {
	global $post;
	return $output . '<a href="'. get_permalink($post->ID) . '"> <div class="readmorelink"><div class="rmtext">[ Read More ]</div></div></a>';
}
add_filter('the_excerpt', 'excerpt_read_more_link');

add_filter('excerpt_more','__return_false');



//* Setup widget counts
function sweets_count_widgets( $id ) {
	global $sidebars_widgets;

	if ( isset( $sidebars_widgets[ $id ] ) ) {
		return count( $sidebars_widgets[ $id ] );
	}

}

function sweets_widget_area_class( $id ) {
	$count = sweets_count_widgets( $id );

	$class = '';

	if( $count == 1 || $count < 9 ) {

		$classes = array(
			'zero',
			'one',
			'two',
			'three',
			'four',
			'five',
			'six',
			'seven',
			'eight',
		);

		$class = $classes[ $count ] . '-widget';
		$class = $count == 1 ? $class : $class . 's';

		return $class;

	} else {

		$class = 'widget-thirds';

		return $class;

	}

}

//* Edit width of tiled gallery
if ( ! isset( $content_width ) )
    $content_width = 775;


//* Customize the credits
add_filter( 'genesis_footer_creds_text', 'sweets_footer_creds_text' );
function sweets_footer_creds_text() {

    echo '<div class="creds"><p>';
    echo 'Copyright &copy; ';
    echo date('Y');
    echo ' &middot; <a target="_blank" href="https://exxempel.se/">My name of the site</a> by <a target="_blank" href="https://exempel.se">Exempel</a>';
    echo '</p></div>';

}

//* Add Theme Support for WooCommerce
add_theme_support( 'genesis-connect-woocommerce' );

//* Remove Related Products
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );

//* Remove Add to Cart on Archives
add_action( 'woocommerce_after_shop_loop_item', 'sweets_remove_add_to_cart_buttons', 1 );
function sweets_remove_add_to_cart_buttons() {

    remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart' );

}

//* Display 20 products per page
add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 20;' ), 20 );


//* Register widget areas
genesis_register_sidebar( array(
	'id'           => 'widget-above-content',
	'name'         => __( 'Widget Above Content', 'sweets' ),
	'description'  => __( 'This is the widget above displayed everywhere except the home page', 'sweets' ),
) );
genesis_register_sidebar( array(
	'id'           => 'home-full-slider',
	'name'         => __( 'Home Full Slider', 'sweets' ),
	'description'  => __( 'This is the home Full slider widget area on the home page', 'sweets' ),
) );
genesis_register_sidebar( array(
	'id'           => 'home-top-left',
	'name'         => __( 'Home Top Left', 'sweets' ),
	'description'  => __( 'This is the home top left widget area on the home page', 'sweets' ),
) );
genesis_register_sidebar( array(
	'id'           => 'home-top-right',
	'name'         => __( 'Home Top Right', 'sweets' ),
	'description'  => __( 'This is the home top right widget area on the home page', 'sweets' ),
) );
genesis_register_sidebar( array(
	'id'           => 'home-badge',
	'name'         => __( 'Home Badge', 'sweets' ),
	'description'  => __( 'This is the home badge widget area on the home page', 'sweets' ),
) );
genesis_register_sidebar( array(
	'id'           => 'home-flexible',
	'name'         => __( 'Home Flexible', 'sweets' ),
	'description'  => __( 'This is the home flexible widget area on the home page', 'sweets' ),
) );
genesis_register_sidebar( array(
	'id'           => 'home-calltoaction',
	'name'         => __( 'Home Call to Action', 'sweets' ),
	'description'  => __( 'This is the home call to action widget area on the home page', 'sweets' ),
) );
genesis_register_sidebar( array(
	'id'           => 'home-featured',
	'name'         => __( 'Home Featured', 'sweets' ),
	'description'  => __( 'This is the home featured widget area on the home page', 'sweets' ),
) );
genesis_register_sidebar( array(
	'id'          => 'social-bar',
	'name'        => __( 'Social Bar', 'sweets' ),
	'description' => __( 'This is the full width Social Bar above the footer.', 'sweets' ),
) );
genesis_register_sidebar( array(
	'id'          => 'nav-social-menu',
	'name'        => __( 'Nav Social Menu', 'sweets' ),
	'description' => __( 'This is the nav social menu section.', 'sweets' ),
) );
genesis_register_sidebar( array(
	'id'          => 'author-box-custom',
	'name'        => __( 'Author Box Widget', 'sweets' ),
	'description' => __( 'This is the Author Box Custom widget', 'sweets' ),
) );
genesis_register_sidebar( array(
	'id'          => 'portfolioblurb',
	'name'        => __( 'Portfolio Archive Page Widget', 'sweets' ),
	'description' => __( 'This widget appears above your portfolio items on your portfolio archive page.', 'sweets' ),
) );



//* Add Font Awesome Support
add_action( 'wp_enqueue_scripts', 'enqueue_font_awesome' );
function enqueue_font_awesome() {
	wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css', array(), '4.1.0' );
}
