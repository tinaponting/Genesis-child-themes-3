<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Elise Theme' );
define( 'CHILD_THEME_VERSION', '2.2.2' );

//* Enqueue Google Fonts
add_action( 'wp_enqueue_scripts', 'elise_enqueue_scripts_styles' );
function elise_enqueue_scripts_styles() {
	wp_enqueue_style( 'dashicons' );
	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Raleway:300,400,700|Old+Standard+TT:400,400italic|Lato:300,400,700', array(), CHILD_THEME_VERSION );

	wp_enqueue_script( 'elise-responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0', true );
	$output = array(
		'mainMenu' => __( 'Menu', 'elise' ),
		'subMenu'  => __( 'Menu', 'elise' ),
	);
	wp_localize_script( 'elise-responsive-menu', 'eliseL10n', $output );
}

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

//* Add Accessibility support
add_theme_support( 'genesis-accessibility', array( 'headings', 'drop-down-menu',  'search-form', 'skip-links', 'rems' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Add Read More Link for Custom Excerpts
function excerpt_read_more_link($output) {
	global $post;
	return $output . '<a href="'. get_permalink($post->ID) . '"> <div class="readmorelink"><div class="rmtext">Read More</div></div></a>';
}
add_filter('the_excerpt', 'excerpt_read_more_link');

//* Change the footer text
add_filter('genesis_footer_creds_text', 'sp_footer_creds_filter');
function sp_footer_creds_filter( $creds ) {
	$creds = '[footer_copyright] &middot; <a href="https://exempel.se">Exempel</a> &middot; by <a href="https://exempel.se" title="exempel">EXEMPEL</a>';
	return $creds;
}

//* Reposition the primary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before_header', 'genesis_do_nav' );

//* Reposition the secondary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before_footer', 'genesis_do_subnav' );

//* Add featured image sizes
add_image_size( 'sidebar', 350, 350, TRUE );
add_image_size( 'blog-featured-image', 740, 500, TRUE );
add_image_size( 'blog-excerpt-image', 320, 210, TRUE );
add_image_size( 'category-archive-image', 250, 250, TRUE );

//* Register widget areas

genesis_register_sidebar( array(
	'id'            => 'adspace',
	'name'          => __( 'AdSpace', 'elise' ),
	'description'   => __( 'This is the AdSpace Widget for the top of every single post', 'elise' ),
) );
genesis_register_sidebar( array(
	'id'		=> 'home-slider',
	'name'		=> __( 'Home Slider', 'elise' ),
	'description'	=> __( 'This is the slider widget area for the homepage.', 'elise' ),
) );
genesis_register_sidebar( array(
	'id'		=> 'subscribewidget',
	'name'		=> __( 'Subscribe Widget', 'elise' ),
	'description'	=> __( 'This is the subscribe widget.', 'elise' ),
) );

//*Hook Widget Areas

/** Ad Space Widget Area */
add_action( 'genesis_before_loop', 'elise_adspace_widget' );
   function elise_adspace_widget() {
// if ( is_page() ) {
	if ( ! is_singular( 'post' ) ) {
		return;
	}
      genesis_widget_area( 'adspace', array(
          'before' => '<div class="adspace">',
          'after' => '</div>',
      ) );

}
add_action( 'genesis_after_header', 'elise_subscribe_widget' );
	function elise_subscribe_widget() {
		genesis_widget_area( 'subscribewidget', array(
			'before' => '<div class=subscribe-widget widget-area">',
			'after' => '</div>',
	) );
}


//* Enqueue sticky menu script
add_action( 'wp_enqueue_scripts', 'sp_enqueue_script' );
function sp_enqueue_script() {
	wp_enqueue_script( 'sample-sticky-menu', get_bloginfo( 'stylesheet_directory' ) . '/js/sticky-menu.js', array( 'jquery' ), '1.0.0' );
}

// Remove custom headline and description on blog template pages.
remove_action( 'genesis_before_loop', 'genesis_do_blog_template_heading' );

//* Remove post meta
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

//* Reposition the secondary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before', 'genesis_do_subnav' );

//*Woo Support
add_theme_support( 'genesis-connect-woocommerce' );
