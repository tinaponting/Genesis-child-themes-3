<?php
/**
 * WordPress template for `portfolio` CPT's archive.
 */

add_action( 'genesis_before_content', 'her_isotope_filter', 20 );
/**
 * Displays Portfolio Categories Filter.
 */
function her_isotope_filter() {

    $terms = get_terms( 'portfolio_category' );

    $count = count( $terms );

    if ( $count > 0 ) { ?>
        <div class="portfolio-categories filter-button-group">
            <button class="active" data-filter="*"><?php esc_html_e( 'All', 'her-exclusive' ); ?></button>

            <?php foreach ( $terms as $term ) { ?>
                <button data-filter=".<?php echo esc_attr( $term->slug ); ?>"><?php echo esc_html( $term->name ); ?></button>
            <?php } ?>
        </div>
    <?php
    }

}

add_filter( 'post_class', 'her_add_taxonomy_term_class' );
/**
 * Adds type names in post class.
 *
 * @param array $classes Existing classes.
 * @return array Modified classes.
 */
function her_add_taxonomy_term_class( $classes ) {

    $terms = get_the_terms( get_the_ID(), 'portfolio_category' );

    if ( $terms ) {
        foreach ( $terms as $term ) {
            $classes[] = esc_attr( $term->slug );
        }
    }

    return $classes;
}

get_template_part( 'template', 'isotope' );

genesis();