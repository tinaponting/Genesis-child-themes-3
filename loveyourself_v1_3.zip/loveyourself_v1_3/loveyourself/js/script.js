// JavaScript Document
jQuery( function ( $ ) {
	$(".entry-content").fitVids();
	
	$('.nav-primary').attr('id', 'menu');
	$('.nav-primary').addClass('menu-min');
	
	/*if($("body").hasClass("logged-in")) {*/
		/*$("#menu").sticky({topSpacing: 45, className: "nav-primary"});*/
		/*$("#menu").css("top", "31px"); */
	/*} else {*/
		/*$("#menu").sticky({topSpacing: 0, className: "nav-primary"});*/
		//$("#menu").css("top", "0"); 
	//}
	
	//nambahspan
	$( "aside .widget .widget-wrap h4" ).wrapInner( "<span></span>");
	$( "body.category .archive-title" ).wrapInner( "<span></span>");
});
jQuery(document).ready(function($){
    var offset = 100;
    var speed = 250;
    var duration = 500;
	   $(window).scroll(function(){
            if ($(this).scrollTop() < offset) {
			     $('#back-top') .fadeOut(duration);
            } else {
			     $('#back-top') .fadeIn(duration);
            }
        });
	$('#back-top').on('click', function(){
		$('html, body').animate({scrollTop:0}, speed);
		return false;
		});
});

