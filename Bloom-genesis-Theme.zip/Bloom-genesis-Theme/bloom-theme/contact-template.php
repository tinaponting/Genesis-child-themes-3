<?php
/**
 * @package      bloom
 */

/*
Template Name: Contact
*/

add_action( 'genesis_meta', 'bloom_template_name_genesis_meta' );
/**
 * Add widget support for this template. If no widgets are active, display the default Genesis loop.
 *
 */
 
function bloom_template_name_genesis_meta() {
 
 if ( is_active_sidebar( 'bloom-contact-widget-left' ) ) {
 
 remove_action( 'genesis_loop', 'genesis_do_loop' );
 add_action( 'genesis_loop', 'bloom_template_name_widget_name' );
 }
}

 add_filter( 'body_class', 'add_body_class' );
 
 function add_body_class( $classes ) {
   $classes[] = 'bloom-contact';
   return $classes;
 }
 
 
//* Remove Page Title
remove_action('genesis_entry_header', 'genesis_do_post_title');

//* Force full width content layout
add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );


//* Contact Page - Left Widget Area
add_action( 'genesis_entry_content', 'bloom_contact_left' );
function bloom_contact_left() {
 
    genesis_widget_area( 'bloom-contact-left', array(
        'before' => '<div class="bloom-contact-left widget-area"><div class="wrap one-half first">',
        'after'  => '</div></div>', 
    ) );
    
}
 
//* Contact Page - Right Widget Area
add_action( 'genesis_entry_content', 'bloom_contact_right' );
function bloom_contact_right() {
 
    genesis_widget_area( 'bloom-contact-right', array(
        'before' => '<div class="bloom-contact-right widget-area"><div class="wrap one-half">',
        'after'  => '</div></div>', 
    ) );
    
}

genesis();