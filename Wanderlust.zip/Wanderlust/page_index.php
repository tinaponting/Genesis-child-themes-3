<?php
/**
* @package      Hello Beautiful
*/
 
/* Template Name: Category Index */

add_action( 'genesis_meta', 'bcs_category_genesis_meta' );
function bcs_category_genesis_meta() {
	if ( is_active_sidebar( 'category-index' )) {
		remove_action( 'genesis_loop', 'genesis_do_loop' );
		add_action( 'genesis_loop', 'bcs_category_sections' );
	}
}

function bcs_category_sections() {
	genesis_widget_area( 'category-index', array(
		'before' => '<div class="category-index widget-area">',
		'after'  => '</div>',
	) );
}

genesis();