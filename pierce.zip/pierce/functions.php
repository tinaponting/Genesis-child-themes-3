<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Pierce' );
define( 'CHILD_THEME_VERSION', '1.1' );

//* Enqueue Google Fonts
add_action( 'wp_enqueue_scripts', 'genesis_custom_google_fonts' );
function genesis_custom_google_fonts() {

	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Montserrat:400,700|Open+Sans:300,300italic,400,400italic,600,600italic,700,700italic', array(), CHILD_THEME_VERSION );

}

//* Enqueue scripts and styles
add_action( 'wp_enqueue_scripts', 'genesis_scripts_styles_mobile_responsive' );
function genesis_scripts_styles_mobile_responsive() {
	wp_enqueue_script( 'responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_style( 'dashicons' );
}

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

//* Add site-inner wrap
add_theme_support( 'genesis-structural-wraps', array('header','nav','subnav','site-inner','footer-widgets','footer') );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for 1-column footer widgets
add_theme_support( 'genesis-footer-widgets', 1 );

//* Remove alt sidebar
unregister_sidebar( 'sidebar-alt' );

//* Unregister layout settings
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );

//* Unregister primary/secondary navigation menus
remove_theme_support( 'genesis-menus' );

/**
 * Remove Genesis Page Templates
 * @param array $page_templates
 * @return array
 */
function genesis_remove_genesis_page_templates( $page_templates ) {
	unset( $page_templates['page_blog.php'] );
	return $page_templates;
}
add_filter( 'theme_page_templates', 'genesis_remove_genesis_page_templates' );

//* Remove Genesis child theme style sheet
remove_action( 'genesis_meta', 'genesis_load_stylesheet' );
 
//* Enqueue Genesis child theme style sheet at higher priority
add_action( 'wp_enqueue_scripts', 'genesis_enqueue_main_stylesheet', 15 );

//* Add Accessibility support
add_theme_support( 'genesis-accessibility', array( 'headings', 'drop-down-menu',  'search-form', 'skip-links' ) );

//* Register Front Page Widget 1
genesis_register_sidebar( array(
    'id'    => 'front-page-1',
    'name'    => __( 'Front Page 1', 'genesis' ),
    'description'    => __( 'This is the Front Page Widget 1 area.', 'Genesis' ),
) );

//* Register Front Page Widget 2
genesis_register_sidebar( array(
    'id'    => 'front-page-2',
    'name'    => __( 'Front Page 2', 'genesis' ),
    'description'    => __( 'This is the Front Page Widget 2 area.', 'Genesis' ),
) );

//* Register Front Page Widget 3
genesis_register_sidebar( array(
    'id'    => 'front-page-3',
    'name'    => __( 'Front Page 3', 'genesis' ),
    'description'    => __( 'This is the Front Page Widget 3 area.', 'Genesis' ),
) );

//* Register CTA
genesis_register_sidebar( array(
    'id'    => 'cta',
    'name'    => __( 'CTA', 'genesis' ),
    'description'    => __( 'This is the CTA area.', 'Genesis' ),
) );

//* Add the Front Page 1
add_action( 'genesis_after_header', 'custom_front_page_1', 15 );
function custom_front_page_1() {
if ( ! is_front_page() )
 return;
   genesis_widget_area( 'front-page-1', array(
	'before' => '<div class="front-page-1 widget-area"><div class="wrap">',
	'after' => '</div></div>',
   ) );
}

//* Add the Front Page 2
add_action( 'genesis_after_header', 'custom_front_page_2', 15 );
function custom_front_page_2() {
if ( ! is_front_page() )
 return;
   genesis_widget_area( 'front-page-2', array(
	'before' => '<div class="front-page-2 widget-area"><div class="wrap">',
	'after' => '</div></div>',
   ) );
}

//* Add the Front Page 3
add_action( 'genesis_after_header', 'custom_front_page_3', 15 );
function custom_front_page_3() {
if ( ! is_front_page() )
 return;
   genesis_widget_area( 'front-page-3', array(
	'before' => '<div class="front-page-3 widget-area"><div class="wrap">',
	'after' => '</div></div>',
   ) );
}

//* Add the CTA
add_action( 'genesis_before_footer', 'custom_cta', 5 );
function custom_cta() {
   genesis_widget_area( 'cta', array(
	'before' => '<div class="cta"><div class="wrap">',
	'after' => '</div></div>',
   ) );
}

//* Display title & excerpt featured image overlay on Front Page
add_filter( 'display_featured_image_genesis_excerpt_show_front_page_title', '__return_true' );

//* Remove Front Page content
add_action('genesis_before','remove_homepage_content');
function remove_homepage_content() {
        if (is_front_page() ) { 
        remove_action( 'genesis_loop', 'genesis_do_loop' );
	remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
	remove_action( 'genesis_sidebar_alt', 'genesis_do_sidebar_alt' );
        }
}

//* Increase content width for Jetpack tiled galleries
if ( ! isset( $content_width ) )
    $content_width = 800;