<?php
/**
 * Brief child theme.
 * @package Brief
 */

/**
 * Supported Genesis navigation menus.
 */
return array(
	'primary'   => __( 'Header Menu', 'brief' ),
	'secondary' => __( 'Footer Menu', 'brief' ),
);
