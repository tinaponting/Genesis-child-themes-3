jQuery(function( $ ){

	$('.posts-archive .content .entry, .category-index .featured-content .entry, .front-page-2 .widget_text .special-services-box, .front-page-4 .widget_text .special-services-box, .front-page-6 .widget_text .special-services-box').matchHeight();

});