<?php
/**
 * Post List Widget
 *
 * Register the widget for use in Appearance -> Widgets
 *
 * @package Prima Donna
 */
add_action( 'widgets_init', 'primadonna_postlist_widget_init' );

function primadonna_postlist_widget_init() {
	register_widget( 'Prima_Donna_Postlist_Widget' );
}

/**
 * Post List widget class
 */
class Prima_Donna_Postlist_Widget extends WP_Widget {

	/**
	 * Registers the widget with WordPress.
	 */
	function __construct() {

		parent::__construct(
			'postlist-primadonna',
			apply_filters( 'primadonna_widget_name', __( 'Prima Donna: Post List', 'primadonna' ) ),
			array(
				'classname'   => 'widget-postlist-primadonna',
				'description' => __( 'Display a post list.', 'primadonna' )
			)
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	function widget( $args, $instance ) {

		// Defaults
		$defaults = $this->defaults();

		// Merge the user-selected arguments with the defaults.
		$instance = wp_parse_args( (array) $instance, $defaults );

		// Open the output of the widget.
		echo $args['before_widget'];

?>
		<?php if ( ! empty( $instance['title'] ) ) : ?>
			<?php echo $args['before_title'] . apply_filters( 'widget_title',  $instance['title'], $instance, $this->id_base ) . $args['after_title']; ?>
		<?php endif; ?>

		<?php
		// Query Args
		$query_args = array( 'ignore_sticky_posts' => 1, 'posts_per_page' => $instance['postlist_limit'] );

		// Post Category
		if ( $instance['postlist_category'] > 0 ) {
			$query_args['cat'] = $instance['postlist_category'];
		}

		// Post Order
		if ( 2 == $instance['postlist_orderby'] ) {
			$query_args['orderby'] = 'comment_count';
		}

		// WP Query
		$postlist_query = new WP_Query( $query_args );
		if ( $postlist_query->have_posts() ) :
		?>
		<ul>
		<?php while( $postlist_query->have_posts() ) : $postlist_query->the_post(); ?>
			<li>
				<?php if ( has_post_thumbnail() ) : ?>
				<div class="postlist-thumbnail">
					<a href="<?php echo esc_url( get_permalink() ); ?>">
					<?php the_post_thumbnail( 'horizontal-entry-image', array( 'class' => 'img-postlist img-responsive' ) ); ?>
					</a>
				</div>
				<?php endif; ?>
				<?php the_title( '<h4 class="postlist-title"><a href="' . esc_url( get_permalink() ) . '">', '</a></h4>' ); ?>
				<div class="postlist-date"><?php echo esc_html( get_the_date() ); ?></div>
			</li>
		<?php endwhile; ?>
		</ul>
		<?php
		endif;
		// Reset Post Data
		wp_reset_postdata();
		?>

<?php

		/** Close the output of the widget. */
		echo $args['after_widget'];

	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	function update( $new_instance, $old_instance ) {

		// Instance
		$instance = $old_instance;

		// Sanitization
		$instance['title']             = strip_tags( $new_instance['title'] );
		$instance['postlist_category'] = absint( $new_instance['postlist_category'] );
		$instance['postlist_orderby']  = absint( $new_instance['postlist_orderby'] );
		$instance['postlist_limit']    = absint( $new_instance['postlist_limit'] );

		return $instance;

	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	function form( $instance ) {

		// Defaults
		$defaults = $this->defaults();

		// Merge the user-selected arguments with the defaults.
		$instance = wp_parse_args( (array) $instance, $defaults );

		// Controls
		$postlist_orderby = array (
			1 => __( 'Recent Posts',  'primadonna'),
			2 => __( 'Popular Posts', 'primadonna'),
		);
		$postlist_limit = range( 1, 20 );
?>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>">
				<?php esc_html_e( 'Title:', 'primadonna' ); ?>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo esc_attr( $instance['title'] ); ?>" />
			</label>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'postlist_category' ); ?>">
				<?php esc_html_e( 'Select Category:', 'primadonna' ); ?>
				<?php
				$args = array(
					'show_option_all'  => __( 'All Categories', 'primadonna' ),
					'selected'         => $instance['postlist_category'],
					'name'             => $this->get_field_name( 'postlist_category' ),
					'class'            => 'widefat',
				);
				wp_dropdown_categories( $args );
				?>
			</label>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'postlist_orderby' ); ?>">
				<?php esc_html_e( 'Post Order:', 'primadonna' ); ?>
	            <select class="widefat" id="<?php echo $this->get_field_id( 'postlist_orderby' ); ?>" name="<?php echo $this->get_field_name( 'postlist_orderby' ); ?>">
	              <?php foreach ( $postlist_orderby as $key => $val ): ?>
				    <option value="<?php echo esc_attr( $key ); ?>" <?php selected( $instance['postlist_orderby'], $key ); ?>><?php echo esc_html( $val ); ?></option>
				  <?php endforeach; ?>
	            </select>
            </label>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'postlist_limit' ); ?>">
				<?php esc_html_e( 'Number of posts to display:', 'primadonna' ); ?>
	            <select class="widefat" id="<?php echo $this->get_field_id( 'postlist_limit' ); ?>" name="<?php echo $this->get_field_name( 'postlist_limit' ); ?>">
	              <?php foreach ( $postlist_limit as $key => $val ): ?>
				    <option value="<?php echo esc_attr( $val ); ?>" <?php selected( $instance['postlist_limit'], $val ); ?>><?php echo esc_html( $val ); ?></option>
				  <?php endforeach; ?>
	            </select>
            </label>
		</p>

<?php
	}

	// Defaults
	function defaults() {

		$defaults = array (
			'title'             => __( 'Post List', 'primadonna'),
			'postlist_category' => 0,
			'postlist_orderby'  => 1,
			'postlist_limit'    => 5
		);

		return $defaults;

	}

}