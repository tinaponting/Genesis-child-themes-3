<div class="promo-area wrap promo3">
	
	<?php if(get_theme_mod('primadonna_front_promo1_title_setting') || get_theme_mod('primadonna_front_promo1_image_setting')) : ?>
	<div class="promo-item promo-item-1" style="background-image:url(<?php if(get_theme_mod('primadonna_front_promo1_image_setting')) { echo get_theme_mod('primadonna_front_promo1_image_setting'); } else { echo get_template_directory_uri() . '/img/slider-default.png'; } ?>)">
		<?php if(get_theme_mod('primadonna_front_promo1_url_setting')) : ?><a href="<?php echo get_theme_mod('primadonna_front_promo1_url_setting'); ?>" class="promo-link"></a><?php endif; ?>
		<div class="promo-overlay">
			<?php if(get_theme_mod('primadonna_front_promo1_title_setting')) : ?>
				<h4><?php echo get_theme_mod('primadonna_front_promo1_title_setting'); ?></h4>
			<?php endif; ?>
		</div>
	</div>
	<?php endif; ?>
	
	<?php if(get_theme_mod('primadonna_front_promo2_title_setting') || get_theme_mod('primadonna_front_promo2_image_setting')) : ?>
	<div class="promo-item promo-item-2" style="background-image:url(<?php if(get_theme_mod('primadonna_front_promo2_image_setting')) { echo get_theme_mod('primadonna_front_promo2_image_setting'); } else { echo get_template_directory_uri() . '/img/slider-default.png'; } ?>)">
		<?php if(get_theme_mod('primadonna_front_promo2_url_setting')) : ?><a href="<?php echo get_theme_mod('primadonna_front_promo2_url_setting'); ?>" class="promo-link"></a><?php endif; ?>
		<div class="promo-overlay">
			<?php if(get_theme_mod('primadonna_front_promo2_title_setting')) : ?>
				<h4><?php echo get_theme_mod('primadonna_front_promo2_title_setting'); ?></h4>
			<?php endif; ?>
		</div>
	</div>
	<?php endif; ?>
	
	<?php if(get_theme_mod('primadonna_front_promo3_title_setting') || get_theme_mod('primadonna_front_promo3_image_setting')) : ?>
	<div class="promo-item promo-item-3" style="background-image:url(<?php if(get_theme_mod('primadonna_front_promo3_image_setting')) { echo get_theme_mod('primadonna_front_promo3_image_setting'); } else { echo get_template_directory_uri() . '/img/slider-default.png'; } ?>)">
		<?php if(get_theme_mod('primadonna_front_promo3_url_setting')) : ?><a href="<?php echo get_theme_mod('primadonna_front_promo3_url_setting'); ?>" class="promo-link"></a><?php endif; ?>
		<div class="promo-overlay">
			<?php if(get_theme_mod('primadonna_front_promo3_title_setting')) : ?>
				<h4><?php echo get_theme_mod('primadonna_front_promo3_title_setting'); ?></h4>
			<?php endif; ?>
		</div>
	</div>
	<?php endif; ?>
	
</div>