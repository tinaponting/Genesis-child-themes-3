<?php
/**
 * This file adds all the functions to the Prima Donna theme.
 */

//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Setup Theme
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );

//* Add Theme Custom Customizer Settings
require_once( get_stylesheet_directory() . '/lib/custom_controller.php' );

//* Add Theme Customizer Sections
require_once( get_stylesheet_directory() . '/lib/customize.php' );

//* Include Customizer CSS
include_once( get_stylesheet_directory() . '/lib/output.php' );

//* Add Widget Spaces
require_once( get_stylesheet_directory() . '/lib/widgets.php' );

//* Add HTML5 markup structure
add_theme_support( 'html5' );

add_theme_support( 'title-tag' );

//* Add new featured image sizes
add_image_size( 'square-entry-image', 600, 600, TRUE );
add_image_size( 'vertical-entry-image', 400, 600, TRUE );
add_image_size( 'horizontal-entry-image', 900, 600, TRUE );
add_image_size( 'horizontal-image', 600, 400, TRUE );
add_image_size( 'blog-entry-image', 820, 500, TRUE );
add_image_size( 'full-thumbnail', 1200, 0, TRUE );
add_image_size( 'masonry-thumbnail', 400, 0, true );
add_image_size( 'carousel-thumb', 1170, 663, true );
add_image_size( 'boxed-slider', 1200, 565, true );
add_image_size( 'boxed-slider-alt', 790, 462.15, true );
add_image_size( 'full-slider', 1800, 565, true );
add_image_size( 'portfolio', 500, 500, TRUE );

// Custom background option
$defaults = array(
    'default-color'          => '',
    'default-image'          => '',
    'default-repeat'         => '',
    'default-position-x'     => '',
    'default-attachment'     => '',
    'wp-head-callback'       => '_custom_background_cb',
    'admin-head-callback'    => '',
    'admin-preview-callback' => ''
);
add_theme_support( 'custom-background', $defaults );

//* Add support for custom header
add_theme_support( 'custom-header', array(
    'header-selector' => '.site-title a',
    'header-text'     => false,
) );

//// Remove Genesis header style so we can use the customiser and header function primadonna_swap_header to add our header logo.
remove_action( 'wp_head', 'genesis_custom_header_style' );
/**
 * Add an image tag inline in the site title element for the main logo
 *
 * The header logo is then added via the Customiser
 *
 * @param string $title All the mark up title.
 * @param string $inside Mark up inside the title.
 * @param string $wrap Mark up on the title.
 * @author @_AlphaBlossom
 * @author @_neilgee
 */
function primadonna_swap_header( $title, $inside, $wrap ) {
    // Set what goes inside the wrapping tags.
    if ( get_header_image() ) :
        $logo = '<img  src="' . get_header_image() . '" width="' . esc_attr( get_custom_header()->width ) . '" height="' . esc_attr( get_custom_header()->height ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '">';
    else :
        $logo = get_bloginfo( 'name' );
    endif;
         $inside = sprintf( '<a href="%s" title="%s">%s</a>', trailingslashit( home_url() ), esc_attr( get_bloginfo( 'name' ) ), $logo );
         // Determine which wrapping tags to use - changed is_home to is_front_page to fix Genesis bug.
         $wrap = is_front_page() && 'title' === genesis_get_seo_option( 'home_h1_on' ) ? 'h1' : 'p';
         // A little fallback, in case an SEO plugin is active - changed is_home to is_front_page to fix Genesis bug.
         $wrap = is_front_page() && ! genesis_get_seo_option( 'home_h1_on' ) ? 'h1' : $wrap;
         // And finally, $wrap in h1 if HTML5 & semantic headings enabled.
         $wrap = genesis_html5() && genesis_get_seo_option( 'semantic_headings' ) ? 'h1' : $wrap;
         $title = sprintf( '<%1$s %2$s>%3$s</%1$s>', $wrap, genesis_attr( 'site-title' ), $inside );
         return $title;
}
add_filter( 'genesis_seo_title','primadonna_swap_header', 5, 3 );

//* Loads Responsive Menu, Google Fonts, Icons, and other scripts
add_action( 'wp_enqueue_scripts', 'primadonna_enqueue_scripts' );
function primadonna_enqueue_scripts() {

    // Register styles
	wp_register_style('owl-css', get_stylesheet_directory_uri() . '/css/owl.carousel.css');
	wp_register_style('owl-theme-css', get_stylesheet_directory_uri() . '/css/owl.theme.css');

    // Enqueue Styles
    wp_enqueue_style( 'google-font', '//fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700|Open+Sans:400,500,600,700', array() );
    wp_enqueue_style('primadonna-google-fonts', primadonna_fonts_url(), array(), null);
    wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css' );
	wp_enqueue_style('owl-css');
	wp_enqueue_style('owl-theme-css');

    // Register scripts
	wp_register_script('owl', get_stylesheet_directory_uri() . '/js/owl.carousel.min.js', 'jquery', '', true);

    //Enqueue Scripts
    wp_enqueue_script( 'global-script', get_stylesheet_directory_uri() . '/js/global.js', array( 'jquery' ), '1.0.0' );
    wp_enqueue_script( 'localScroll', get_stylesheet_directory_uri() . '/js/jquery.localScroll.min.js', array( 'scrollTo' ), '1.2.8b', true );
    wp_enqueue_script( 'scrollTo', get_stylesheet_directory_uri() . '/js/jquery.scrollTo.min.js', array( 'jquery' ), '1.4.5-beta', true );
    wp_enqueue_script( 'match-height', get_stylesheet_directory_uri() . '/js/jquery.matchHeight-min.js', array( 'jquery' ), '1.0.0', true );
    wp_enqueue_script( 'match-height-init', get_stylesheet_directory_uri() . '/js/matchheight-init.js', array( 'match-height' ), '1.0.0', true );
    wp_enqueue_script( 'masonry' );
	wp_enqueue_script('owl');
}

/********* Google Fonts URL function  ***********/
if ( ! function_exists( 'primadonna_fonts_url' ) ){
    function primadonna_fonts_url() {
        $fonts_url = '';
        $primarymenu_font = get_theme_mod('primarymenu_google_font_list', '');
        $primarymenu_dd_font = get_theme_mod('primarymenu_dd_google_font_list', '');
        $sitetitle_font = get_theme_mod('sitetitle_google_font_list', '');
        $sitedesc_font = get_theme_mod('sitedesc_google_font_list', '');
        $headermenu_font = get_theme_mod('headermenu_google_font_list', '');
        $headermenu_dd_font = get_theme_mod('headermenu_dd_google_font_list', '');
        $secmenu_font = get_theme_mod('secmenu_google_font_list', '');
        $secmenu_dd_font = get_theme_mod('secmenu_dd_google_font_list', '');
        $headings_font = get_theme_mod('headings_google_font_list', '');
        $content_font = get_theme_mod('body_google_font_list', '');
        $postsmeta_font = get_theme_mod('postmeta_google_font_list', '');
        $footermeta_font = get_theme_mod('footermeta_google_font_list', '');
        $sidebar_font = get_theme_mod('sidebar_google_font_list', '');
        $footer_menu_font = get_theme_mod('footer_menu_google_font_list', '');
        $footer_font = get_theme_mod('footer_google_font_list', '');
        $homepage_font = get_theme_mod('homepage_widget_google_font_list', '');
        $readmore_font = get_theme_mod('readmore_google_font_list', '');
        $button_font = get_theme_mod('buttons_google_font_list', '');

        // Translators: If there are characters in your language that are not supported by Google font, translate it to 'off'. Do not translate into your own language.
        // $content_font = _x( 'on', ''.$content_font.' font: on or off', 'yourtheme' );
 
 
        if ( 'off' !== $primarymenu_font || 'off' !== $primarymenu_dd_font || 'off' !== $sitetitle_font || 'off' !== $sitedesc_font || 'off' !== $headermenu_font || 'off' !== $headermenu_dd_font || 'off' !== $secmenu_font  || 'off' !== $secmenu_dd_font || 'off' !== $headings_font || 'off' !== $content_font || 'off' !== $postsmeta_font || 'off' !== $footermeta_font || 'off' !== $sidebar_font || 'off' !== $footer_menu_font || 'off' !== $footer_font || 'off' !== $homepage_font || 'off' !== $readmore_font || 'off' !== $button_font ) {
            $font_families = array();
 
            if ( 'off' !== $primarymenu_font ) {
                $font_families[] = $primarymenu_font;
            }

            if ( 'off' !== $primarymenu_dd_font ) {
                $font_families[] = $primarymenu_dd_font;
            }

            if ( 'off' !== $sitetitle_font ) {
                $font_families[] = $sitetitle_font;
            }

            if ( 'off' !== $sitedesc_font  ) {
                $font_families[] = $sitedesc_font;
            }

            if ( 'off' !== $headermenu_font ) {
                $font_families[] = $headermenu_font;
            }

            if ( 'off' !== $headermenu_dd_font ) {
                $font_families[] = $headermenu_dd_font;
            }

            if ( 'off' !== $secmenu_font ) {
                $font_families[] = $secmenu_font;
            }

            if ( 'off' !== $secmenu_dd_font ) {
                $font_families[] = $secmenu_dd_font;
            }

            if ( 'off' !== $headings_font ) {
                $font_families[] = $headings_font;
            }

            if ( 'off' !== $content_font ) {
                $font_families[] = $content_font;
            }

            if ( 'off' !== $postsmeta_font ) {
                $font_families[] = $postsmeta_font;
            }

            if ( 'off' !== $footermeta_font ) {
                $font_families[] = $footermeta_font;
            }

            if ( 'off' !== $sidebar_font ) {
                $font_families[] = $sidebar_font;
            }

            if ( 'off' !== $footer_menu_font ) {
                $font_families[] = $footer_menu_font;
            }

             if ( 'off' !== $footer_font ) {
                $font_families[] = $footer_font;
            }

            if ( 'off' !== $homepage_font ) {
                $font_families[] = $homepage_font;
            }

            if ( 'off' !== $readmore_font ) {
                $font_families[] = $readmore_font;
            }

            if ( 'off' !== $button_font ) {
                $font_families[] = $button_font;
            }
 
             $query_args = array(
                'family' => urlencode( implode( '|', array_unique($font_families) ) ),
            );
 
            $fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
        }
 
        return esc_url_raw( $fonts_url );
    }
}


/**
 * Add class for screen readers to site description.
 * This will keep the site description mark up but will not have any visual presence on the page
 * This runs if their is a header image set in the Customiser.
 *
 * @param string $attributes Add screen reader class.
 * @author @_AlphaBlossom
 * @author @_neilgee
 */
 function primadonna_add_site_description_class( $attributes ) {
        if ( get_header_image() ) :
            $attributes['class'] .= ' screen-reader-text';
            return $attributes;
        endif;
            return $attributes;
 }
 add_filter( 'genesis_attr_site-description', 'primadonna_add_site_description_class' );

function customize_register_init( $wp_customize ){
    // Edit section names
    $wp_customize->get_section('background_image')->title = __( 'Background & Accent Colors', 'primadonna' );
    $wp_customize->get_section('header_image')->title = __( 'Logo & Header', 'primadonna' );

    //Edit section order
    $wp_customize->get_section('static_front_page')->priority = 21;
    $wp_customize->get_section('header_image')->priority = 22;
    $wp_customize->get_section('background_image')->priority = 1;

    //Move to panels
    $wp_customize->get_section('background_image')->panel = 'panel_fonts';

    //Remove sections
    $wp_customize->remove_section( 'colors');
   
}

add_action( 'customize_register', 'customize_register_init' );

/**
 * This function adds some styles to the WordPress Customizer
 */
function my_customizer_styles() { ?>
    <style>
        span.customize-control-title {
            margin: 5px 0 20px;
            border-bottom:2px solid;
            padding:5px;
            color:#58719E;
            text-transform:uppercase;
        }
    </style>
    <?php

}
add_action( 'customize_controls_print_styles', 'my_customizer_styles', 999 );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for after entry widget
add_theme_support( 'genesis-after-entry-widget-area' );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Add Archive Settings option to Portolio CPT
add_post_type_support( 'portfolio', 'genesis-cpt-archives-settings' );

//* Unregister layout settings
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );

//* Unregister secondary sidebar
unregister_sidebar( 'sidebar-alt' );

//* Add Custom Widgets

include("lib/widgets/facebook_widget.php");
include("lib/widgets/widget-postlist.php");
include("lib/widgets/widget-postcarousel.php");
include("lib/widgets/post_widget.php");
include("lib/widgets/promo_widget.php");
include("lib/widgets/ad_widget.php");

//////////////////////////////////////////
// MENUS
//////////////////////////////////////////

//* Reposition the primary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before_header', 'genesis_do_nav', 7 );

/**
 * Add arrows to menu items
 * @param string $item_output, HTML output for the menu item
 * @param object $item, menu item object
 * @param int $depth, depth in menu structure
 * @param object $args, arguments passed to wp_nav_menu()
 * @return string $item_output
 */
function primadonna_arrows_in_menus( $item_output, $item, $depth, $args ) {
    if( in_array( 'menu-item-has-children', $item->classes ) ) {
        $arrow = 0 == $depth ? '<i class="fa fa-angle-down" aria-hidden="true"></i>' : '<i class="fa fa-angle-right" aria-hidden="true"></i>
';
        $item_output = str_replace( '</a>', $arrow . '</a>', $item_output );
    }
    return $item_output;
}
add_filter( 'walker_nav_menu_start_el', 'primadonna_arrows_in_menus', 10, 4 );

add_filter( 'wp_nav_menu_items', 'theme_menu_extras', 10, 2 );
/**
 * Filter menu items to append a search form.
 *
 * @param string   $menu HTML string of list items.
 * @param stdClass $args Menu arguments.
 *
 * @return string Amended HTML string of list items.
 */
function theme_menu_extras( $menu, $args ) {

	if ( 'primary' !== $args->theme_location )
		return $menu;

	$menu .= '</ul><div class="search"><a id="main-nav-search-link" class="icon-search"></a><div class="search-wrap"><div class="search-div">' . get_search_form( false ) . '</div></div></div>';
	
	return $menu;

}

//* Customize search form input button text
add_filter( 'genesis_search_button_text', 'sp_search_button_text' );
function sp_search_button_text( $text ) {
	return esc_attr( 'Go' );
}

//* Add widget to primary navigation
add_filter( 'genesis_nav_items', 'primadonna_social_icons', 10, 3 );
add_filter( 'wp_nav_menu_items', 'primadonna_social_icons', 10, 3 );

function primadonna_social_icons($menu, $args) {
	$args = (array)$args;
	if ( 'primary' !== $args['theme_location'] )
		return $menu;
	ob_start();
	genesis_widget_area('nav-social-menu');
	$social = ob_get_clean();
	return $menu . $social;
}

//* Add support for footer menu & rename menus
add_theme_support ( 'genesis-menus' , array ( 
	'primary'   => 'Above Header Menu', 
	'secondary' => 'Below Header Menu', 
	'footer'    => 'Footer Menu' 
) );

//* Hook menu in footer
add_action( 'genesis_before_footer', 'primadonna_footer_menu', 7 );
function primadonna_footer_menu() {

	printf( '<nav %s>', genesis_attr( 'nav-footer' ) );

	wp_nav_menu( array(
		'theme_location' => 'footer',
		'container'      => false,
		'depth'          => 1,
		'fallback_cb'    => false,
		'menu_class'     => 'genesis-nav-menu',		
		
	) );
	
	echo '</nav>';

}

//* Reduce the footer navigation menu to one level depth
add_filter( 'wp_nav_menu_args', 'primadonna_footer_menu_args' );
function primadonna_footer_menu_args( $args ){

	if( 'footer' != $args['theme_location'] ){
		return $args;
	}

	$args['depth'] = 1;
	return $args;

}
    
/////////////////////////////////////////////////////
// POST SETTINGS
////////////////////////////////////////////////////

/* Display Featured Image on top of the post */
$filayout = get_theme_mod( 'primadonna_fi_setting', 'true' );
if ( $filayout === 'false' ) {
add_action( 'genesis_entry_header', 'featured_post_image', 8 );
function featured_post_image() {
  if ( ! is_singular( 'post' ) )  return;
	the_post_thumbnail('full-thumbnail');
}
}

$filayout = get_theme_mod( 'primadonna_fi_setting', 'true' );
if ( $filayout === 'true' ) {
add_action( 'genesis_entry_content', 'featured_post_image', 8 );
function featured_post_image() {
  if ( ! is_singular( 'post' ) )  return;
    the_post_thumbnail('full-thumbnail');
}
}

/* Remove Image Alignment from Featured Image  */
// function primadonna_remove_image_alignment( $attributes ) {
//  $attributes['class'] = str_replace( 'alignleft', 'alignnone', $attributes['class'] );
//    return $attributes;
//}
//add_filter( 'genesis_attr_entry-image', 'primadonna_remove_image_alignment' );

//* Move Post info below title
remove_action( 'genesis_before_loop', 'genesis_do_taxonomy_title_description', 15 );
add_action( 'genesis_before_content', 'genesis_do_taxonomy_title_description', 15 );

//* Customize the post info function
add_filter( 'genesis_post_info', 'primadonna_post_info_filter' );
function primadonna_post_info_filter($post_info) {
if ( !is_page() ) {
	$post_info = '[post_date]';
	return $post_info;
}}

//* Add Post categories above Post title on single Posts
add_action ( 'genesis_entry_header', 'primadonna_show_category_name', 9 );
function primadonna_show_category_name() {

	echo do_shortcode('[post_categories before="" sep=", "]');
}



//* Add Post categories above Post title on single Posts
add_action ( 'genesis_after_entry_content', 'primadonna_show_tags_name', 9 );
function primadonna_show_tags_name() {
	if (is_single() ) {
	echo do_shortcode('[post_tags sep="" before=""]');
}}

//* Modify the WordPress read more link
add_filter( 'the_content_more_link', 'primadonna_read_more_link' );
function primadonna_read_more_link() {
    $readmore = get_theme_mod( 'primadonna_read_more_setting', 'continue reading' );
	return '<div class="read-more"><a class="more-link" href="' . get_permalink() . '">' . $readmore . '</a></div>';
}

//* Customize the post meta function - remove post meta
add_filter( 'genesis_post_meta', 'primadonna_post_meta_filter' );
function primadonna_post_meta_filter($post_meta) {
if ( !is_page() ) {
    $post_meta = '';
    return $post_meta;
}}

add_action( 'genesis_after_entry_content', 'primadonna_shop_the_post', 5 );
function primadonna_shop_the_post() {
    if (is_home() || is_archive() || is_single() ) {
    echo'<div class="shop-the-post">';
    echo genesis_get_custom_field('shop_the_post');
    echo do_shortcode(genesis_get_custom_field('shop_the_post_shortcode'));
    echo '</div>';
}
}

function primadonna_post_footer() {
    if (!is_page() ) {
    echo '<div class=\'post-footer-container\'><div class=\'post-footer-line post-footer-line-1\'>by ' . do_shortcode("[post_author_posts_link]") . '&nbsp;</div> <div class=\'post-footer-line post-footer-line-2\'>' . do_shortcode("[post_comments]") . '</div> <div class=\'post-footer-line post-footer-line-3\'>' . do_shortcode("[afterpost_share]") . '</div></div>';
}
}
add_filter( 'genesis_after_entry_content', 'primadonna_post_footer', 10 );



//* Afterpost Sharing Icons
function primadonna_afterpost_share() {
    global $post;
    return '<div class="post-sharing-icons">
        <a target="_blank" href="http://www.facebook.com/sharer.php?u=' . get_permalink() . '&amp;t=' . get_the_title() . ' " title="Share on Facebook!"><i class="fa fa-post-footer fa-facebook"></i></a>  
        <a target="_blank" href="http://twitter.com/home/?status=' . get_the_title() . '-' . get_permalink() . ' " title="Tweet this!"><i class="fa fa-post-footer fa-twitter"></i></a>  
        <a target="_blank" href="http://pinterest.com/pin/create/button/?url=' . get_permalink() . '&media=' . $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ) . '&description=' . get_the_title() . ' " title="Pin it!"><i class="fa fa-post-footer fa-pinterest-p"></i></a> 
        <a target="_blank" href="https://plus.google.com/share?url='. get_permalink() . ' "><i class="fa fa-post-footer fa-google-plus"></i></a>  
        <a href="mailto:?subject=' . get_the_title() . '&amp;body=' . get_permalink() . '" title="Send this article to a friend!"><i class="fa fa-post-footer fa-envelope"></i></a> 
        </div>';  
}

add_shortcode( 'afterpost_share', 'primadonna_afterpost_share' );


/**
 * Changing the AuthorBox in WordPress
 * 
 * @package   Changing the AuthorBox in WordPress
 */
//Change Default Method Contacts in User Profile
function primadonna_modify_user_contact_methods( $user_contact ){

  /* Add user contact methods */
  $user_contact['facebook'] = __( 'Facebook URL', 'primadonna' );
  $user_contact['twitter'] = __( 'Twitter URL', 'primadonna' );
  $user_contact['pinterest'] = __( 'Pinterest URL', 'primadonna' );
  $user_contact['linkedin'] = __( 'LinkedIn URL', 'primadonna' );  
  $user_contact['youtube'] = __( 'YouTube URL', 'primadonna' ); 

  /* Remove user contact methods */
  unset($user_contact['aim']);
  unset($user_contact['jabber']);
  unset($user_contact['yim']);
  return $user_contact;
}
add_filter( 'user_contactmethods', 'primadonna_modify_user_contact_methods' );

//Create New Author Box
function primadonna_alt_author_box() {
    if( is_single( '' ) ) {
//author box code goes here
			?>
	   		<div class="author-box"><?php echo get_avatar( get_the_author_meta( 'ID' ), '150' ); ?> 
                <div class="about-author"><h4>About <?php echo get_the_author(); ?></h4><p><?php echo get_the_author_meta( 'description' ); ?> 
            <div class="all-posts"><a href="<?php echo get_author_posts_url(  get_the_author_meta( 'ID' )); ?>">View all posts by <?php echo  get_the_author(); ?></a></div>

                <ul class="social-links">
	                
                <?php if ( get_the_author_meta( 'facebook' ) != '' ): ?>
                    <li><a target="_blank" href="<?php echo get_the_author_meta( 'facebook' ); ?>"><i class="fa fa-facebook"></i></a></li>
                <?php endif; ?>
                
                <?php if ( get_the_author_meta( 'twitter' ) != '' ): ?>
                    <li><a target="_blank" href="https://twitter.com/<?php echo get_the_author_meta( 'twitter' ); ?>"><i class="fa fa-twitter"></i></a></li>
                <?php endif; ?>

                <?php if ( get_the_author_meta( 'pinterest' ) != '' ): ?>
                    <li><a target="_blank" href="https://pinterest.com/<?php echo get_the_author_meta( 'pinterest' ); ?>"><i class="fa fa-pinterest"></i></a></li>
                <?php endif; ?>
                
                <?php if ( get_the_author_meta( 'googleplus' ) != '' ): ?>
                    <li><a target="_blank" href="<?php echo get_the_author_meta( 'googleplus' ); ?>"><i class="fa fa-google-plus"></i></a></li>
                <?php endif; ?>
                
                <?php if ( get_the_author_meta( 'linkedin' ) != '' ): ?>
                    <li><a target="_blank" href="<?php echo get_the_author_meta( 'linkedin' ); ?>"><i class="fa fa-linkedin"></i></a></li>
                <?php endif; ?>

                <?php if ( get_the_author_meta( 'youtube' ) != '' ): ?>
                    <li><a target="_blank" href="<?php echo get_the_author_meta( 'youtube' ); ?>"><i class="fa fa-youtube-play"></i></a></li>
                <?php endif; ?>
                
                <?php if ( get_the_author_meta( 'user_email' ) != '' ): ?>
                    <li><a href="mailto:<?php echo get_the_author_meta( 'user_email' ); ?>"><i class="fa fa-envelope"></i></a></li>
                <?php endif; ?>
                
                <?php  if ( get_the_author_meta( 'user_url' ) != '' ): ?>
                    <li><a target="_blank" href="<?php echo get_the_author_meta( 'user_url' ); ?>"><i class="fa fa-desktop"></i> </a></li>
                <?php endif; ?>
                
                </ul>
            </div>
         </div>
    <?php 
    }
}
remove_action( 'genesis_after_entry', 'genesis_do_author_box_single', 8 );
add_action( 'genesis_entry_footer', 'primadonna_alt_author_box', 10 );

// Related Posts
add_action( 'genesis_entry_footer', 'child_related_posts' );

function child_related_posts() {

if ( is_single ( ) ) {

global $post;

$count = 0;
$postIDs = array( $post->ID );
$related = '';
$tags = wp_get_post_tags( $post->ID );
$cats = wp_get_post_categories( $post->ID );

if ( $tags ) {

foreach ( $tags as $tag ) {

$tagID[] = $tag->term_id;

}

$args = array(
'tag__in' => $tagID,
'post__not_in' => $postIDs,
'showposts' => 4,
'ignore_sticky_posts' => 1,
'tax_query' => array(
array(
'taxonomy' => 'post_format',
'field' => 'slug',
'terms' => array(
'post-format-link',
'post-format-status',
'post-format-aside',
'post-format-quote'
),
'operator' => 'NOT IN'
)
)
);

$tag_query = new WP_Query( $args );

if ( $tag_query->have_posts() ) {

while ( $tag_query->have_posts() ) {

$tag_query->the_post();

$img = genesis_get_image() ? genesis_get_image( array( 'size' => 'square-entry-image' ) ) : '<img src="' . get_stylesheet_directory_uri() . '/images/related.png" alt="' . get_the_title() . '" />';

$related .= '<li><a href="' . get_permalink() . '" rel="bookmark" title="Permanent Link to' . get_the_title() . '">' . $img . get_the_title() . '</a></li>';

$postIDs[] = $post->ID;

$count++;
}
}
}

if ( $count <= 3 ) {

$catIDs = array( );

foreach ( $cats as $cat ) {

if ( 2 == $cat )
continue;
$catIDs[] = $cat;

}

$showposts = 4 - $count;

$args = array(
'category__in' => $catIDs,
'post__not_in' => $postIDs,
'showposts' => $showposts,
'ignore_sticky_posts' => 1,
'orderby' => 'rand',
'tax_query' => array(
array(
'taxonomy' => 'post_format',
'field' => 'slug',
'terms' => array(
'post-format-link',
'post-format-status',
'post-format-aside',
'post-format-quote' ),
'operator' => 'NOT IN'
)
)
);

$cat_query = new WP_Query( $args );

if ( $cat_query->have_posts() ) {

while ( $cat_query->have_posts() ) {

$cat_query->the_post();

$img = genesis_get_image() ? genesis_get_image( array( 'size' => 'square-entry-image' ) ) : '<img src="' . get_stylesheet_directory_uri() . '/images/related.png" alt="' . get_the_title() . '" />';

$related .= '<li><a href="' . get_permalink() . '" rel="bookmark" title="Permanent Link to' . get_the_title() . '">' . $img . get_the_title() . '</a></li>';
}
}
}

if ( $related ) {

printf( '<div class="related-posts"><h3 class="related-title">Related Posts</h3><ul class="related-list">%s</ul></div>', $related );

}

wp_reset_query();

}
}

/** Genesis Previous/Next Post Post Navigation */

add_action( 'genesis_before_comments', 'primadonna_prev_next_post_nav' );
 
function primadonna_prev_next_post_nav() {
  
	if ( is_single() ) {

        $previous = get_theme_mod( 'primadonna_previous_setting', 'previous article' );
        $next = get_theme_mod( 'primadonna_next_setting', 'next article' );
		echo '<div class="adjacent-entry-pagination pagination">';
		previous_post_link( '<div class="pagination-previous alignleft">' . $previous . ': %link</div>', '%title' );
		next_post_link( '<div class="pagination-next alignright">' . $next . ': %link</div>', '%title' );
		echo '</div><!-- .adjacent-entry-pagination -->';
	}
 
}

remove_action( 'genesis_list_comments', 'genesis_default_list_comments' );
add_action( 'genesis_list_comments', 'primadonna_list_comments' );

function primadonna_list_comments() {
    $defaults = array(
        'type'        => 'comment',
        'avatar_size' => 64,
        'format'      => 'html5',
        'callback'    => 'primadonna_comment_callback', // <-- this is the change
    );

    $args = apply_filters( 'genesis_comment_list_args', $defaults );
    wp_list_comments( $args );
}

// Comments Layout
function primadonna_comment_callback( $comment, array $args, $depth ) {

    $GLOBALS['comment'] = $comment; ?>

    <li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">

        <?php do_action( 'genesis_before_comment' ); ?>

        <div class="comment-header">
            <div class="comment-author vcard">
                <?php echo get_avatar( $comment, $args['avatar_size'] ); ?>
            </div>

            <div class="comment-text">
	            <div class="comment-meta commentmetadata">
	            	<?php printf( __( '<cite class="comment-author">%s</cite> <span class="says">%s:</span>', 'genesis' ), get_comment_author_link(), apply_filters( 'comment_author_says_text', __( 'says', 'genesis' ) ) ); ?>
	                 <a class="comment-time-link" href="<?php echo esc_url( get_comment_link( $comment->comment_ID ) ); ?>"><?php printf( __( '%1$s at %2$s', 'genesis' ), get_comment_date(), get_comment_time() ); ?></a>
	            </div>
	        </div>

	        <div class="comment-content">
	            <?php if ( ! $comment->comment_approved ) : ?>
	                <p class="alert"><?php echo apply_filters( 'genesis_comment_awaiting_moderation', __( 'Your comment is awaiting moderation.', 'genesis' ) ); ?></p>
	            <?php endif; ?>

	            <?php comment_text(); ?>
	        </div>
	        <div class="reply">
            	<?php edit_comment_link( __( 'Edit', 'genesis' ), '' ); ?>
        		<?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
        	</div>
	    </div>

        <?php do_action( 'genesis_after_comment' );

    //* No ending </li> tag because of comment threading

}

// Modify the speak your mind title in comments - Comment Box title -
//
add_filter( 'comment_form_defaults', 'primadonna_comment_form_defaults' );
function primadonna_comment_form_defaults( $defaults ) {
	$defaults['title_reply'] = __( 'Leave Your Comment', 'primadonna' );
	return $defaults;
}

// Changing the mini Comment title to something else 
//
function primadonna_modify_comment_form_text_area($arg) {
    $arg['comment_field'] = '<p class="comment-form-comment"><label for="comment">' . _x( '', 'noun', 'primadonna' ) . '</label><textarea id="comment" name="comment" cols="55" rows="7" aria-required="true"></textarea></p>';
    return $arg;
}
add_filter('comment_form_defaults', 'primadonna_modify_comment_form_text_area');

// Customize The Comment Form
add_filter( 'comment_form_defaults', 'primadonna_custom_comment_form' );
function primadonna_custom_comment_form($fields) {
    $fields['title_reply'] = __( '<span>Leave Your Comments</span>', 'primadonna' ); //Changes The Form Headline
	$fields['label_submit'] = __( 'Submit', 'customtheme' ); //Changes The Submit Button Text
	$fields['comment_notes_after'] = ''; //Removes Form Allowed Tags Box
    return $fields;
}

/* Add Placehoder in comment Form Fields (Name, Email, Website) */
 
add_filter( 'comment_form_default_fields', 'help4cms_comment_placeholders' );
function help4cms_comment_placeholders( $fields )
{
    $fields['author'] = str_replace(
        '<input',
        '<input placeholder="Your Name"',
        $fields['author']
    );
    $fields['email'] = str_replace(
        '<input',
        '<input placeholder="Email Address"',
        $fields['email']
    );
    $fields['url'] = str_replace(
        '<input',
        '<input placeholder="Your Website"',
        $fields['url']
    );
    return $fields;
}
 
/* Add Placehoder in comment Form Field (Comment) */
add_filter( 'comment_form_defaults', 'help4cms_textarea_placeholder' );
 
function help4cms_textarea_placeholder( $fields )
{
  
        $fields['comment_field'] = str_replace(
            '<textarea',
            '<textarea placeholder="Your thoughts"',
            $fields['comment_field']
        );
   
 
    return $fields;
}

///////////////////////////////////////////////////
// WIDGETS
//////////////////////////////////////////////////
//* Setup widget counts
function primadonna_count_widgets( $id ) {

	global $sidebars_widgets;

	if ( isset( $sidebars_widgets[ $id ] ) ) {
		return count( $sidebars_widgets[ $id ] );
	}

}

//* Flexible widget classes
function primadonna_widget_area_class( $id ) {

	$count = primadonna_count_widgets( $id );

	$class = '';

	if( $count == 1 ) {
		$class .= ' widget-full';
	} elseif( $count % 3 == 1 ) {
		$class .= ' widget-thirds';
	} elseif( $count % 4 == 1 ) {
		$class .= ' widget-fourths';
	} elseif( $count % 2 == 0 ) {
		$class .= ' widget-halves uneven';
	} else {	
		$class .= ' widget-halves even';
	}
	return $class;

}

// Customize Tag Cloud Widget font size
function primadonna_tag_cloud_widget($args) {
	$args['largest'] = 12; //largest tag
	$args['smallest'] = 12; //smallest tag
	$args['unit'] = 'px'; //tag font unit
	return $args;
}
add_filter( 'widget_tag_cloud_args', 'primadonna_tag_cloud_widget' );

// Modify the size of the Gravatar in the User Profile Widget
 
add_filter( 'genesis_gravatar_sizes', 'primadonna_user_profile' );
function primadonna_user_profile( $sizes ) {
    $sizes['Extra Large Image'] = 300;
    return $sizes;
}

//* Hooks Widget Area Above Content
add_action( 'genesis_after_header', 'primadonna_widget_above_content'  ); 
function primadonna_widget_above_content() {

if ( !is_home() ) {

    genesis_widget_area( 'widget-above-content', array(
		'before' => '<div class="widget-above-content widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );

}}

//* Hooks Widget Area Below Footer
add_action( 'genesis_before_footer', 'primadonna_widget_below_footer', 10 ); 
function primadonna_widget_below_footer() {

    genesis_widget_area( 'widget-below-footer', array(
		'before' => '<div class="widget-below-footer widget-area">',
		'after'  => '</div>',
    ) );

}


//* Customize the credits
add_filter( 'genesis_footer_creds_text', 'primadonna_footer_creds_text' );
function primadonna_footer_creds_text() {

    echo '<div class="creds"><p>';
    echo 'Copyright &copy; ';
    echo date('Y');
    echo ' &middot; <a target="_blank" href="https://exempel.se">EXEMPEL</a> by <a target="_blank" href="https://exempel.se">MY name or blog title/a>';
    echo '</p></div>';

}

// Add To Top button
add_action( 'genesis_before', 'genesis_to_top');
    function genesis_to_top() {
     echo '<a class="backtotop" href="#"><i class="fa fa-angle-up"></i></a>';
}

/////////////////////////////////////////////////
// WOOCOMMERCE
////////////////////////////////////////////////

add_action( 'after_setup_theme', 'primadonna_woocommerce_support' );
    function primadonna_woocommerce_support() {
    add_theme_support( 'woocommerce' );
}

// Add WooCommerce support for Genesis layouts (sidebar, full-width, etc) 
add_post_type_support( 'product', array( 'genesis-layouts', 'genesis-seo' ) );
// Unhook WooCommerce Sidebar - use Genesis Sidebars instead
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
// Unhook WooCommerce wrappers
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
// Hook new functions with Genesis wrappers
add_action( 'woocommerce_before_main_content', 'primadonna_my_theme_wrapper_start', 10 );
add_action( 'woocommerce_after_main_content', 'primadonna_my_theme_wrapper_end', 10 );
// Add opening wrapper before WooCommerce loop
function primadonna_my_theme_wrapper_start() {
 do_action( 'genesis_before_content_sidebar_wrap' );
 genesis_markup( array(
 'html5' => '<div %s>',
 'xhtml' => '<div id="content-sidebar-wrap">',
 'context' => 'content-sidebar-wrap',
 ) );
 do_action( 'genesis_before_content' );
 genesis_markup( array(
 'html5' => '<main %s>',
 'xhtml' => '<div id="content" class="hfeed">',
 'context' => 'content',
 ) );
 do_action( 'genesis_before_loop' );
}
/* Add closing wrapper after WooCommerce loop */
function primadonna_my_theme_wrapper_end() {
 do_action( 'genesis_after_loop' );
 genesis_markup( array(
 'html5' => '</main>', //* end .content
 'xhtml' => '</div>', //* end #content
 ) );
 do_action( 'genesis_after_content' );
 echo '</div>'; //* end .content-sidebar-wrap or #content-sidebar-wrap
 do_action( 'genesis_after_content_sidebar_wrap' );
}

// Remove WooCommerce breadcrumbs, using Genesis crumbs instead.
add_action( 'get_header', 'primadonna_remove_wc_breadcrumbs' );
function primadonna_remove_wc_breadcrumbs() {
 remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );
}

//* Change number or products per row to 3
add_filter('loop_shop_columns', 'loop_columns');
if (!function_exists('loop_columns')) {
    function loop_columns() {
        return 3; // 3 products per row
    }
}

// Option to make full width on all pages
if ( class_exists( 'WooCommerce' ) ) {
$woosidebar = get_theme_mod( 'primadonna_woocommerce_sidebar_setting', 'false' );
if ( $woosidebar === 'false' ) {
function primadonna_cpt_layout() {
    if( is_page ( array( 'cart', 'checkout' )) || is_shop() || 'product' == get_post_type() ) {
        return 'full-width-content';
    }
}
add_filter( 'genesis_site_layout', 'primadonna_cpt_layout' );
}
}

add_action( 'after_setup_theme', 'primadonna_woo_extras' );

function primadonna_woo_extras() {
add_theme_support( 'wc-product-gallery-lightbox' );
add_theme_support( 'wc-product-gallery-slider' );
}

//////////////////////////////////////////////////
// ADMIN DOCS LINK
/////////////////////////////////////////////////
function primadonna_docs_notice() {
    ?>
    <div class="updated notice">
        <p><?php _e( '<i>Thanks for shopping with us!</i> We hope you enjoy your new WordPress theme from Georgia Lou Studios. You can find all your theme documentation <strong><a href="https://exempel.zendesk.com/hc/en-us/sections/myshop" target="_blank">here.</a></strong>', 'quebella' ); ?></p>
    </div>
    <?php
}
add_action( 'admin_notices', 'primadonna_docs_notice' );


//////////////////////////////////////////////////
// DEMO CONTENT
/////////////////////////////////////////////////
function ocdi_import_files() {
    return array(
        array(
            'import_file_name'             => 'Demo Import 1 - Default',
            'local_import_file'            => trailingslashit( get_stylesheet_directory() ) . 'ocdi/demo-content.xml',
            'local_import_widget_file'     => trailingslashit( get_stylesheet_directory() ) . 'ocdi/widgets.wie',
            'local_import_customizer_file' => trailingslashit( get_stylesheet_directory() ) . 'ocdi/customizer.dat',
            'import_preview_image_url'     => 'https://exempel.se/wp-content/uploads/2016/10/prima-donna-default.png',
            'import_notice'                => __( 'You will need to assign a menu to your menu location. See in Dashboard docs for help.', 'primadonna' ),
        ),
        array(
            'import_file_name'             => 'Demo Import 2 - Fashion',
            'local_import_file'            => trailingslashit( get_stylesheet_directory() ) . 'ocdi/demo-content2.xml',
            'local_import_widget_file'     => trailingslashit( get_stylesheet_directory() ) . 'ocdi/widgets2.wie',
            'local_import_customizer_file' => trailingslashit( get_stylesheet_directory() ) . 'ocdi/customizer2.dat',
            'import_preview_image_url'     => 'https://exempels.se/wp-content/uploads/2016/10/prima-donna-fashion.png',
            'import_notice'                => __( 'You will need to assign a menu to your menu location. See in Dashboard docs for help.', 'primadonna' ),
        ),
        array(
            'import_file_name'             => 'Demo Import 3 - Minimal',
            'local_import_file'            => trailingslashit( get_stylesheet_directory() ) . 'ocdi/demo-content3.xml',
            'local_import_widget_file'     => trailingslashit( get_stylesheet_directory() ) . 'ocdi/widgets3.wie',
            'local_import_customizer_file' => trailingslashit( get_stylesheet_directory() ) . 'ocdi/customizer3.dat',
            'import_preview_image_url'     => 'https://exempel.se/wp-content/uploads/2016/10/prima-donna-minimal.png',
            'import_notice'                => __( 'You will need to assign a menu to your menu location. See in Dashboard docs for help.', 'primadonna' ),
        ),
        array(
            'import_file_name'             => 'Demo Import 4 - Girly',
            'local_import_file'            => trailingslashit( get_stylesheet_directory() ) . 'ocdi/demo-content4.xml',
            'local_import_widget_file'     => trailingslashit( get_stylesheet_directory() ) . 'ocdi/widgets4.wie',
            'local_import_customizer_file' => trailingslashit( get_stylesheet_directory() ) . 'ocdi/customizer4.dat',
            'import_preview_image_url'     => 'https://exempel.se/wp-content/uploads/2016/10/prima-donna-girly.png',
            'import_notice'                => __( 'You will need to assign a menu to your menu location. See in Dashboard docs for help.', 'primadonna' ),
        ),
    );
}
add_filter( 'pt-ocdi/import_files', 'ocdi_import_files' );

function ocdi_after_import_setup() {
    // Assign menus to their locations.
    $main_menu = get_term_by( 'name', 'Top Menu', 'nav_menu' );
    $footer_menu = get_term_by( 'name', 'Secondary Menu', 'nav_menu' );

    set_theme_mod( 'nav_menu_locations', array(
            'primary' => $main_menu->term_id,
            'secondary' => $main_menu->term_id,
        )
    );
}
add_action( 'pt-ocdi/after_import', 'ocdi_after_import_setup' );

/////////////////////////////////////////////////
// RECOMMENDED PLUGINS
////////////////////////////////////////////////

/**
 * This file represents an example of the code that themes would use to register
 * the required plugins.
 * @package    TGM-Plugin-Activation
 * @subpackage Example
 */

/**
 * Include the TGM_Plugin_Activation class.
 *
 */
require_once get_stylesheet_directory() . '/class-tgm-plugin-activation.php';

add_action( 'tgmpa_register', 'primadonna_register_required_plugins' );

/**
 * Register the required plugins for this theme.
 *
 * In this example, we register five plugins:
 * - one included with the TGMPA library
 * - two from an external source, one from an arbitrary source, one from a GitHub repository
 * - two from the .org repo, where one demonstrates the use of the `is_callable` argument
 *
 * The variables passed to the `tgmpa()` function should be:
 * - an array of plugin arrays;
 * - optionally a configuration array.
 * If you are not changing anything in the configuration array, you can remove the array and remove the
 * variable from the function call: `tgmpa( $plugins );`.
 * In that case, the TGMPA default settings will be used.
 *
 * This function is hooked into `tgmpa_register`, which is fired on the WP `init` action on priority 10.
 */
function primadonna_register_required_plugins() {
	/*
	 * Array of plugin arrays. Required keys are name and slug.
	 * If the source is NOT from the .org repo, then source is also required.
	 */
	$plugins = array(
        array(
            'name'                  => 'GLS Admin Zendesk Help Widget', // The plugin name
            'slug'                  => 'gls-wordpress-zendesk-admin', // The plugin slug (typically the folder name)
            'source'                => get_stylesheet_directory() . '/plugins/gls-wordpress-zendesk-admin.zip', // The plugin source
            'required'              => true, // If false, the plugin is only 'recommended' instead of required
            'version'               => '', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
            'force_activation'      => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
            'force_deactivation'    => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
            'external_url'          => '', // If set, overrides default API URL and points to an external URL
        ),
		array(
			'name'     				=> 'Lightweight Social Icons', // The plugin name
			'slug'     				=> 'lightweight-social-icons', // The plugin slug (typically the folder name)
			'required' 				=> false, // If false, the plugin is only 'recommended' instead of required
			'version' 				=> '', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
			'force_activation' 		=> false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
			'force_deactivation' 	=> false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
			'external_url' 			=> '', // If set, overrides default API URL and points to an external URL
		),
		array(
			'name'     				=> 'WP Instagram Widget', // The plugin name
			'slug'     				=> 'wp-instagram-widget', // The plugin slug (typically the folder name)
			'required' 				=> false, // If false, the plugin is only 'recommended' instead of required
			'version' 				=> '', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
			'force_activation' 		=> false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
			'force_deactivation' 	=> false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
			'external_url' 			=> '', // If set, overrides default API URL and points to an external URL
		),
		array(
			'name'     				=> 'Contact Form 7', // The plugin name
			'slug'     				=> 'contact-form-7', // The plugin slug (typically the folder name)
			'required' 				=> false, // If false, the plugin is only 'recommended' instead of required
			'version' 				=> '', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
			'force_activation' 		=> false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
			'force_deactivation' 	=> false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
			'external_url' 			=> '', // If set, overrides default API URL and points to an external URL
		),
		array(
			'name'     				=> 'Regenerate Thumbnails', // The plugin name
			'slug'     				=> 'regenerate-thumbnails', // The plugin slug (typically the folder name)
			'required' 				=> false, // If false, the plugin is only 'recommended' instead of required
			'version' 				=> '', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
			'force_activation' 		=> false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
			'force_deactivation' 	=> false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
			'external_url' 			=> '', // If set, overrides default API URL and points to an external URL
		),
		array(
			'name'     				=> 'Smart Slider 3', // The plugin name
			'slug'     				=> 'smart-slider-3', // The plugin slug (typically the folder name)
			'required' 				=> false, // If false, the plugin is only 'recommended' instead of required
			'version' 				=> '', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
			'force_activation' 		=> false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
			'force_deactivation' 	=> false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
			'external_url' 			=> '', // If set, overrides default API URL and points to an external URL
		),
		array(
			'name'     				=> 'AccessPress Social Icons', // The plugin name
			'slug'     				=> 'accesspress-social-icons', // The plugin slug (typically the folder name)
			'required' 				=> false, // If false, the plugin is only 'recommended' instead of required
			'version' 				=> '', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
			'force_activation' 		=> false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
			'force_deactivation' 	=> false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
			'external_url' 			=> '', // If set, overrides default API URL and points to an external URL
		),
        array(
            'name'                  => 'Genesis Portfolio Pro', // The plugin name
            'slug'                  => 'genesis-portfolio-pro', // The plugin slug (typically the folder name)
            'required'              => false, // If false, the plugin is only 'recommended' instead of required
            'version'               => '', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
            'force_activation'      => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
            'force_deactivation'    => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
            'external_url'          => '', // If set, overrides default API URL and points to an external URL
        ),
        array(
            'name'                  => 'Genesis Responsive Slider', // The plugin name
            'slug'                  => 'genesis-responsive-slider', // The plugin slug (typically the folder name)
            'required'              => false, // If false, the plugin is only 'recommended' instead of required
            'version'               => '', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
            'force_activation'      => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
            'force_deactivation'    => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
            'external_url'          => '', // If set, overrides default API URL and points to an external URL
        ),
        array(
            'name'                  => 'Genesis eNews Extended', // The plugin name
            'slug'                  => 'genesis-enews-extended', // The plugin slug (typically the folder name)
            'required'              => false, // If false, the plugin is only 'recommended' instead of required
            'version'               => '', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
            'force_activation'      => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
            'force_deactivation'    => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
            'external_url'          => '', // If set, overrides default API URL and points to an external URL
        ),
        array(
            'name'                  => 'One Click Demo Import', // The plugin name
            'slug'                  => 'one-click-demo-import', // The plugin slug (typically the folder name)
            'required'              => false, // If false, the plugin is only 'recommended' instead of required
            'version'               => '', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
            'force_activation'      => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
            'force_deactivation'    => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
            'external_url'          => '', // If set, overrides default API URL and points to an external URL
        ),
        array(
            'name'                  => 'Image Widget', // The plugin name
            'slug'                  => 'image-widget', // The plugin slug (typically the folder name)
            'required'              => false, // If false, the plugin is only 'recommended' instead of required
            'version'               => '', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
            'force_activation'      => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
            'force_deactivation'    => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
            'external_url'          => '', // If set, overrides default API URL and points to an external URL
        ),
	);

	/*
	 * Array of configuration settings. Amend each line as needed.
	 *
	 * TGMPA will start providing localized text strings soon. If you already have translations of our standard
	 * strings available, please help us make TGMPA even better by giving us access to these translations or by
	 * sending in a pull-request with .po file(s) with the translations.
	 *
	 * Only uncomment the strings in the config array if you want to customize the strings.
	 */
	$config = array(
		'id'           => 'primadonna',                 // Unique ID for hashing notices for multiple instances of TGMPA.
		'default_path' => '',                      // Default absolute path to bundled plugins.
		'menu'         => 'tgmpa-install-plugins', // Menu slug.
		'parent_slug'  => 'themes.php',            // Parent menu slug.
		'capability'   => 'edit_theme_options',    // Capability needed to view plugin install page, should be a capability associated with the parent menu used.
		'has_notices'  => true,                    // Show admin notices or not.
		'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
		'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
		'is_automatic' => true,                   // Automatically activate plugins after installation or not.
		'message'      => '',                      // Message to output right before the plugins table.

		'strings'      => array(
			'page_title'                      => __( 'Install Required Plugins', 'primadonna' ),
			'menu_title'                      => __( 'Install Plugins', 'primadonna' ),
			'installing'                      => __( 'Installing Plugin: %s', 'primadonna' ),
			'updating'                        => __( 'Updating Plugin: %s', 'primadonna' ),
			'oops'                            => __( 'Something went wrong with the plugin API.', 'primadonna' ),
			'notice_can_install_required'     => _n_noop(
				'This theme requires the following plugin: %1$s.',
				'This theme requires the following plugins: %1$s.',
				'primadonna'
			),
			'notice_can_install_recommended'  => _n_noop(
				'This theme recommends the following plugin: %1$s.',
				'This theme recommends the following plugins: %1$s.',
				'primadonna'
			),
			'notice_ask_to_update'            => _n_noop(
				'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.',
				'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.',
				'primadonna'
			),
			'notice_ask_to_update_maybe'      => _n_noop(
				'There is an update available for: %1$s.',
				'There are updates available for the following plugins: %1$s.',
				'primadonna'
			),
			'notice_can_activate_required'    => _n_noop(
				'The following required plugin is currently inactive: %1$s.',
				'The following required plugins are currently inactive: %1$s.',
				'primadonna'
			),
			'notice_can_activate_recommended' => _n_noop(
				'The following recommended plugin is currently inactive: %1$s.',
				'The following recommended plugins are currently inactive: %1$s.',
				'primadonna'
			),
			'install_link'                    => _n_noop(
				'Begin installing plugin',
				'Begin installing plugins',
				'primadonna'
			),
			'update_link' 					  => _n_noop(
				'Begin updating plugin',
				'Begin updating plugins',
				'primadonna'
			),
			'activate_link'                   => _n_noop(
				'Begin activating plugin',
				'Begin activating plugins',
				'primadonna'
			),
			'return'                          => __( 'Return to Required Plugins Installer', 'primadonna' ),
			'plugin_activated'                => __( 'Plugin activated successfully.', 'primadonna' ),
			'activated_successfully'          => __( 'The following plugin was activated successfully:', 'primadonna' ),
			'plugin_already_active'           => __( 'No action taken. Plugin %1$s was already active.', 'primadonna' ),
			'plugin_needs_higher_version'     => __( 'Plugin not activated. A higher version of %s is needed for this theme. Please update the plugin.', 'primadonna' ),
			'complete'                        => __( 'All plugins installed and activated successfully. %1$s', 'primadonna' ),
			'dismiss'                         => __( 'Dismiss this notice', 'primadonna' ),
			'notice_cannot_install_activate'  => __( 'There are one or more required or recommended plugins to install, update or activate.', 'primadonna' ),
			'contact_admin'                   => __( 'Please contact the administrator of this site for help.', 'primadonna' ),

			'nag_type'                        => '', // Determines admin notice type - can only be one of the typical WP notice classes, such as 'updated', 'update-nag', 'notice-warning', 'notice-info' or 'error'. Some of which may not work as expected in older WP versions.
		),
	);

	tgmpa( $plugins, $config );
}