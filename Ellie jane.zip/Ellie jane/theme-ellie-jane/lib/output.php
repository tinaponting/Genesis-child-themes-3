<?php
/**
 * Ellie Jane.
 * @package Ellie Jane
 */

add_action( 'wp_enqueue_scripts', 'ellie_custom_css' );
/**
 * Check to see if there is a new value for link color or the accent color, and if
 * so, print that value to the theme's main stylesheet.
 *
 * @since 3.2.0
 */
function ellie_custom_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';

	$color_link   = get_theme_mod( 'ellie_link_color', ellie_customizer_get_default_link_color() );
	$color_accent = get_theme_mod( 'ellie_accent_color', ellie_customizer_get_default_accent_color() );
	$color_main = get_theme_mod( 'ellie_main_color', ellie_customizer_get_default_main_color() );
	$color_white = get_theme_mod( 'ellie_white_color', ellie_customizer_get_default_white_color() );
	$color_white_hover = get_theme_mod( 'ellie_white_color_hover', ellie_customizer_get_default_white_color_hover() );
	$color_title = get_theme_mod( 'ellie_title_color', ellie_customizer_get_default_title_color() );
	$color_description = get_theme_mod( 'ellie_description_color', ellie_customizer_get_default_description_color() );
	$color_body = get_theme_mod( 'ellie_body_font_color', ellie_customizer_get_default_body_font_color() );
	$color_entry = get_theme_mod( 'ellie_entry_title_color', ellie_customizer_get_default_entry_title_color() );

	$css = '';

	$css .= ( ellie_customizer_get_default_link_color() !== $color_link ) ? sprintf( '

		a,
		.featuredpost a.more-link,
		.entry-title a:focus,
		.entry-title a:hover,
		.site-footer a {
			color: %1$s;
		}

		', $color_link ) : '';

	$css .= ( ellie_customizer_get_default_accent_color() !== $color_accent ) ? sprintf( '

		button,
		input[type="button"],
		input[type="reset"],
		input[type="submit"],
		.button,
		.widget-title,
		.nav-primary,
		.archive-pagination li a:focus,
		.archive-pagination li a:hover,
		.archive-pagination li.active a,
		.footer-widgets .enews-widget input[type="submit"] {
			border-bottom-color: %1$s;
		}
		
		.site-footer,
		.entry-footer {
			border-top-color: %1$s;
		}

		.home-page-2 .enews-widget input[type="submit"], 
		.widget-above-content .enews-widget input[type="submit"],
		.sidebar .enews-widget input[type="submit"] {
			background-color: %1$s;
		}

		#sharing_email .sharing_send, 
		.sd-content ul li .option a.share-ustom, 
		.sd-content ul li a.sd-button, 
		.sd-content ul li.advanced a.share-more, 
		.sd-content ul li.preview-item div.option.option-smart-off a, 
		.sd-social-icon .sd-content ul li a.sd-button, 
		.sd-social-icon-text .sd-content ul li a.sd-button, 
		.sd-social-official .sd-content > ul > li .digg_button > a, 
		.sd-social-official .sd-content > ul > li > a.sd-button, 
		.sd-social-text .sd-content ul li a.sd-button {
			border-bottom-color: %1$s !important; 
		}

		.soliloquy-container .soliloquy-caption a.soliloquy-button {
			color: %1$s !important;
		}

		', $color_accent ) : '';

		$css .= ( ellie_customizer_get_default_main_color() !== $color_main ) ? sprintf( '

		.home-page-2 .widget.enews-widget,
		.widget-above-content .widget.enews-widget,
		.widget-title,
		a.more-link, 
		.more-from-category a,
		.sidebar .enews,
		.site-footer,
		div.filter button,
		button, 
		input[type="button"], 
		input[type="reset"], 
		input[type="submit"], 
		.button {
			background-color: %1$s;
		}

		.nav-primary,
		.nav-secondary,
		nav.genesis-responsive-menu,
		.genesis-nav-menu .sub-menu a,
		.genesis-nav-menu .sub-menu a:focus,
		.genesis-nav-menu .sub-menu a:hover,
		.genesis-nav-menu li > a:focus,
		.genesis-nav-menu li > a:hover,
		.genesis-nav-menu a:focus,
		.genesis-nav-menu a:hover,
		.genesis-nav-menu .current-menu-item > a,
		.genesis-responsive-menu .genesis-nav-menu .menu-item a,
		.menu-toggle,
		.menu-toggle:hover,
		.menu-toggle:focus,
		.sub-menu-toggle:hover,
		.sub-menu-toggle:focus,
		.sub-menu-toggle,
		#genesis-mobile-nav-secondary,
		.nav-secondary.genesis-responsive-menu,
		.nav-secondary.genesis-responsive-menu .genesis-nav-menu .menu-item a,
		.genesis-responsive-menu .genesis-nav-menu .sub-menu {
			background-color: %1$s;

		}

		.content div.sharedaddy a.sd-button,
		#sharing_email .sharing_send, .sd-content ul li .option a.share-ustom, 
		.sd-content ul li a.sd-button, .sd-content ul li.advanced a.share-more, 
		.sd-content ul li.preview-item div.option.option-smart-off a, 
		.sd-social-icon .sd-content ul li a.sd-button, .sd-social-icon-text .sd-content ul li a.sd-button, 
		.sd-social-official .sd-content > ul > li .digg_button > a, 
		.sd-social-official .sd-content > ul > li > a.sd-button, .sd-social-text .sd-content ul li a.sd-button {
			background: %1$s !important;
		}

		.content .share-filled .facebook .count,
		.content .share-filled .facebook .count:hover,
		.content .share-filled .googlePlus .count,
		.content .share-filled .googlePlus .count:hover,
		.content .share-filled .linkedin .count,
		.content .share-filled .linkedin .count:hover,
		.content .share-filled .pinterest .count,
		.content .share-filled .pinterest .count:hover,
		.content .share-filled .stumbleupon .count,
		.content .share-filled .stumbleupon .count:hover,
		.content .share-filled .twitter .count,
		.content .share-filled .twitter .count:hover {
			color: %1$s;
			border-color: %1$s;
		}

		.content .share-filled .facebook .share,
		.content .share-filled .facebook:hover .count,
		.content .share-filled .googlePlus .share,
		.content .share-filled .googlePlus:hover .count,
		.content .share-filled .linkedin .share,
		.content .share-filled .linkedin:hover .count,
		.content .share-filled .pinterest .share,
		.content .share-filled .pinterest:hover .count,
		.content .share-filled .stumbleupon .share,
		.content .share-filled .stumbleupon:hover .count,
		.content .share-filled .twitter .share,
		.content .share-filled .twitter:hover .count {
			background: %1$s !important;
		}

		.content .share-filled .facebook:hover .count,
		.content .share-filled .googlePlus:hover .count,
		.content .share-filled .linkedin:hover .count,
		.content .share-filled .pinterest:hover .count,
		.content .share-filled .stumbleupon:hover .count,
		.content .share-filled .twitter:hover .count {
			color: %1$s;
		}

		', $color_main ) : '';

	$css .= ( ellie_customizer_get_default_white_color() !== $color_white ) ? sprintf( '

		.genesis-nav-menu a,
		.genesis-nav-menu a:focus, 
		.genesis-nav-menu .current-menu-item > a, 
		.genesis-nav-menu .sub-menu a,
		.genesis-nav-menu .sub-menu .current-menu-item > a:focus,
		.widget-title,
		.home-page-2 .enews-widget p, 
		.widget-above-content .enews-widget p,
		.home-page-2 .enews-widget .widget-title, 
		.widget-above-content .enews-widget .widget-title,
		a.more-link, 
		.more-from-category a,
		a.more-link:hover, 
		.more-from-category a:hover,
		.site-footer,
		.sidebar .enews-widget, 
		.sidebar .enews-widget .widget-title,
		.site-footer .genesis-nav-menu a,
		div.filter button,
		button, input[type="button"], input[type="reset"], input[type="submit"], 
		.button,
		.menu-toggle, 
		.sub-menu-toggle,
		.nav-secondary.genesis-responsive-menu .genesis-nav-menu .menu-item a,
		#genesis-mobile-nav-secondary {
			color: %1$s;
		}

		', $color_white ) : '';

	$css .= ( ellie_customizer_get_default_white_color_hover() !== $color_white_hover ) ? sprintf( '

		
		.nav-primary .genesis-nav-menu a:focus,
		.nav-primary .genesis-nav-menu a:hover,
		.nav-primary .genesis-nav-menu li.menu-item-has-children:focus > a,
		.nav-primary .genesis-nav-menu li.menu-item-has-children:hover > a,
		.genesis-nav-menu .sub-menu .current-menu-item > a:hover,
		.genesis-nav-menu .sub-menu a:hover,
		.nav-secondary .genesis-nav-menu a:focus,
		.nav-secondary .genesis-nav-menu a:hover,
		.nav-secondary .genesis-nav-menu li.menu-item-has-children:focus > a,
		.nav-secondary .genesis-nav-menu li.menu-item-has-children:hover > a,
		.menu-toggle:focus,
		.menu-toggle:hover,
		.sub-menu-toggle:focus,
		.sub-menu-toggle:hover,
		.site-footer .genesis-nav-menu a:hover,
		.nav-secondary.genesis-responsive-menu .genesis-nav-menu .menu-item a:hover {
			color: %1$s;
		}

	', $color_white_hover ) : '';

	$css .= ( ellie_customizer_get_default_title_color() !== $color_title ) ? sprintf( '

		.site-title a, 
		.site-title a:hover, .site-title a:focus {
			color: %1$s;
		}
		
		', $color_title ) : '';

	$css .= ( ellie_customizer_get_default_description_color() !== $color_description ) ? sprintf( '

		.site-description {
			color: %1$s;
		}
	
	', $color_description ) : '';

	$css .= ( ellie_customizer_get_default_body_font_color() !== $color_body ) ? sprintf( '

		body {
			color: %1$s;
		}

		.soliloquy-caption-inside {
			color: %1$s !important;
		}
		
		', $color_body ) : '';

	$css .= ( ellie_customizer_get_default_entry_title_color() !== $color_entry ) ? sprintf( '

		.entry-title a, .sidebar .widget-title a,
		.footer-widgets .widget-title,
		.archive-pagination li a,
		h1, h2, h3, h4, h5, h6,
		div.filter button:hover, div.filter button.active,
		.soliloquy-caption h4.title,
		.after-entry.widget-area .widget-title {
			color: %1$s;
		}
		
		', $color_entry ) : '';


	if ( $css ) {
		wp_add_inline_style( $handle, $css );
	}

}