jQuery(function( $ ){

	$(".nav-primary .genesis-nav-menu, .nav-secondary .genesis-nav-menu, .nav-header .genesis-nav-menu").addClass("responsive-menu").before('<div class="responsive-menu-icon"></div>');

	$(".responsive-menu-icon").click(function(){
		$(this).next(".nav-primary .genesis-nav-menu, .nav-secondary .genesis-nav-menu, .nav-header .genesis-nav-menu").slideToggle();
	});

	$(window).resize(function(){
		if(window.innerWidth > 800) {
			$(".nav-primary .genesis-nav-menu, .nav-secondary .genesis-nav-menu, .nav-header .genesis-nav-menu, nav .sub-menu").removeAttr("style");
			$(".responsive-menu > .menu-item").removeClass("menu-open");
		}
	});
	

	$(".responsive-menu > .menu-item").click(function(event){
		if (event.target !== this)
		return;
			$(this).find(".sub-menu:first").slideToggle(function() {
			$(this).parent().toggleClass("menu-open");
		});
	});
	
	// Local Scroll Speed
	$.localScroll({
		duration: 500
	});

	// Search

	$('#main-nav-search-link').click(function(){
		$('.search-div').show('slow');
	});

	$("*", document.body).click(function(event){
		// event.stopPropagation();
		var el = $(event.target);
		var gsfrm = $(el).closest('form');
		if(el.attr('id') !='main-nav-search-link' && el.attr('role') != 'search' && gsfrm.attr('role') != 'search'){
			$('.search-div').hide('slow');
		}
	}); 

	// Post Carousel
		$(".primadonna-postcarousel").owlCarousel({
		navigation : true,
		pagination: false,
		autoPlay: true,
		stopOnHover: true,
		navigationText: ["&#8249;", "&#8250;"],
		singleItem:true
	});


	// Owl Carousel
	$(".featured-area-carousel #owl-demo").owlCarousel({
		navigation : false,
		pagination: true,
		autoPlay: true,
		stopOnHover: true,
		margin: 10,
		items : 2,
		itemsDesktop : [1199, 2],
		itemsDesktopSmall : [980,2],
		itemsTablet: [800,1],
		itemsTabletSmall: [568,1],
		itemsMobile : [479,1],
	});

	$(".featured-area-full #owl-demo").owlCarousel({
		singleItem: true,
        responsive: true,
        lazyLoad: true,
        autoPlay: 5e3,
        stopOnHover: true,
		pagination: true,	
		navigation: false,
		slideSpeed: 1000,
		paginationSpeed: 1000
	});

	$(".featured-area #owl-demo").owlCarousel({
		singleItem:true,
        responsive: true,
        lazyLoad: true,
        autoPlay: 5e3,
        stopOnHover: true,
		pagination: false,	
		navigation: true,
		navigationText: ["&#8249;", "&#8250;"],
		slideSpeed: 1000,
		paginationSpeed: 1000
	});

	  //Lookbook page
  	  if ($(".page-template-page_blog .post .entry-header").length){  
        $(".page-template-page_blog .post .entry-header").click(function() {
          window.location = $(this).find("h2 a").attr("href"); 
          return false;
        });
    }

});

 //Menu Opacity function
jQuery(document).ready(function($) {

	"use strict";

$(document).scroll(function(){
     $('.nav-primary').toggleClass('menuOpacity2', $(this).scrollTop() > 50);
 });
    });

//Scroll to top

jQuery(document).ready(function() {

	"use strict";
	
var offset = 300;
var duration = 1000;
jQuery(window).scroll(function() {
if (jQuery(this).scrollTop() > offset) {
jQuery('.backtotop').fadeIn(duration);
} else {
jQuery('.backtotop').fadeOut(duration);
}
});

jQuery('.backtotop').click(function(event) {
event.preventDefault();
jQuery('html, body').animate({scrollTop: 0}, duration);
return false;
})
});