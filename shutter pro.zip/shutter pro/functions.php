<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Set Localization (do not remove)
load_child_theme_textdomain( 'shutter', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/languages', 'shutter' ) );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', __( 'Shutter Pro Theme', 'shutter' ) );
define( 'CHILD_THEME_VERSION', '2.0' );




//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Enqueue Google Fonts and JS scripts
add_action( 'wp_enqueue_scripts', 'shutter_enqueue_scripts' );
function shutter_enqueue_scripts() {


	wp_enqueue_style( 'google-font', '//fonts.googleapis.com/css?family=Open+Sans:300,400,700', array(), PARENT_THEME_VERSION );
	wp_enqueue_script( 'shutter-responsive-menu', get_bloginfo( 'stylesheet_directory' ) . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0' );
	wp_enqueue_script( 'shutter-sticky-menu', get_bloginfo( 'stylesheet_directory' ) . '/js/sticky-menu.js', array( 'jquery' ), '1.0.0' );

}

//* Force full-width-content layout setting
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );


//* Add Color Selection to WordPress Theme Customizer
require_once( get_stylesheet_directory() . '/lib/customize.php' );


//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Unregister layout settings
genesis_unregister_layout( 'content-sidebar' );
genesis_unregister_layout( 'sidebar-content' );
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );

//* Unregister secondary navigation menu
add_theme_support( 'genesis-menus', array( 'primary' => __( 'Primary Navigation Menu', 'shutter' ) ) );

//* Unregister sidebars
unregister_sidebar( 'sidebar' );
unregister_sidebar( 'sidebar-alt' );
unregister_sidebar( 'header-right' );



//* Reposition the primary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before', 'genesis_do_nav' );

//* Customize the post info function
add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
if ( !is_page() ) {
	$post_info = '[post_date]';
	return $post_info;
} }

//* Customize the entry meta in the entry footer
add_filter( 'genesis_post_meta', 'sp_post_meta_filter' );
function sp_post_meta_filter( $post_meta ) {
	$post_meta = '[post_categories before=""] [post_comments] [oto_jetpack_share]';
	return $post_meta;
}

/** Modify post navigation */
add_action('genesis_before_comments', 'genesis_post_nav');
function genesis_post_nav(){

    echo '<div class="post-nav">';
    echo '<div class="next-post-nav">';
    echo '<span class="next">';
    echo 'Next Post';
    echo '</span>';
    echo next_post_link('%link', '%title');
    echo '</div>';
    echo '<div class="prev-post-nav">';
    echo '<span class="prev">';
    echo 'Previous Post';
    echo '</span>';
    echo previous_post_link('%link', '%title');
    echo '</div>';
    echo '</div>';

}



//* Modify the size of the Gravatar in the entry comments
add_filter( 'genesis_comment_list_args', 'shutter_comments_gravatar' );
function shutter_comments_gravatar( $args ) {

	$args['avatar_size'] = 150;
	return $args;

}

//* Add edit link below entries on single post pages
add_action( 'genesis_entry_content', 'shutter_edit_link' );
	function shutter_edit_link() {
	if ( is_single() ) {
		edit_post_link( __( '(Edit)', 'shutter' ), '<p>', '</p>' );
	}
}

//* Add Oops! to 404 page
add_action( 'genesis_loop', 'shutter_404_page', 9 );
	function shutter_404_page() {
	if ( is_404() ) {
		echo '<div class="oops-404"><p>' . __( 'Oops!', 'shutter' ) . '</p></div>';
	}
}


//* Remove comment form allowed tags
add_filter( 'comment_form_defaults', 'shutter_remove_comment_form_allowed_tags' );
function shutter_remove_comment_form_allowed_tags( $defaults ) {
	
	$defaults['comment_notes_after'] = '';
	return $defaults;

}


/** Add new image sizes **/
add_image_size( 'post-photo', 1100, 500, true );


//* Change footer text
add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');
function custom_footer_creds_text($creds) {
	$creds = 'Copyright [footer_copyright] &middot; ' . get_bloginfo(' name') . ' &middot; Theme by <a href="http://wackyjacquisdesigns.com/" target="_blank">Wacky Jacquis Designs</a>';
 	return  $creds;
}

// Move image above post title in Genesis Framework 2.0
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
add_action( 'genesis_entry_header', 'genesis_do_post_image', 8 );




 // Instagram Feed custom filter
add_filter( 'wpiw_item_class', 'my_instagram_class' );
function my_instagram_class( $classes ) {
$classes = "one-sixth";
return $classes;
}


// Move Jetpack from the_content / the_excerpt using shortcode
 
function jptweak_remove_share() {
    remove_filter( 'the_content', 'sharing_display',19 );
    remove_filter( 'the_excerpt', 'sharing_display',19 );
    if ( class_exists( 'Jetpack_Likes' ) ) {
        remove_filter( 'the_content', array( Jetpack_Likes::init(), 'post_likes' ), 30, 1 );
    }
}
  
add_action( 'loop_start', 'jptweak_remove_share' );
 
function oto_jetpack_share_func( $atts ){
     
    if ( function_exists( 'sharing_display' ) ) {
        sharing_display( '', true );
    }
      
    if ( class_exists( 'Jetpack_Likes' ) ) {
        $custom_likes = new Jetpack_Likes;
        return $custom_likes->post_likes( '' );
    }
 
}
add_shortcode( 'oto_jetpack_share', 'oto_jetpack_share_func' );
