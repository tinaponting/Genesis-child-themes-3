<?php
//* Add archive body class to the head
add_filter( 'body_class', 'her_add_archive_body_class' );
function her_add_archive_body_class( $classes ) {
   $classes[] = 'c-archive';
   return $classes;
}

// Force full width content.
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

/**
 * Display as Columns.
 *
 */
function be_portfolio_post_class( $classes ) {

    if ( is_main_query() ) { // conditional to ensure that column classes do not apply to Featured widgets
        $columns = 3; // Set the number of columns here

        $column_classes = array( '', '', 'one-half', 'one-third', 'one-fourth', 'one-fifth', 'one-sixth' );
        $classes[] = $column_classes[$columns];
        global $wp_query;
        if( 0 == $wp_query->current_post || 0 == $wp_query->current_post % $columns )
            $classes[] = 'first';
    }

    return $classes;
}
add_filter( 'post_class', 'be_portfolio_post_class' );

// Remove all actions from entry hooks.
$hooks = array(
	'genesis_entry_header',
    'genesis_entry_content',
    'genesis_entry_footer',
);

foreach ( $hooks as $hook ) {
    remove_all_actions( $hook );
}

add_action( 'genesis_before_while', 'custom_posts_wrap_open' );
/**
 * Add opening div.posts tag for posts.
 */
function custom_posts_wrap_open() {
    echo '<div class="posts">';
}

add_action( 'genesis_after_endwhile', 'custom_posts_wrap_close' );
/**
 * Add closing div.posts tag for posts.
 */
function custom_posts_wrap_close() {
    echo '</div>';
}

// Entry header.
add_action ( 'genesis_entry_header', 'her_archive_featured_image' );

function her_archive_featured_image() {
	if ( ! has_post_thumbnail() ) {
        return;
	}

	global $wp_query;

	if( ( $wp_query->post ) ) {
		$image_args = array(
			'size' => 'vertical-image',
			'attr' => array(
			'class' => 'aligncenter',
			),
		);
	
	}
	
	$image = genesis_get_image( $image_args );
	
	echo '<div class="archive-featured-image"><a href="' . get_permalink() . '">' . $image .'<h6 class="overlay">View <i>the</i> Post</h6></a></div>';
	
}

// Entry content.
add_action( 'genesis_entry_content', 'genesis_do_post_title' );
add_action( 'genesis_entry_content', 'genesis_post_info' );

add_filter( 'genesis_post_info', 'custom_post_info' );
/**
 * Customize post info.
 *
 * @param  string $post_info Existing post info
 * @return string            Modified post info
 */
function custom_post_info( $post_info ) {
    $post_info = '[post_date]';

    return $post_info;
}


genesis();