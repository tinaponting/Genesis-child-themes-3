<?php
/**
 * This file adds the Portfolio template to the Delightful Theme.
 *
 */
 
/*
Template Name: Portfolio
*/

/** Force the full width layout layout on the Portfolio page */
add_filter( 'genesis_pre_get_option_site_layout', 'delightful_portfolio_layout' );
function delightful_portfolio_layout( $opt ) {
	return 'full-width-content';
}

/** Remove the standard loop */
remove_action( 'genesis_loop', 'genesis_do_loop' );

/** Add the Portfolio widget area */
add_action( 'genesis_loop', 'delightful_porfolio_widget' );
function delightful_porfolio_widget() {
	dynamic_sidebar( 'portfolio' );
}

genesis();