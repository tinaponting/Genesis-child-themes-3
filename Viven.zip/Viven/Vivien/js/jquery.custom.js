jQuery.noConflict();
jQuery(document).ready(function(jQuery) {
/*-------------------------------------------------*/
// Isotope Filter Effect
/*-------------------------------------------------*/
	// cache container
	var jQuerycontainer = jQuery('#container');
	jQuerycontainer.isotope({
		 itemSelector : '.element'
	});
	//filter
	var jQueryoptionSets = jQuery('#options .option-set'),
	  jQueryoptionLinks = jQueryoptionSets.find('a');
							
		  jQueryoptionLinks.click(function(){
			var jQuerythis = jQuery(this);
	
			// don't proceed if already selected
			if ( jQuerythis.hasClass('selected') ) {
			  return false;
			}
		
			var jQueryoptionSet = jQuerythis.parents('.option-set');
			jQueryoptionSet.find('.selected').removeClass('selected');
			jQuerythis.addClass('selected');
								  
			// make option object dynamically, i.e. { filter: '.my-filter-class' }
			var options = {},
				key = jQueryoptionSet.attr('data-option-key'),
				value = jQuerythis.attr('data-option-value');
				// parse 'false' as false boolean
				value = value === 'false' ? false : value;
				options[ key ] = value;
			
			if ( key === 'layoutMode' && typeof changeLayoutMode === 'function' ) {
			  // changes in layout modes need extra logic
			  changeLayoutMode( jQuerythis, options )
			} else {
			 // otherwise, apply new options
				jQuerycontainer.isotope( options );
			}
										
			return false;
	});
/*-------------------------------------------------*/
// Portfolio Hover Effect
/*-------------------------------------------------*/			
	jQuery('.portfolio_image').hover(function(){	
		jQuery(this).children('.icon').css({display: 'block'});
	}, function(){
		jQuery(this).children('.icon').css({display: 'none'});		
	});
/*-------------------------------------------------*/
// Tooltip
/*-------------------------------------------------*/
		
			jQuery(".hastip").tipTip({defaultPosition: "bottom", offset:-10});
			
			
/*-------------------------------------------------*/
// Mobile Menu
/*-------------------------------------------------*/				
		jQuery( '#mobile_menu' ).click(function(){
			jQuery( '.nav-primary' ).slideToggle();	
		});
/*-------------------------------------------------*/
// Lightbox (Prettyphoto)
/*-------------------------------------------------*/	
			jQuery("a[rel^='prettyPhoto']").prettyPhoto({
				theme: 'light_rounded',
				counter_separator_label: ' of '
			});
/*-------------------------------------------------*/
// Image Hover
/*-------------------------------------------------*/	
			jQuery( ".ad img, .portfolio-large img" ).hover( 
				function( ) {
					jQuery( this ).animate( {"opacity": ".8"}, "fast" );
					},
				function( ) {
					jQuery( this ).animate( {"opacity": "1"}, "fast" );
			} );			
								
							
/*-------------------------------------------------*/
// Toggle 
/*-------------------------------------------------*/	
			jQuery( ".toggle-container" ).hide( );	 
			jQuery( ".trigger" ).toggle( function( ){
				jQuery( this ).addClass( "active" );
				}, function ( ) {
				jQuery( this ).removeClass( "active" );
			} );
			jQuery( ".trigger" ).click( function( ){
				jQuery( this ).next( ".toggle-container" ).slideToggle( );
			} );
			jQuery( '.trigger a' ).hover( function( ) {
			jQuery( this ).stop( true,false ).animate( {color: '#666'},50 );
				}, function ( ) {
				jQuery( this ).stop( true,false ).animate( {color: '#888'},150 );
			} );
/*-------------------------------------------------*/
// Accordion
/*-------------------------------------------------*/	
			jQuery( '.accordion' ).hide( );
			jQuery( '.trigger-button' ).click( function( ) {
				jQuery( ".trigger-button" ).removeClass( "active" )
				jQuery( '.accordion' ).slideUp( 'normal' );
				if( jQuery( this ).next( ).is( ':hidden' ) == true ) {
					jQuery( this ).next( ).slideDown( 'normal' );
					jQuery( this ).addClass( "active" );
				 } 
			 } );
			 jQuery( '.trigger-button' ).hover( function( ) {
				jQuery( this ).stop( true,false ).animate( {color: '#666'},50 );
					}, function ( ) {
					jQuery( this ).stop( true,false ).animate( {color: '#888'},150 );
			} );	
			
/*-------------------------------------------------*/
//	To Top Link
/*-------------------------------------------------*/
		jQuery.fn.topLink = function(settings) {
			settings = jQuery.extend({
				min: 1,
				fadeSpeed: 200
				},
				settings );
				return this.each(function() {
					// listen for scroll
					var el = jQuery(this);
					el.hide(); // in case the user forgot
					jQuery(window).scroll(function() {
					if(jQuery(window).scrollTop() >= settings.min) {
					el.fadeIn(settings.fadeSpeed);
					} else {
					el.fadeOut(settings.fadeSpeed);
					}
				});
			});
			};
			
			jQuery(document).ready(function() {
				jQuery('#top-link').topLink({
				min: 400,
				fadeSpeed: 500
				});
				
			
				jQuery('#top-link').click(function() {
					 jQuery(' html body').stop().animate({
		
								scrollTop: jQuery('.site-container').offset().top
		
							}, 1000);
						   //e.preventDefault();
				});
			});	
});

jQuery(window).load(function(){
	var jQuerycontainer = jQuery('#container');
	jQuerycontainer.isotope({
		 itemSelector : '.element'
	});
});
/* ========== refresh isotope on window resize ========== */
jQuery( window ).resize(function() {
	var jQuerycontainer = jQuery('#container');
	jQuerycontainer.isotope({
		 itemSelector : '.element'
	});
});