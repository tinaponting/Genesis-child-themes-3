<?php
/**
 * This file is the custom portfolio post type archive template.
 *
 */

// Add portfolio body class
add_filter( 'body_class', 'ellie_add_portfolio_body_class' );
function ellie_add_portfolio_body_class( $classes ) {

	$classes[] = 'filterable-portfolio';
	return $classes;

}

// Load Isotope & imagesLoaded and initialize Isotope
wp_enqueue_script( 'isotope', get_stylesheet_directory_uri() . '/js/isotope.pkgd.min.js', array( 'jquery' ), '2.2.2', true );

wp_enqueue_script( 'imagesLoaded', get_stylesheet_directory_uri() . '/js/imagesloaded.pkgd.min.js', '', '3.2.0', true );

wp_enqueue_script( 'isotope_init', get_stylesheet_directory_uri() . '/js/isotope_init.js', array( 'isotope', 'imagesLoaded' ), '1.0.0', true );

// Force full width content layout
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

// Remove the breadcrumb navigation
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );

// Reposition Title and Description on Portfolio taxonomy Archives
remove_action( 'genesis_before_loop', 'genesis_do_taxonomy_title_description', 15 );
add_action( 'genesis_before_content', 'genesis_do_taxonomy_title_description' );

// Portfolio Categories Filter Row
add_action( 'genesis_before_loop', 'ellie_isotope_filter' );
function ellie_isotope_filter() {

	// Display only on the CPT Archive
	if ( is_post_type_archive( 'portfolio' ) )

		$terms = get_terms( 'portfolio_category' );
		$count = count( $terms ); $i=0;
		if ( $count > 0 ) { ?>
			<div class="portfolio-cats filter clearfix">
				<button class="active" data-filter="*"><?php _e('All', 'genesis'); ?></button>
				<?php foreach ( $terms as $term ) : ?>
					<button data-filter=".<?php echo $term->slug; ?>"><?php echo $term->name; ?></button>
				<?php endforeach; ?>
			</div><!-- /portfolio-cats -->
		<?php }

}

// Wrap Portfolio items in a custom div - opening
add_action( 'genesis_before_loop', 'portfolio_content_opening_div' );
function portfolio_content_opening_div() {
	echo '<div class="portfolio-content"><!-- .gutter-sizer empty element, only used for horizontal gap --><div class="gutter-sizer"></div>';
}

// Add category names in post class
add_filter( 'post_class', 'portfolio_category_class' );
function portfolio_category_class( $classes ) {

	$terms = get_the_terms( get_the_ID(), 'portfolio_category' );
	if( $terms ) foreach ( $terms as $term )
		$classes[] = $term->slug;

	return $classes;

}

// Remove entry header (having entry title and post info)
remove_action( 'genesis_entry_header', 'genesis_do_post_format_image', 4 );
remove_action( 'genesis_entry_header', 'genesis_entry_header_markup_open', 5 );
remove_action( 'genesis_entry_header', 'genesis_entry_header_markup_close', 15 );
remove_action( 'genesis_entry_header', 'genesis_do_post_title' );
remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );

// Remove post content
remove_action( 'genesis_entry_content', 'genesis_do_post_content' );

// Remove post image (coming from Theme settings)
remove_action( 'genesis_entry_header', 'genesis_do_post_image', 1 );

// Add featured image
add_action( 'genesis_entry_content', 'portfolio_grid_image' );
function portfolio_grid_image() {

	if ( $image = genesis_get_image( 'format=url&size=portfolio' ) ) {
		printf( '<div class="portfolio-image"><a href="%s" rel="bookmark"><img src="%s" alt="%s" /><h1 class="entry-title" itemprop="headline">%s</h1></a></div>', get_permalink(), $image, the_title_attribute( 'echo=0' ), get_the_title() );

	}

}

// Remove entry footer (having entry meta)
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

// Show Portfolio Type hyperlinked terms in Post Meta. This is useful if entry footer is being shown.
add_filter( 'genesis_post_meta', 'ellie_post_meta_filter' );
function ellie_post_meta_filter( $post_meta ) {

	$post_meta = '[post_terms taxonomy="portfolio_category" before=""]';
	return $post_meta;

}

// Wrap Portfolio items in a custom div - closing
add_action('genesis_after_loop', 'portfolio_content_closing_div' );
function portfolio_content_closing_div() {

	echo "</div>";

}

// Reposition Post Navigation (Previous / Next or Numeric). This is for Portfolio taxonomy archives
remove_action( 'genesis_after_endwhile', 'genesis_posts_nav' );
add_action( 'genesis_after_content', 'genesis_posts_nav' );

// Display 'back to portfolio' link and Title on Portfolio taxonomy archives
add_action( 'genesis_after_content', 'ellie_taxonomy_page_additions' );
function ellie_taxonomy_page_additions() {

	if ( is_tax( 'portfolio_category' ) || is_tax( 'portfolio_tag' ) ) {

		echo '<a href="' . get_bloginfo( 'url' ) . '/portfolio/">&laquo; Back to Full Portfolio</a>';
		global $wp_query;

		// To display the taxonomy term i.e., Portfolio Category Title
		// $term = $wp_query->get_queried_object();
		// echo '<h2 class="taxonomy-title">' . $term->name . '</h2>';

	}

}

genesis();