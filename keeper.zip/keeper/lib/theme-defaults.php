<?php
add_filter( 'genesis_theme_settings_defaults', 'keeper_theme_defaults' );
/**
* Updates theme settings on reset.
*
* @since 2.2.3
*/
function keeper_theme_defaults( $defaults ) {

	$defaults['blog_cat_num']              = 8;
	$defaults['content_archive']           = 'full';
	$defaults['content_archive_limit']     = 240;
	$defaults['content_archive_thumbnail'] = 1;
	$defaults['image_size']                = 'large';
	$defaults['image_alignment']           = 'none';
	$defaults['posts_nav']                 = 'numeric';
	$defaults['site_layout']               = 'full-width-content';

	return $defaults;

}

add_action( 'after_switch_theme', 'keeper_theme_setting_defaults' );
/**
* Updates theme settings on activation.
*
* @since 2.2.3
*/
function keeper_theme_setting_defaults() {

	if ( function_exists( 'genesis_update_settings' ) ) {

		genesis_update_settings( array(
			'blog_cat_num'              => 8,	
			'content_archive'           => 'full',
			'content_archive_limit'     => 240,
			'content_archive_thumbnail' => 1,
			'image_size'                => 'large',
			'image-alignment'           => 'none',
			'posts_nav'                 => 'numeric',
			'site_layout'               => 'full-width-content',
		) );
		
	} 

	update_option( 'posts_per_page', 8 );

}

//* Advanced Theme Setup
add_action( 'after_setup_theme', 'keeper_theme_settings' );
function keeper_theme_settings() {

	//* Unregister layout settings
	genesis_unregister_layout( 'content-sidebar-sidebar' );
	genesis_unregister_layout( 'sidebar-content-sidebar' );
	genesis_unregister_layout( 'sidebar-sidebar-content' );

	//* Unregister sidebars
	unregister_sidebar( 'sidebar-alt' );

	//* Remove the site description
	remove_action( 'genesis_site_description', 'genesis_seo_site_description' );

}