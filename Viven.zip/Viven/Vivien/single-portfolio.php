<?php 
/*------------------------------
Portfolio Single Page 
------------------------------*/ 
/** Force the full width layout layout on the Portfolio page */
add_filter('genesis_pre_get_option_site_layout', '__genesis_return_full_width_content');
remove_action(	'genesis_loop', 'genesis_do_loop' );
add_action(	'genesis_loop', 'zp_portfolio_single_template' );
function zp_portfolio_single_template() { ?>
	<?php global $post;
	
	?>
    	<div class="entry">
		<header class="entry-header"><h1 itemprop="headline" class="entry-title"><?php the_title( '', false ); ?></h1></header>
        <div class="portfolio_single_feature">
        <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); 
		//get portfolio meta settings
		$portfolio_images = get_post_meta( $post->ID, 'portfolio_images', true );


		$video_url = get_post_meta($post->ID, 'zp_video_url_value', true);
		$video_embed = get_post_meta($post->ID, 'zp_video_embed_value', true);
		$video_ht = get_post_meta($post->ID, 'zp_height_value', true);	
		?>     
        <!--if  Video exist -->
        <?php if($video_url !='' || $video_embed!= ''){ ?>
        <div class="portfolio_single_video">
        <?php
		if(trim($video_embed) == '') 
					{
						if(preg_match('/youtube/', $video_url)) 
						{	
							if(preg_match('/[\\?\\&]v=([^\\?\\&]+)/', $video_url, $matches))
							{
								$output = '<iframe title="YouTube video player" class="youtube-player" type="text/html" width="100%" height="'.$video_ht.'" src="http://www.youtube.com/embed/'.$matches[1].'" frameborder="0" allowFullScreen></iframe>';
							}
							else 
							{
								$output = __('Sorry that seems to be an invalid <strong>YouTube</strong> URL. Please check it again.', 'framework');
							}	
						}
						elseif(preg_match('/vimeo/', $video_url)) 
						{
							
							if(preg_match('~^http://(?:www\.)?vimeo\.com/(?:clip:)?(\d+)~', $video_url, $matches))
							{
								$output = '<iframe src="http://player.vimeo.com/video/'.$matches[1].'" width="100%" height="'.$video_ht.'" frameborder="0"></iframe>';
							}
							else 
							{
								$output = __('Sorry that seems to be an invalid <strong>Vimeo</strong> URL. Please check it again. Make sure there is a string of numbers at the end.', 'framework');
							}
							
						}
						else 
						{
							$output = __('Sorry that is an invalid YouTube or Vimeo URL.', 'framework');
						}
						
						echo $output;
						
					}
		else
		{
			echo stripslashes(htmlspecialchars_decode($video_embed));
		}
		
		?>        
        </div>        
	
        <!-- if images exists (slider)-->
        <?php } elseif( !empty( $portfolio_images ) ){?> 
		<?php wp_enqueue_script( 'jquery.flexslider_js' ); ?>     
            <script type="text/javascript">
        	jQuery.noConflict();
            jQuery(document).ready(function(jQuery) {
			jQuery('.portfolio_single_slider').flexslider({
					animation: "<?php echo genesis_get_option( 'zp_animation' , ZP_SETTINGS_FIELD );?>",              
					slideDirection: "horizontal",                  
					slideshowSpeed: <?php echo genesis_get_option( 'zp_slider_speed' , ZP_SETTINGS_FIELD );?>,           
					animationDuration: <?php echo genesis_get_option( 'zp_animation_duration' , ZP_SETTINGS_FIELD );?>,         
					directionNav: <?php echo genesis_get_option( 'zp_direction_nav' , ZP_SETTINGS_FIELD );?>,             
					controlNav: <?php echo genesis_get_option( 'zp_control_nav' , ZP_SETTINGS_FIELD );?>,                                                                   
					pauseOnAction: <?php echo genesis_get_option( 'zp_pauseonaction' , ZP_SETTINGS_FIELD );?>,         
					pauseOnHover: <?php echo genesis_get_option( 'zp_pauseonhover' , ZP_SETTINGS_FIELD );?>,
				    animationLoop: true
			});
				
                jQuery('.portfolio_image').hover(function(){	
                    jQuery(this).children('.icon').css({display: 'block'});
                }, function(){
                    jQuery(this).children('.icon').css({display: 'none'});		
                });
                
            });		
    
        
            </script>
		<div class="portfolio_single_slider flexslider">
        	<ul class="slides">
                <?php 
                $ids = explode(",", $portfolio_images );	
				$i=0;
				while( $i < count( $ids ) ){
					if( $ids[$i] != '' ){
						// get image url
						$url = wp_get_attachment_image( $ids[$i] , 'full' );
						$full_url = wp_get_attachment_image_src( $ids[$i] , 'full' );		
						echo '<li>'.$url.'</li>';
					}
					$i++;
				}
                ?>
            </ul>
        </div>        
        <?php }else {?>
        <!-- display fetaured image-->
        <div class="portfolio-items">
								<a href="<?php echo wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) ); ?>"  rel="prettyPhoto[pp_gal]"><?php the_post_thumbnail('portfolio_single');?></a>	
	
		</div>
		<?php } ?>
				<?php endwhile; ?>
		<?php endif; ?>     
      </div> <!-- end portfolio_single_feature-->
	</div>
	<div class="entry">
	<?php 
	$wid = '';
	$disp = '';
	if(get_post_meta( $post->ID, 'zp_portfolio_meta_item_value' , true ) == 'false' ){ 
		$wid  = 'style="width:100%;"';
		$disp = 'style="display:none;"';
	}
	
	?>
		<div class="metaItem" <?php echo $disp;  ?>>
		
			<div class="authorStuff"><span><?php echo get_post_meta( $post->ID, 'zp_client_label_value', true ); ?></span><?php echo get_post_meta( $post->ID, 'zp_client_value', true ); ?></div>
			<div class="dateStuff"><span><?php echo get_post_meta( $post->ID, 'zp_date_label_value', true ); ?></span><?php echo get_post_meta( $post->ID, 'zp_date_value', true ); ?></div>
            <div class="categoryStuff"><span><?php echo get_post_meta( $post->ID, 'zp_category_label_value', true ); ?></span> <?php echo get_post_meta( $post->ID, 'zp_category_value', true ); ?></div>
            <div class="projectStuff"><a href="<?php echo get_post_meta( $post->ID,'zp_visit_project_value', true );?>"><strong><?php echo get_post_meta( $post->ID,'zp_visit_project_label_value', true );	?></strong></a> </div>
            
    
        <div class="metaItem_nav">
            <?php 
                $prev_post = get_previous_post();	
                if (!empty( $prev_post )){?>
                
                    <div class="prev_project"><a href="<?php echo get_permalink( $prev_post->ID ); ?>" > </a> </div>
                
            <?php } ?>  
	                <div class="nav-back">
                        <a href="<?php echo get_post_meta( $post->ID, 'zp_backto_value', true ); ?>"></a>
	                </div>
            <?php 
                $next_post = get_next_post();	
                if (!empty( $next_post )){?>
						<div class="next_project"><a href="<?php echo get_permalink( $next_post->ID ); ?>" > </a> </div>
          		<?php } ?>     
            </div>    
		</div>      
	<div class="folio-entry"  <?php echo $wid;?>>
		<?php the_content(); ?>
    </div>
</div>
<div class="entry">
 <?php  if (genesis_get_option('zp_related_portfolio', ZP_SETTINGS_FIELD ) == true ):?>
<div class="folio-more">
	<?php zp_related_portfolio(); ?>
</div><!-- End columns. -->
</div>
<?php 
endif;
}
genesis();