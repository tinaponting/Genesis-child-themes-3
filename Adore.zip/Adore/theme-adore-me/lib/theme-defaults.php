<?php
/**
 * Adore me.
 * @package Adore Me
 */

add_filter( 'genesis_theme_settings_defaults', 'adore_theme_defaults' );
/**
 * Updates theme settings on reset.
 *
 * @since 3.0.2
 */
function adore_theme_defaults( $defaults ) {

	$defaults['blog_cat_num']              = 4;
	$defaults['content_archive']           = 'full';
	$defaults['content_archive_limit']     = 250;
	$defaults['content_archive_thumbnail'] = 1;
	$defaults['image_size']                = 'full-blog-image';
	$defaults['image_alignment']           = 'aligncenter';
	$defaults['posts_nav']                 = 'numeric';
	$defaults['site_layout']               = 'content-sidebar';

	return $defaults;

}

add_action( 'after_switch_theme', 'adore_theme_setting_defaults' );
/**
 * Updates theme settings on activation.
 *
 * @since 3.0.2
 */
function adore_theme_setting_defaults() {

	if( function_exists( 'genesis_update_settings' ) ) {

		genesis_update_settings( array(
			'blog_cat_num'              => 4,
			'content_archive'           => 'full',
			'content_archive_limit'     => 250,
			'content_archive_thumbnail' => 1,
			'image_size'                => 'full-blog-image',
			'image_alignment'           => 'aligncenter',
			'posts_nav'                 => 'numeric',
			'site_layout'               => 'content-sidebar',
		) );

	}

	update_option( 'posts_per_page', 9 );

}

add_filter( 'simple_social_default_styles', 'adore_social_default_styles' );
/**
 * Updates Simple Social Icon settings on activation.
 *
 * @since 3.0.2
 */
function adore_social_default_styles( $defaults ) {

	$args = array(
		'alignment'              => 'aligncenter',
		'background_color'       => '#f3e9e7',
		'background_color_hover' => '#f3e9e7',
		'border_radius'          => 0,
		'icon_color'             => '#222',
		'icon_color_hover'       => '#BCA17A',
		'size'                   => 26,
		);

	$args = wp_parse_args( $args, $defaults );

	return $args;

}