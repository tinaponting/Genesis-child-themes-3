<?php
/**---------------------------------------------------------
 * ZP Theme Settings
------------------------------------------------------------*/
/* Define constants
------------------------------------------------------------ */
define( 'ZP_SETTINGS_FIELD', 'zp-settings' );
/* Setup default options
------------------------------------------------------------ */
/**
 * zpsettings_default_theme_options function.
 *
*/
function zpsettings_default_theme_options() {
	$options = array(
		'zp_related_portfolio' => 1,
		'zp_related_portfolio_title' => __( 'Related Portfolio','vivien' ),
		'zp_num_portfolio_items' => 6,
		'zp_portfolio_categories_label' => 'Archives for: ',
		
	);
	return apply_filters( 'zpsettings_default_theme_options', $options );
}
/* Sanitize any inputs
------------------------------------------------------------ */
add_action( 'genesis_settings_sanitizer_init', 'zpsettings_sanitize_inputs' );
/**
* zpsettings_sanitize_inputs function.
*
*/ 
function zpsettings_sanitize_inputs() {
    genesis_add_option_filter( 'one_zero', 
				ZP_SETTINGS_FIELD, 
				array( 					
					'zp_home_portfolio_filter',
					
				) 
	);
	
    genesis_add_option_filter( 'no_html', 
				ZP_SETTINGS_FIELD, 
				array( 
					'zp_home_portfolio_title',
					
					'zp_num_portfolio_items',
					
				
					'zp_home_portfolio_title',
					'zp_portfolio_categories_label'
					
				) 
	);	
	 genesis_add_option_filter( 'requires_unfiltered_html', 
					ZP_SETTINGS_FIELD, 
					array( 
					
						
						
						'zp_home_portfolio_desc'				
					) 
		);		
}
/* Register our settings and add the options to the database
------------------------------------------------------------ */
add_action( 'admin_init', 'zpsettings_register_settings' );
/**
* zpsettings_register_settings function.
*
*/
function zpsettings_register_settings() {
	register_setting( ZP_SETTINGS_FIELD, ZP_SETTINGS_FIELD );
	add_option( ZP_SETTINGS_FIELD, zpsettings_default_theme_options() );
	
	if ( genesis_get_option( 'reset', ZP_SETTINGS_FIELD ) ) {
		update_option( ZP_SETTINGS_FIELD, zpsettings_default_theme_options() );
		genesis_admin_redirect( ZP_SETTINGS_FIELD, array( 'reset' => 'true' ) );
		exit;
	}
}
/* Admin notices for when options are saved/reset
------------------------------------------------------------ */
add_action( 'admin_notices', 'zpsettings_theme_settings_notice' );
/**
* zpsettings_theme_settings_notice function.
*/
function zpsettings_theme_settings_notice() {
	if ( ! isset( $_REQUEST['page'] ) || $_REQUEST['page'] != ZP_SETTINGS_FIELD )
		return;
	if ( isset( $_REQUEST['reset'] ) && 'true' == $_REQUEST['reset'] )
		echo '<div id="message" class="updated"><p><strong>' . __( 'Settings reset.', 'vivien' ) . '</strong></p></div>';
	elseif ( isset( $_REQUEST['settings-updated'] ) && 'true' == $_REQUEST['settings-updated'] )
		echo '<div id="message" class="updated"><p><strong>' . __( 'Settings saved.', 'absolute' ) . '</strong></p></div>';
}
/* Register our theme options page
------------------------------------------------------------ */
add_action( 'admin_menu', 'zpsettings_theme_options' );
/**
* zpsettings_theme_options function.
*
*/
function zpsettings_theme_options() {
	global $_zpsettings_settings_pagehook;
	$_zpsettings_settings_pagehook = add_submenu_page( 'genesis', 'Vivien Settings', 'Vivien Settings', 'edit_theme_options', ZP_SETTINGS_FIELD, 'zpsettings_theme_options_page' );
	//add_action( 'load-'.$_zpsettings_settings_pagehook, 'zpsettings_settings_styles' );
	add_action( 'load-'.$_zpsettings_settings_pagehook, 'zpsettings_settings_scripts' );
	add_action( 'load-'.$_zpsettings_settings_pagehook, 'zpsettings_settings_boxes' );
}
/* Setup our scripts
------------------------------------------------------------ */
/**
* zpsettings_settings_scripts function.
* This function enqueues the scripts needed for the ZP Settings settings page.
*/
function zpsettings_settings_scripts() {	
	global $_zpsettings_settings_pagehook;
	
	if( is_admin() ){
	
	wp_register_script( 'zp_image_upload', get_stylesheet_directory_uri() .'/includes/upload/image-upload.js', array('jquery','media-upload','thickbox') );	
	wp_enqueue_script('media-upload');
	wp_enqueue_script('jquery');
	wp_enqueue_script('thickbox');
	wp_enqueue_style('thickbox');
	wp_enqueue_script( 'common' );
	wp_enqueue_script( 'wp-lists' );
	wp_enqueue_script( 'postbox' );
	
	wp_enqueue_media( );
	wp_enqueue_script('zp_image_upload');
}
}
/* Setup our metaboxes
------------------------------------------------------------ */
/**
* zpsettings_settings_boxes function.
*
* This function sets up the metaboxes to be populated by their respective callback functions.
*
*/
function zpsettings_settings_boxes() {
	global $_zpsettings_settings_pagehook;
	
	add_meta_box( 'zpsettings_portfolio', __( 'Portfolio Settings ', 'vivien' ), 'zpsettings_portfolio', $_zpsettings_settings_pagehook, 'main','high' );	

}
/* Add our custom post metabox for social sharing
------------------------------------------------------------ */
/**
* zpsettings_home_settings function.
*
* Callback function for the ZP Settings Social Sharing metabox.
*
*/
 
function zpsettings_portfolio() { ?>
    <p>	<input type="checkbox" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_related_portfolio]" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_related_portfolio]" value="1" <?php checked( 1, genesis_get_option( 'zp_related_portfolio', ZP_SETTINGS_FIELD ) ); ?> /> <label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_related_portfolio]"><?php _e( 'Check to enable related portfolio in single portfolio page.', 'vivien' ); ?></label>
    </p>
     <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_related_portfolio_title]"><?php _e( 'Related Portfolio Title', 'vivien' ) ?></label>
        <input type="text" size="30" value="<?php echo genesis_get_option( 'zp_related_portfolio_title', ZP_SETTINGS_FIELD ); ?>" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_related_portfolio_title]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_related_portfolio_title]"></p> 
        
     <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_num_portfolio_items]"><?php _e( 'Number of items in the portfolio page', 'vivien' ) ?></label>
        <input type="text" size="30" value="<?php echo genesis_get_option( 'zp_num_portfolio_items', ZP_SETTINGS_FIELD ); ?>" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_num_portfolio_items]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_num_portfolio_items]"></p>      
      <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_portfolio_categories_label]"><?php _e( 'Portfolio Categories Label', 'vivien' ) ?></label>
        <input type="text" size="30" value="<?php echo genesis_get_option( 'zp_portfolio_categories_label', ZP_SETTINGS_FIELD ); ?>" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_portfolio_categories_label]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_portfolio_categories_label]"></p>        
 
     <p><span class="description"><?php _e( 'This settings applies to portfolio.','vivien' ) ?></span></p>  
    
<?php }
/* Replace the 'Insert into Post Button inside Thickbox'
------------------------------------------------------------ */
function zp_replace_thickbox_text($translated_text, $text ) {	
	if ( 'Insert into Post' == $text ) {
		$referer = strpos( wp_get_referer(), ZP_SETTINGS_FIELD );
		if ( $referer != '' ) {
			return __('Insert Image!', 'absolute' );
		}
	}
	return $translated_text;
}
/* Hook to filter Insert into Post Button in thickbox
------------------------------------------------------------ */
function zp_change_insert_button_text() {
		add_filter( 'gettext', 'zp_replace_thickbox_text' , 1, 2 );
}
add_action( 'admin_init', 'zp_change_insert_button_text' );
/* Set the screen layout to one column
------------------------------------------------------------ */
add_filter( 'screen_layout_columns', 'zpsettings_settings_layout_columns', 10, 2 );
/**
* zpsettings_settings_layout_columns function.
*
* This function sets the column layout to one for the ZP Settings settings page.
*
*/
function zpsettings_settings_layout_columns( $columns, $screen ) {
	global $_zpsettings_settings_pagehook;
	if ( $screen == $_zpsettings_settings_pagehook ) {
		$columns[$_zpsettings_settings_pagehook] = 2;
	}
	return $columns;
}
/* Build our theme options page
------------------------------------------------------------ */
/**
* zpsettings_theme_options_page function.
*
* This function displays the content for the ZP Settings settings page, builds the forms and outputs the metaboxes.
*
*/
function zpsettings_theme_options_page() { 
	global $_zpsettings_settings_pagehook, $screen_layout_columns;
	$screen = get_current_screen();
	$width = "width: 100%;";
	$hide2 = $hide3 = " display: none;";
	?>	
	
	<div id="zpsettings" class="wrap genesis-metaboxes">
		<form method="post" action="options.php">
		
			<?php wp_nonce_field( 'closedpostboxes', 'closedpostboxesnonce', false ); ?>
			<?php wp_nonce_field( 'meta-box-order', 'meta-box-order-nonce', false ); ?>
			<?php settings_fields( ZP_SETTINGS_FIELD ); ?>
		
			<h2>
				<?php _e( 'Absolute Child Theme Settings', 'absolute' ); ?>
				<input type="submit" class="button-primary genesis-h2-button" value="<?php _e( 'Save Settings', 'absolute' ) ?>" />
				<input type="submit" class="button genesis-h2-button" name="<?php echo ZP_SETTINGS_FIELD; ?>[reset]" value="<?php _e( 'Reset Settings', 'absolute' ); ?>" onclick="return genesis_confirm('<?php echo esc_js( __( 'Are you sure you want to reset?', 'absolute' ) ); ?>');" />
			</h2>
			<div class="metabox-holder">
				<div class="postbox-container" style="<?php echo $width; ?>">
					<?php do_meta_boxes( $_zpsettings_settings_pagehook, 'main', null ); ?>
				</div>
			</div>
		
		</form>
	</div>
	<script type="text/javascript">
		//<![CDATA[
		jQuery(document).ready( function($) {
			// close postboxes that should be closed
			$('.if-js-closed').removeClass('if-js-closed').addClass('closed');
			// postboxes setup
			postboxes.add_postbox_toggles('<?php echo $_zpsettings_settings_pagehook; ?>');
		});
		//]]>
	</script>
<?php }