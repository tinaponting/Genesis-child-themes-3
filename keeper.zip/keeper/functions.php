<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Setup Theme
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );

//* Set Localization (do not remove)
load_child_theme_textdomain( 'keeper', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/languages', 'keeper' ) );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Keeper' );
define( 'CHILD_THEME_VERSION', '1.1' );

//* Enqueue Scripts and Styles
add_action( 'wp_enqueue_scripts', 'keeper_enqueue_scripts_styles' );
function keeper_enqueue_scripts_styles() {

	wp_enqueue_style( 'keeper-fonts', '//fonts.googleapis.com/css?family=Montserrat:500,700|Libre+Baskerville:400,400i,700', array(), CHILD_THEME_VERSION );

	wp_enqueue_style( 'dashicons' );

	wp_enqueue_script( 'keeper-responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0', true );
	$output = array(
		'mainMenu' => __( '', 'keeper' ),
		'subMenu'  => __( '', 'keeper' ),
	);

	wp_localize_script( 'keeper-responsive-menu', 'keeperL10n', $output );

}

//* Enqueue Genesis child theme style sheet at higher priority
remove_action( 'genesis_meta', 'genesis_load_stylesheet' );
add_action( 'wp_enqueue_scripts', 'genesis_enqueue_main_stylesheet', 15 );

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'caption', 'comment-form', 'comment-list', 'gallery', 'search-form' ) );

//* Add Accessibility support
add_theme_support( 'genesis-accessibility', array( '404-page', 'drop-down-menu', 'headings', 'rems', 'search-form', 'skip-links' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'width'           => 600,
	'height'          => 160,
	'header-selector' => '.site-title a',
	'header-text'     => false,
	'flex-height'     => true,
) );

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Add Image Sizes
add_image_size( 'featured-image', 720, 400, TRUE );
add_image_size( 'portfolio', 300, 300, TRUE );

//* Unregister secondary navigation menu
add_theme_support( 'genesis-menus', array( 'primary' => __( 'Primary Navigation Menu', 'genesis' ) ) );

//* Display author box on single posts & author page
add_filter( 'get_the_author_genesis_author_box_single', '__return_true' );
add_filter( 'get_the_author_genesis_author_box_archive', '__return_true' );

//* Modify size of the Gravatar in the author box
add_filter( 'genesis_author_box_gravatar_size', 'keeper_author_box_gravatar' );
function keeper_author_box_gravatar( $size ) {

	return 90;

}

//* Modify size of the Gravatar in the entry comments
add_filter( 'genesis_comment_list_args', 'keeper_comments_gravatar' );
function keeper_comments_gravatar( $args ) {

	$args['avatar_size'] = 60;

	return $args;

}

//* Modify breadcrumbs display
add_filter('genesis_breadcrumb_args', 'customize_breadcrumbs');
function customize_breadcrumbs($args) {
	$args['labels']['prefix'] = '';
	$args['home'] = 'Home ';
	$args['labels']['author'] = '';
	$args['labels']['category'] = '';
	$args['labels']['tag'] = '';
	$args['labels']['date'] = '';
	$args['labels']['search'] = '';
	$args['labels']['tax'] = '';
	$args['labels']['post_type'] = '';
	$args['labels']['404'] = 'Not found';
    return $args;
}

//* Add the breadcrumb navigation to portfolio archives
add_action( 'genesis_before_loop', 'keeper_portfolio_breadcrumb' );
function keeper_portfolio_breadcrumb() {
	if ( get_post_type() == 'portfolio' || is_post_type_archive( 'portfolio' ) || is_tax( 'portfolio-type' ) ) {
		add_action( 'genesis_before_loop', 'genesis_do_breadcrumbs', 15 );
        }
}

//* Reposition custom post type archive title and description
remove_action( 'genesis_before_loop', 'genesis_do_cpt_archive_title_description' );
add_action( 'genesis_before_loop', 'genesis_do_cpt_archive_title_description', 30 );
remove_action( 'genesis_before_loop', 'genesis_do_taxonomy_title_description', 15 );
add_action( 'genesis_before_loop', 'genesis_do_taxonomy_title_description', 30 );

/**
 * Remove Genesis Page Templates
 * @param array $page_templates
 * @return array
 */
function genesis_remove_genesis_page_templates( $page_templates ) {
	unset( $page_templates['page_blog.php'] );
	return $page_templates;
}
add_filter( 'theme_page_templates', 'genesis_remove_genesis_page_templates' );

//* Add Post categories above Post title on single Posts
add_action ( 'genesis_entry_header', 'keeper_show_category_name', 9 );
function keeper_show_category_name() {

	if ( ! is_singular('post') )
		return;

	echo do_shortcode('[post_categories before=""]');
}

//* Add portfolio type above entry title on single portfolio pages
add_action( 'genesis_entry_header', 'keeper_portfolio_type', 9 );
function keeper_portfolio_type() {

	if ( ! is_singular('portfolio') )
		return;

	echo do_shortcode('[post_terms taxonomy="portfolio-type" before=""]');
}

//* Register front page 1
genesis_register_sidebar( array(
    'id'    => 'front-page-1',
    'name'    => __( 'Front Page 1', 'keeper' ),
    'description'    => __( 'This is the Front Page Widget 1 area.', 'keeper' ),
) );

//* Register front page 2
genesis_register_sidebar( array(
    'id'    => 'front-page-2',
    'name'    => __( 'Front Page 2', 'keeper' ),
    'description'    => __( 'This is the Front Page Widget 2 area.', 'keeper' ),
) );

//* Register front page 3
genesis_register_sidebar( array(
    'id'    => 'front-page-3',
    'name'    => __( 'Front Page 3', 'keeper' ),
    'description'    => __( 'This is the Front Page Widget 3 area.', 'keeper' ),
) );

//* Register before footer area
genesis_register_sidebar( array(
    'id'    => 'before-footer',
    'name'    => __( 'Before Footer', 'keeper' ),
    'description'    => __( 'This is the Before Footer area.', 'keeper' ),
) );

//* Add the front page 1
add_action( 'genesis_after_header', 'keeper_front_page_1' );
function keeper_front_page_1() {
if ( ! is_front_page() )
 return;
   genesis_widget_area( 'front-page-1', array(
	'before' => '<div class="front-page-1 widget-area"><div class="wrap">',
	'after' => '</div></div>',
   ) );
}

//* Add the front page 2
add_action( 'genesis_after_header', 'keeper_front_page_2' );
function keeper_front_page_2() {
if ( ! is_front_page() )
 return;
   genesis_widget_area( 'front-page-2', array(
	'before' => '<div class="front-page-2 widget-area"><div class="wrap">',
	'after' => '</div></div>',
   ) );
}

//* Add the front page 3
add_action( 'genesis_after_header', 'keeper_front_page_3' );
function keeper_front_page_3() {
if ( ! is_front_page() )
 return;
   genesis_widget_area( 'front-page-3', array(
	'before' => '<div class="front-page-3 widget-area"><div class="wrap">',
	'after' => '</div></div>',
   ) );
}

//* Add the before footer area
add_action( 'genesis_before_footer', 'keeper_before_footer', 1 );
function keeper_before_footer() {
   genesis_widget_area( 'before-footer', array(
	'before' => '<div class="before-footer widget-area"><div class="wrap">',
	'after' => '</div></div>',
   ) );
}

//* Add support for Genesis Connect for WooCommerce 
add_theme_support( 'genesis-connect-woocommerce' );

//* Declare WooCommerce support
add_action( 'after_setup_theme', 'woocommerce_support' );
function woocommerce_support() {
    add_theme_support( 'woocommerce' );
}

//* Reposition WooCommerce tabs
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );
add_action( 'woocommerce_single_product_summary', 'woocommerce_output_product_data_tabs', 60 );

//* Remove front page loop (or comment out to show latest posts or static front page)
add_action('genesis_before','remove_homepage_content');
function remove_homepage_content() {
if (is_front_page() ) { 
	remove_action( 'genesis_loop', 'genesis_do_loop' );
        }
}

//* Increase content width for Jetpack tiled galleries
if ( ! isset( $content_width ) )
    $content_width = 800;

/**
 * Modify the Featured Image CSS Classes
 * @param array $attr, existing attributes
 * @return array $attr
 */
function keeper_featured_image_classes( $attr ) {
  $attr['class'] .= ' extend';
  return $attr;
}
add_filter( 'genesis_attr_entry-image', 'keeper_featured_image_classes' );