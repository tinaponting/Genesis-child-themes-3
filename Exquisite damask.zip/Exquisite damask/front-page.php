<?php
/**
 * This file adds the Home Page to the Exquisite Damask Theme.
 * @package Exquisite Damask
 * @subpackage Customizations
 */

add_action( 'genesis_meta', 'exquisite_home_genesis_meta' );
/**
 * Add widget support for homepage. If no widgets active, display the default loop.
 *
 */
function exquisite_home_genesis_meta() {

	if ( is_active_sidebar( 'home-slider' ) || is_active_sidebar( 'announcement-bar' ) || is_active_sidebar( 'featured-flex-posts' ) || is_active_sidebar( 'home-testimonial' ) || is_active_sidebar( 'featured-products' ) ) {
		
		add_action( 'genesis_before', 'exquisite_home_sections', 23 ); 
		add_filter( 'body_class', 'exquisite_add_home_body_class' );

		//* Remove default loop & sidebar (remove the // symbols in front of the next two lines to remove the default blog loop and sidebar from the home page of Exquisite Damask.)
		remove_action( 'genesis_loop', 'genesis_do_loop' );
		remove_action( 'genesis_sidebar', 'genesis_do_sidebar' ); 

//* Add body class to home page
function exquisite_add_home_body_class( $classes ) {

	$classes[] = 'exquisite-home';
	return $classes;
	
		}

	}

}

function exquisite_home_sections() {

if( !is_paged()) {

	echo '<div class="home-top">';

	genesis_widget_area( 'home-slider', array(
		'before' => '<div id="home-slider" class="home-slider"><div class="widget-area fadeup-effect"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );

	genesis_widget_area( 'announcement-bar', array(
		'before' => '<div id="announcement-bar" class="announcement-bar"><div class="widget-area fadeup-effect"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );

	genesis_widget_area( 'featured-flex-posts', array(
		'before' => '<div id="featured-flex-posts" class="featured-flex-posts"><div class="widget-area fadeup-effect"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );

	genesis_widget_area( 'home-testimonial', array(
		'before' => '<div id="home-testimonial" class="home-testimonial"><div class="widget-area fadeup-effect"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );

	genesis_widget_area( 'featured-products', array(
		'before' => '<div id="featured-products" class="featured-products"><div class="widget-area fadeup-effect"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );

	echo '</div>';

}}

genesis();