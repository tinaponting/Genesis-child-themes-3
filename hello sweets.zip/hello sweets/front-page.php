<?php
/**
 * Custom Home Page.
 * @package      Hello Sweets
 */


//* Add widget support for homepage. If no widgets active, display the default loop.
add_action( 'genesis_meta', 'sweets_front_page_genesis_meta' );
function sweets_front_page_genesis_meta() {

	if ( is_active_sidebar( 'home-full-slider' ) || is_active_sidebar( 'home-top-left' ) || is_active_sidebar( 'home-top-right' ) || is_active_sidebar( 'home-badge' ) ||  is_active_sidebar( 'home-flexible' ) || is_active_sidebar( 'home-calltoaction' ) || is_active_sidebar( 'home-featured' ) ) {

		//* Add body class
		add_filter( 'body_class', 'sweets_front_page_body_class' );

		//* Force full width content layout
		add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

		//* Remove Genesis Loop
		remove_action( 'genesis_loop', 'genesis_do_loop' );

	}
}


//* Add category body class to the head
function sweets_front_page_body_class( $classes ) {

	$classes[] = 'sweets-home category';
	return $classes;

}

//* Hook welcome widget area after site header
add_action( 'genesis_before_content', 'sweets_welcome_widget_area' );
function sweets_welcome_widget_area() {

	if( !is_paged()) {

	genesis_widget_area( 'home-full-slider', array(
		'before' => '<div class="home-full-slider">',
		'after'  => '</div>',
	) );

if ( is_active_sidebar( 'home-top-left' ) || is_active_sidebar( 'home-top-right' ) ) {

	echo '<div class="home-top-split">';

	genesis_widget_area( 'home-top-left', array(
		'before' => '<div class="home-top-left widget-area">',
		'after'  => '</div>',
	) );

	genesis_widget_area( 'home-top-right', array(
		'before' => '<div class="home-top-right widget-area">',
		'after'  => '</div>',
	) );

	echo '</div>';

	}

	genesis_widget_area( 'home-badge', array(
		'before' => '<div id="home-badge" class="home-badge"><div class="widget-area ' . sweets_widget_area_class( 'home-badge' ) . '"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );

	genesis_widget_area( 'home-flexible', array(
		'before' => '<div id="home-flexible" class="home-flexible"><div class="widget-area ' . sweets_widget_area_class( 'home-flexible' ) . '"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );

	genesis_widget_area( 'home-calltoaction', array(
		'before' => '<div id="home-calltoaction" class="home-calltoaction"><div class="widget-area ' . sweets_widget_area_class( 'home-calltoaction' ) . '"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );

	genesis_widget_area( 'home-featured', array(
		'before' => '<div class="home-featured">',
		'after'  => '</div>',
	) );

}}




//* Run the default Genesis loop
genesis();
