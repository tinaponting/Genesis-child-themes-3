<?php
/**
 * Easy Digital Downloads Theme Updater
 *
 * @package EDD Sample Theme
 */

// Includes the files needed for the theme updater
if ( !class_exists( 'EDD_Theme_Updater_Admin' ) ) {
	include( dirname( __FILE__ ) . '/theme-updater-admin.php' );
}


if(get_locale() != 'es_ES')
	$idioma = '/en';
else
	$idioma = '';

// Loads the updater classes
$updater = new EDD_Theme_Updater_Admin(
	$config = array(
		'remote_api_url' => 'http://www.hodeidesign.com'. $idioma,
		'item_name' => 'Flamingo Theme',
		'theme_slug' => get_stylesheet(),
		'version' => '1.1.0',
		'author' => 'Hodei Design',
		'download_id' => '', // Optional, used for generating a license renewal link
		'renew_url' => '' // Optional, allows for a custom license renewal link
	),
	$strings = array(
		'theme-license' => __( 'Theme License', 'flamingo_theme' ),
		'enter-key' => __( 'Enter your theme license key.', 'flamingo_theme' ),
		'license-key' => __( 'License Key', 'flamingo_theme' ),
		'license-action' => __( 'License Action', 'flamingo_theme' ),
		'deactivate-license' => __( 'Deactivate License', 'flamingo_theme' ),
		'activate-license' => __( 'Activate License', 'flamingo_theme' ),
		'status-unknown' => __( 'License status is unknown.', 'flamingo_theme' ),
		'renew' => __( 'Renew?', 'flamingo_theme' ),
		'unlimited' => __( 'unlimited', 'flamingo_theme' ),
		'license-key-is-active' => __( 'License key is active.', 'flamingo_theme' ),
		'expires%s' => __( 'Expires %s.', 'flamingo_theme' ),
		'%1$s/%2$-sites' => __( 'You have %1$s / %2$s sites activated.', 'flamingo_theme' ),
		'license-key-expired-%s' => __( 'License key expired %s.', 'flamingo_theme' ),
		'license-key-expired' => __( 'License key has expired.', 'flamingo_theme' ),
		'license-keys-do-not-match' => __( 'License keys do not match.', 'flamingo_theme' ),
		'license-is-inactive' => __( 'License is inactive.', 'flamingo_theme' ),
		'license-key-is-disabled' => __( 'License key is disabled.', 'flamingo_theme' ),
		'site-is-inactive' => __( 'Site is inactive.', 'flamingo_theme' ),
		'license-status-unknown' => __( 'License status is unknown.', 'flamingo_theme' ),
		'update-notice' => __( "Updating this theme will lose any customizations you have made. 'Cancel' to stop, 'OK' to update.", 'flamingo_theme' ),
		'update-available' => __('<strong>%1$s %2$s</strong> is available. <a href="%3$s" class="thickbox" title="%4s">Check out what\'s new</a> or <a href="%5$s"%6$s>update now</a>.', 'flamingo_theme' )
	)
);