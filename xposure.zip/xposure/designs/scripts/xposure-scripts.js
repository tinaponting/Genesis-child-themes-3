/* Theme Base scripts */

$j = jQuery.noConflict();
$j(document).ready(function() {
	
	$j('.primary-menu-button').click(function() {
		$j('.menu-primary').fadeToggle('slow', 'easeInOutCubic');
	})
	
});

// Damn cool header!
$j(window).scroll(function() {
	var width = $j(window).width();
	var scroll = window.pageYOffset;
	if( width > 540 ) {
		if( scroll >= 200 ) {
			$j('.site-header').addClass('shrinked');
		}
		else {
			$j('.site-header').removeClass('shrinked');
		}
		if( $j('.home.fullscreen-portfolio .site-header').hasClass('shrinked') ) {
			$j('.home.fullscreen-portfolio .site-header').removeClass('shrinked');
		}
	
		if( width > 800 ) {
			if( scroll >=30 ) {
				$j('.xposure.pagewidth .site-header').css('top', '0');
			}
			else {
				$j('.xposure.pagewidth .site-header').css('top', '40px');
				$j('.xposure.pagewidth.fullscreen-portfolio .site-header').css('top', '0');
			}
		}
	}
});