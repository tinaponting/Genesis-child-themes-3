<?php
/**
 * Her Exclusive.
 * @package Her Exclusive
 */

add_filter( 'woocommerce_enqueue_styles', 'her_woocommerce_styles' );
/**
 * Enqueue custom WooCommerce styles when WooCommerce active.
 *
 * @since 1.1.0
 */
function her_woocommerce_styles( $enqueue_styles ) {

 	$enqueue_styles['her-woocommerce-styles'] = array(
 		'src'     => get_stylesheet_directory_uri() . '/lib/woocommerce/her-woocommerce.css',
 		'deps'    => '',
 		'version' => CHILD_THEME_VERSION,
 		'media'   => 'screen',
 	);

 	return $enqueue_styles;

}

add_action( 'wp_enqueue_scripts', 'her_woocommerce_customizer_css' );
/**
 * Add WooCommerce specific Customizer CSS.
 *
 * @since 1.1.1
 *
 * @return string Customizer CSS outputted to the custom WooCommerce stylesheet.
 */
function her_woocommerce_customizer_css() {

	// If WooCommerce isn't active, exit early.
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}

	$color_accent = get_theme_mod( 'her_accent_color', her_customizer_get_default_accent_color() );
	$color_headings = get_theme_mod( 'her_headings_color', her_customizer_get_default_headings_color() );
	$color_button = get_theme_mod( 'her_button_color', her_customizer_get_default_button_color() );
	$color_button_font = get_theme_mod( 'her_button_font_color', her_customizer_get_default_button_font_color() );
	
	$woo_css = '';

	$woo_css .= ( her_customizer_get_default_accent_color() !== $color_accent ) ? sprintf( '

			.woocommerce div.product .woocommerce-tabs ul.tabs li a:focus, 
			.woocommerce div.product .woocommerce-tabs ul.tabs li a:hover {
				color: %1$s;
			}

	', $color_accent ) : '';
	
	$woo_css .= ( her_customizer_get_default_headings_color() !== $color_headings ) ? sprintf( '

			.woocommerce ul.products li.product .price,
			.woocommerce div.product p.price {
				color: %1$s;
			}

	', $color_headings ) : '';
	
	$woo_css .= ( her_customizer_get_default_button_color() !== $color_button ) ? sprintf( '
	
	
			.woocommerce a.button,
			.woocommerce a.button.alt,
			.woocommerce button.button,
			.woocommerce button.button.alt,
			.woocommerce input.button,
			.woocommerce input.button.alt,
			.woocommerce input.button[type="submit"],
			.woocommerce #respond input#submit,
			.woocommerce #respond input#submit.alt,
			.woocommerce span.onsale {
				background-color: %1$s;
				border-color: %1$s;
			}

	', $color_button ) : '';
	
	$woo_css .= ( her_customizer_get_default_button_font_color() !== $color_button_font ) ? sprintf( '

			.woocommerce a.button,
			.woocommerce a.button.alt,
			.woocommerce button.button,
			.woocommerce button.button.alt,
			.woocommerce input.button,
			.woocommerce input.button.alt,
			.woocommerce input.button[type="submit"],
			.woocommerce #respond input#submit,
			.woocommerce #respond input#submit.alt,
			.woocommerce span.onsale {
				color: %1$s;
			}

	', $color_button_font ) : '';
	

	if ( $woo_css ) {
		wp_add_inline_style( 'her-woocommerce-styles', $woo_css );
	}

}
