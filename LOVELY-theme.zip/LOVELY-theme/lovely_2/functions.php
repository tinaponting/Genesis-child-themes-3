<?php
//* this will bring in the Genesis Parent files needed:
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme
define( 'CHILD_THEME_NAME', 'LOVELY Theme' );
define( 'CHILD_THEME_URL', 'http://https://teskedsgumman.se' );
define( 'CHILD_THEME_VERSION', '2.0' );
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );
add_theme_support( 'genesis-responsive-viewport' );

// Adds image upload and color select to Customizer.
require_once('lib/customizer_setting.php');

// Includes Customizer CSS.
require_once('lib/customizer_output.php'); 

// SkyandStars widget.
require_once('lib/skystars_widget.php');

// Theme default settings.
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );

// Adds required plugins for this theme.
require_once dirname( __FILE__ ) . '/lib/class-tgm-plugin-activation.php';
add_action( 'tgmpa_register', 'skyandstars_required_plugins' );
function skyandstars_required_plugins() {
 
    $plugins = array(
        array(
            'name'      => 'Genesis Simple Share',
            'slug'      => 'genesis-simple-share',
            'required'  => true,
        ),
        array(
            'name'      => 'Simple Social Icons',
            'slug'      => 'simple-social-icons',
            'required'  => true, // this plugin is recommended
        ),
        array(
            'name'      => 'Smash Balloon Social Photo Feed',
            'slug'      => 'instagram-feed',
            'required'  => true,
        ),
        array(
            'name'      => 'WPForms',
            'slug'      => 'wpforms-lite',
            'required'  => true,
        ),
        array(
            'name'      => 'Regenerate Thumbnails',
            'slug'      => 'regenerate-thumbnails',
            'required'  => false, // this plugin is recommended
        ),
    );
    

    $config = array( /* The array to configure TGM Plugin Activation */ );
 
    tgmpa( $plugins, $config );
 
}
/* end muplugin*/

//Enqueues scripts and styles.
add_action( 'wp_enqueue_scripts', 'skyandstars_enqueue_scripts' );
function skyandstars_enqueue_scripts() {
    wp_enqueue_script( 'fitvids', get_stylesheet_directory_uri() . '/js/jquery.fitvids.js', array( 'jquery' ), '1.0.0', true );
    wp_enqueue_script( 'prefix-responsive-menu', get_stylesheet_directory_uri() . '/js/responsivemenu.js', array( 'jquery' ), '1.0.0', true );
    wp_enqueue_script( 'site-script', get_stylesheet_directory_uri() . '/js/script.js', array( 'jquery' ), '1.0.0', true );
    wp_enqueue_style( 'google-font', 'https://fonts.googleapis.com/css?family=Martel+Sans:300,400|Italiana|Yrsa:400,700', array() );
    wp_enqueue_style( 'google-font2', 'https://fonts.googleapis.com/css2?family=Fanwood+Text:ital@0;1&display=swap', array() );
    wp_enqueue_style( 'fontawesome', '//maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css' );
}


// Adds image sizes
add_image_size('sidebar-featured', 300, 300, TRUE);
add_image_size('autoreadmore', 745, 500, TRUE);
add_image_size('cat_image', 400, 400, TRUE);


//* Add support for custom header
add_theme_support( 'genesis-custom-header');
add_theme_support( 'custom-header', array(
    'header-selector' => '.site-title a',
    'header-text'     => false,
    'height'      => 300,
    'width'       => 800,
    'flex-height' => true,
    'flex-width'  => true,
) );

// Removes header right widget area.
unregister_sidebar( 'header-right' );

// Removes secondary menu
add_theme_support( 'genesis-menus', array( 'primary' => __( 'Primary Navigation Menu', 'genesis' ) ) );

// Move Primary Nav Menu Above Header
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before_header', 'genesis_do_nav' );

// Removes site layouts.
 genesis_unregister_layout( 'content-sidebar-sidebar' );
 genesis_unregister_layout( 'sidebar-sidebar-content' );
 genesis_unregister_layout( 'sidebar-content-sidebar' );
unregister_sidebar( 'sidebar-alt' );

/*========================== POSTING AREA ========================== */
//* Gutenberg full width image
function mytheme_setup() {
  add_theme_support( 'align-wide' );
}
add_action( 'after_setup_theme', 'mytheme_setup' );

//pindahin tgl and title
remove_action( 'genesis_entry_header', 'genesis_post_info', 12);
add_action( 'genesis_entry_header', 'genesis_post_info', 9 );

// Auto Read More
add_filter('excerpt_more', 'auto_excerpt_more');
function auto_excerpt_more($more) {
    return '<span>.</span><span>.</span><span>.</span> <a class="autoreadmore x1" href="'.get_permalink().'" rel="nofollow">Read More</a>';
}


//* Modify the Genesis content limit read more link
add_filter( 'get_the_content_more_link', 'modify_read_more_link_text' );
function modify_read_more_link_text() {
    return '...</p><p> <a class="autoreadmore x3" href="' . get_permalink() . '">Read More</a></p>';
}

//* Remove the post meta function
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
 
// Add New Post footer
add_action( 'genesis_entry_footer', 'new_genesis_post_footer' );
function new_genesis_post_footer() {
if(!is_feed() && !is_page()) { ?>
    <?php if ( comments_open() ) : ?>
    <span class="comments-link">
      <?php comments_popup_link( '<span class="leave-reply">' . __( 'Leave a Comment', 'twentytwelve' ) . '</span>', __( '1 Comment', 'twentytwelve' ), __( '% Comments', 'twentytwelve' ) ); ?>
    </span>
    <!-- .comments-link -->
    
    <?php endif; // comments_open() ?>
    
    <span class="catlinkwrap"> Categories: <?php the_category(', '); ?></span>
    
<?php }
}

//* Customize the entry meta in the entry header (requires HTML5 theme support)
add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
    $post_info = '[post_date]';
    return $post_info;
}

//* Add featured image to post
add_post_type_support( 'post', 'genesis-singular-images' );
add_post_type_support( 'page', 'genesis-singular-images' );

//* Set number of posts on category archive pages
function set_posts_per_category($query)
{
    if ($query->is_main_query() && $query->is_category() && !is_admin())
        $query->set('posts_per_page', 6);
}
 
add_action('pre_get_posts', 'set_posts_per_category');



/*========================== FOOTER AREA ========================== */
//* 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//CREDITS
function genesischild_footer_creds_text () {
  echo '<div class="creds">Theme by <a href="http://demo.com/" target="_blank">MY NAME IS HERE</a></div><div id="back-top"><a href="#top"><span>Back Top</span></a></div>';
}
add_filter( 'genesis_pre_get_option_footer_text', 'genesischild_footer_creds_text', 9 ); 


//Instagram Widget
function genesischild_footerwidgetheader() {
    genesis_register_sidebar( array(
    'id' => 'footerwidgetheader',
    'name' => __( 'Instagram Full Width Widget Footer', 'genesis' ),
    'description' => __( 'This is for full width instagram widget', 'genesis' ),
    ) );
}
add_action ('widgets_init','genesischild_footerwidgetheader');
function genesischild_footerwidgetheader_position ()  {
    echo '<div class="instagramwidget"><div class="wrap">';
    genesis_widget_area ('footerwidgetheader');
    echo '</div></div>';

}
add_action ('genesis_before_footer','genesischild_footerwidgetheader_position', 3);

/*========================== CUSTOM FIELDS ========================== */
add_action( 'genesis_entry_footer', 'custom_field_after_content', 10 );
/**
* @author Brad Dalton - WP Sites
* @link http://wp.me/p1lTu0-9WF
*/
function custom_field_after_content() {

    $custom_field = genesis_get_custom_field('shopthelook_code');
    if ( $custom_field ) {
        if ( ! is_category() ) {
            echo '<div id="shopthelook" class="stl">'; 
            echo '<h4 class="stl_title">';
            echo genesis_custom_field('shopthelook_title');
            echo '</h4>';
            echo do_shortcode( $custom_field );
            echo '</div>';
        }
    }
}

/*========================== WIDGET ========================== */
//search
add_filter( 'genesis_search_button_text', 'ss_genesis_search_button_text' );
function ss_genesis_search_button_text( $text ) {
  return esc_attr( 'Go' );
}


/*========================== Instagram Link Page ========================== */
function yoon_socpage() {
    genesis_register_sidebar( array(
    'id' => 'socpage-widgets-1',
    'name' => __( 'Instagram Landing Page', 'genesis' ),
    'description' => __( 'Displaying menu items or any widgets for your Instagram landing page', 'genesis' ),
    ) );
}
add_action ('widgets_init','yoon_socpage');