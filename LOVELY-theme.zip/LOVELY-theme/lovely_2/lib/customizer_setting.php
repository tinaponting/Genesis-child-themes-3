<?php
/*========================== CUSTOMIZER ========================== */
function ss_customizer( $wp_customize ) {
		// Section : Header Area
		$wp_customize->add_section( 'skyandstars_headerlogo', array(
			'title' => __( 'Header Size', 'skyandstars' ),
			'priority' => 60,
		) );

		// Section : Theme Color
		$wp_customize->add_section( 'skyandstars_theme_colors', array(
			'title' => __( 'Theme Color', 'skyandstars' ),
			'priority' => 80,
		) );

		// Section : Front Page
		$wp_customize->add_section('sk_section_home_top', array(
				'title'			=> __( 'Front page Setting', 'theme-slug' ),
				'active_callback' => 'is_front_page',
				'priority' => 80,
			)
		);


	
		//SETTING
		
		// Setting : Header Area Height
		$wp_customize->add_setting( 'header_logo_height' , array(
			'default' => '180',
			'transport'   => 'refresh',
			'sanitize_callback' => 'absint'
		) );
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'header_logo_height', array(
			'type' => 'number',
			'description' => __( 'Resize your Header height (Default is 180 pixels, maximum 300 pixels.).', 'skyandstars' ),
			'label' => 'Header logo height',
			'section' => 'skyandstars_headerlogo',
			'settings' => 'header_logo_height',
		) ) );

		// Background Color
		$wp_customize->add_setting( 'bgx_color' , array(
			'default' => '#ffffff',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'bgx_color', array(
			'label' => 'Theme Background Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'bgx_color',
		) ) );

		// MENU BACKGROUND
		$wp_customize->add_setting( 'menu_bg_color' , array(
			'default' => '#000000',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'menu_bg_color', array(
			'label' => 'Top Menu Background Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'menu_bg_color',
		) ) );
		// MENU LINK Color
		$wp_customize->add_setting( 'menu_link_color' , array(
			'default' => '#ffffff',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'menu_link_color', array(
			'label' => 'Top Menu Text Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'menu_link_color',
		) ) );
		// MENU LINK HOVER text
		$wp_customize->add_setting( 'menu_link_hvrcolor' , array(
			'default' => '#ffcccc',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'menu_link_hvrcolor', array(
			'label' => 'Menu Text Hover Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'menu_link_hvrcolor',
		) ) );



		// Text Color
		$wp_customize->add_setting( 'text_color' , array(
			'default' => '#333333',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'text_color', array(
			'label' => 'Text Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'text_color',
		) ) );
		
		// Post Title Color
		$wp_customize->add_setting( 'posttitle_color' , array(
			'default' => '#3d3d3d',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'posttitle_color', array(
			'label' => 'Post Title Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'posttitle_color',
		) ) );

		// Post Title Hover Color
		$wp_customize->add_setting( 'posttitle_hvrcolor' , array(
			'default' => '#ffcccc',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'posttitle_hvrcolor', array(
			'label' => 'Post Title Hover Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'posttitle_hvrcolor',
		) ) );

		// Theme Link Color
		$wp_customize->add_setting( 'content_link_color' , array(
			'default' => '#a2a2a2',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'content_link_color', array(
			'label' => 'Link Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'content_link_color',
		) ) );
		
		// Theme Link Hover Color
		$wp_customize->add_setting( 'link_hvrcolor' , array(
			'default' => '#ffcccc',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'link_hvrcolor', array(
			'label' => 'Link Hover Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'link_hvrcolor',
		) ) );
		
		//Read more button

		// BUTTON Color
		$wp_customize->add_setting( 'rmbtn_color' , array(
			'default' => '#ffcccc',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'rmbtn_color', array(
			'label' => 'Read more Background Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'rmbtn_color',
		) ) );
		
		// Button Text Color
		$wp_customize->add_setting( 'rmbtn_txt_color' , array(
			'default' => '#ffffff',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'rmbtn_txt_color', array(
			'label' => 'Read more Button Text Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'rmbtn_txt_color',
		) ) );
		
		// BUTTON HOVER Color
		$wp_customize->add_setting( 'rmbtn_hvrcolor' , array(
			'default' => '#f8b4b3',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'rmbtn_hvrcolor', array(
			'label' => 'Read more Button Hover Background Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'rmbtn_hvrcolor',
		) ) );
		
		
		// Button Text Hover Color
		$wp_customize->add_setting( 'rmbtntxt_hvrcolor' , array(
			'default' => '#ffffff',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'rmbtntxt_hvrcolor', array(
			'label' => 'Read more Button Text Hover Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'rmbtntxt_hvrcolor',
		) ) );

		/* end read more */
		
		// BUTTON Color
		$wp_customize->add_setting( 'btn_color' , array(
			'default' => '#000000',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'btn_color', array(
			'label' => 'Button Background Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'btn_color',
		) ) );
		
		// Button Text Color
		$wp_customize->add_setting( 'btn_txt_color' , array(
			'default' => '#ffffff',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'btn_txt_color', array(
			'label' => 'Button Text Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'btn_txt_color',
		) ) );
		
		// BUTTON HOVER Color
		$wp_customize->add_setting( 'btn_hvrcolor' , array(
			'default' => '#ffcccc',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'btn_hvrcolor', array(
			'label' => 'Button Hover Background Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'btn_hvrcolor',
		) ) );
		
		
		// Button Text Hover Color
		$wp_customize->add_setting( 'btntxt_hvrcolor' , array(
			'default' => '#ffffff',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'btntxt_hvrcolor', array(
			'label' => 'Button Text Hover Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'btntxt_hvrcolor',
		) ) );
		
		// Widget Text Color
		$wp_customize->add_setting( 'widgettxt_color' , array(
			'default' => '#000000',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'widgettxt_color', array(
			'label' => 'Widget Title Color',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'widgettxt_color',
		) ) );

		

		// Footer background
		$wp_customize->add_setting( 'footer_bgolor' , array(
			'default' => '#f6f6f6',
			'transport'   => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'footer_bgolor', array(
			'label' => 'Footer Background Color (3 columns footer widget area)',
			'section' => 'skyandstars_theme_colors',
			'settings' => 'footer_bgolor',
		) ) );

}
add_action( 'customize_register', 'ss_customizer' );
?>