<?php
/**
 * Custom amendments for the theme.
 * @package     Vivien Theme
 * @subpackage  Genesis
 */

//* Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'after_setup_theme', 'vivien_load_textdomain' );

//** Loads the child theme textdomain.
function vivien_load_textdomain() {
	load_child_theme_textdomain(
		'vivien',
		trailingslashit( get_stylesheet_directory() ) . 'languages'
	);
}

//* Translate theme
load_theme_textdomain('vivien', get_template_directory() . '/languages');


function my_theme_setup(){
	load_theme_textdomain('vivien', get_template_directory() . '/languages');


}


//** disable redirect front page
function disable_front_page_redirect_madness($redirect_url) {
	if( is_front_page() ) {
		$redirect_url = false;
	}

	return $redirect_url;
}

add_filter( 'redirect_canonical', 'disable_front_page_redirect_madness' );


//* Remove wordpress galery styles
add_filter( 'use_default_gallery_style', '__return_false' );

//* Add Theme Support for WooCommerce
add_theme_support( 'genesis-connect-woocommerce' );

//* Load Font Awesome
add_action( 'wp_enqueue_scripts', 'enqueue_font_awesome' );
function enqueue_font_awesome() {

	wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css' );

}

//* Compatibility with Woocommerce 3.0
add_action( 'after_setup_theme', 'yourtheme_setup' );

function yourtheme_setup() {
add_theme_support( 'wc-product-gallery-zoom' ); 
add_theme_support( 'wc-product-gallery-lightbox' );
add_theme_support( 'wc-product-gallery-slider' );

}


//* Add support for custom header
	add_theme_support( 'custom-header', array(
	'width'           => 800,
	'height'          => 300,
	'header-selector' => '.site-title a',
	'header-text'     => false
	) );


//* Change title H1 to H2
add_filter('tc_content_title_tag' , 'my_title_tag');
function my_title_tag() {
	return 'h2';
}


//* Include Shortcodes
require_once( get_stylesheet_directory() . '/includes/shortcodes/shortcode.php'  );


//* Include Custom Post Types
require_once( get_stylesheet_directory() . '/includes/cpt/super-cpt.php'  );
require_once( get_stylesheet_directory() . '/includes/cpt/vivien_cpt.php'  );


//* Theme Options/Functions

require_once ( get_stylesheet_directory() . '/includes/theme_functions.php'  );
require_once ( get_stylesheet_directory() . '/includes/theme_settings.php'  );


// Add Image upload and Color select to WordPress Theme Customizer.
require( get_stylesheet_directory() . '/lib/customize.php' );

// Include Customizer CSS.
require( get_stylesheet_directory() . '/lib/output.php' );


//* Additional Stylesheets

add_action( 'wp_enqueue_scripts', 'vivien_print_styles' );

function vivien_print_styles() {

	wp_register_style( 'pretty_photo_css', get_stylesheet_directory_uri().'/css/prettyPhoto.css' ,'', '3.1.5');
	wp_enqueue_style( 'pretty_photo_css' );
	wp_register_style( 'shortcode-css', get_stylesheet_directory_uri( ).'/includes/shortcodes/shortcode.css' ,'', '1.4' );
	wp_enqueue_style( 'shortcode-css'  );
	wp_register_style( 'font-awesome', get_stylesheet_directory_uri( ).'/css/font-awesome.min.css' );
	wp_enqueue_style( 'font-awesome'  );
	wp_enqueue_style( 'dashicons' );	
	wp_register_style( 'font-awesome', get_stylesheet_directory_uri( ).'/css/font-awesome.min.css' );
	wp_enqueue_style( 'font-awesome'  );
	wp_register_style( 'flexslider-css', get_stylesheet_directory_uri().'/css/flexslider.css' );
	wp_enqueue_style( 'flexslider-css' );
	

}


//* Shortcode CSS

add_action('admin_enqueue_scripts', 'vivien_enqueue_scripts');  
function vivien_enqueue_scripts(){
	global $current_screen;
	if($current_screen->base=='post'){

		//enqueue the script and CSS files for the TinyMCE editor formatting buttons
		
		wp_enqueue_script('jquery');
		wp_enqueue_script('jquery-ui-dialog');
		wp_enqueue_script('jquery-ui-core');
		wp_enqueue_script('jquery-ui-sortable');
		//set the style files
		wp_enqueue_style( 'shortcode_editor_style',get_stylesheet_directory_uri( ).'/includes/shortcodes/shortcode_editor_style.css' );

	}

}


//* Enable Shortcode in the Widget Area
add_filter('widget_text', 'do_shortcode');

//* Remove default WooCommerce Styles
add_filter( 'woocommerce_enqueue_styles', 'dequeue_woocommerce_general_stylesheet' );
function dequeue_woocommerce_general_stylesheet( $enqueue_styles ) {
	unset( $enqueue_styles['woocommerce-general'] );	
	return $enqueue_styles;
} 


/*//*+ Add WooCommerce Styles
function woocommerce_style_sheet() {
wp_register_style( 'woocommerce', get_stylesheet_directory_uri() . '/woocommerce/woocommerce.css' );
if ( class_exists( 'woocommerce' ) ) {
wp_enqueue_style( 'woocommerce' );
	}
}
add_action('wp_enqueue_scripts', 'woocommerce_style_sheet'); */



//* Display 12 products per page
add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 12;' ), 21 );

//* Change number or products per row to 3
add_filter('loop_shop_columns', 'loop_columns');
if (!function_exists('loop_columns')) {
function loop_columns() {
return 3; // 3 products per row
}
}

//* Number of related products on product page
function woo_related_products_limit() {
  global $product;
	
	$args['posts_per_page'] = 9;
	return $args;
}

//* Number of related products on product page
add_filter( 'woocommerce_output_related_products_args', 'vivien_related_products_args' );
  function vivien_related_products_args( $args ) {
	$args['posts_per_page'] = 3; // 3 related products
	$args['columns'] = 3; // arranged in 3 columns
	return $args;
}

//* Remove default sidebar, add shop sidebar
add_action( 'genesis_before', 'vivien_add_woo_sidebar', 20 );
function vivien_add_woo_sidebar() {
	if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
		if( is_woocommerce() ) {
			remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
			remove_action( 'genesis_sidebar_alt', 'genesis_do_sidebar_alt' );
			add_action( 'genesis_sidebar', 'vivien_woo_sidebar' );
		}
	}
	
}

//* Display the WooCommerce sidebar
function vivien_woo_sidebar() {
	if ( ! dynamic_sidebar( 'woo_primary_sidebar' ) && current_user_can( 'edit_theme_options' )  ) {
		genesis_default_widget_area_content( __( 'WooCommerce Primary Sidebar', 'genesis' ) );
	}
}


/**
* Add search and cart in Nav areas
*/
add_filter( 'wp_nav_menu_items', 'zp_theme_nav_extras', 10, 2 );
function zp_theme_nav_extras( $menu, $args ) {
	global $woocommerce, $post;
	$cart_nav_icon_item = $minicart = '';
	if ( 'primary' !== $args->theme_location && 'sticky_menu' !== $args->theme_location )
		return $menu;
	if (class_exists( 'Woocommerce' )) {	
		//get cart icon settings
		$link = $woocommerce->cart->get_cart_url();
		$total = $woocommerce->cart->cart_contents_count;
		$total = ( $total > 0 ) ? $total : 0;
		$checkout = $woocommerce->cart->get_checkout_url();
		//mini cart
		$minicart .= '<div class="widget woocommerce widget_shopping_cart" style="display: none;"><div class="widget_shopping_cart_content">
			<ul class="cart_list product_list_widget "></ul>
			<p class="total"><strong>'.__( 'Subtotal:', 'vivien').'</strong> <span class="amount">0</span></p>
			<p class="buttons">
				<a href="'.$link.'" class="button wc-forward">'.__( 'View Cart', 'vivien').'</a>
				<a href="'.$checkout.'" class="button checkout wc-forward">'.__( 'Checkout', 'vivien').'</a>
			</p></div></div>';
		$cart_nav_icon_item .= '<li class="right zp_cart_item"><a href="'.$link.'" class="external navcart"><i class="fa fa-shopping-cart"></i>( '.$total.' )</a>'.$minicart.'</li>';
	}
	$menu .= $cart_nav_icon_item;
	return $menu;
}


/**
 * Product Cart Contents
*/
add_filter('woocommerce_add_to_cart_fragments', 'zp_add_to_cart_fragment');
function zp_add_to_cart_fragment( $fragments ) {
	global $woocommerce;

	$link = $woocommerce->cart->get_cart_url();
	$total = $woocommerce->cart->cart_contents_count;
	$total = ( $total > 0 ) ? $total : 0;

	ob_start();
	?>
	<a href="<?php echo $link; ?>" class="external navcart" ><i class="fa fa-shopping-cart"></i>( <?php echo $total; ?> )</a>
	<?php

	$fragments['a.navcart'] = ob_get_clean();

	return $fragments;
}



//* Add Menu descriptions
add_filter( 'walker_nav_menu_start_el', 'skin_add_menu_description', 10, 4 );
function skin_add_menu_description( $item_output, $item, $depth, $args ) {
	if ( 'secondary' == $args->theme_location && $item->description );
	if ( 'primary' == $args->theme_location && $item->description );
	 {
		$item_output = str_replace( $args->link_after . '</a>', '<span class="menu-description">' . $item->description . '</span>' . $args->link_after . '</a>', $item_output );
	}

	return $item_output;
}  


//* Add theme support for new menu
// Add Footer Menu; Keep Primary and Secondary Menus

add_theme_support ( 'genesis-menus' , array ( 
	'primary'   => __( 'Primary Navigation Menu', 'vivien' ),
	'secondary' => __( 'Secondary Navigation Menu', 'vivien' ),
	'footer'    => __( 'Footer Navigation Menu', 'vivien' )
	) );


//* Add Attributes for Footer Navigation
add_filter( 'genesis_attr_nav-footer', 'genesis_attributes_nav' ); 



// Add attributes to markup
// Add footer menu just above footer widget area
add_action( 'genesis_footer', 'vivien_footer_menu', 9 );
function vivien_footer_menu() {

	genesis_nav_menu( array(
		'theme_location' => 'footer',
		'container'       => 'div',
		'container_class' => 'wrap',
		'menu_class'     => 'menu genesis-nav-menu menu-footer',
		'depth'           => 1
	) );

}

//* Add custom attributes to footer navigation
add_filter( 'genesis_attr_nav-footer', 'custom_add_nav_footer_attr' );
function custom_add_nav_footer_attr( $attributes ){

	$attributes['role'] = 'navigation';
	$attributes['itemscope'] = 'itemscope';
	$attributes['itemtype'] = 'http://schema.org/SiteNavigationElement';
	
	return $attributes;
		
}


add_action( 'genesis_setup', 'vivien_theme_setup', 15 );


//* Theme Setup

function vivien_theme_setup() {

	//* Child theme (do not remove)
	define( 'CHILD_THEME_NAME', __( 'vivien Theme', 'vivien' ) );
	define( 'CHILD_THEME_VERSION', '1.0.0' );
	define( 'CHILD_THEME_URL', 'http://lovelyconfetti.com/feminine-wordpress-themes' );
	define( 'CHILD_THEME_DEVELOPER', __( 'Cristina Sanz', 'vivien' ) );

	//* Add viewport meta tag for mobile browsers.
	add_theme_support( 'genesis-responsive-viewport' );

	//* Add HTML5 markup structure.
	add_theme_support( 'html5' );

	//**	Set content width.
	$content_width = apply_filters( 'content_width', 610, 610, 980 );

	//* Add new featured image sizes.
	add_image_size( 'horizontal-blog', 400, 300, true );
	add_image_size( 'vertical-blog', 400, 600, true );
	add_image_size( 'square-blog', 400, 400, true );
	add_image_size( 'Flexible image widgets', 564, 263, true );
	add_image_size( 'portfolio', 365, 250, TRUE );
	add_image_size( 'related', 235, 175, TRUE );
	add_image_size( 'gallery-item', 352, 200, false );
	add_image_size( 'medium', 300, 200, true );
	add_image_size( 'large-thumbnail', 1024, 678, true );



	
//* Unregister header right sidebar.
	
	unregister_sidebar( 'header-right' );

//* Replace 'Home' text with a home icon in Genesis Framework breadcrumb
	add_filter ( 'genesis_home_crumb', 'afn_breadcrumb_home_icon' ); 
	function afn_breadcrumb_home_icon( $crumb ) {
	 $crumb = '<a href="' . home_url() . '" title="' . get_bloginfo('name') . '"><i class="dashicons dashicons-admin-home"></i></a>';
	 return $crumb;
	}

//* Remove 'You are here' texts in Genesis Framework breadcrumb

	add_filter( 'genesis_breadcrumb_args', 'vivien_breadcrumb_args' );
	function vivien_breadcrumb_args( $args ) {
	$args['labels']['prefix'] = '';
	return $args;
	}

//* Unregister layout settings

	genesis_unregister_layout( 'content-sidebar-sidebar' );
	genesis_unregister_layout( 'sidebar-content-sidebar' );
	genesis_unregister_layout( 'sidebar-sidebar-content' );

//* Unregister secondary sidebar

	unregister_sidebar( 'sidebar-alt' );

//* Reposition the Secondary navigation menu

	remove_action( 'genesis_after_header', 'genesis_do_subnav' );
	add_action( 'genesis_before_footer', 'genesis_do_subnav', 9 );


//* Remove output of primary navigation right extras
	remove_filter( 'genesis_nav_items', 'genesis_nav_right', 10, 2 );
	remove_filter( 'wp_nav_menu_items', 'genesis_nav_right', 10, 2 );


//* Add support for custom header

	add_theme_support( 'custom-header', array(
	'width'           => 800,
	'height'          => 300,
	'header-selector' => '.site-title a',
	'header-text'     => false
	) );



//* Add support for 3-column footer widgets.

 add_theme_support( 'genesis-footer-widgets', 3 );
	}

	add_action( 'genesis_setup', 'vivien_includes', 20 );

//* Load additional functions and helpers.

	function vivien_includes() {
	$includes_dir = trailingslashit( get_stylesheet_directory() ) . 'includes/';

	// Load the customizer library.
	require_once $includes_dir . 'vendor/customizer-library/customizer-library.php';

	// Load all customizer files.
	require_once $includes_dir . 'customizer/customizer-display.php';
	require_once $includes_dir . 'customizer/customizer-settings.php';


	// Load everything in the includes root directory.
	require_once $includes_dir . 'helper-functions.php';
	require_once $includes_dir . 'compatability.php';
	require_once $includes_dir . 'simple-grid.php';
	require_once $includes_dir . 'widgeted-areas.php';
	require_once $includes_dir . 'widgets.php';


	// End here if we're not in the admin panel.
	if ( ! is_admin() ) {
		return;
	}



}

/**
 * Load Genesis
 *
 * This is technically not needed.
 * However, to make functions.php snippets work, it is necessary.
 */
require_once( get_template_directory() . '/lib/init.php' );

add_action( 'wp_enqueue_scripts', 'vivien_enqueue_js' );


//* Load all required JavaScript for the vivien theme.

function vivien_enqueue_js() {
	$js_uri = get_stylesheet_directory_uri() . '/assets/js/';

	// Add general purpose scripts.

	

	wp_register_script( 'jquery_cycle', get_stylesheet_directory_uri(  ) . '/js/jquery.cycle.lite.js', array( 'jquery' ), '1.7', true );	
	wp_register_script('custom_js', get_stylesheet_directory_uri().'/js/jquery.custom.js',array( 'jquery' ), '1.5', true );
	wp_register_script('jquery_pretty_photo_js', get_stylesheet_directory_uri() . '/js/jquery.prettyPhoto.js', array('jquery', 'custom_js') ,'3.1.6', true);			
    wp_enqueue_script('jquery');
	wp_enqueue_script('jquery_easing_js', get_stylesheet_directory_uri() . '/js/jquery-easing.js', array(), '1.3', true);
	wp_enqueue_script('script_js', get_stylesheet_directory_uri() . '/js/script.js', array(), '1.2.4', true );	
	wp_enqueue_script('jquery_isotope_min_js', get_stylesheet_directory_uri().'/js/jquery.isotope.min.js', array(), '1.5.25', true );
	wp_enqueue_script('jQuery_ScrollTo_min_js', get_stylesheet_directory_uri() .'/js/jquery.scrollTo.min.js', array(), '1.4.2', true );
	wp_enqueue_script('jquery_tipTip', get_stylesheet_directory_uri().'/js/jquery.tipTip.minified.js', array(), '1.3', true );
	wp_enqueue_script('custom_js');	
	wp_enqueue_script('jquery_pretty_photo_js');
	wp_register_script( 'jquery_carouFredSel', get_stylesheet_directory_uri(  ) . '/js/carousel/jquery.carouFredSel.min.js', array( 'jquery' ), '6.2.1', true );
	wp_register_script( 'jquery_mousewheel', get_stylesheet_directory_uri(  ) . '/js/carousel/jquery.mousewheel.min.js',array( 'jquery' ), '3.0.6', true );
	wp_register_script( 'jquery_touchswipe', get_stylesheet_directory_uri(  ) . '/js/carousel/jquery.touchSwipe.min.js',array( 'jquery' ), '1.3.3', true );
	wp_register_script( 'jquery_transit', get_stylesheet_directory_uri(  ) . '/js/carousel/jquery.transit.min.js',array( 'jquery' ), '0.9.9', true );
	wp_register_script( 'jquery_throttle', get_stylesheet_directory_uri(  ) . '/js/carousel/jquery.ba-throttle-debounce.min.js', array( 'jquery' ), '1.1', true );		
	wp_enqueue_script( 'localScroll', get_stylesheet_directory_uri() . '/js/jquery.localScroll.min.js', array( 'scrollTo' ), '1.2.8b', true );
	wp_enqueue_script( 'scrollTo', get_stylesheet_directory_uri() . '/js/jquery.scrollTo.min.js', array( 'jquery' ), '1.4.5-beta', true );
	wp_enqueue_script( 'fadeup-script', get_stylesheet_directory_uri() . '/js/fadeup.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_script( 'match-height', get_stylesheet_directory_uri() . '/js/jquery.matchHeight-min.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_script( 'match-height-init', get_stylesheet_directory_uri() . '/js/matchheight-init.js', array( 'match-height' ), '1.0.0', true );
	wp_enqueue_script( 'global-script', get_bloginfo( 'stylesheet_directory' ) . '/js/nav.js', array( 'jquery' ), '1.0.0' );




}

add_filter( 'body_class', 'vivien_add_body_class' );

//* Add the theme name class to the body element.

function vivien_add_body_class( $classes ) {
	$classes[] = 'vivien';
	return $classes;
}





//* Add post navigation.
add_filter( 'excerpt_more', 'vivien_read_more_link' );
add_filter( 'get_the_content_more_link', 'vivien_read_more_link' );
add_filter( 'the_content_more_link', 'vivien_read_more_link' );



//* Genesis Previous/Next Post Post Navigation 

add_action( 'genesis_before_comments', 'vivien_prev_next_post_nav' );
 
function vivien_prev_next_post_nav() {
  
	if ( is_single() ) {
 
		echo '<div class="prev-next-navigation">';
		previous_post_link( '<div class="previouspost">Previous: %link</div>', '%title' );
		next_post_link( '<div class="nextpost">Next: %link</div>', '%title' );
		echo '</div><!-- .prev-next-navigation -->';
 
	}
 
}

//* To Top Link
add_action( 'genesis_before_footer','zp_add_top_link' );
function zp_add_top_link(  ){
	echo '<a href="#top" id="top-link"><i class="fa fa-angle-up"></i></a>';
}

//* Modify the Genesis read more link.

function vivien_read_more_link() {
	return '...</p><p><a class="more-link" href="' . get_permalink() . '">' . __( 'Read More', 'vivien' ) . ' </a></p>';
}

add_filter( 'genesis_comment_form_args', 'vivien_comment_form_args' );


//* Setup widget counts

function vivien_count_widgets( $id ) {

	global $sidebars_widgets;

	if ( isset( $sidebars_widgets[ $id ] ) ) {
		return count( $sidebars_widgets[ $id ] );
	}

}

function vivien_widget_area_class( $id ) {

	$count = vivien_count_widgets( $id );

	$class = '';

	if ( $count == 1 ) {
		$class .= ' widget-full';
	} elseif ( $count % 3 == 0 ) {
		$class .= ' widget-thirds';
	} elseif ( $count % 4 == 0 ) {
		$class .= ' widget-fourths';
	} elseif ( $count % 2 == 1 ) {
		$class .= ' widget-halves uneven';
	} else {	
		$class .= ' widget-halves';
	}

	return $class;

}

//* Modify the speak your mind text.

function vivien_comment_form_args( $args ) {
	$args['title_reply'] = __( 'Comments', 'vivien' );
	return $args;
}



//* Customize the credits 

	add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');
	function custom_footer_creds_text() {
	echo '<div class="creds"><p>';
	echo 'Copyright &copy; ';
	echo date('Y');
	echo ' &middot; <a target="_blank" href="https://exempel.se/shop">My theme</a> by <a target="_blank" href="https://exempel.se">EXEMPEL</a><a href="http://www.dmca.com/Protection/Status.aspx?ID=0960d3f3-2441-4900-bc5d-877ef3e6272c" title="DMCA.com Protection Status" class="dmca-badge"> <img src="//images.dmca.com/Badges/dmca-badge-w100-5x1-11.png?ID=0960d3f3-2441-4900-bc5d-877ef3e6272c" alt="DMCA.com Protection Status"></a> <script src="//images.dmca.com/Badges/DMCABadgeHelper.min.js"> </script>';
	echo '</p></div>';

}



//* Customize search form input box text
add_filter( 'genesis_search_text', 'sp_search_text' );
function sp_search_text( $text ) {
	return esc_attr( 'Search this site' );
}

//* Customize search form input button text
add_filter( 'genesis_search_button_text', 'sk_search_button_text' );
function sk_search_button_text( $text ) {

	return esc_attr( '&#xf179;' );

}


//* Add Accessibility support

add_theme_support( 'genesis-accessibility', array( 'headings', 'drop-down-menu',  'search-form', 'skip-links' ) );


//* Hide Woocommerce page title 

add_filter( 'woocommerce_show_page_title' , 'woo_hide_page_title' );
function woo_hide_page_title() {
	
	return false;
	
}

//* Customize the entry meta in the entry header

add_filter( 'genesis_post_info', 'vivien_post_info_filter' );
function vivien_post_info_filter( $post_info ) {

	$post_info = '[post_date format="M d Y"] [post_comments] [post_edit]';

	return $post_info;

}

//* Customize the entry meta in the entry footer

add_filter( 'genesis_post_meta', 'vivien_post_meta_filter' );
function vivien_post_meta_filter( $post_meta ) {

	$post_meta = '[post_tags before=" Tagged: "] [post_categories before=" Categorized: "]';
	return $post_meta;
	
}



// Register a custom image size for images in the carousel slider on front page

add_image_size( 'home-carousel-image', 0, 520, true );

// Display Home Carousel widget area on front page

add_action( 'genesis_after_header', 'vivien_home_carousel');
function vivien_home_carousel() {
	if ( ! is_front_page() ) {
		return;
	}

	genesis_widget_area( 'home-carousel', array(
		'before'	=> '<div class="home-carousel-section widget-area">',
		'after'		=> '</div>',
	) );

	genesis_widget_area( 'carousel-cta', array(
		'before'	=> '<div class="carousel-cta widget-area">',
		'after'		=> '</div>',
	) );
	

}

// Enqueue Slick on front page
add_action( 'wp_enqueue_scripts', 'vivien_enqueue_slick' );
function vivien_enqueue_slick() {

	if ( ! is_front_page() ) {
		return;
	}

	wp_enqueue_style( 'slick-styles', get_stylesheet_directory_uri() . '/css/slick.css' );
	wp_enqueue_script( 'slick-js', get_stylesheet_directory_uri() . '/js/slick.min.js', array( 'jquery' ), '1.5.0', true );
	wp_enqueue_script( 'slick-init', get_stylesheet_directory_uri() . '/js/slick-init.js', array( 'slick-js' ), '1.0.0', true );

}

add_filter( 'soliloquy_output', 'vivien_soliloquy_transform_to_carousel', 10, 2 );
/**
 * Circumvents the slider output and allows access to raw format.
 *
 * @param string $slider   The slider HTML.
 * @param array $data      Array of slider data.
 * @return string $carousel New HTML output with the data being turned into a carousel!
 */
function vivien_soliloquy_transform_to_carousel( $slider, $data ) {

	// Prepare your $carousel variable. All carousel HTML will be stored in here.
	$carousel = '';

	$slider_id = $data['id']; // Get Slider ID

	$carousel = '<div class="home-carousel"><div class="items-wrapper">';

	foreach ( (array) $data['slider'] as $id => $item ) {
		// Skip over images that are pending (ignore if in Preview mode).
		if ( isset( $item['status'] ) && 'pending' == $item['status'] && ! is_preview() ) {
			continue;
		}

		$src = wp_get_attachment_image_src( $id, 'home-carousel-image' );
		$carousel .= '<img src="'. $src[0] .'" />';
	}


	$carousel .= '</div>';

	// Return the $carousel variable to be output by Soliloquy.
	return $carousel;

}


//* Hooks widget area before footer
add_action( 'genesis_before_footer', 'vivien_above_footers', 10  );
function vivien_above_footers() {{

	genesis_widget_area( 'above-footers', array(
		'before' => '<div class="above-footers widget-area"><div class="above-footers-wrap">',
		'after'  => '</div></div>',
	) );

}}


//* Related posts

//for XHTML themes
add_action( 'genesis_after_post_content', 'child_related_posts' );

//for HTML5 themes
add_action( 'genesis_after_entry_content', 'child_related_posts' );
/**
 * Outputs related posts with thumbnail
 * @global object $post 
 */
function child_related_posts() {
	 
	if ( is_single ( ) ) {
		 
		global $post;
 
		$count = 0;
		$postIDs = array( $post->ID );
		$related = '';
		$cats = wp_get_post_categories( $post->ID );
		 
			   
		   
		if ( $count <= 3 ) {
			 
			$catIDs = array( );
 
			foreach ( $cats as $cat ) {
				 
				if ( 3 == $cat )
					continue;
				$catIDs[] = $cat;
				 
			}
			 
			$showposts = 4 - $count;
 
			$args = array(
				'category__in'          => $catIDs,
				'post__not_in'          => $postIDs,
				'showposts'             => $showposts,
				'ignore_sticky_posts'   => 1,
				'orderby'               => 'rand',
				'tax_query'             => array(
									array(
										'taxonomy'  => 'post_format',
										'field'     => 'slug',
										'terms'     => array( 
											'post-format-link', 
											'post-format-status', 
											'post-format-aside', 
											'post-format-quote' ),
										'operator' => 'NOT IN'
									)
				)
			);
 
			$cat_query = new WP_Query( $args );
			 
			if ( $cat_query->have_posts() ) {
				 
				while ( $cat_query->have_posts() ) {
					 
					$cat_query->the_post();
 
					$img = genesis_get_image() ? genesis_get_image( array( 'size' => 'related' ) ) : '<img src="' . get_bloginfo( 'stylesheet_directory' ) . '/images/related.png" alt="' . get_the_title() . '" />';
 
					$related .= '<li><a href="' . get_permalink() . '" rel="bookmark" title="Permanent Link to' . get_the_title() . '">' . $img . get_the_title() . '</a></li>';
				}
			}
		}
 
		if ( $related ) {
			 
			printf( '<div class="related-posts"><h3 class="related-title">Related Posts</h3><ul class="related-list">%s</ul></div>', $related );
		 
		}
		 
		wp_reset_query();
		 
	}
}

/**
* @author Brad Dalton - WP Sites
*/
add_action( 'genesis_before_content', 'wpsites_custom_widget', 5 );
function wpsites_custom_widget() {
if ( is_page_template( 'page_blog.php' ) && is_active_sidebar( 'custom-widget' ) ) 
	genesis_widget_area( 'custom-widget', array(
	'before' => '<aside class="custom-widget">',
	'after'  => '</aside>',
) );
}

//* Hooks Utiliy Bar above header

add_action( 'genesis_before_header', 'utility_bar' );
/**
* Add utility bar above header.
*
* @author Carrie Dils
* @copyright Copyright (c) 2013, Carrie Dils
* @license GPL-2.0+
*/
function utility_bar() {
 
	echo '<div class="utility-bar"><div class="wrap">';
 
	genesis_widget_area( 'utility-bar-left', array(
		'before' => '<div class="utility-bar-left">',
		'after' => '</div>',
	) );
 
	genesis_widget_area( 'utility-bar-right', array(
		'before' => '<div class="utility-bar-right">',
		'after' => '</div>',
	) );
 
	echo '</div></div>';
 
}

//* Hooks column header widget areas

add_action( 'genesis_before_header', 'column_header_widgets'  ); 

function column_header_widgets() {
	echo '<div class="column-header">';
	genesis_widget_area( 'column-header-left', array(
		'before' => '<div class="column-header-left widget-area"><div class="wrap">',
		'after'  => '</div></div>',

	) );

  
	genesis_widget_area( 'column-header-right', array(
		'before' => '<div class="column-header-right widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );
   
	echo '</div>';



}





//* Hooks Widget Area Above Content
	add_action( 'genesis_after_header', 'vivien_widget_above_content'  );
	function vivien_widget_above_content() {
		if ( ! is_front_page() ) {

	genesis_widget_area( 'widget-above-content', array(
		'before' => '<div class="widget-above-content widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );

	}}