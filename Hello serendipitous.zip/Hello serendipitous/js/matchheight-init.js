jQuery(function( $ ){

	$('.hyd-archive .content .entry, .front-page .content .entry, .journal .entry, .category-index .featured-content .entry, .footer-widgets-1 .widget, .footer-widgets-3 .widget, .woocommerce ul.products li.product, .woocommerce-page ul.products li.product').matchHeight();

});
