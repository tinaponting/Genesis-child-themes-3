<?php
/*========================== CUSTOMIZER ========================== */
function ss_customizer( $wp_customize ) {
		// Section : Header Area
		$wp_customize->add_section( 'skyandstars_headerlogo', array(
			'title' => __( 'Header Size', 'skyandstars' ),
			'priority' => 60,
		) );
	
		//SETTING
		
		// Setting : Header Area Height
		$wp_customize->add_setting( 'header_logo_height' , array(
			'default' => '150',
			'transport'   => 'refresh',
			'sanitize_callback' => 'absint'
		) );
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'header_logo_height', array(
			'type' => 'number',
			'description' => __( 'Resize your Header height (Default is 150px, maximum 380px).', 'skyandstars' ),
			'label' => 'Header logo height',
			'section' => 'skyandstars_headerlogo',
			'settings' => 'header_logo_height',
		) ) );

		
		//Footer
		$wp_customize->add_section( 'ss_copyright', array(
		'title' => __( 'Footer Credit', 'skyandstars' ),
		'priority' => 70,
		) );
		$wp_customize->add_setting( 'sky_copyright' , array(
			'default' => 'Your Blog Name.  All Rights Reserved.',
			'transport' => 'refresh',
			'priority' => 4,     
		) );
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'sky_copyright', array(
			'type' => 'text',
			'label' => 'Footer Copyright',
			'section' => 'ss_copyright',
			'settings' => 'sky_copyright'
		) ) );
}
add_action( 'customize_register', 'ss_customizer' );
?>