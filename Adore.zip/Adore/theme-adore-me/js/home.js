/**
 * This script adds the jquery effects to the front page of the Adore Me Theme.
 * @package Adore Me\JS
 */

(function( $ ){

	$( '.home-tabs' ).tabs({
		hide: true // tab panels will fade out with the default duration and the default easing.
	});
	
	
})(jQuery);
