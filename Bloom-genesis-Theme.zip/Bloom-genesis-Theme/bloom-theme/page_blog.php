<?php
/**
 * This file adds the blog page to the theme
 */

/*
Template Name: Blog
*/



genesis();