<?php
/**
 * Kylee More.
 * @package Kylee More
 */

add_action( 'wp_enqueue_scripts', 'kylee_css' );
/**
 * Checks the settings for the link color color, accent color, and header.
 * If any of these value are set the appropriate CSS is output.
 *
 * @since 1.0.0
 */
function kylee_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';

	$color_accent = get_theme_mod( 'kylee_accent_color', kylee_customizer_get_default_accent_color() );
	$color_accent_font = get_theme_mod( 'kylee_accent_font_color', kylee_customizer_get_default_accent_font_color() );
	$color_link = get_theme_mod( 'kylee_link_color', kylee_customizer_get_default_link_color() );
	$color_site_title = get_theme_mod( 'kylee_site_title_color', kylee_customizer_get_default_site_title_color() );
	$color_site_description = get_theme_mod( 'kylee_site_description_color', kylee_customizer_get_default_site_description_color() );
	$color_heading = get_theme_mod( 'kylee_heading_color', kylee_customizer_get_default_heading_color() );
	$color_body_font = get_theme_mod( 'kylee_body_font_color', kylee_customizer_get_default_body_font_color() );
	$color_button = get_theme_mod( 'kylee_button_color', kylee_customizer_get_default_button_color() );
	$color_button_font = get_theme_mod( 'kylee_button_font_color', kylee_customizer_get_default_button_font_color() );


	$css = '';
	

	$css .= ( kylee_customizer_get_default_accent_color() !== $color_accent ) ? sprintf( '
		
		blockquote,
		.site-container button:disabled,
		.site-container button:disabled:hover,
		.site-container input:disabled,
		.site-container input:disabled:hover,
		.site-container input[type="button"]:disabled,
		.site-container input[type="button"]:disabled:hover,
		.site-container input[type="reset"]:disabled,
		.site-container input[type="reset"]:disabled:hover,
		.site-container input[type="submit"]:disabled,
		.site-container input[type="submit"]:disabled:hover,
		.nf-form-cont,
		.enews,
		.content div.sharedaddy a.sd-button,
		.genesis-nav-menu .sub-menu a,
		.search .search-form input[type="search"]:focus,
		.even.entry,
		.front-page-2,
		.archive-pagination li a,
		.archive-pagination .pagination-next > a,
		.archive-pagination .pagination-previous > a,
		.instagram-page .site-inner,
		.widget-above-footer.widget-area,
		.footer-widgets,
		.after-entry {
			background-color: %1$s;
		}
		
		.nav-primary {
			border-top-color: %1$s;
		}
		
		.sidebar li.cat-item a:hover,
  		.sidebar .widget_nav_menu a:hover {
			background-color: %1$s;
			border-color: %1$s;
		}
		
		.landing-page .content {
			border-color: %1$s;
		}
		
		#sharing_email .sharing_send, 
		.sd-content ul li .option a.share-ustom, 
		.sd-content ul li a.sd-button, 
		.sd-content ul li.advanced a.share-more, 
		.sd-content ul li.preview-item div.option.option-smart-off a, 
		.sd-social-icon .sd-content ul li a.sd-button, 
		.sd-social-icon-text .sd-content ul li a.sd-button, 
		.sd-social-official .sd-content > ul > li .digg_button > a, 
		.sd-social-official .sd-content > ul > li > a.sd-button, 
		.sd-social-text .sd-content ul li a.sd-button,
		.front-page-2 .enews-widget {
			background-color: %1$s !important;
		}
		
		.site-footer {
			border-bottom-color: %1$s;
		}
		
		@media only screen and (max-width: 800px) {
			.menu-toggle,
			.sub-menu-toggle {
				border-top-color: %1$s !important;
			}
		}

		', $color_accent, kylee_color_contrast( $color_accent ) ) : '';
	
	$css .= ( kylee_customizer_get_default_accent_font_color() !== $color_accent_font ) ? sprintf( '
	
		.genesis-nav-menu .search ::-moz-placeholder,
		.front-page-1 .featuredpage .widget-title, 
		.front-page-1 .featuredpost .widget-title,
		.search .search-form input[type="search"]:focus,
		.soliloquy-caption h4.title,
		.enews .widget-title,
		.enews-widget p,
		.even.entry .entry-title a,
		.even.entry .entry-header,
		.even.entry p,
		.even.entry .share-after::before,
		.even.entry .sharrre .share,
		.even.entry .sharrre:hover .share,
		.archive-pagination li a,
		.footer-widgets a,
		.footer-widgets,
		.footer-widgets .widget-title,
		.footer-widgets h2,
		.instagram-page .entry-title, 
		.instagram-page .entry-title a,
		.instagram-page .widget-title,
		.sidebar li.cat-item a:hover, 
		.sidebar .widget_nav_menu a:hover,
		.genesis-nav-menu .sub-menu a,
		.wp-block-ninja-forms-form {
			color: %1$s;
		}
		
		.soliloquy-caption-inside {
			color: %1$s !important;
		}
	
		', $color_accent_font, kylee_color_contrast( $color_accent_font ) ) : '';
	
	$css .= ( kylee_customizer_get_default_link_color() !== $color_link ) ? sprintf( '
	
		a,
		.entry-title a:hover,
		.entry-title a:focus,
		.even.entry .entry-title a:hover,
		.even.entry .entry-title a:focus,
		.footer-widgets .featured-content .entry-meta a:hover,
		.footer-widgets .featured-content .entry-meta a:focus,
		.sidebar .featured-content .entry-meta a:hover,
		.sidebar .featured-content .entry-meta a:focus,
		.genesis-nav-menu a:hover,
		.genesis-nav-menu a:focus,
		.genesis-nav-menu .sub-menu a:hover, 
		.genesis-nav-menu .sub-menu a:focus,
		.instagram-page a:hover,
		.footer-widgets a:hover,
		.footer-widgets a:focus,
		.site-footer a:hover,
		.site-footer a:focus,
		.front-page-1 a:hover,
		.front-page-1 a:focus {
			color: %1$s;
		}
		
		.kylee-archive .entry-title a:hover,
		.kylee-archive .entry-title a:focus {
			color: %1$s !important;
		}
		
		@media only screen and (max-width: 800px) {
		
			.menu-toggle:focus,
			.menu-toggle:hover,
			.sub-menu-toggle:focus,
			.sub-menu-toggle:hover {
				color: %1$s;
			}
		
		}
	
		', $color_link, kylee_color_contrast( $color_link ) ) : '';
	
	$css .= ( kylee_customizer_get_default_site_title_color() !== $color_site_title ) ? sprintf( '
	
		.site-title a,
		.site-title a:hover,
		.site-title a:focus{
			color: %1$s;
		}
		
		', $color_site_title, kylee_color_contrast( $color_site_title ) ) : '';
	
	$css .= ( kylee_customizer_get_default_site_description_color() !== $color_site_description ) ? sprintf( '
	
		.site-description {
			color: %1$s;
		}
		
		', $color_site_description, kylee_color_contrast( $color_site_description ) ) : '';
	
	$css .= ( kylee_customizer_get_default_heading_color() !== $color_heading ) ? sprintf( '
	
		.entry-title a,
		h1,
		h2,
		h3,
		h4,
		h5,
		h6 {
			color: %1$s;
		}
		
		.kylee-archive .entry-title,
		.kylee-archive .entry-title a {
			color: %1$s !important;
		}
		
		
		', $color_heading, kylee_color_contrast( $color_heading ) ) : '';
	
	$css .= ( kylee_customizer_get_default_body_font_color() !== $color_body_font ) ? sprintf( '
	
		body,
		::-moz-placeholder,
		.genesis-nav-menu a,
		.site-footer a,
		.site-footer p,
		.search .search-form:before,
		.sidebar li.cat-item a, 
		.sidebar .widget_nav_menu a,
		.widget-above-footer h3,
		.instagram-page a,
		a.more-link:hover,
		button:hover,
		input:hover[type="button"],
		input:hover[type="reset"],
		input:hover[type="submit"],
		.button:hover,
		button:focus,
		input:focus[type="button"],
		input:focus[type="reset"],
		input:focus[type="submit"],
		.button:focus,
		.soliloquy-caption .button:hover,
		.soliloquy-caption .button:focus,
		.archive-pagination li.active a,
		.archive-pagination li a:hover, 
		.archive-pagination li a:focus,
		.footer-widgets .button:hover, 
		.footer-widgets .button:focus {
			color: %1$s;
		}
		
		@media only screen and (max-width: 800px) {
		
			.search .search-form:before {
				color: %1$s;
			}
		
		}
		
		', $color_body_font, kylee_color_contrast( $color_body_font ) ) : '';
	
	$css .= ( kylee_customizer_get_default_button_color() !== $color_button ) ? sprintf( '
	
		button,
		input[type="button"],
		input[type="reset"],
		input[type="select"],
		input[type="submit"],
		.button,
		.soliloquy-caption .button,
		a.more-link,
		.soliloquy-container .soliloquy-caption a.soliloquy-button,
		.to-top {
			background-color: %1$s;
		}
		
		.enews-widget input[type="submit"],
		button,
		input[type="button"],
		input[type="reset"],
		input[type="select"],
		input[type="submit"],
		.button,
		.soliloquy-caption .button {
			border-color: %1$s;
		}
		
		', $color_button, kylee_color_contrast( $color_button ) ) : '';
	
	$css .= ( kylee_customizer_get_default_button_font_color() !== $color_button_font ) ? sprintf( '
	
		button,
		input[type="button"],
		input[type="reset"],
		input[type="select"],
		input[type="submit"],
		.button,
		.soliloquy-caption .button,
		a.more-link,
		.footer-widgets .button {
			color: %1$s;
		}
	
		', $color_button_font, kylee_color_contrast( $color_button_font ) ) : '';


	if ( $css ) {
		wp_add_inline_style( $handle, $css );
	}

}
