<?php
/**
 * Template Name: Instagram
 *
 */

add_action( 'genesis_meta', 'social_page' );
function social_page() {
	if ( is_active_sidebar( 'socpage-widgets-1' ) ) {

			//* Force full width content layout
			add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
			
			//* Remove navigation
			remove_theme_support( 'genesis-menus' );

			//* Remove breadcrumbs
			remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );

			//* Remove site footer widgets
			remove_theme_support( 'genesis-footer-widgets' );

			//* Remove Insta Feed
			remove_action( 'genesis_before_footer','genesischild_footerwidgetheader_position' );

			//* Remove breadcrumbs
			remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );

			//* Remove the default Genesis loop
			remove_action( 'genesis_loop', 'genesis_do_loop' );
			
			//* Add category widgets
			add_action( 'genesis_loop', 'blossom_socpage_widgets' );

			//* Remove site footer elements
			remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
			remove_action( 'genesis_footer', 'genesis_do_footer' );
			remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );

	}
}

//* Add custom body class to the head
add_filter( 'body_class', 'skystars_instagram_class' );
function skystars_instagram_class( $classes ) {
	$classes[] = 'social-page';
	return $classes;	
}

function blossom_socpage_widgets() {

	echo '<div class="socpage-widgets">';
	
	genesis_widget_area( 'socpage-widgets-1', array(
		'before' => '<div class="socpage-widgets widget-area">',
		'after'  => '</div>',
	) );

	echo '</div>';

}



genesis();