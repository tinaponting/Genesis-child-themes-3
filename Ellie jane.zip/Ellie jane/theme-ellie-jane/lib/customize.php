<?php
/**
 * Ellie Jane.
 * @package Ellie Jane
 */

add_action( 'customize_register', 'ellie_customizer_register' );
/**
 * Register settings and controls with the Customizer.
 *
 * @since 3.2.0
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function ellie_customizer_register( $wp_customize ) {

	$wp_customize->add_setting(
		'ellie_link_color',
		array(
			'default'           => ellie_customizer_get_default_link_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ellie_link_color',
			array(
				'description' => __( 'Change the color for links, the color of post info links, the hover color of linked titles, and more.', 'ellie-jane' ),
				'label'       => __( 'Link Color', 'ellie-jane' ),
				'section'     => 'colors',
				'settings'    => 'ellie_link_color',
			)
		)
	);

	$wp_customize->add_setting(
		'ellie_accent_color',
		array(
			'default'           => ellie_customizer_get_default_accent_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ellie_accent_color',
			array(
				'description' => __( 'Change the color for the header background, buttons, and more.', 'ellie-jane' ),
				'label'       => __( 'Accent Color', 'ellie-jane' ),
				'section'     => 'colors',
				'settings'    => 'ellie_accent_color',
			)
		)
	);

	$wp_customize->add_setting(
		'ellie_main_color',
		array(
			'default'           => ellie_customizer_get_default_main_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ellie_main_color',
			array(
				'description' => __( 'Change the black background color on the Menus, Subscribe Box, Widget Titles, etc.', 'ellie-jane' ),
			    'label'       => __( 'Main Color', 'ellie-jane' ),
			    'section'     => 'colors',
			    'settings'    => 'ellie_main_color',
			)
		)
	);

	$wp_customize->add_setting(
		'ellie_white_color',
		array(
			'default'           => ellie_customizer_get_default_white_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ellie_white_color',
			array(
				'description' => __( 'Change the white font color for the Menus, Subscribe Boxes, Widget Titles, etc.', 'ellie-jane' ),
			    'label'       => __( 'White Font Color', 'ellie-jane' ),
			    'section'     => 'colors',
			    'settings'    => 'ellie_white_color',
			)
		)
	);

	$wp_customize->add_setting(
		'ellie_white_color_hover',
		array(
			'default'           => ellie_customizer_get_default_white_color_hover(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ellie_white_color_hover',
			array(
				'description' => __( 'Change the gold hover font color for the Menus.', 'ellie-jane' ),
			    'label'       => __( 'Gold Hover Color', 'ellie-jane' ),
			    'section'     => 'colors',
			    'settings'    => 'ellie_white_color_hover',
			)
		)
	);

	$wp_customize->add_setting(
		'ellie_title_color',
		array(
			'default'           => ellie_customizer_get_default_title_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ellie_title_color',
			array(
				'description' => __( 'Change the Site Title color.', 'ellie-jane' ),
			    'label'       => __( 'Site Title Color', 'ellie-jane' ),
			    'section'     => 'colors',
			    'settings'    => 'ellie_title_color',
			)
		)
	);

	$wp_customize->add_setting(
		'ellie_description_color',
		array(
			'default'           => ellie_customizer_get_default_description_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ellie_description_color',
			array(
				'description' => __( 'Change the Site Description color.', 'ellie-jane' ),
			    'label'       => __( 'Site Description Color', 'ellie-jane' ),
			    'section'     => 'colors',
			    'settings'    => 'ellie_description_color',
			)
		)
	);

	$wp_customize->add_setting(
		'ellie_body_font_color',
		array(
			'default'           => ellie_customizer_get_default_body_font_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ellie_body_font_color',
			array(
				'description' => __( 'Change the Body Font color.', 'ellie-jane' ),
			    'label'       => __( 'Body Font Color', 'ellie-jane' ),
			    'section'     => 'colors',
			    'settings'    => 'ellie_body_font_color',
			)
		)
	);

	$wp_customize->add_setting(
		'ellie_entry_title_color',
		array(
			'default'           => ellie_customizer_get_default_entry_title_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'ellie_entry_title_color',
			array(
				'description' => __( 'Change the Headings, Post, and Pages Title Font color.', 'ellie-jane' ),
			    'label'       => __( 'Post and Page Title Color', 'ellie-jane' ),
			    'section'     => 'colors',
			    'settings'    => 'ellie_entry_title_color',
			)
		)
	);


}