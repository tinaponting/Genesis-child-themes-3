<?php
/**
 * This file adds the Home Page to the Hello Gorgeous Homepage.
 * @package Hello Gorgeous
 * @subpackage Customizations
 */

add_action( 'genesis_meta', 'hyd_front_page_genesis_meta' );
/**
 * Add widget support for homepage. If no widgets active, display the default loop.
 *
 */
function hyd_front_page_genesis_meta() {

	if ( is_active_sidebar ( 'home-badge' ) || is_active_sidebar( 'left-large' ) || is_active_sidebar( 'right-medium' ) || is_active_sidebar( 'right-small' ) || is_active_sidebar( 'right-large' ) || is_active_sidebar( 'left-medium' ) || is_active_sidebar( 'home-welcome' ) || is_active_sidebar( 'home-calltoaction' ) || is_active_sidebar( 'home-services' ) || is_active_sidebar( 'home-featured' ) ) {

		//* Enqueue scripts
		add_action( 'wp_enqueue_scripts', 'hyd_enqueue_hyd_script' );
		function hyd_enqueue_hyd_script() {

			wp_enqueue_script( 'hyd-script', get_bloginfo( 'stylesheet_directory' ) . '/js/home.js', array( 'jquery' ), '1.0.0' );
			wp_enqueue_script( 'localScroll', get_stylesheet_directory_uri() . '/js/jquery.localScroll.min.js', array( 'scrollTo' ), '1.2.8b', true );
			wp_enqueue_script( 'scrollTo', get_stylesheet_directory_uri() . '/js/jquery.scrollTo.min.js', array( 'jquery' ), '1.4.5-beta', true );

		}

		//* Add front-page body class
		add_filter( 'body_class', 'hyd_body_class' );
		function hyd_body_class( $classes ) {

   			$classes[] = 'front-page';
  			return $classes;

		}

		//* Force full width content layout
		add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );

		//* Remove breadcrumbs
		remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );

		//* Remove the default Genesis loop
		remove_action( 'genesis_loop', 'genesis_do_loop' );

		//* Add homepage widgets
		add_action( 'genesis_loop', 'hyd_front_page_widgets' );

		//* Add featured-section body class
		if ( is_active_sidebar( 'left-large' ) ) {
}
}
}

//* Add markup for front page widgets
function hyd_front_page_widgets() {


	if (  is_active_sidebar( 'left-large' ) || is_active_sidebar( 'right-medium' ) || is_active_sidebar( 'right-small' ) || is_active_sidebar( 'home-badge' )|| is_active_sidebar( 'right-large' ) || is_active_sidebar( 'left-small' ) ||is_active_sidebar( 'left-medium' )  ) {

	echo '<div class="home-grid">';

  genesis_widget_area( 'left-large', array(
		'before' => '<div class="left-large widget-area">',
		'after'  => '</div>',
	) );
	genesis_widget_area( 'right-medium', array(
		'before' => '<div class="right-medium widget-area">',
		'after'  => '</div>',
	) );
	genesis_widget_area( 'right-small', array(
		'before' => '<div class="right-small widget-area">',
		'after'  => '</div>',
	) );
	genesis_widget_area( 'home-badge', array(
		'before' => '<div class="home-badge widget-area">',
		'after'  => '</div>',
	) );
	genesis_widget_area( 'right-large', array(
		'before' => '<div class="right-large widget-area">',
		'after'  => '</div>',
	) );
	genesis_widget_area( 'left-medium', array(
		'before' => '<div class="left-medium widget-area">',
		'after'  => '</div>',
	) );
	echo '</div>';
}

genesis_widget_area( 'home-welcome', array(
	'before' => '<div id="home-welcome" class="home-welcome"><div class="front-section"><div class="flexible-widgets widget-area fadeup-effect' . hyd_widget_area_class( 'home-welcome' ) . '"><div class="wrap">',
	'after'  => '</div></div></div></div>',
) );
	genesis_widget_area( 'home-calltoaction', array(
		'before' => '<div id="home-calltoaction" class="home-calltoaction"><div class="front-section"><div class="flexible-widgets widget-area fadeup-effect' . hyd_widget_area_class( 'home-calltoaction' ) . '"><div class="wrap">',
		'after'  => '</div></div></div></div>',
	) );
	genesis_widget_area( 'home-services', array(
		'before' => '<div id="home-services" class="home-services"><div class="front-section"><div class="flexible-widgets widget-area fadeup-effect' . hyd_widget_area_class( 'home-services' ) . '"><div class="wrap">',
		'after'  => '</div></div></div></div>',
	) );
	genesis_widget_area( 'home-featured', array(
		'before' => '<div id="home-featured" class="home-featured"><div class="front-section"><div class="flexible-widgets widget-area fadeup-effect' . hyd_widget_area_class( 'home-featured' ) . '"><div class="wrap">',
		'after'  => '</div></div></div></div>',
	) );


}

genesis();
