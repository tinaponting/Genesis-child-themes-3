jQuery(document).ready(function($){
	$('.color-field').wpColorPicker();
});