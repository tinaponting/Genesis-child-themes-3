<?php
/**
 * This file adds all the settings for the home page alternate template of the Prima Donna theme.
 * @package      Prima Donna
 */

/*
Template Name: Home Page Alt
*/


//* Add widget support for homepage. If no widgets active, display the default loop.
add_action( 'genesis_meta', 'primadonna_front_page_genesis_meta' );
function primadonna_front_page_genesis_meta() {
	
		//* Enqueue scripts
		add_action( 'wp_enqueue_scripts', 'primadonna_enqueue_primadonna_script' );
		function primadonna_enqueue_primadonna_script() {

			wp_enqueue_style( 'primadonna-front-styles', get_stylesheet_directory_uri() . '/style-front-alt.css', array(), 'CHILD_THEME_VERSION' );

		}


		//* Add body class
		add_filter( 'body_class', 'primadonna_front_page_body_class' );
		
		//* Force full width content layout
		add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

		//* Remove the default Genesis loop
		remove_action( 'genesis_loop', 'genesis_do_loop' );

}


//* Add body class to the head
function primadonna_front_page_body_class( $classes ) {

	$classes[] = 'front-page';
	return $classes;

}

add_action( 'genesis_after_header', 'primadonna_front_slider'  ); 
function primadonna_front_slider() {

	echo'<div class="wrap home-alt-wrap">';

	genesis_widget_area( 'front-page-1', array(
		'before' => '<div id="front-page-1" class="front-page-1"><div><div class="widget-area' . primadonna_widget_area_class( 'front-page-1' ) . '">',
		'after'  => '</div></div></div>',
	) );

    $slider = get_theme_mod( 'primadonna_front_featured_layout_setting', 'none' );
	if ( $slider === 'boxed' ) {
		get_template_part('lib/featured/featured-front-alt');
	}	

    genesis_widget_area( 'front-page-2', array(
		'before' => '<div id="front-page-2" class="front-page-2"><div class="widget-area' . primadonna_widget_area_class( 'front-page-2' ) . '">',
		'after'  => '</div></div></div>',
	) );

    $promo = get_theme_mod( 'primadonna_front_promo_setting', 'none' );
	if ( $promo === '2boxes' ) {
		get_template_part('lib/promo/promo2-front');
	}

    $promo = get_theme_mod( 'primadonna_front_promo_setting', 'none' );
	if ( $promo === '3boxes' ) {
		get_template_part('lib/promo/promo3-front');
	}

	$promo = get_theme_mod( 'primadonna_front_promo_setting', 'none' );
	if ( $promo === '4boxes' ) {
		get_template_part('lib/promo/promo4-front');
	}

	genesis_widget_area( 'front-page-3', array(
		'before' => '<div id="front-page-3" class="front-page-3"><div class="wrap"><div class="flexible-widgets widget-area fadeup-effect' . primadonna_widget_area_class( 'front-page-3' ) . '">',
		'after'  => '</div></div></div>',
	) );
	
	genesis_widget_area( 'front-page-4', array(
		'before' => '<div id="front-page-4" class="front-page-4"><div class="wrap"><div class="flexible-widgets widget-area fadeup-effect' . primadonna_widget_area_class( 'front-page-4' ) . '">',
		'after'  => '</div></div></div>',
	) );
	
	genesis_widget_area( 'front-page-5', array(
		'before' => '<div id="front-page-5" class="front-page-5"><div class="wrap"><div class="flexible-widgets widget-area fadeup-effect' . primadonna_widget_area_class( 'front-page-5' ) . '">',
		'after'  => '</div></div></div>',
	) );

	genesis_widget_area( 'front-page-6', array(
		'before' => '<div id="front-page-6" class="front-page-6"><div class="wrap"><div class="flexible-widgets widget-area fadeup-effect' . primadonna_widget_area_class( 'front-page-6' ) . '">',
		'after'  => '</div></div></div>',
	) );

}


//* Run the default Genesis loop
genesis();
