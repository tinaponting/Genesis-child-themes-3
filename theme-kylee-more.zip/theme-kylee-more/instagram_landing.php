<?php
/**
 * This file adds the Instagram Page to the Kylee More Theme.
 * @package      Kylee More
 */
 
/*
Template Name: Instagram
*/

//* Add Instagram page body class to the head.
add_filter( 'body_class', 'kylee_instagram_menu_add_body_class' );
function kylee_instagram_menu_add_body_class( $classes ) {

	$classes[] = 'instagram-page';

	return $classes;

}


// Remove Skip Links.
remove_action ( 'genesis_before_header', 'genesis_skip_links', 5 );

// Dequeue Skip Links Script.
add_action( 'wp_enqueue_scripts', 'kylee_dequeue_skip_links' );
function kylee_dequeue_skip_links() {
	wp_dequeue_script( 'skip-links' );
}

// Force full width content layout.
add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );

// Remove navigation.
remove_theme_support( 'genesis-menus' );

// Remove breadcrumbs.
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );

// Remove site footer widgets.
remove_theme_support( 'genesis-footer-widgets' );

// Remove site footer elements.
remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );
remove_action( 'genesis_before_footer', 'kylee_widget_above_footer', 1 ); 



genesis();