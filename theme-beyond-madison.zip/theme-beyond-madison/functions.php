<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Setup Theme
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );

//* Add Color Selection to WordPress Theme Customizer
require_once( get_stylesheet_directory() . '/lib/customize.php' );

//* Set Localization (do not remove)
load_child_theme_textdomain( 'beyond', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/languages', 'beyond' ) );


//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', __( 'Beyond Madison Theme', 'beyond' ) );
define( 'CHILD_THEME_VERSION', '2.0' );

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* woocommerce
add_theme_support( 'genesis-connect-woocommerce' );

//* Add WooCommerce Gallery Options
add_action( 'after_setup_theme', 'beyond_woo_gallery' );
function beyond_woo_gallery() {
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
}

//* Enqueue Scripts
add_action( 'wp_enqueue_scripts', 'beyond_load_scripts' );
function beyond_load_scripts() {
	
	wp_enqueue_script( 'beyond-responsive-menu', get_bloginfo( 'stylesheet_directory' ) . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0' );
	
	wp_enqueue_style( 'dashicons' );
	
	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Questrial|Satisfy|Open+Sans:300', array(), CHILD_THEME_VERSION );
	
}

//* Add new image sizes
add_image_size( 'home-large', 634, 360, TRUE );
add_image_size( 'home-small', 266, 160, TRUE );
add_image_size( 'featured-post', 375, 250, TRUE );

// Full Width Header and Nav
	remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
	remove_action( 'genesis_header', 'genesis_do_header' );
	remove_action( 'genesis_header', 'genesis_header_markup_close', 15 );
	remove_action( 'genesis_after_header', 'genesis_do_nav' );

	add_action( 'genesis_before', 'genesis_header_markup_open', 5 );
	add_action( 'genesis_before', 'genesis_do_header' );
	add_action( 'genesis_before', 'genesis_header_markup_close', 15 );
	add_action( 'genesis_before', 'genesis_do_nav', 18 );

//* Making Footer Area Full Width
	remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );
	add_action( 'genesis_after', 'genesis_footer_widget_areas' );

	remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
	remove_action( 'genesis_footer', 'genesis_do_footer' );
	remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );
	remove_action( 'genesis_footer', 'beyond_bottom_bar' );

	add_action( 'genesis_after', 'genesis_footer_markup_open', 11 );
	add_action( 'genesis_after', 'genesis_do_footer', 12 );
	add_action( 'genesis_after', 'genesis_footer_markup_close', 13 );
	add_action( 'genesis_after', 'beyond_bottom_bar', 10 );

//* Unregister secondary navigation menu
add_theme_support( 'genesis-menus', array( 'primary' => __( 'Primary Navigation Menu', 'genesis' ) ) );

//* Customize search form input box text
add_filter( 'genesis_search_text', 'beyond_search_text' );
function beyond_search_text( $text ) {
	return esc_attr( 'Search...' );
}

//* Remove Widgets
function remove_some_widgets(){

     unregister_sidebar( 'header-right' );
     unregister_sidebar( 'sidebar-alt' );
     unregister_sidebar( 'after-entry' );
}
add_action( 'widgets_init', 'remove_some_widgets', 11 );

//* Unregister Layouts
	genesis_unregister_layout( 'content-sidebar-sidebar' ); 
	genesis_unregister_layout( 'sidebar-sidebar-content' ); 
	genesis_unregister_layout( 'sidebar-content-sidebar' );

//* Modify the Genesis content limit read more link
add_filter( 'get_the_content_more_link', 'sp_read_more_link' );
function sp_read_more_link() {
	return '... <a class="more-link" href="' . get_permalink() . '">Read More...</a>';
}

//* Add Title & Caption to Soliloquy Slider
add_filter( 'soliloquy_output_caption', 'beyond_soliloquy_title_before_caption', 10, 5 );
function beyond_soliloquy_title_before_caption( $caption, $id, $slide, $data, $i ) {
     
    // Check if current slide has a title specified
    if ( isset( $slide['title'] ) && !empty( $slide['title'] ) ) {
        $caption = '<h4 class="title">' . $slide['title'] . '</h4>'; 
	$caption .= '<div class="caption">' . $slide['caption'] . '</h4>';  
        } 
        return $caption;
}

//* Customize the credits
add_filter( 'genesis_footer_creds_text', 'sp_footer_creds_text' );
function sp_footer_creds_text() {
	echo '<div class="creds"><p>';
	echo ' Made By <a href="http://exempel.se" title="EXEMPEL">exempel</a> &middot; ';
	echo 'Copyright &copy; ';
	echo date('Y');
	echo '</p></div>';
}

//* Remove the post info function
remove_action( 'genesis_before_post_content', 'genesis_post_info' );

//* Customize the entry meta in the entry header (requires HTML5 theme support)
add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
	$post_info = '[post_date] [post_edit]';
	return $post_info;
}

//* Customize the post meta function
add_filter( 'genesis_post_meta', 'post_meta_filter' );
function post_meta_filter($post_meta) {
	$post_meta = '[post_comments] </br> [post_categories before="Filed Under: "] [post_tags before="Tagged: "] [post_edit]';
	return $post_meta;
}

//* Add support for custom background
add_theme_support( 'custom-background', array(
	'default-image' => '',
	'default-color' => 'ffffff',
) );

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'header_image'    => '',
	'header-selector' => '.site-title a',
	'header-text'     => false,
	'height'          => 200,
	'width'           => 1240,
) );

//* Rename Section Header Image in Customize 
function my_custom_header_title( $wp_customize ) {
    $wp_customize->get_section( 'header_image' )->title = __( 'Header Logo', 'beyond' );
}
add_action( 'customize_register', 'my_custom_header_title');

//* Modify the size of the Gravatar in the author box
add_filter( 'genesis_author_box_gravatar_size', 'beyond_author_box_gravatar' );
function beyond_author_box_gravatar( $size ) {

	return 96;
		
}

//* Modify the size of the Gravatar in the entry comments
add_filter( 'genesis_comment_list_args', 'beyond_comments_gravatar' );
function beyond_comments_gravatar( $args ) {

	$args['avatar_size'] = 60;
	return $args;
	
}

//* Remove comment form allowed tags
add_filter( 'comment_form_defaults', 'beyond_remove_comment_form_allowed_tags' );
function beyond_remove_comment_form_allowed_tags( $defaults ) {
	
	$defaults['comment_notes_after'] = '';
	return $defaults;

}

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Add Fourth Footer Area
function beyond_bottom_bar() {

	echo '<div class="bottom-bar"><div class="wrap">';

	genesis_widget_area( 'bottom-bar-left', array(
		'before' => '<div class="bottom-bar-left">',
		'after' => '</div>',
	) );

	echo '</div></div>';
}

//* Add support for after entry widget
add_theme_support( 'genesis-after-entry-widget-area' );

//* Relocate after entry widget
remove_action( 'genesis_after_entry', 'genesis_after_entry_widget_area' );
add_action( 'genesis_after_entry', 'genesis_after_entry_widget_area', 5 );


//* Register widget areas

genesis_register_sidebar( array(
	'id'          => 'home-slider',
	'name'        => __( 'Homepage Slider', 'beyond' ),
	'description' => __( 'This is the slider section of the homepage.', 'beyond' ),
) );

genesis_register_sidebar( array(
	'id'          => 'subscribe-bar',
	'name'        => __( 'Homepage Subscribe Bar', 'beyond' ),
	'description' => __( 'This is the subscribe bar after the slider of the homepage.', 'beyond' ),
) );

genesis_register_sidebar( array(
	'id'          => 'featured-flex-posts',
	'name'        => __( 'Homepage Featured Posts', 'beyond' ),
	'description' => __( 'This is the featured posts section after the subscribe bar on the homepage.', 'beyond' ),
) );

genesis_register_sidebar( array(
	'id'          => 'bottom-bar-left',
	'name'        => __( 'Bottom Bar', 'beyond' ),
	'description' => __( 'This is the bottom bar after the footer widgets. Can be used for a wide Instagram Widget.', 'beyond' ),
) );


/**
 * HEX Color sanitization callback.
 * @param string               $hex_color HEX color to sanitize.
 * @param WP_Customize_Setting $setting   Setting instance.
 * @return string The sanitized hex color if not null; otherwise, the setting default.
 */
function beyond_sanitize_hex_color( $hex_color, $setting ) {
	// Sanitize $input as a hex value.
	$hex_color = sanitize_hex_color( $hex_color );

	// If $input is a valid hex value, return it; otherwise, return the default.
	return ( ! is_null( $hex_color ) ? $hex_color : $setting->default );
}

/**
 * Image sanitization callback.
 * @param string               $image   Image filename.
 * @param WP_Customize_Setting $setting Setting instance.
 * @return string The image filename if the extension is allowed; otherwise, the setting default.
 */
function beyond_sanitize_image( $image, $setting ) {

	/*
	 * Array of valid image file types.
	 *
	 * The array includes image mime types that are included in wp_get_mime_types()
	 */
	$mimes = array(
		'jpg|jpeg|jpe' => 'image/jpeg',
		'gif'          => 'image/gif',
		'png'          => 'image/png',
		'bmp'          => 'image/bmp',
		'tif|tiff'     => 'image/tiff',
		'ico'          => 'image/x-icon'
	);

	// Return an array with file extension and mime_type.
	$file = wp_check_filetype( $image, $mimes );

	// If $image has a valid mime_type, return it; otherwise, return the default.
	return ( $file['ext'] ? $image : $setting->default );
}

/**
 * Checkbox sanitization callback.
 *
 * Sanitization callback for 'checkbox' type controls. This callback sanitizes `$checked`
 * as a boolean value, either TRUE or FALSE.
 *
 * @param bool $checked Whether the checkbox is checked.
 * @return bool Whether the checkbox is checked.
 */
function beyond_sanitize_checkbox( $checked ) {
	// Boolean check.
	return ( ( isset( $checked ) && true == $checked ) ? true : false );
}


/**
 * Customizer: Add Sections
 */


/**
 * Theme Options Customizer Implementation.
 * @param WP_Customize_Manager $wp_customize Object that holds the customizer data.
 */
function beyond_register_theme_customizer( $wp_customize ) {

	/*
	 * Failsafe is safe
	 */
	if ( ! isset( $wp_customize ) ) {
		return;
	}


	/**
	 * Add Header Section for General Options.
	 */
	$wp_customize->add_section(
		// $id
		'beyond_section_header',
		// $args
		array(
			'title'			=> __( 'Header Background', 'beyond' ),
			'description'	=> __( 'Set background color and/or background image for the header', 'beyond' ),
			'priority'		=> 60,
		)
	);


	/**
	 * Header Background Color setting.
	 */
	$wp_customize->add_setting(
		// $id
		'header_background_color_setting',
		// $args
		array(
			'sanitize_callback'	=> 'beyond_sanitize_hex_color',
			'transport'			=> 'postMessage'
		)
	);


	/**
	 * Header Background Image setting.
	 */
	$wp_customize->add_setting(
		// $id
		'header_background_image_setting',
		// $args
		array(
			'default'			=> '',
			'sanitize_callback'	=> 'beyond_sanitize_image',
			'transport'			=> 'postMessage'
		)
	);


	/**
	 * Display Header Backgroud Image Repeat setting.
	 */
	$wp_customize->add_setting(
		// $id
		'header_background_image_repeat_setting',
		// $args
		array(
			'default'			=> true,
			'sanitize_callback'	=> 'beyond_sanitize_checkbox',
			'transport'			=> 'postMessage'
		)
	);

	/**
	 * Display Header Backgroud Image Size setting.
	 */
	$wp_customize->add_setting(
		// $id
		'header_background_image_size_setting',
		// $args
		array(
			'default'			=> false,
			'sanitize_callback'	=> 'beyond_sanitize_checkbox',
			'transport'			=> 'postMessage'
		)
	);

	/**
	 * Core Color control.
	 */
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			// $wp_customize object
			$wp_customize,
			// $id
			'header_background_color',
			// $args
			array(
				'settings'		=> 'header_background_color_setting',
				'section'		=> 'beyond_section_header',
				'label'			=> __( 'Header Background Color', 'beyond' ),
				'description'	=> __( 'Select the background color for header.', 'beyond' ),
			)
		)
	);


	/**
	 * Image Upload control.
	 */
	$wp_customize->add_control(
		new WP_Customize_Image_Control(
			// $wp_customize object
			$wp_customize,
			// $id
			'header_background_image',
			// $args
			array(
				'settings'		=> 'header_background_image_setting',
				'section'		=> 'beyond_section_header',
				'label'			=> __( 'Header Background Image', 'beyond' ),
				'description'	=> __( 'Select the background image for header.', 'beyond' )
			)
		)
	);

	/**
	 * Basic Checkbox control.
	 */
	$wp_customize->add_control(
		// $id
		'header_background_image_repeat',
		// $args
		array(
			'settings'		=> 'header_background_image_repeat_setting',
			'section'		=> 'beyond_section_header',
			'type'			=> 'checkbox',
			'label'			=> __( 'Background Repeat', 'beyond' ),
			'description'	=> __( 'Should the header background image repeat?', 'beyond' ),
		)
	);


}

// Settings API options initilization and validation.
add_action( 'customize_register', 'beyond_register_theme_customizer' );


/**
 * Registers the Theme Customizer Preview with WordPress.
 *
 * @package    Beyond Madison
 * @since      0.3.0
 * @version    0.3.0
 */
function beyond_customizer_live_preview() {
	wp_enqueue_script(
		'beyond-theme-customizer',
		get_stylesheet_directory_uri() . '/js/theme-customizer.js',
		array( 'customize-preview' ),
		'0.1.0',
		true
	);
} // end beyond_customizer_live_preview
add_action( 'customize_preview_init', 'beyond_customizer_live_preview' );


/**
 * Writes the Header Background related controls' values out to the 'head' element of the document
 * by reading the value(s) from the theme mod value in the options table.
 */
function beyond_customizer_css() {
	if ( ! get_theme_mod( 'header_background_color_setting' ) && '' === get_theme_mod( 'header_background_image_setting' ) && false === get_theme_mod( 'header_background_image_repeat_setting' ) && false === get_theme_mod( 'header_background_image_size_setting' ) ) {
		return;
	}
?>
	<style type="text/css">
		.site-header {
			<?php if ( get_theme_mod( 'header_background_color_setting' ) ) { ?>
			background-color: <?php echo get_theme_mod( 'header_background_color_setting' ); ?>;
			<?php } ?>
			<?php if ( get_theme_mod( 'header_background_image_setting' ) != '' ) { ?>
				background-image: url(<?php echo get_theme_mod( 'header_background_image_setting' ); ?>);
			<?php } ?>
			<?php if ( true === get_theme_mod( 'header_background_image_repeat_setting' ) ) { ?>
				background-repeat: repeat;
			<?php } ?>
			<?php if ( true === get_theme_mod( 'header_background_image_size_setting' ) ) { ?>
				background-size: cover;
			<?php } ?>
		}
	</style>
<?php
} // end beyond_customizer_css
add_action( 'wp_head', 'beyond_customizer_css');