<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Initialize Instllr
include_once ('instllr.php');

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Jennifer Theme' );
define( 'CHILD_THEME_VERSION', '2.1' );

//* Enqueue Fonts and Scripts
add_action( 'wp_enqueue_scripts', 'genesis_fonts_and_scripts' );
function genesis_fonts_and_scripts() {
	wp_enqueue_script( 'jquery', get_bloginfo( 'stylesheet_directory' ) . '/lib/js/jquery-2.1.4.js', array( 'jquery' ) );
	wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css' );
	wp_enqueue_script( 'global', get_bloginfo( 'stylesheet_directory' ) . '/lib/js/global.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_script( 'prefix-responsive-menu', get_stylesheet_directory_uri() . '/lib/js/responsive-menu.js', array( 'jquery' ), '1.0.0', true ); 
	wp_enqueue_script( 'owl-init', get_bloginfo( 'stylesheet_directory' ) . '/lib/js/owl-init.js', array( 'jquery' ), '', true );
	wp_enqueue_style( 'owl-style', get_stylesheet_directory_uri() . '/lib/owlcarousel/owl.carousel.css' );
	wp_enqueue_script( 'owl-script', get_bloginfo( 'stylesheet_directory' ) . '/lib/owlcarousel/owl.carousel.min.js', array( 'jquery' ), '', true );
}
//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Remove the header right widget area
unregister_sidebar( 'header-right' );

//* Reposition the primary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_header', 'genesis_do_nav', 12 );

/**
 * Remove Genesis child theme style sheet
*/ 
remove_action( 'genesis_meta', 'genesis_load_stylesheet' );
add_action( 'wp_enqueue_scripts', 'genesis_enqueue_main_stylesheet', 15 );

//* Add support for post formats
add_theme_support( 'post-formats', array(
	'gallery',
	'image',
	'video'
));

/** Back to top Button */
function ll_backtotop() {
	wp_enqueue_script(
		'custom-script',
		get_stylesheet_directory_uri() . '/lib/js/backtotop.js',
		array( 'jquery' )
	);}
add_action( 'wp_enqueue_scripts', 'll_backtotop' );
genesis_register_sidebar( array(
	'id'=> 'home-slider',
	'name'=> __( 'Home - Slider', 'your-theme' ),
	'description'=> __( 'This section is for homepage slider.', 'your-theme' ),
));
genesis_register_sidebar( array(
	'id'=> 'insta-container',
	'name'=> __( 'Instagram  - Container', 'your-theme' ),
	'description'=> __( 'This section is for Instagram.', 'your-theme' ),
));
genesis_register_sidebar( array(
	'id'=> 'footer-container',
	'name'=> __( 'Footer - Container', 'your-theme' ),
	'description'=> __( 'This section is for Footer.', 'your-theme' ),
));
add_action( 'genesis_after_header', 'll_home_slider' );
	function ll_home_slider() {
	if ( is_home() )
		genesis_widget_area( 'home-slider', array(
			'before'=> '<div class="home-slider widget-area"><div class="wrap">',
			'after'=> '</div></div>',
	));}

add_action( 'genesis_before_footer', 'll_home_insta' );
	function ll_home_insta() {
	if ( is_singular( 'post' ) | is_page() | is_home() | is_search() )
		genesis_widget_area( 'insta-container', array(
			'before'=> '<div class="insta-container widget-area">',
			'after'=> '</div>',
	)); }
add_action( 'genesis_before_footer', 'll_custom_footer' );
	function ll_custom_footer() {
	if ( is_singular( 'post' ) | is_page () | is_home() | is_search() )
		genesis_widget_area( 'footer-container', array(
			'before'=> '<div class="footer-container widget-area"><div class="wrap">',
			'after'=> '</div></div>',
	));}
//* Add Structural Wraps
add_theme_support( 'genesis-structural-wraps', array( 'header', 'nav', 'subnav', 'inner', 'footer-widgets', 'footer' ) );

//* Customize search form input button text
add_filter( 'genesis_search_button_text', 'sp_search_button_text' );
function sp_search_button_text( $text ) {return esc_attr( 'Search' );
}
//* Remove usual Footer
remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );

//* Add Back To Top Button
function ll_back_to_top() {echo '<a href="#" class="backtotop"></a>';
};
add_action('genesis_before_footer', 'll_back_to_top');

//* Add Recent Posts Carousel Shortcodes
include_once('recent-posts-carousel.php');

//* Modify Read More Link
add_filter( 'excerpt_more', 'child_read_more_link' );
add_filter( 'get_the_content_more_link', 'child_read_more_link' );
add_filter( 'the_content_more_link', 'child_read_more_link' );
/**
 * Custom Read More link.
 */
function child_read_more_link() {return '<a class="more-link" href="' . get_permalink() . '" rel="nofollow">Read More</a>';
}
//* Add new image sizes
if ( function_exists( 'add_theme_support' ) ) {
  add_theme_support( 'post-thumbnails' );
}
add_image_size( 'Recent_Post', 80, 80, true );
add_image_size( 'Homepage_Featured', 1200, 800, true );

//*Run shortcodes in text widgets
add_filter('widget_text', 'do_shortcode');

//* Afterpost Sharing Icons
function ll_afterpost_share() {
	return '<div class="post-sharing-icons">
		<a href="http://www.facebook.com/sharer.php?u=' . get_permalink() . '&amp;t=' . get_the_title() . ' " title="Share on Facebook"><i class="fa fa-post-footer fa-facebook"></i></a>  
		<a href="http://twitter.com/home/?status=' . get_the_title() . '-' . get_permalink() . ' " title="Tweet this!"><i class="fa fa-post-footer fa-twitter"></i></a>  
		<a href="http://pinterest.com/pin/create/button/?url=' . get_permalink() . '&media=' . $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ) . '&description=' . get_the_title() . ' "><i class="fa fa-post-footer fa-pinterest"></i></a> 
	</div>';  
}
add_shortcode( 'afterpost_share', 'll_afterpost_share' );