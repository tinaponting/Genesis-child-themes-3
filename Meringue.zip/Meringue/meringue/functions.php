<?php
require_once(TEMPLATEPATH.'/lib/init.php');

//* Child Theme (do not remove)
define( 'CHILD_THEME_NAME', __( 'Meringue Theme', 'meringue' ) );
define( 'CHILD_THEME_VERSION', '1.0.0' );
define( 'CHILD_THEME_DEVELOPER', __( 'WP Chic', 'meringue' ) );

//* Add Child Theme Body Class
add_filter( 'body_class', 'meringue_add_body_class' );
function meringue_add_body_class( $classes ) {
		$classes[] = 'meringue';
		return $classes;
}

//* Add Color Selection to WordPress Theme Customizer
require_once( get_stylesheet_directory() . '/lib/customize.php' );

//* Enqueue Responsonsive Menu and Google Fonts scripts
add_action( 'wp_enqueue_scripts', 'meringue_enqueue_scripts' );
function meringue_enqueue_scripts() {
wp_enqueue_script( 'global-script', get_bloginfo( 'stylesheet_directory' ) . '/js/global.js', array( 'jquery' ), '1.0.0' );
wp_enqueue_script( 'ajax-handler', get_bloginfo( 'stylesheet_directory' ) . '/includes/ajax_handler.js', array( 'jquery' ), '1.0.0' );
wp_enqueue_script( 'localScroll', get_stylesheet_directory_uri() . '/js/jquery.localScroll.min.js', array( 'scrollTo' ), '1.2.8b', true );
wp_enqueue_script( 'scrollTo', get_stylesheet_directory_uri() . '/js/jquery.scrollTo.min.js', array( 'jquery' ), '1.4.5-beta', true );
wp_enqueue_style( 'google-font', '//fonts.googleapis.com/css?family=Source+Sans+Pro:300,300i,400,400i,600,600i,700,700i,900|Arbutus+Slab|Playfair+Display:400,400i,700,700i,900,900i|Pontano+Sans', array() );
	if ( !is_admin() ) {
		wp_enqueue_style( 'font-awesome', get_bloginfo( 'stylesheet_directory' ) . '/css/font-awesome.min.css', array(), '4.0.3' );
	}
}

//* Add Dashicons
add_action( 'wp_enqueue_scripts', 'meringue_scripts' );
function meringue_scripts() {
wp_enqueue_style( 'dashicons-style', get_stylesheet_uri(), array( 'dashicons' ), '1.0' );
}

//* Enqueue Dashicons
add_action( 'wp_enqueue_scripts', 'enqueue_dashicons' );
function enqueue_dashicons() {
wp_enqueue_style( 'dashicons' );
} 

//* Add Support for HTML5 
add_theme_support( 'html5' );

//* Add support for viewport 
add_theme_support( 'genesis-responsive-viewport' );


//* Add Support for Custom Background
add_theme_support( 'custom-background' );

//* Add Support for Custom Header
add_theme_support( 'custom-header', array(
	'width'           => 320,
	'height'          => 100,
	'header-selector' => '.site-title a',
	'header-text'     => false,
) );

//* Add Support for 3-column Footer Widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Add Support for After Entry Widget
add_theme_support( 'genesis-after-entry-widget-area' );

//* Move Primary Nav Menu 
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before_content_sidebar_wrap', 'genesis_do_nav', 1 );

//* Add Support for Post Formats
add_theme_support( 'post-formats', array( 'aside', 'chat', 'gallery', 'image', 'link', 'quote', 'status', 'video', 'audio', 'portfolio' ));

//* Position Post Info Above Post Title
remove_action( 'genesis_entry_header', 'genesis_post_info', 12);
add_action( 'genesis_entry_header', 'genesis_post_info', 9 );

//* Position Featured Image Above Entry Title
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
add_action( 'genesis_entry_header', 'genesis_do_post_image', 8 );

//* Move Secondary Nav Menu 
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before_footer', 'genesis_do_subnav', 2 );

//* Add Span to Widget Titles
add_filter( 'widget_title', 'meringue_widget_title' );
function meringue_widget_title( $title ){
	if( $title )
		return sprintf('<span class="widgettitle">%s</span>', $title );
}

//* Unregister Alt Sidebar
unregister_sidebar( 'sidebar-alt' );
genesis_register_sidebar(
  array(
    'id' => 'sidebar-alt',
    'name' => 'Alternate Sidebar',
    'description' => 'This sidebar will appear instead of the primary sidebar, on all pages using the Recipe Index template.',
  )
);

//* Unregister 3-column Site Layouts 
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );

//* Register Theme Image Sizes
add_image_size( 'horizontal-thumbnail', 840, 620, true );
add_image_size( 'horizontal-thumbnail-small', 340, 225, true );
add_image_size( 'vertical-thumbnail', 680, 900, true );
add_image_size( 'vertical-thumbnail-large', 780, 1000, true );
add_image_size( 'vertical-thumbnail-small', 340, 450, true );
add_image_size( 'square-thumbnail', 274, 410, true );

//* Register Above Header Widget Area
genesis_register_sidebar( array(
'id' => 'above-header',
'name' => __( 'Above Header', 'meringue' ),
'description' => __( 'This is the widget area above the header.', 'meringue' ),
) );

//* Add Above Header Widget Area
add_action( 'genesis_before_header', 'above_header'  ); 
function above_header() {
    genesis_widget_area( 'above-header', array(
		'before' => '<div class="above-header widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );
}

//* Register Below Header Widget Area
genesis_register_sidebar( array(
'id' => 'below-header',
'name' => __( 'Below Header', 'meringue' ),
'description' => __( 'This is the widget area below the header.', 'meringue' ),
) );

//* Register Home Top Widget Area
genesis_register_sidebar( array(
'id' => 'home-top',
'name' => __( 'Home Top', 'meringue' ),
'description' => __( 'This is the top widget area on the homepage.', 'meringue' ),
) );

//* Register Home Middle Widget Area
genesis_register_sidebar( array(
	'id'			=> 'home-middle',
	'name'			=> __( 'Home Middle', 'meringue' ),
	'description'	=> __( 'This is the section below the home top widget area on the homepage.', 'meringue' ),
) );

//* Register Home Bottom Widget Area
genesis_register_sidebar( array(
	'id'			=> 'home-bottom',
	'name'			=> __( 'Home Bottom ', 'meringue' ),
	'description'	=> __( 'This is the bottom section on the homepage.', 'meringue' ),
) );

//* Register Below Content Widget Area
genesis_register_sidebar( array(
'id' => 'below-content',
'name' => __( 'Below Content', 'meringue' ),
'description' => __( 'This is the widget area below the page content.', 'meringue' ),
) );

//* Add Below Content Widget Area
add_action( 'genesis_before_footer', 'below_content', 1 ); 
function below_content() {
    genesis_widget_area( 'below-content', array(
		'before' => '<div class="below-content widget-area">',
		'after'  => '</div>',
    ) );
}

//* Register Recipe Index Top Widget Area
genesis_register_sidebar( array(
'id' => 'recipe-index-top',
'name' => __( 'Recipe Index Top', 'meringue' ),
'description' => __( 'This is the widget area above the content area on the Recipe Index page.', 'meringue' ),
) );

//* Register WooCommerce Sidebar
genesis_register_sidebar( array(
    'id'            => 'woo_primary_sidebar',
    'name'          => __( 'WooCommerce Sidebar', 'meringue' ),
    'description' => __( 'This is the WooCommerce sidebar', 'meringue' ),
) );

//* Remove Default Sidebar, Add WooCommerce Sidebar
add_action( 'genesis_before', 'meringue_add_woo_sidebar', 20 );
function meringue_add_woo_sidebar() {
    if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
        if( is_woocommerce() ) {
            remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
            remove_action( 'genesis_sidebar_alt', 'genesis_do_sidebar_alt' );
            add_action( 'genesis_sidebar', 'meringue_woo_sidebar' );
        }
    }
    
}

//* Display the WooCommerce Sidebar
function meringue_woo_sidebar() {
    if ( ! dynamic_sidebar( 'woo_primary_sidebar' ) && current_user_can( 'edit_theme_options' )  ) {
        genesis_default_widget_area_content( __( 'WooCommerce Primary Sidebar', 'genesis' ) );
    }
}

//* Customize Entry Meta 
add_filter( 'genesis_post_info', 'meringue_post_info_filter' );
function meringue_post_info_filter($post_info) {
$post_info = '[post_categories before=""]';
return $post_info;
}

//* Customize Post Meta 
add_filter( 'genesis_post_meta', 'meringue_post_meta_filter' );
function meringue_post_meta_filter($post_meta) {
	return g_ent( ' [post_tags before=""]' );
}


//* Add Post Navigation
add_action( 'genesis_entry_footer', 'genesis_prev_next_post_nav' );

//* Customize Comment heading
add_filter( 'comment_form_defaults', 'meringue_custom_comment_form' );
function meringue_custom_comment_form($fields) {
    $fields['comment_notes_before'] = ''; 
    $fields['title_reply'] = __( 'Comments', 'merginue' ); 
    $fields['comment_notes_after'] = '';
    return $fields;
}

//* Customize Comment Avatar size
add_filter( 'genesis_comment_list_args', 'meringue_comment_list_args' );
function meringue_comment_list_args( $args ) {
$args['avatar_size'] = 100;
return $args;
}

//* Modify the size of the Gravatar in the author box
add_filter( 'genesis_author_box_gravatar_size', 'author_box_gravatar_size' );
function author_box_gravatar_size( $size ) {
return '100';
}

//* Customize search form 
add_filter( 'genesis_search_text', 'meringue_search_text' );
function meringue_search_text($text) {
return esc_attr( 'Search Recipes...' );
}

//* Customize search form input button text
add_filter( 'genesis_search_button_text', 'meringue_search_button_text' );
function meringue_search_button_text( $text ) {
return esc_attr( '&#xf179;' );
}

//* Add support for Read More link 
add_filter('excerpt_more', 'get_read_more_link');
	add_filter( 'the_content_more_link', 'get_read_more_link' );
	function get_read_more_link() {
	   return '...&nbsp;<a href="' . get_permalink() . '" class="read-more">Continue to Recipe</a>';
}

//* Add support for Grid More link 
add_filter( 'get_the_content_more_link', 'balance_read_more_link' );
add_filter( 'the_content_more_link', 'balance_read_more_link' );
function balance_read_more_link() {
	return '...&nbsp;<a href="' . get_permalink() . '" class="read-more">Continue to Recipe</a>';
}

//* Customize footer credits 
add_filter('genesis_footer_creds_text', 'meringue_custom_footer_creds_text');
function meringue_custom_footer_creds_text() {
    echo '<div class="creds"><p>';
    echo '&copy; ';
    echo date('Y');
    echo ' &middot; <a href="https://exempel.se">Meringue Theme</a> By <a href="https://exempel.se">EXEMPEL/a>';
    echo '</p></div>';

}

//* Add Support for Woocommerce
add_theme_support( 'genesis-connect-woocommerce' );


//* Disable general woocommerce css
add_filter( 'woocommerce_enqueue_styles', 'dequeue_woocommerce_general_stylesheet' );
function dequeue_woocommerce_general_stylesheet( $enqueue_styles ) {
unset( $enqueue_styles['woocommerce-general'] );
return $enqueue_styles;
}

//*Add Theme Woocommerce CSS
function woocommerce_style_sheet() {
wp_register_style( 'woocommerce', get_stylesheet_directory_uri() . '/woocommerce.css' );
if ( class_exists( 'woocommerce' ) ) {
wp_enqueue_style( 'woocommerce' );
}
}
add_action('wp_enqueue_scripts', 'woocommerce_style_sheet');

//* Change WooCommerce Pagination Arrows
add_filter( 'woocommerce_pagination_args', 	'rocket_woo_pagination' );
function rocket_woo_pagination( $args ) {
	$args['prev_text'] = '<i class="fa fa-angle-left"></i>';
	$args['next_text'] = '<i class="fa fa-angle-right"></i>';
	return $args;
}

//* Add Support for WooCommerce Lightbox
add_action( 'after_setup_theme', 'meringue_setup' );

function meringue_setup() {
add_theme_support( 'wc-product-gallery-zoom' );
add_theme_support( 'wc-product-gallery-lightbox' );
add_theme_support( 'wc-product-gallery-slider' );
}

//* Change number or products per row to 3
add_filter( 'loop_shop_columns', create_function(  '$columns','return 3;' ) );

add_filter( 'loop_shop_per_page', 'new_loop_shop_per_page', 20 );

function new_loop_shop_per_page( $cols ) {
  // $cols contains the current number of products per page based on the value stored on Options -> Reading
  // Return the number of products you wanna show per page.
  $cols = 9;
  return $cols;
}

?>