<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Constance' );
define( 'CHILD_THEME_VERSION', '1.3' );

//* Enqueue Scripts
add_action( 'wp_enqueue_scripts', 'genesis_load_scripts_styles' );
function genesis_load_scripts_styles() {

	wp_enqueue_script( 'responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Lato:300,400,300italic,400italic|Playfair+Display:400,400italic', array(), CHILD_THEME_VERSION );
	wp_enqueue_style( 'dashicons' );	

}

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

//* Add Accessibility support
add_theme_support( 'genesis-accessibility', array( 'headings', 'drop-down-menu',  'search-form', 'skip-links', 'rems' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Remove Genesis child theme style sheet
remove_action( 'genesis_meta', 'genesis_load_stylesheet' );

//* Enqueue Genesis child theme style sheet at higher priority
add_action( 'wp_enqueue_scripts', 'genesis_enqueue_main_stylesheet', 15 );

//* Remove sidebars and header widget area
unregister_sidebar( 'header-right' );
unregister_sidebar( 'sidebar' );
unregister_sidebar( 'sidebar-alt' );

//* Unregister layout settings
genesis_unregister_layout( 'content-sidebar' );
genesis_unregister_layout( 'sidebar-content' );
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );

//* Force full width layout selection
add_filter( 'genesis_pre_get_option_site_layout', 'genesis_do_layout' );
function genesis_do_layout( $opt ) {
    $opt = 'full-width-content';
    return $opt;
}

//* Reposition the primary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before_header', 'genesis_do_nav' );

//* Add support for 1 footer widget
add_theme_support( 'genesis-footer-widgets', 1 );

//* Display featured image on top of the post
add_action( 'genesis_before_entry', 'featured_post_image', 8 );

function featured_post_image() {
  if ( ! is_singular() )  return;
	the_post_thumbnail('post-image');

}

//* Move featured image above post title in archives
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
add_action( 'genesis_before_entry', 'genesis_do_post_image', 8 );

//* Display author box on archive pages & single posts
add_filter( 'get_the_author_genesis_author_box_archive', '__return_true' );
add_filter( 'get_the_author_genesis_author_box_single', '__return_true' );

//* Remove comment form allowed tags
add_filter( 'comment_form_defaults', 'genesis_remove_comment_form_allowed_tags' );
function genesis_remove_comment_form_allowed_tags( $defaults ) {

	$defaults['comment_notes_after'] = '';
	return $defaults;

}

//* Customize read more text to include post title for screen readers
add_filter( 'excerpt_more', 'genesis_read_more_link' );
add_filter( 'get_the_content_more_link', 'genesis_read_more_link' );
add_filter( 'the_content_more_link', 'genesis_read_more_link' );
function genesis_read_more_link() {

	return '... <a href="'. get_permalink() .'" class="more-link">' . __( 'Read more', 'genesis' ) . '<span class="screen-reader-text"> ' . __( 'about' ) . " " . get_the_title() . "</span></a>";

}