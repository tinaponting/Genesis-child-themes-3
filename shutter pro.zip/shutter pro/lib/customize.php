<?php

/**
 * This file adds the Customizer ability to the Fresh Theme.
 *
 * @package      Fresh
 * @subpackage   Customizations
 * @link         http://restored316designs.com/themes
 * @author       Lauren Gaige // Restored 316 LLC
 * @copyright    Copyright (c) 2015, Restored 316 LLC, Released 08/18/2015
 * @license      GPL-2.0+
 */
 
//* This theme contains intellectual property owned by Restored 316 LLC, including trademarks, copyrights, proprietary information, and other intellectual property. You may not modify, publish, transmit, participate in the transfer or sale of, create derivative works from, distribute, reproduce or perform, or in any way exploit in any format whatsoever any of this theme or intellectual property, in whole or in part, without our prior written consent. 
 
/**
 * Get default primary color for Customizer.
 *
 * @return string Hex color code for primary color.
 */
function fresh_customizer_get_default_primary_color() {
	return '#FAB9B5';
}

/**
 * Get default accent color for Customizer.
 *
 * @return string Hex color code for accent color.
 */
function fresh_customizer_get_default_accent_color() {
	return '#F9ECE6';
}

add_action( 'customize_register', 'fresh_customizer' );
/**
 * Register settings and controls with the Customizer.
 *
 * @since 1.0.0
 * 
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function fresh_customizer(){

global $wp_customize;
	
	$wp_customize->add_setting(
		'fresh_primary_color',
		array(
			'default' => fresh_customizer_get_default_primary_color(),
		)
	);

	$wp_customize->add_setting(
		'fresh_accent_color',
		array(
			'default' => fresh_customizer_get_default_accent_color(),
		)
	);
	
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'fresh_primary_color',
			array(
				'description' => __( 'Change the default primary color for the newsletter capture areas.', 'fresh' ),
			    'label'       => __( 'Primary Color', 'fresh' ),
			    'section'     => 'colors',
			    'settings'    => 'fresh_primary_color',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'fresh_accent_color',
			array(
				'description' => __( 'Change the default accent color for links, buttons, and more.', 'fresh' ),
			    'label'       => __( 'Accent Color', 'fresh' ),
			    'section'     => 'colors',
			    'settings'    => 'fresh_accent_color',
			)
		)
	);

}

add_action( 'wp_enqueue_scripts', 'fresh_css' );
/**
* Checks the settings for the images and background colors for each image
* If any of these value are set the appropriate CSS is output
*
* @since 1.0
*/
function fresh_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';
	
	$color_primary = get_theme_mod( 'fresh_primary_color', fresh_customizer_get_default_primary_color() );
	$color_accent = get_theme_mod( 'fresh_accent_color', fresh_customizer_get_default_accent_color() );
	
	$opts = apply_filters( 'fresh_images', array( 'header', '2', '4', '6' ) );

	$settings = array();

	foreach( $opts as $opt ){
		$settings[$opt]['image'] = preg_replace( '/^https?:/', '', get_option( $opt .'-image', sprintf( '%s/images/bg-%s.jpg', get_stylesheet_directory_uri(), $opt ) ) );
	}

	$css = '';

	foreach ( $settings as $section => $value ) { 

		$background = $value['image'] ? sprintf( 'background-image: url(%s);', $value['image'] ) : '';

		$css .= ( ! empty( $section ) && ! empty( $background ) ) ? sprintf( '
		.front-page-%s {
			%s
		}
		', $section, $background ) : '';

	}
	
	$css .= ( fresh_customizer_get_default_primary_color() !== $color_primary ) ? sprintf( '
		
		.nav-primary,
		.footer-widgets,
		.after-entry {
			background-color: %1$s;
		}
		
		a,
		.archive-pagination li a:hover, 
		.archive-pagination .active a {
			color: %1$s;
		}

		', $color_primary ) : '';

	$css .= ( fresh_customizer_get_default_accent_color() !== $color_accent ) ? sprintf( '
		
		.site-header,
		.site-footer,
		.enews-widget input[type="submit"]:hover,
		button:hover, 
		input[type="button"]:hover, 
		input[type="reset"]:hover, 
		input[type="submit"]:hover, 
		.button:hover,
		.pagination {
			background-color: %1$s;
		}
		
		', $color_accent ) : '';

	if( $css ){
		wp_add_inline_style( $handle, $css );
	}

}
