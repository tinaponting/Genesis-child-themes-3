<?php
/**
 * This file adds the Customizer to the Prima Donna Theme.
 * @package      Prima Donna
 */

/////////////////////////////////////////////////////////////////
// Customizer Sections Settings Controls
/////////////////////////////////////////////////////////////////

//* Register settings and controls with the Customizer.;
function primadonna_register_theme_customizer( $wp_customize ) {

// Add Settings to Colors section

	// Background Colors Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'background_colors_title', array(
        'label' => __('Background Colors', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'background_image',
        'settings' => 'primadonna_options[info]',
        'priority' => 10
        ) )
	);

// Full Width Header Background Color
	$wp_customize->add_setting(
		'primadonna_header_background_color',
		array(
			'default'     => 'transparent',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'header_background_color',
			array(
				'label'      => 'Full width Header Background Color',
				'section'    => 'background_image',
				'settings'   => 'primadonna_header_background_color',
				'priority'	 => 11
			)
		)
	);

	// Boxed Header Background Color
	$wp_customize->add_setting(
		'primadonna_boxed_header_background_color',
		array(
			'default'     => 'transparent',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'boxed_header_background_color',
			array(
				'label'      => 'Boxed Header Background Color',
				'section'    => 'background_image',
				'settings'   => 'primadonna_boxed_header_background_color',
				'priority'	 => 12
			)
		)
	);

// Body Background Color
	$wp_customize->add_setting(
		'primadonna_body_background_color',
		array(
			'default'     => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'body_background_color',
			array(
				'label'      => 'Body Background Color',
				'section'    => 'background_image',
				'settings'   => 'primadonna_body_background_color',
				'priority'	 => 13
			)
		)
	);

// Content Background Color
	$wp_customize->add_setting(
		'primadonna_content_background_color',
		array(
			'default'     => 'transparent',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'content_background_color',
			array(
				'label'      => 'Content Background Color',
				'section'    => 'background_image',
				'settings'   => 'primadonna_content_background_color',
				'priority'	 => 14
			)
		)
	);

	// Add Content Padding
    $wp_customize->add_setting(
        'primadonna_content_padding_setting',
        array(
            'default' => 'false',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'primadonna_content_padding_setting',
				array(
					'label'      => 'Add Content Padding',
					'section'    => 'background_image',
					'settings'   => 'primadonna_content_padding_setting',
					'type'        => 'select',
					'priority'	 => 15,
					'choices'     => array(                    
						'false'   => __( 'No Padding', 'primadonna' ),
						'true'    => __( 'Add Content Padding', 'primadonna' ),
			),
        ))
	);

	// Sidebar Background Color
	$wp_customize->add_setting(
		'primadonna_sidebar_background_color',
		array(
			'default'     => 'transparent',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'primadonna_sidebar_background_color',
			array(
				'label'      => 'Sidebar Background Color',
				'section'    => 'background_image',
				'settings'   => 'primadonna_sidebar_background_color',
				'priority'	 => 16
			)
		)
	);

	// Add Sidebar Padding
    $wp_customize->add_setting(
        'primadonna_sidebar_padding_setting',
        array(
            'default' => 'false',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'primadonna_sidebar_padding_setting',
				array(
					'label'      => 'Add Sidebar Padding',
					'section'    => 'background_image',
					'settings'   => 'primadonna_sidebar_padding_setting',
					'type'        => 'select',
					'priority'	 => 17,
					'choices'     => array(                    
						'false'   => __( 'No Padding', 'primadonna' ),
						'true'    => __( 'Add Sidebar Padding', 'primadonna' ),
			),
        ))
	);

	// Accent Colors Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'accent_colors_title', array(
        'label' => __('Accent Colors', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'background_image',
        'settings' => 'primadonna_options[info]',
        'priority' => 18
        ) )
	);

	// Accent Color
	$wp_customize->add_setting(
		'primadonna_accent_color',
		array(
			'default'     => '#8495a6',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'accent_color',
			array(
				'label'      => 'Accent Color',
				'section'    => 'background_image',
				'settings'   => 'primadonna_accent_color',
				'priority'	 => 19
			)
		)
	);

	// Link Color
	$wp_customize->add_setting(
		'primadonna_link_color',
		array(
			'default'     => '#8495a6',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'primadonna_link_color',
			array(
				'label'      => 'Link Color',
				'section'    => 'background_image',
				'settings'   => 'primadonna_link_color',
				'priority'	 => 20
			)
		)
	);

	// Link Hover Color
	$wp_customize->add_setting(
		'primadonna_link_hover_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'rimadonna_link_hover_color',
			array(
				'label'      => 'Link Hover Color',
				'section'    => 'background_image',
				'settings'   => 'primadonna_link_hover_color',
				'priority'	 => 21
			)
		)
	);

	// Category Index page widget area bg
	$wp_customize->add_setting(
		'primadonna_index_widgets_color',
		array(
			'default'     => '#fafafa',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'primadonna_index_widgets_color',
			array(
				'label'      => 'Category index Widgets BG Color',
				'section'    => 'background_image',
				'settings'   => 'primadonna_index_widgets_color',
				'priority'	 => 19
			)
		)
	);

	// Breadcrumbs bg
	$wp_customize->add_setting(
		'primadonna_breadcrumbs_color',
		array(
			'default'     => '#f9f9f9',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'primadonna_breadcrumbs_color',
			array(
				'label'      => 'Breadcrumbs BG Color',
				'section'    => 'background_image',
				'settings'   => 'primadonna_breadcrumbs_color',
				'priority'	 => 20
			)
		)
	);


//__Button Styles Panel__//

$wp_customize->add_panel( 'button_styles', array(
  'title' => __( 'Button Styles', 'primadonna' ),
  'description' => __( '', 'primadonna' ), // Include html tags such as <p>.
  'priority' => 24, // Mixed with top-level-section hierarchy.
) );

	//___Custom Buttom Settings___//
    $wp_customize->add_section( 'primadonna_custom_button_section', array(
        'title'    => __( 'Custom Button Settings', 'primadonna' ),
        'description' => __( '', 'primadonna' ),
        'panel' => 'button_styles',
        'priority' => 1,
    ));

    // Small Button BG
	$wp_customize->add_setting(
        'primadonna_small_button_setting',
		array ( 
		'default' => '',
		'sanitize_callback' => 'esc_url_raw',
	));

	$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				'small_button_control',
				array(
					'label'      => 'Small Button Background',
					'section'    => 'primadonna_custom_button_section',
					'description' => __( 'Custom image button background for small buttons like Read More and Slider', 'primadonna' ),
					'settings'   => 'primadonna_small_button_setting',
					'priority'	 => 1
				)
			)
		);

	// Large Button BG
	$wp_customize->add_setting(
        'primadonna_large_button_setting',
		array ( 
		'default' => '',
		'sanitize_callback' => 'esc_url_raw',
	));

	$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				'large_button_control',
				array(
					'label'      => 'Large Button Background',
					'section'    => 'primadonna_custom_button_section',
					'description' => __( 'Custom image button background for large buttons like Newsletter forms', 'primadonna' ),
					'settings'   => 'primadonna_large_button_setting',
					'priority'	 => 2
				)
			)
		);

	//___Button Size Settings___//
    $wp_customize->add_section( 'primadonna_button_size_section', array(
        'title'    => __( 'Button Size Settings', 'primadonna' ),
        'description' => __( '', 'primadonna' ),
        'panel' => 'button_styles',
        'priority' => 2,
    ));

    // Small Button Height
	$wp_customize->add_setting(
        'primadonna_small_button_height_setting',
        array(
            'default'     => '47',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'primadonna_small_button_height_control',
				array(
					'label'      => 'Adjust Small Button Height',
					'section'    => 'primadonna_button_size_section',
					'settings'   => 'primadonna_small_button_height_setting',
					'type'		 => 'number',
					'priority'	 => 1
				)
			)
		);

    // Small Button Width
	$wp_customize->add_setting(
        'primadonna_small_button_width_setting',
        array(
            'default'     => '170',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'primadonna_small_button_width_control',
				array(
					'label'      => 'Adjust Small Button Width',
					'section'    => 'primadonna_button_size_section',
					'settings'   => 'primadonna_small_button_width_setting',
					'type'		 => 'number',
					'priority'	 => 2
				)
			)
		);

    // Large Button Height
	$wp_customize->add_setting(
        'primadonna_large_button_height_setting',
        array(
            'default'     => '67',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'primadonna_large_button_height_control',
				array(
					'label'      => 'Adjust Large Button Height',
					'section'    => 'primadonna_button_size_section',
					'settings'   => 'primadonna_large_button_height_setting',
					'type'		 => 'number',
					'priority'	 => 3
				)
			)
		);

    // Large Button Width
	$wp_customize->add_setting(
        'primadonna_large_button_width_setting',
        array(
            'default'     => '240',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'primadonna_large_button_width_control',
				array(
					'label'      => 'Adjust Large Button Width',
					'section'    => 'primadonna_button_size_section',
					'settings'   => 'primadonna_large_button_width_setting',
					'type'		 => 'number',
					'priority'	 => 4
				)
			)
		);

    //___Standard Button Settings___//
    $wp_customize->add_section( 'primadonna_standard_button_section', array(
        'title'    => __( 'Standard Button Settings', 'primadonna' ),
        'description' => __( '', 'primadonna' ),
        'panel' => 'button_styles',
        'priority' => 3,
    ));

   	//Button Background
	$wp_customize->add_setting(
		'primadonna_button_bg_setting',
		array(
			'default'     => '',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'primadonna_button_bg_control',
			array(
				'label'      => 'Button Background Color',
				'section'    => 'primadonna_standard_button_section',
				'settings'   => 'primadonna_button_bg_setting',
				'priority'	 => 1
			)
		)
	);

	//Button Hover Background
	$wp_customize->add_setting(
		'primadonna_button_hover_bg_setting',
		array(
			'default'     => 'transparent',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'primadonna_button_hover_bg_control',
			array(
				'label'      => 'Button Hover Background Color',
				'section'    => 'primadonna_standard_button_section',
				'settings'   => 'primadonna_button_hover_bg_setting',
				'priority'	 => 2
			)
		)
	);

	//Button Color
	$wp_customize->add_setting(
		'primadonna_button_color_setting',
		array(
			'default'     => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'primadonna_button_color_control',
			array(
				'label'      => 'Button Text Color',
				'section'    => 'primadonna_standard_button_section',
				'settings'   => 'primadonna_button_color_setting',
				'priority'	 => 3
			)
		)
	);

	//Button Color
	$wp_customize->add_setting(
		'primadonna_button_hover_color_setting',
		array(
			'default'     => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'primadonna_button_hover_color_control',
			array(
				'label'      => 'Button Hover Text Color',
				'section'    => 'primadonna_standard_button_section',
				'settings'   => 'primadonna_button_hover_color_setting',
				'priority'	 => 4
			)
		)
	);

	//___Button Fonts___//
    $wp_customize->add_section( 'primadonna_button_fonts_section', array(
        'title'    => __( 'Button fonts', 'primadonna' ),
        'description' => __( '', 'primadonna' ),
        'panel' => 'button_styles',
        'priority' => 4,
    ));

    // Font Family
    $wp_customize->add_setting( 'buttons_google_font_list', array(
        'default'           => 'Open Sans',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control( new Google_Font_Dropdown_Custom_Control( $wp_customize, 'buttons_google_font_list', array(
        'label'      => 'Font Family',
        'section'    => 'primadonna_button_fonts_section',
        'settings'   => 'buttons_google_font_list',
        'priority'	 => 1,
    )));

    // Font weight
    $wp_customize->add_setting(
        'buttons_google_font_weight',
        array(
            'default' => '400',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'buttons_google_font_weight',
				array(
					'label' => 'Font Weight',
					'description'      => 'Some font weights will not apply to certain fonts. See https://fonts.google.com/ for more info about each font in the list.',
					'section'    => 'primadonna_button_fonts_section',
					'settings'   => 'buttons_google_font_weight',
					'type'        => 'select',
					'priority'	 => 3,
					'choices'     => array(                    
						'100'   => __( '100', 'primadonna' ),
						'200'    => __( '200', 'primadonna' ),
						'300'    => __( '300', 'primadonna' ),
						'400'    => __( 'normal', 'primadonna' ),
						'500'    => __( '500', 'primadonna' ),
						'600'    => __( '600', 'primadonna' ),
						'700'    => __( 'bold', 'primadonna' ),
						'800'    => __( '800', 'primadonna' ),
						'900'    => __( '900', 'primadonna' ),
			),
        ))
	);

	// Letter Spacing
    $wp_customize->add_setting(
   		'buttons_google_font_spacing',
        array(
            'default'     => '1',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'buttons_google_font_spacing',
				array(
					'label'      => 'Letter Spacing',
					'section'    => 'primadonna_button_fonts_section',
					'settings'   => 'buttons_google_font_spacing',
					'type'		 => 'number',
					'priority'	 => 4,
				)
			)
		);

	// Text transform
    $wp_customize->add_setting(
        'buttons_google_font_transform',
        array(
            'default' => 'uppercase',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'buttons_google_font_transform',
				array(
					'label' => 'Text Transform (Case)',
					'description'      => '',
					'section'    => 'primadonna_button_fonts_section',
					'settings'   => 'buttons_google_font_transform',
					'type'        => 'select',
					'priority'	 => 5,
					'choices'     => array(                    
						'none'   => __( 'none', 'primadonna' ),
						'lowercase'    => __( 'lowercase', 'primadonna' ),
						'capitalize'    => __( 'capitalize', 'primadonna' ),
						'uppercase'    => __( 'uppercase', 'primadonna' ),
			),
        ))
	);


	//___Header & Logo Settings___//

    //Logo Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'header_logo_title', array(
        'label' => 'Header & Logo Settings',
        'section' => 'header_image',
        'settings' => 'primadonna_options[info]',
        'priority' => 11
        ) )
	);

    // Logo Height
	$wp_customize->add_setting(
        'primadonna_logo_height_setting',
        array(
            'default'     => '175',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'primadonna_logo_height_control',
				array(
					'label'      => 'Adjust Image Logo Height',
					'section'    => 'header_image',
					'settings'   => 'primadonna_logo_height_setting',
					'type'		 => 'number',
					'priority'	 => 12
				)
			)
		);

    // Padding Top
	$wp_customize->add_setting(
        'primadonna_logo_padding_top_setting',
        array(
            'default'     => '30',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'primadonna_logo_padding_top_control',
				array(
					'label'      => 'Logo Top Padding',
					'section'    => 'header_image',
					'settings'   => 'primadonna_logo_padding_top_setting',
					'type'		 => 'number',
					'priority'	 => 13
				)
			)
	);

	// Padding Bottom
	$wp_customize->add_setting(
        'primadonna_logo_padding_bottom_setting',
        array(
            'default'     => '40',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'primadonna_logo_padding_bottom_control',
				array(
					'label'      => 'Logo Bottom Padding',
					'section'    => 'header_image',
					'settings'   => 'primadonna_logo_padding_bottom_setting',
					'type'		 => 'number',
					'priority'	 => 14
				)
			)
		);

    // Header Top Padding
	$wp_customize->add_setting(
        'primadonna_header_padding_top_setting',
        array(
            'default'     => '50',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'primadonna_header_padding_top_setting',
				array(
					'label'      => 'Header Padding Top',
					'description' => __( 'Adjust padding at very top of header. Useful when not using Primary Menu or Top Bar', 'primadonna' ),
					'section'    => 'header_image',
					'settings'   => 'primadonna_header_padding_top_setting',
					'type'		 => 'number',
					'priority'	 => 15
				)
			)
		);

//__Home Page Panel__//

$wp_customize->add_panel( 'home_page', array(
  'title' => __( 'Home Page Settings', 'primadonna' ),
  'description' => __( '', 'primadonna' ), // Include html tags such as <p>.
  'priority' => 26, // Mixed with top-level-section hierarchy.
) );

	   //___Home Page Slider___//
    //* Add home page slider settings
    $wp_customize->add_section( 'primadonna_slider_front_section', array(
        'title'    => __( 'Home Page Slider', 'primadonna' ),
        'panel' => 'home_page',
        'description' => __( 'Setup the Featured Post slider at the top of the home page', 'primadonna' ),
        'priority' => 1,
    ));

    // Featured Layout title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'front_featured_layout_title', array(
        'label' => __('Slider Layout', 'primadonna'),
        'description' => __( 'All 3 Layouts available on Home Page template. Only Boxed layout available on Home Page Alt template.', 'primadonna' ),
        'section' => 'primadonna_slider_front_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 1
        ) )
	);

	// Featured Layout
	$wp_customize->add_setting(
	        'primadonna_front_featured_layout_setting',
	        array(
	            'default'     => 'none',
	            'sanitize_callback' => 'primadonna_sanitize_featured_layout',
	        )
	    );

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'front_featured_layout_control',
			array(
				'label'          => '',
				'section'        => 'primadonna_slider_front_section',
				'settings'       => 'primadonna_front_featured_layout_setting',
				'type'           => 'radio',
				'priority'	 => 2,
				'choices'        => array(
					'none' => 'No Slider',
					'boxed'   => 'Boxed Slider',
					'full'  => 'Fullwidth Slider',
					'carousel'  => 'Carousel Slider',
				)
			)
		)
	);

	// Featured Category title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'front_featured_category_title', array(
        'label' => __('Featured Slider Category or Posts', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_slider_front_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 3
        ) )
	);

	// Featured Category
	$wp_customize->add_setting(
        'primadonna_front_featured_cat_setting',
        array(
            'default'     => '',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
    );

    $wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'front_featured_cat_control',
				array(
					'label'    => 'Select a Featured Category or Categories',
					'description' => __( 'Enter the ID of your Featured Category or Categories. Separate with a comma and no spaces.', 'primadonna' ),
					'settings' => 'primadonna_front_featured_cat_setting',
					'section'  => 'primadonna_slider_front_section',
					'type'		 => 'text',
					'priority'	 => 4,
				)
			)
		);

    // Featured by ID
	$wp_customize->add_setting(
        'primadonna_front_featured_id_setting',
        array(
            'default'     => '',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
    );

    $wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'front_featured_id_control',
				array(
					'label'      => 'Or Select featured post IDs',
					'section'    => 'primadonna_slider_front_section',
					'settings'   => 'primadonna_front_featured_id_setting',
					'type'		 => 'text',
					'priority'	 => 5
				)
			)
		);

    // Featured Slides title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'front_featured_slides_title', array(
        'label' => __('Number of Featured Slides to Display', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_slider_front_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 6
        ) )
	);

    // Featured Slides Number
	$wp_customize->add_setting(
        'primadonna_front_featured_slider_slides_setting',
        array(
            'default'     => '6',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'front_featured_slider_slides_control',
				array(
					'label'      => 'Amount of Slides',
					'section'    => 'primadonna_slider_front_section',
					'settings'   => 'primadonna_front_featured_slider_slides_setting',
					'type'		 => 'number',
					'priority'	 => 7
				)
			)
		);

    // Featured Slides title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'front_featured_overlay_title', array(
        'label' => __('Featured Title Overlay', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_slider_front_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 8
        ) )
	);

    // Featured Overlay
    $wp_customize->add_setting(
        'primadonna_front_featured_overlay_setting',
        array(
            'default' => false,
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'front_featured_overlay_control',
				array(
					'label'      => 'Disable Text on Slider',
					'section'    => 'primadonna_slider_front_section',
					'settings'   => 'primadonna_front_featured_overlay_setting',
					'type'        => 'select',
					'priority'	 => 9,
					'choices'     => array(                    
						'false'   => __( 'Show Slider Text', 'primadonna' ),
						'true'    => __( 'Hide Slider Text', 'primadonna' ),
			),
        ))
	);

	// Featured Overlay Labels
    $wp_customize->add_setting(
        'primadonna_front_featured_overlay_cats_setting',
        array(
            'default' => false,
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'front_featured_overlay_cats_control',
				array(
					'label'      => 'Hide Categories Only on Slider',
					'section'    => 'primadonna_slider_front_section',
					'settings'   => 'primadonna_front_featured_overlay_cats_setting',
					'type'		 => 'select',
					'priority'	 => 10,
					'choices'     => array(                    
						'false'   => __( 'Show Slider Categories', 'primadonna' ),
						'true'    => __( 'Hide Slider Categories', 'primadonna' ),
			),
				)
			)
		);

	// Read More Button Text
    $wp_customize->add_setting(
        'primadonna_front_slider_read_more_setting',
        array(
            'default'     => 'read more',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
    );

    $wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'front_slider_read_more_control',
				array(
					'label'      => 'Read Article button text',
					'section'    => 'primadonna_slider_front_section',
					'settings'   => 'primadonna_front_slider_read_more_setting',
					'type'		 => 'text',
					'priority'	 => 11
				)
			)
		);

    //___Home Page Promo Box Settings___//
    //* Add front page Promo Box Settings
    $wp_customize->add_section( 'primadonna_promo_front_section', array(
        'title'    => __( 'Home Page Promo Boxes', 'primadonna' ),
        'panel' => 'home_page',
        'description' => __( 'Promo Boxes on the Home Page template.', 'primadonna' ),
        'priority' => 2,
    ));

    // Promo Box Layout title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'front_featured_promo_title', array(
        'label' => __('Promo Box Layout', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_promo_front_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 1
        ) )
	);

	// Enable Promo
	$wp_customize->add_setting(
        'primadonna_front_promo_setting',
        array(
            'default' => 'none',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
    );

    $wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'front_promo_control',
				array(
					'label'      => '',
					'description' => __( 'Hide or display 2, 3 or 4 Promo boxes below slider on home page template.', 'primadonna' ),
					'section'    => 'primadonna_promo_front_section',
					'settings'   => 'primadonna_front_promo_setting',
					'type'        => 'select',
					'priority'	 => 2,
					'choices'     => array(                    
						'none'   => __( 'Do not display Promo Boxes', 'primadonna' ),
						'2boxes'    => __( 'Display 2 boxes', 'primadonna' ),
						'3boxes'    => __( 'Display 3 boxes', 'primadonna' ),
						'4boxes'    => __( 'Display 4 boxes', 'primadonna' ),
			),
        ))
	);	

	// Promo Box Height title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'front_featured_promo_height_title', array(
        'label' => __('Promo Boxes Height', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_promo_front_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 3
        ) )
	);

	// Promo Box Height
	$wp_customize->add_setting(
        'primadonna_front_promo_height_setting',
        array(
            'default'     => '250',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'primadonna_front_promo_height_control',
				array(
					'label'      => 'Adjust Promo Boxes Height',
					'section'    => 'primadonna_promo_front_section',
					'settings'   => 'primadonna_front_promo_height_setting',
					'type'		 => 'number',
					'priority'	 => 4
				)
			)
		);

    // Promo Box 1 title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'front_featured_promo1_title', array(
        'label' => __('Promo Boxes 1 Settings', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_promo_front_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 5
        ) )
	);

    // Promo 1 Title
	$wp_customize->add_setting(
        'primadonna_front_promo1_title_setting',
        array(
            'default'     => '',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
    );

    $wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'front_promo1_title_control',
				array(
					'label'      => 'Promo Box #1 Title',
					'section'    => 'primadonna_promo_front_section',
					'settings'   => 'primadonna_front_promo1_title_setting',
					'type'		 => 'text',
					'priority'	 => 6
				)
			)
		);

    // Promo 1 Image
	$wp_customize->add_setting(
        'primadonna_front_promo1_image_setting',
		array ( 
		'default' => '',
		'sanitize_callback' => 'esc_url_raw',
	));

	$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				'front_promo1_image_control',
				array(
					'label'      => 'Promo Box #1 Image',
					'section'    => 'primadonna_promo_front_section',
					'settings'   => 'primadonna_front_promo1_image_setting',
					'priority'	 => 7
				)
			)
		);

	//Promo 1 URL
	$wp_customize->add_setting(
        'primadonna_front_promo1_url_setting',
	    array ( 
	    'default' => '',
	    'sanitize_callback' => 'esc_url_raw',
	));

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'front_promo1_url_control',
				array(
					'label'      => 'Promo Box #1 URL',
					'section'    => 'primadonna_promo_front_section',
					'settings'   => 'primadonna_front_promo1_url_setting',
					'type'		 => 'text',
					'priority'	 => 8
				)
			)
		);

	// Promo Box 2 title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'front_featured_promo2_title', array(
        'label' => __('Promo Boxes 2 Settings', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_promo_front_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 9
        ) )
	);

	// Promo 2 Title
	$wp_customize->add_setting(
        'primadonna_front_promo2_title_setting',
        array(
            'default'     => '',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
    );

    $wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'front_promo2_title_control',
				array(
					'label'      => 'Promo Box #2 Title',
					'section'    => 'primadonna_promo_front_section',
					'settings'   => 'primadonna_front_promo2_title_setting',
					'type'		 => 'text',
					'priority'	 => 10
				)
			)
		);

    // Promo 2 Image
	$wp_customize->add_setting(
        'primadonna_front_promo2_image_setting',
	    array ( 
	    'default' => '',
	    'sanitize_callback' => 'esc_url_raw',
	));

	$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				'front_promo2_image_control',
				array(
					'label'      => 'Promo Box #2 Image',
					'section'    => 'primadonna_promo_front_section',
					'settings'   => 'primadonna_front_promo2_image_setting',
					'priority'	 => 11
				)
			)
		);

	// Promo 2 URL
	$wp_customize->add_setting(
        'primadonna_front_promo2_url_setting',
	    array ( 
	    'default' => '',
	    'sanitize_callback' => 'esc_url_raw',
	));

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'front_promo2_url_control',
				array(
					'label'      => 'Promo Box #2 URL',
					'section'    => 'primadonna_promo_front_section',
					'settings'   => 'primadonna_front_promo2_url_setting',
					'type'		 => 'text',
					'priority'	 => 12
				)
			)
		);

	// Promo Box 3 title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'front_featured_promo3_title', array(
        'label' => __('Promo Boxes 3 Settings', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_promo_front_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 13
        ) )
	);

	//Promo 3 Title
	$wp_customize->add_setting(
        'primadonna_front_promo3_title_setting',
        array(
            'default'     => '',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
    );

    $wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'front_promo3_title_control',
				array(
					'label'      => 'Promo Box #3 Title',
					'section'    => 'primadonna_promo_front_section',
					'settings'   => 'primadonna_front_promo3_title_setting',
					'type'		 => 'text',
					'priority'	 => 14
				)
			)
		);

    // Promo 3 Image
	$wp_customize->add_setting(
        'primadonna_front_promo3_image_setting',
	    array ( 
	    'default' => '',
	    'sanitize_callback' => 'esc_url_raw',
	));

	$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				'front_promo3_image_control',
				array(
					'label'      => 'Promo Box #3 Image',
					'section'    => 'primadonna_promo_front_section',
					'settings'   => 'primadonna_front_promo3_image_setting',
					'priority'	 => 15
				)
			)
		);

	// Promo 3 URL
	$wp_customize->add_setting(
        'primadonna_front_promo3_url_setting',
	    array ( 
	    'default' => '',
	    'sanitize_callback' => 'esc_url_raw',
	));

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'front_promo3_url_control',
				array(
					'label'      => 'Promo Box #3 URL',
					'section'    => 'primadonna_promo_front_section',
					'settings'   => 'primadonna_front_promo3_url_setting',
					'type'		 => 'text',
					'priority'	 => 16
				)
			)
		);

	// Promo Box 4 title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'front_featured_promo4_title', array(
        'label' => __('Promo Boxes 4 Settings', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_promo_front_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 17
        ) )
	);

	//Promo 4 Title
	$wp_customize->add_setting(
        'primadonna_front_promo4_title_setting',
        array(
            'default'     => '',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
    );

    $wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'front_promo4_title_control',
				array(
					'label'      => 'Promo Box #4 Title',
					'section'    => 'primadonna_promo_front_section',
					'settings'   => 'primadonna_front_promo4_title_setting',
					'type'		 => 'text',
					'priority'	 => 18
				)
			)
		);

    // Promo 4 Image
	$wp_customize->add_setting(
        'primadonna_front_promo4_image_setting',
	    array ( 
	    'default' => '',
	    'sanitize_callback' => 'esc_url_raw',
	));

	$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				'front_promo4_image_control',
				array(
					'label'      => 'Promo Box #4 Image',
					'section'    => 'primadonna_promo_front_section',
					'settings'   => 'primadonna_front_promo4_image_setting',
					'priority'	 => 19
				)
			)
		);

	// Promo 4 URL
	$wp_customize->add_setting(
        'primadonna_front_promo4_url_setting',
	    array ( 
	    'default' => '',
	    'sanitize_callback' => 'esc_url_raw',
	));

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'front_promo4_url_control',
				array(
					'label'      => 'Promo Box #4 URL',
					'section'    => 'primadonna_promo_front_section',
					'settings'   => 'primadonna_front_promo4_url_setting',
					'type'		 => 'text',
					'priority'	 => 20
				)
			)
		);

//__Blog Page Panel__//

$wp_customize->add_panel( 'blog_page', array(
  'title' => __( 'Blog Page Settings', 'primadonna' ),
  'description' => __( '', 'primadonna' ), // Include html tags such as <p>.
  'priority' => 27, // Mixed with top-level-section hierarchy.
) );

	//___Blog Page Settings___//
    //* Add blog page setting to the Customizer
    $wp_customize->add_section( 'primadonna_blogpage_section', array(
        'title'    => __( 'Blog Layout', 'primadonna' ),
        'panel' => 'blog_page',
        'description' => __( '', 'primadonna' ),
        'priority' => 1,
    ));

    //Blog Layout Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'blog_page_title', array(
        'label' => __('Blog Post Layout', 'primadonna'),
        'description' => __( 'Choose the layout for the posts on the Blog Page Template', 'primadonna' ),
        'section' => 'primadonna_blogpage_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 1
        ) )
	);

    //* Add blog page setting to the Customizer
    $wp_customize->add_setting( 'primadonna_bloglayout_setting', array(
        'default'           => 'full',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'primadonna_sanitize_homepage_layout',

    ));

    $wp_customize->add_control( new WP_Customize_Control( 
        $wp_customize, 'primadonna_bloglayout_control', array(
			'label'       => __( '', 'primadonna' ),
			'description' => __( '', 'primadonna' ),
			'section'     => 'primadonna_blogpage_section',
			'settings'    => 'primadonna_bloglayout_setting',
			'type'        => 'radio',
			'priority'	 => 2,
			'choices'     => array(                    
				'full'   => 'Full Post Layout',
				'grid'  => 'Grid Post Layout',
				'full_grid'  => '1 Full Post then Grid Layout',
				'list'  => 'List Post Layout',
				'full_list'  => '1 Full Post then List Layout',
				'masonry' => 'Masonry Post Layout',
				'full_masonry'  => '1 Full Post then Masonry Layout',
			),
        ))
	);	

	//Blog Columns Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'blog_columns_title', array(
        'label' => __('Blog Columns Layout', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_blogpage_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 3
        ) )
	);

	//* Set column number on blog page
    $wp_customize->add_setting( 'primadonna_column_setting', array(
        'default'           => '2col',
        'sanitize_callback' => 'primadonna_sanitize_text',
    ));

    $wp_customize->add_control( new WP_Customize_Control( 
        $wp_customize, 'primadonna_column_control', array(
			'label'       => __( '', 'primadonna' ),
			'description' => __( 'Set number of columns on Blog Page template. For Grid and Masonry Layouts. Only affects main blog page, not blog posts.', 'primadonna' ),
			'section'     => 'primadonna_blogpage_section',
			'settings'    => 'primadonna_column_setting',
			'type'        => 'select',
			'priority'	 => 4,
			'choices'     => array(                    
				'2col'   => __( '2 columns', 'primadonna' ),
				'3col'    => __( '3 columns', 'primadonna' ),
			),
        ))
	);

	//Blog Sidebar Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'blog_sidebar_title', array(
        'label' => __('Blog Sidebar Setting', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_blogpage_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 5
        ) )
	);

    //* Add option to hide sidebar on blog page
    $wp_customize->add_setting( 'primadonna_sidebar_setting', array(
        'default'           => 'false',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'primadonna_sanitize_text',
    ));

    $wp_customize->add_control( new WP_Customize_Control( 
        $wp_customize, 'primadonna_sidebar_control', array(
			'label'       => __( '', 'primadonna' ),
			'description' => __( 'Show or Hide the blog page template sidebar. The sidebar will display by default. Only affects main blog page, not blog posts.', 'primadonna' ),
			'section'     => 'primadonna_blogpage_section',
			'settings'    => 'primadonna_sidebar_setting',
			'type'        => 'select',
			'priority'	 => 6,
			'choices'     => array(                    
				'false'   => __( 'Display blog template sidebar', 'primadonna' ),
				'true'    => __( 'Hide blog template sidebar', 'primadonna' ),
			),
        ))
	);

	//Read More Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'blog_readmore_title', array(
        'label' => __('Read More Button Text Setting', 'primadonna'),
        'description' => __( 'Customize the text on your Read More buttons', 'primadonna' ),
        'section' => 'primadonna_blogpage_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 7
        ) )
	);

	// Read more text
    $wp_customize->add_setting(
        'primadonna_read_more_setting',
        array(
        'default'           => 'continue reading',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'primadonna_sanitize_text',
        )
    );

    $wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'primadonna_read_more_control',
				array(
					'label'      => '',
					'section'    => 'primadonna_blogpage_section',
					'settings'   => 'primadonna_read_more_setting',
					'type'		 => 'text',
					'priority'	 => 8
				)
			)
		);

    //___Blog Page Slider___//
    //* Add blog page slider settings
    $wp_customize->add_section( 'primadonna_slider_section', array(
        'title'    => __( 'Blog Page Slider', 'primadonna' ),
        'panel' => 'blog_page',
        'description' => __( 'Setup the Featured Post slider at the top of the blog page', 'primadonna' ),
        'priority' => 2,
    ));

    // Featured Layout title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'featured_layout_title', array(
        'label' => __('Slider Layout', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_slider_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 1
        ) )
	);

	// Featured Layout
	$wp_customize->add_setting(
	        'primadonna_featured_layout_setting',
	        array(
	            'default'     => 'none',
	            'sanitize_callback' => 'primadonna_sanitize_featured_layout',
	        )
	    );

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'featured_layout_control',
			array(
				'label'          => '',
				'section'        => 'primadonna_slider_section',
				'settings'       => 'primadonna_featured_layout_setting',
				'type'           => 'radio',
				'priority'	 => 2,
				'choices'        => array(
					'none' => 'No Slider',
					'boxed'   => 'Boxed Slider',
					'full'  => 'Fullwidth Slider',
					'carousel'  => 'Carousel Slider',
					'split' => '2/3 + 1/3 - Slider + Widget'
				)
			)
		)
	);

	// Featured Category title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'featured_category_title', array(
        'label' => __('Featured Slider Category or Posts', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_slider_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 3
        ) )
	);

	// Featured Category
	$wp_customize->add_setting(
        'primadonna_featured_cat_setting',
        array(
            'default'     => '',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
    );

    $wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'featured_cat_control',
				array(
					'label'    => 'Select a Featured Category or Categories',
					'description' => __( 'Enter the ID of your Featured Category or Categories. Separate with a comma and no spaces.', 'primadonna' ),
					'settings' => 'primadonna_featured_cat_setting',
					'section'  => 'primadonna_slider_section',
					'type'		 => 'text',
					'priority'	 => 4
				)
			)
		);

    // Featured by ID
	$wp_customize->add_setting(
        'primadonna_featured_id_setting',
        array(
            'default'     => '',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
    );

    $wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'featured_id_control',
				array(
					'label'      => 'Or Select featured post IDs',
					'section'    => 'primadonna_slider_section',
					'settings'   => 'primadonna_featured_id_setting',
					'type'		 => 'text',
					'priority'	 => 5
				)
			)
		);

    // Featured Slides title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'featured_slides_title', array(
        'label' => __('Number of Featured Slides to Display', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_slider_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 6
        ) )
	);

    // Featured Slides Number
	$wp_customize->add_setting(
        'primadonna_featured_slider_slides_setting',
        array(
            'default'     => '6',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'featured_slider_slides_control',
				array(
					'label'      => 'Amount of Slides',
					'section'    => 'primadonna_slider_section',
					'settings'   => 'primadonna_featured_slider_slides_setting',
					'type'		 => 'number',
					'priority'	 => 7
				)
			)
		);

    // Featured Slides title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'featured_overlay_title', array(
        'label' => __('Featured Title Overlay', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_slider_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 8
        ) )
	);

    // Featured Overlay
    $wp_customize->add_setting(
        'primadonna_featured_overlay_setting',
        array(
            'default' => false,
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'featured_overlay_control',
				array(
					'label'      => 'Disable Text on Slider',
					'section'    => 'primadonna_slider_section',
					'settings'   => 'primadonna_featured_overlay_setting',
					'type'		 => 'select',
					'priority'	 => 9,
					'choices'     => array(                    
						'false'   => __( 'Show Slider Text', 'primadonna' ),
						'true'    => __( 'Hide Slider Text', 'primadonna' ),
			),
				)
			)
		);

	// Featured Overlay Labels
    $wp_customize->add_setting(
        'primadonna_featured_overlay_cats_setting',
        array(
            'default' => false,
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'featured_overlay_cats_control',
				array(
					'label'      => 'Disable Categories Only on Slider',
					'section'    => 'primadonna_slider_section',
					'settings'   => 'primadonna_featured_overlay_cats_setting',
					'type'		 => 'select',
					'priority'	 => 10,
					'choices'     => array(                    
						'false'   => __( 'Show Slider Categories', 'primadonna' ),
						'true'    => __( 'Hide Slider Categories', 'primadonna' ),
			),
				)
			)
		);

	// Read More Button Text
    $wp_customize->add_setting(
        'primadonna_slider_read_more_setting',
        array(
            'default'     => 'read more',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
    );

    $wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'slider_read_more_control',
				array(
					'label'      => 'Read Article button text',
					'section'    => 'primadonna_slider_section',
					'settings'   => 'primadonna_slider_read_more_setting',
					'type'		 => 'text',
					'priority'	 => 11
				)
			)
		);

    //___Blog Promo Box Settings___//
    //* Add blog page Promo Box Settings
    $wp_customize->add_section( 'primadonna_promo_section', array(
        'title'    => __( 'Blog Page Promo Boxes', 'primadonna' ),
        'panel' => 'blog_page',
        'description' => __( 'Promo Boxes on the Blog Page template.', 'primadonna' ),
        'priority' => 3,
    ));

    // Promo Box Layout title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'featured_promo_title', array(
        'label' => __('Promo Box Layout', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_promo_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 1
        ) )
	);

	// Enable Promo
	$wp_customize->add_setting(
        'primadonna_promo_setting',
        array(
            'default' => 'none',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
    );

    $wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'promo_control',
				array(
					'label'      => '',
					'description' => __( 'Hide or display 2, 3 or 4 Promo boxes below slider on blog page template.', 'primadonna' ),
					'section'    => 'primadonna_promo_section',
					'settings'   => 'primadonna_promo_setting',
					'type'        => 'select',
					'priority'	 => 2,
					'choices'     => array(                    
						'none'   => __( 'Do not display Promo Boxes', 'primadonna' ),
						'2boxes'    => __( 'Display 2 boxes', 'primadonna' ),
						'3boxes'    => __( 'Display 3 boxes', 'primadonna' ),
						'4boxes'    => __( 'Display 4 boxes', 'primadonna' ),
			),
        ))
	);	

	// Promo Box Height title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'featured_promo_height_title', array(
        'label' => __('Promo Boxes Height', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_promo_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 3
        ) )
	);

	// Promo Box Height
	$wp_customize->add_setting(
        'primadonna_promo_height_setting',
        array(
            'default'     => '250',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'primadonna_promo_height_control',
				array(
					'label'      => 'Adjust Promo Boxes Height',
					'section'    => 'primadonna_promo_section',
					'settings'   => 'primadonna_promo_height_setting',
					'type'		 => 'number',
					'priority'	 => 4
				)
			)
		);

    // Promo Box 1 title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'featured_promo1_title', array(
        'label' => __('Promo Boxes 1 Settings', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_promo_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 5
        ) )
	);

    // Promo 1 Title
	$wp_customize->add_setting(
        'primadonna_promo1_title_setting',
        array(
            'default'     => '',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
    );

    $wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'promo1_title_control',
				array(
					'label'      => 'Promo Box #1 Title',
					'section'    => 'primadonna_promo_section',
					'settings'   => 'primadonna_promo1_title_setting',
					'type'		 => 'text',
					'priority'	 => 6
				)
			)
		);

    // Promo 1 Image
	$wp_customize->add_setting(
        'primadonna_promo1_image_setting',
		array ( 
		'default' => '',
		'sanitize_callback' => 'esc_url_raw',
	));

	$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				'promo1_image_control',
				array(
					'label'      => 'Promo Box #1 Image',
					'section'    => 'primadonna_promo_section',
					'settings'   => 'primadonna_promo1_image_setting',
					'priority'	 => 7
				)
			)
		);

	//Promo 1 URL
	$wp_customize->add_setting(
        'primadonna_promo1_url_setting',
	    array ( 
	    'default' => '',
	    'sanitize_callback' => 'esc_url_raw',
	));

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'promo1_url_control',
				array(
					'label'      => 'Promo Box #1 URL',
					'section'    => 'primadonna_promo_section',
					'settings'   => 'primadonna_promo1_url_setting',
					'type'		 => 'text',
					'priority'	 => 8
				)
			)
		);

	// Promo Box 2 title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'featured_promo2_title', array(
        'label' => __('Promo Boxes 2 Settings', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_promo_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 9
        ) )
	);

	// Promo 2 Title
	$wp_customize->add_setting(
        'primadonna_promo2_title_setting',
        array(
            'default'     => '',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
    );

    $wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'promo2_title_control',
				array(
					'label'      => 'Promo Box #2 Title',
					'section'    => 'primadonna_promo_section',
					'settings'   => 'primadonna_promo2_title_setting',
					'type'		 => 'text',
					'priority'	 => 10
				)
			)
		);

    // Promo 2 Image
	$wp_customize->add_setting(
        'primadonna_promo2_image_setting',
	    array ( 
	    'default' => '',
	    'sanitize_callback' => 'esc_url_raw',
	));

	$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				'promo2_image_control',
				array(
					'label'      => 'Promo Box #2 Image',
					'section'    => 'primadonna_promo_section',
					'settings'   => 'primadonna_promo2_image_setting',
					'priority'	 => 11
				)
			)
		);

	// Promo 2 URL
	$wp_customize->add_setting(
        'primadonna_promo2_url_setting',
	    array ( 
	    'default' => '',
	    'sanitize_callback' => 'esc_url_raw',
	));

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'promo2_url_control',
				array(
					'label'      => 'Promo Box #2 URL',
					'section'    => 'primadonna_promo_section',
					'settings'   => 'primadonna_promo2_url_setting',
					'type'		 => 'text',
					'priority'	 => 12
				)
			)
		);

	// Promo Box 3 title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'featured_promo3_title', array(
        'label' => __('Promo Boxes 3 Settings', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_promo_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 13
        ) )
	);

	//Promo 3 Title
	$wp_customize->add_setting(
        'primadonna_promo3_title_setting',
        array(
            'default'     => '',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
    );

    $wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'promo3_title_control',
				array(
					'label'      => 'Promo Box #3 Title',
					'section'    => 'primadonna_promo_section',
					'settings'   => 'primadonna_promo3_title_setting',
					'type'		 => 'text',
					'priority'	 => 14
				)
			)
		);

    // Promo 3 Image
	$wp_customize->add_setting(
        'primadonna_promo3_image_setting',
	    array ( 
	    'default' => '',
	    'sanitize_callback' => 'esc_url_raw',
	));

	$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				'promo3_image_control',
				array(
					'label'      => 'Promo Box #3 Image',
					'section'    => 'primadonna_promo_section',
					'settings'   => 'primadonna_promo3_image_setting',
					'priority'	 => 15
				)
			)
		);

	// Promo 3 URL
	$wp_customize->add_setting(
        'primadonna_promo3_url_setting',
	    array ( 
	    'default' => '',
	    'sanitize_callback' => 'esc_url_raw',
	));

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'promo3_url_control',
				array(
					'label'      => 'Promo Box #3 URL',
					'section'    => 'primadonna_promo_section',
					'settings'   => 'primadonna_promo3_url_setting',
					'type'		 => 'text',
					'priority'	 => 16
				)
			)
		);

	// Promo Box 4 title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'featured_promo4_title', array(
        'label' => __('Promo Boxes 4 Settings', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_promo_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 17
        ) )
	);

	//Promo 4 Title
	$wp_customize->add_setting(
        'primadonna_promo4_title_setting',
        array(
            'default'     => '',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
    );

    $wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'promo4_title_control',
				array(
					'label'      => 'Promo Box #4 Title',
					'section'    => 'primadonna_promo_section',
					'settings'   => 'primadonna_promo4_title_setting',
					'type'		 => 'text',
					'priority'	 => 18
				)
			)
		);

    // Promo 4 Image
	$wp_customize->add_setting(
        'primadonna_promo4_image_setting',
	    array ( 
	    'default' => '',
	    'sanitize_callback' => 'esc_url_raw',
	));

	$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				'promo4_image_control',
				array(
					'label'      => 'Promo Box #4 Image',
					'section'    => 'primadonna_promo_section',
					'settings'   => 'primadonna_promo4_image_setting',
					'priority'	 => 19
				)
			)
		);

	// Promo 4 URL
	$wp_customize->add_setting(
        'primadonna_promo4_url_setting',
	    array ( 
	    'default' => '',
	    'sanitize_callback' => 'esc_url_raw',
	));

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'promo4_url_control',
				array(
					'label'      => 'Promo Box #4 URL',
					'section'    => 'primadonna_promo_section',
					'settings'   => 'primadonna_promo4_url_setting',
					'type'		 => 'text',
					'priority'	 => 20
				)
			)
		);

//__Single Posts Panel__//

$wp_customize->add_panel( 'posts_page', array(
  'title' => __( 'Post Settings', 'primadonna' ),
  'description' => __( '', 'primadonna' ), // Include html tags such as <p>.
  'priority' => 28, // Mixed with top-level-section hierarchy.
) );


	//___Featured Image Settings___//
    //* Add blog post setting to the Customizer
    $wp_customize->add_section( 'primadonna_posts_section', array(
        'title'    => __( 'Featured Image', 'primadonna' ),
        'panel' => 'posts_page',
        'description' => __( '', 'primadonna' ),
        'priority' => 1,
    ));


    // Featured title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'posts_fi_title', array(
        'label' => __('Featured Image Settings', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_posts_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 1
        ) )
	);

    //* Featured image Position
    $wp_customize->add_setting( 'primadonna_fi_setting', array(
        'default'           => 'true',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'primadonna_sanitize_text',
    ));

    $wp_customize->add_control( new WP_Customize_Control( 
        $wp_customize, 'primadonna_fi_control', array(
			'label'       => __( 'Featured Image Position', 'primadonna' ),
			'description' => __( 'Show Featured Image above or below post title. Default setting is below', 'primadonna' ),
			'section'     => 'primadonna_posts_section',
			'settings'    => 'primadonna_fi_setting',
			'type'        => 'select',
			'priority'	 => 2,
			'choices'     => array(                    
				'false'   => __( 'Above Title', 'primadonna' ),
				'true'    => __( 'Below Title', 'primadonna' ),
			),
        ))
	);

	//* Hide Featured Images in Single Post
    $wp_customize->add_setting( 'primadonna_hide_fi_setting', array(
        'default'           => 'false',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'primadonna_sanitize_text',
    ));

    $wp_customize->add_control( new WP_Customize_Control( 
        $wp_customize, 'primadonna_hide_fi_control', array(
			'label'       => __( 'Hide Featured Image in Posts', 'primadonna' ),
			'description' => __( 'Show or Hide Featured Images at top of Single Post pages', 'primadonna' ),
			'section'     => 'primadonna_posts_section',
			'settings'    => 'primadonna_hide_fi_setting',
			'type'        => 'select',
			'priority'	 => 3,
			'choices'     => array(                    
				'false'   => __( 'Show Featured Image', 'primadonna' ),
				'true'    => __( 'Hide Featured Image', 'primadonna' ),
			),
        ))
	);

	//___Post Sidebar Settings___//
    $wp_customize->add_section( 'primadonna_posts_sidebar_section', array(
        'title'    => __( 'Sidebar Settings', 'primadonna' ),
        'panel' => 'posts_page',
        'description' => __( '', 'primadonna' ),
        'priority' => 2,
    ));

	// Single Post Sidebar title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'posts_sidebar_title', array(
        'label' => __('Show or Hide Posts Sidebar', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_posts_sidebar_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 1
        ) )
	);

	//* Add option to hide sidebar on blog pposts
    $wp_customize->add_setting( 'primadonna_post_sidebar_setting', array(
        'default'           => 'false',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'primadonna_sanitize_text',
    ));

    $wp_customize->add_control( new WP_Customize_Control( 
        $wp_customize, 'primadonna_post_sidebar_control', array(
			'label'       => __( '', 'primadonna' ),
			'description' => __( 'Show or Hide the sidebar on ALL posts. Show or hide sidebar can be done individually in the post editor for each post. This setting will override all individual post settings and hide ALL post sidebars.', 'primadonna' ),
			'section'     => 'primadonna_posts_sidebar_section',
			'settings'    => 'primadonna_post_sidebar_setting',
			'type'        => 'select',
			'priority'	 => 2,
			'choices'     => array(                    
				'false'   => __( 'Display post sidebar', 'primadonna' ),
				'true'    => __( 'Hide post sidebar', 'primadonna' ),
			),
        ))
	);

	//___Post Text Settings___//
    $wp_customize->add_section( 'primadonna_posts_text_section', array(
        'title'    => __( 'Post Text Settings', 'primadonna' ),
        'panel' => 'posts_page',
        'description' => __( '', 'primadonna' ),
        'priority' => 3,
    ));

	// Pager Text title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'posts_pager_title', array(
        'label' => __('Next & Previous Posts Text', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_posts__text_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 1
        ) )
	);

	// Previous Article Text
    $wp_customize->add_setting(
        'primadonna_previous_setting',
        array(
        'default'           => 'previous article',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'primadonna_sanitize_text',
        )
    );

    $wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'primadonna_previous_control',
				array(
					'label'      => 'Previous Article Text',
					'section'    => 'primadonna_posts_text_section',
					'settings'   => 'primadonna_previous_setting',
					'type'		 => 'text',
					'priority'	 => 2
				)
			)
		);

    // Next Article Text
    $wp_customize->add_setting(
        'primadonna_next_setting',
        array(
        'default'           => 'next article',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'primadonna_sanitize_text',
        )
    );

    $wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'primadonna_next_control',
				array(
					'label'      => 'Next Article Text',
					'section'    => 'primadonna_posts_text_section',
					'settings'   => 'primadonna_next_setting',
					'type'		 => 'text',
					'priority'	 => 3
				)
			)
		);

   //___Post Show & Hide Elements___//
    $wp_customize->add_section( 'primadonna_posts_hide_section', array(
        'title'    => __( 'Post Hide Elements', 'primadonna' ),
        'panel' => 'posts_page',
        'description' => __( '', 'primadonna' ),
        'priority' => 4,
    ));

    // Hide elements
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'posts_hide_title', array(
        'label' => __('Hide Elements on Posts', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_posts_hide_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 1
        ) )
	);

	//* Add option to hide Category on Posts
    $wp_customize->add_setting( 'primadonna_post_category_setting', array(
        'default'           => 'false',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'primadonna_sanitize_text',
    ));

    $wp_customize->add_control( new WP_Customize_Control( 
        $wp_customize, 'primadonna_post_category_control', array(
			'label'       => __( 'Categories', 'primadonna' ),
			'description' => __( '', 'primadonna' ),
			'section'     => 'primadonna_posts_hide_section',
			'settings'    => 'primadonna_post_category_setting',
			'type'        => 'radio',
			'priority'	 => 2,
			'choices'     => array(                    
				'false'   => __( 'Show', 'primadonna' ),
				'true'    => __( 'Hide', 'primadonna' ),
			),
        ))
	);

	//* Add option to hide Date on Posts
    $wp_customize->add_setting( 'primadonna_post_date_setting', array(
        'default'           => 'false',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'primadonna_sanitize_text',
    ));

    $wp_customize->add_control( new WP_Customize_Control( 
        $wp_customize, 'primadonna_post_date_control', array(
			'label'       => __( 'Date', 'primadonna' ),
			'description' => __( '', 'primadonna' ),
			'section'     => 'primadonna_posts_hide_section',
			'settings'    => 'primadonna_post_date_setting',
			'type'        => 'radio',
			'priority'	 => 3,
			'choices'     => array(                    
				'false'   => __( 'Show', 'primadonna' ),
				'true'    => __( 'Hide', 'primadonna' ),
			),
        ))
	);

	//* Add option to hide tags on Posts
    $wp_customize->add_setting( 'primadonna_post_tags_setting', array(
        'default'           => 'false',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'primadonna_sanitize_text',
    ));

    $wp_customize->add_control( new WP_Customize_Control( 
        $wp_customize, 'primadonna_post_tags_control', array(
			'label'       => __( 'Tags', 'primadonna' ),
			'description' => __( '', 'primadonna' ),
			'section'     => 'primadonna_posts_hide_section',
			'settings'    => 'primadonna_post_tags_setting',
			'type'        => 'radio',
			'priority'	 => 4,
			'choices'     => array(                    
				'false'   => __( 'Show', 'primadonna' ),
				'true'    => __( 'Hide', 'primadonna' ),
			),
        ))
	);

	//* Add option to hide Author Link
    $wp_customize->add_setting( 'primadonna_post_author_link_setting', array(
        'default'           => 'false',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'primadonna_sanitize_text',
    ));

    $wp_customize->add_control( new WP_Customize_Control( 
        $wp_customize, 'primadonna_post_author_link_control', array(
			'label'       => __( 'Author Link', 'primadonna' ),
			'description' => __( '', 'primadonna' ),
			'section'     => 'primadonna_posts_hide_section',
			'settings'    => 'primadonna_post_author_link_setting',
			'type'        => 'radio',
			'priority'	 => 5,
			'choices'     => array(                    
				'false'   => __( 'Show', 'primadonna' ),
				'true'    => __( 'Hide', 'primadonna' ),
			),
        ))
	);

	//* Add option to hide Comment Link on Posts
    $wp_customize->add_setting( 'primadonna_post_comment_setting', array(
        'default'           => 'false',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'primadonna_sanitize_text',
    ));

    $wp_customize->add_control( new WP_Customize_Control( 
        $wp_customize, 'primadonna_post_comment_control', array(
			'label'       => __( 'Comment Link', 'primadonna' ),
			'description' => __( '', 'primadonna' ),
			'section'     => 'primadonna_posts_hide_section',
			'settings'    => 'primadonna_post_comment_setting',
			'type'        => 'radio',
			'priority'	 => 6,
			'choices'     => array(                    
				'false'   => __( 'Show', 'primadonna' ),
				'true'    => __( 'Hide', 'primadonna' ),
			),
        ))
	);

	//* Add option to hide social share on Posts
    $wp_customize->add_setting( 'primadonna_post_social_setting', array(
        'default'           => 'false',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'primadonna_sanitize_text',
    ));

    $wp_customize->add_control( new WP_Customize_Control( 
        $wp_customize, 'primadonna_post_social_control', array(
			'label'       => __( 'Social Share', 'primadonna' ),
			'description' => __( '', 'primadonna' ),
			'section'     => 'primadonna_posts_hide_section',
			'settings'    => 'primadonna_post_social_setting',
			'type'        => 'radio',
			'priority'	 => 7,
			'choices'     => array(                    
				'false'   => __( 'Show', 'primadonna' ),
				'true'    => __( 'Hide', 'primadonna' ),
			),
        ))
	);

	//* Add option to hide author profile on Posts
    $wp_customize->add_setting( 'primadonna_post_author_setting', array(
        'default'           => 'false',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'primadonna_sanitize_text',
    ));

    $wp_customize->add_control( new WP_Customize_Control( 
        $wp_customize, 'primadonna_post_author_control', array(
			'label'       => __( 'Author Profile', 'primadonna' ),
			'description' => __( '', 'primadonna' ),
			'section'     => 'primadonna_posts_hide_section',
			'settings'    => 'primadonna_post_author_setting',
			'type'        => 'radio',
			'priority'	 => 8,
			'choices'     => array(                    
				'false'   => __( 'Show', 'primadonna' ),
				'true'    => __( 'Hide', 'primadonna' ),
			),
        ))
	);

    //* Add option to hide related posts on Posts
    $wp_customize->add_setting( 'primadonna_post_related_setting', array(
        'default'           => 'false',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'primadonna_sanitize_text',
    ));

    $wp_customize->add_control( new WP_Customize_Control( 
        $wp_customize, 'primadonna_post_related_control', array(
			'label'       => __( 'Related Posts', 'primadonna' ),
			'description' => __( '', 'primadonna' ),
			'section'     => 'primadonna_posts_hide_section',
			'settings'    => 'primadonna_post_related_setting',
			'type'        => 'radio',
			'priority'	 => 9,
			'choices'     => array(                    
				'false'   => __( 'Show', 'primadonna' ),
				'true'    => __( 'Hide', 'primadonna' ),
			),
        ))
	);



	//___Archive Settings___//
    //* Add archive settings to the Customizer
    $wp_customize->add_section( 'primadonna_archive_section', array(
        'title'    => __( 'Archives Layout Settings', 'primadonna' ),
        'description' => __( '', 'primadonna' ),
        'priority' => 29,
    ));

    //Archive Layout Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'archive_layout_title', array(
        'label' => __('Archive Pages', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_archive_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 1
        ) )
	);

    //* Add archive setting to the Customizer
    $wp_customize->add_setting( 'primadonna_archive_setting', array(
        'default'           => 'full',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'primadonna_sanitize_homepage_layout',
    ));

    $wp_customize->add_control( new WP_Customize_Control( 
        $wp_customize, 'primadonna_archive_control', array(
			'label'       => __( '', 'primadonna' ),
			'description' => __( 'Choose the post layout for your Archives, Category, Tag and Search pages.', 'primadonna' ),
			'section'     => 'primadonna_archive_section',
			'settings'    => 'primadonna_archive_setting',
			'type'        => 'radio',
			'priority'	 => 2,
			'choices'     => array(                    
				'full'   => 'Full Post Layout',
				'grid'  => 'Grid Post Layout',
				'full_grid'  => '1 Full Post then Grid Layout',
				'list'  => 'List Post Layout',
				'full_list'  => '1 Full Post then List Layout',
				'masonry' => 'Masonry Post Layout',
				'full_masonry'  => '1 Full Post then Masonry Layout'
			),
        ))
	);

	//Archive Columns Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'archive_columns_title', array(
        'label' => __('Archive Columns Layout', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_archive_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 3
        ) )
	);

	//* Set column number on Archive pages
    $wp_customize->add_setting( 'primadonna_archive_column_setting', array(
        'default'           => '2col',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'primadonna_sanitize_text',
    ));

    $wp_customize->add_control( new WP_Customize_Control( 
        $wp_customize, 'primadonna_archive_column_control', array(
			'label'       => __( '', 'primadonna' ),
			'description' => __( 'Set number of columns on Archive Pages. For Masonry Layouts. Only affects main archive pages, not blog posts.', 'primadonna' ),
			'section'     => 'primadonna_archive_section',
			'settings'    => 'primadonna_archive_column_setting',
			'type'        => 'select',
			'priority'	 => 4,
			'choices'     => array(                    
				'2col'   => __( '2 columns', 'primadonna' ),
				'3col'    => __( '3 columns', 'primadonna' ),
			),
        ))
	);

	//Archive Sidebar Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',      
            'sanitize_callback' => 'primadonna_sanitize_text',      
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'archive_sidebar_title', array(
        'label' => __('Archive Sidebar Setting', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'primadonna_archive_section',
        'settings' => 'primadonna_options[info]',
        'priority' => 5
        ) )
	);

	//* Add option to hide sidebar on archive pages
    $wp_customize->add_setting( 'primadonna_archive_sidebar_setting', array(
        'default'           => 'false',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'primadonna_sanitize_text',
    ));

    $wp_customize->add_control( new WP_Customize_Control( 
        $wp_customize, 'primadonna_archive_sidebar_control', array(
			'label'       => __( '', 'primadonna' ),
			'description' => __( 'Show or Hide Archive Pages template sidebar. The sidebar will display by default. Only affects main archive pages, not blog posts.', 'primadonna' ),
			'section'     => 'primadonna_archive_section',
			'settings'    => 'primadonna_archive_sidebar_setting',
			'type'        => 'select',
			'priority'	 => 6,
			'choices'     => array(                    
				'true'   => __( 'Display archive pages sidebar', 'primadonna' ),
				'false'    => __( 'Hide archive pages sidebar', 'primadonna' ),
			),
        ))
	);

	//__WooCommerce__//

	$wp_customize->add_section( 'primadonna_new_section_woocommerce' , array(
   		'title'      => 'WooCommerce',
   		'description'=> '',
   		'priority'   => 298,
	) );

	//* Add option to hide sidebar on WooCommerce pages
    $wp_customize->add_setting( 'primadonna_woocommerce_sidebar_setting', array(
        'default'           => 'false',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'primadonna_sanitize_text',
    ));

    $wp_customize->add_control( new WP_Customize_Control( 
        $wp_customize, 'primadonna_woocommerce_sidebar_control', array(
			'label'       => __( '', 'primadonna' ),
			'description' => __( 'Show or Hide sidebar on all WooCommerce pages', 'primadonna' ),
			'section'     => 'primadonna_new_section_woocommerce',
			'settings'    => 'primadonna_woocommerce_sidebar_setting',
			'type'        => 'select',
			'priority'	 => 1,
			'choices'     => array(                    
				'true'   => __( 'Display sidebar', 'primadonna' ),
				'false'    => __( 'Hide sidebar', 'primadonna' ),
			),
        ))
	);

	//__Custom CSS__//

	$wp_customize->add_section( 'primadonna_new_section_custom_css' , array(
   		'title'      => 'Custom CSS',
   		'description'=> 'Add your custom CSS which will overwrite the theme CSS',
   		'priority'   => 299,
	) );

	//Custom CSS
	$wp_customize->add_setting(
		'primadonna_custom_css',
        array(
            'default'     => '',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
    	);

	$wp_customize->add_control(
		new Customize_CustomCss_Control(
			$wp_customize,
			'custom_css',
			array(
				'label'      => 'Custom CSS',
				'section'    => 'primadonna_new_section_custom_css',
				'settings'   => 'primadonna_custom_css',
				'type'		 => 'custom_css',
				'priority'	 => 1
			)
		)
	);

//__Colors & Fonts Panel__//

$wp_customize->add_panel( 'panel_fonts', array(
  'title' => __( 'Colors & Fonts', 'primadonna' ),
  'description' => __( '', 'primadonna' ), // Include html tags such as <p>.
  'priority' => 23, // Mixed with top-level-section hierarchy.
) );

//__Top Bar Section__//

$wp_customize->add_section('section_topbar_fonts', array(
	'title'		=> esc_html__('Top Bar', 'primadonna'),
	'priority'	=> 2,
	'panel' => 'panel_fonts',

));	

	// Bg color
	$wp_customize->add_setting(
		'topbar_bg_color',
		array(
			'default'     => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'topbar_bg_color',
			array(
				'label'      => 'Background Color',
				'section'    => 'section_topbar_fonts',
				'settings'   => 'topbar_bg_color',
				'priority'	 => 1
			)
		)
	);

	// Search Icon Font Size
    $wp_customize->add_setting(
   		'topbar_search_font_size',
        array(
            'default'     => '12',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'topbar_search_font_size',
				array(
					'label'      => 'Font Size',
					'section'    => 'section_topbar_fonts',
					'settings'   => 'topbar_search_font_size',
					'type'		 => 'number',
					'priority'	 => 2,
				)
			)
		);

	// Search icon color
	$wp_customize->add_setting(
		'topbar_search_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'topbar_search_color',
			array(
				'label'      => 'Search Icon Color',
				'section'    => 'section_topbar_fonts',
				'settings'   => 'topbar_search_color',
				'priority'	 => 3
			)
		)
	);

	// Search icon hover color
	$wp_customize->add_setting(
		'topbar_search_color_hover',
		array(
			'default'     => '#8495a6',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'topbar_search_color_hover',
			array(
				'label'      => 'Search Icon Hover',
				'section'    => 'section_topbar_fonts',
				'settings'   => 'topbar_search_color_hover',
				'priority'	 => 4
			)
		)
	);

//__Primary Menu Fonts Section__//

$wp_customize->add_section('section_primarymenu_fonts', array(
	'title'		=> esc_html__('Primary Menu', 'primadonna'),
	'priority'	=> 3,
	'panel' => 'panel_fonts',

));

	// Primary Menu Font Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'primarymenu_font_title', array(
        'label' => __('Top Links', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_primarymenu_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 1
        ) )
	);

	// Font Family
    $wp_customize->add_setting( 'primarymenu_google_font_list', array(
        'default'           => 'Montserrat',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control( new Google_Font_Dropdown_Custom_Control( $wp_customize, 'primarymenu_google_font_list', array(
        'label'      => 'Font Family',
        'section'    => 'section_primarymenu_fonts',
        'settings'   => 'primarymenu_google_font_list',
        'priority'	 => 2,
    )));

    // Font Size
    $wp_customize->add_setting(
   		'primarymenu_google_font_size',
        array(
            'default'     => '12',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'primarymenu_google_font_size',
				array(
					'label'      => 'Font Size',
					'section'    => 'section_primarymenu_fonts',
					'settings'   => 'primarymenu_google_font_size',
					'type'		 => 'number',
					'priority'	 => 3,
				)
			)
		);

    // Font weight
    $wp_customize->add_setting(
        'primarymenu_google_font_weight',
        array(
            'default' => '400',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'primarymenu_google_font_weight',
				array(
					'label' => 'Font Weight',
					'description'      => 'Some font weights will not apply to certain fonts. See https://fonts.google.com/ for more info about each font in the list.',
					'section'    => 'section_primarymenu_fonts',
					'settings'   => 'primarymenu_google_font_weight',
					'type'        => 'select',
					'priority'	 => 4,
					'choices'     => array(                    
						'100'   => __( '100', 'primadonna' ),
						'200'    => __( '200', 'primadonna' ),
						'300'    => __( '300', 'primadonna' ),
						'400'    => __( 'normal', 'primadonna' ),
						'500'    => __( '500', 'primadonna' ),
						'600'    => __( '600', 'primadonna' ),
						'700'    => __( 'bold', 'primadonna' ),
						'800'    => __( '800', 'primadonna' ),
						'900'    => __( '900', 'primadonna' ),
			),
        ))
	);

	// Letter Spacing
    $wp_customize->add_setting(
   		'primarymenu_google_font_spacing',
        array(
            'default'     => '1',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'primarymenu_google_font_spacing',
				array(
					'label'      => 'Letter Spacing',
					'section'    => 'section_primarymenu_fonts',
					'settings'   => 'primarymenu_google_font_spacing',
					'type'		 => 'number',
					'priority'	 => 5,
				)
			)
		);

	// Text transform
    $wp_customize->add_setting(
        'primarymenu_google_font_transform',
        array(
            'default' => 'uppercase',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'primarymenu_google_font_transform',
				array(
					'label' => 'Text Transform (Case)',
					'description'      => '',
					'section'    => 'section_primarymenu_fonts',
					'settings'   => 'primarymenu_google_font_transform',
					'type'        => 'select',
					'priority'	 => 6,
					'choices'     => array(                    
						'none'   => __( 'none', 'primadonna' ),
						'lowercase'    => __( 'lowercase', 'primadonna' ),
						'capitalize'    => __( 'capitalize', 'primadonna' ),
						'uppercase'    => __( 'uppercase', 'primadonna' ),
			),
        ))
	);

    // Font color
	$wp_customize->add_setting(
		'primarymenu_google_font_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'primarymenu_google_font_color',
			array(
				'label'      => 'Color',
				'section'    => 'section_primarymenu_fonts',
				'settings'   => 'primarymenu_google_font_color',
				'priority'	 => 7
			)
		)
	);

	// Font hover color
	$wp_customize->add_setting(
		'primarymenu_google_font_color_hover',
		array(
			'default'     => '#8495a6',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'primarymenu_google_font_color_hover',
			array(
				'label'      => ' Hover Color',
				'section'    => 'section_primarymenu_fonts',
				'settings'   => 'primarymenu_google_font_color_hover',
				'priority'	 => 8
			)
		)
	);

	// Primary Menu Font Title - Drop Downs
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'primarymenu_dd_font_title', array(
        'label' => __('Drop Down Links', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_primarymenu_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 9
        ) )
	);

	// Font Family
    $wp_customize->add_setting( 'primarymenu_dd_google_font_list', array(
        'default'           => 'Montserrat',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control( new Google_Font_Dropdown_Custom_Control( $wp_customize, 'primarymenu_dd_google_font_list', array(
        'label'      => 'Font Family',
        'section'    => 'section_primarymenu_fonts',
        'settings'   => 'primarymenu_dd_google_font_list',
        'priority'	 => 10,
    )));

    // Font Size
    $wp_customize->add_setting(
   		'primarymenu_dd_google_font_size',
        array(
            'default'     => '10',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'primarymenu_dd_google_font_size',
				array(
					'label'      => 'Font Size',
					'section'    => 'section_primarymenu_fonts',
					'settings'   => 'primarymenu_dd_google_font_size',
					'type'		 => 'number',
					'priority'	 => 11,
				)
			)
		);

    // Font weight
    $wp_customize->add_setting(
        'primarymenu_dd_google_font_weight',
        array(
            'default' => '400',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'primarymenu_dd_google_font_weight',
				array(
					'label' => 'Font Weight',
					'description'      => 'Some font weights will not apply to certain fonts. See https://fonts.google.com/ for more info about each font in the list.',
					'section'    => 'section_primarymenu_fonts',
					'settings'   => 'primarymenu_dd_google_font_weight',
					'type'        => 'select',
					'priority'	 => 12,
					'choices'     => array(                    
						'100'   => __( '100', 'primadonna' ),
						'200'    => __( '200', 'primadonna' ),
						'300'    => __( '300', 'primadonna' ),
						'400'    => __( 'normal', 'primadonna' ),
						'500'    => __( '500', 'primadonna' ),
						'600'    => __( '600', 'primadonna' ),
						'700'    => __( 'bold', 'primadonna' ),
						'800'    => __( '800', 'primadonna' ),
						'900'    => __( '900', 'primadonna' ),
			),
        ))
	);

	// Letter Spacing
    $wp_customize->add_setting(
   		'primarymenu_dd_google_font_spacing',
        array(
            'default'     => '1',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'primarymenu_dd_google_font_spacing',
				array(
					'label'      => 'Letter Spacing',
					'section'    => 'section_primarymenu_fonts',
					'settings'   => 'primarymenu_dd_google_font_spacing',
					'type'		 => 'number',
					'priority'	 => 13,
				)
			)
		);

	// Text transform
    $wp_customize->add_setting(
        'primarymenu_dd_google_font_transform',
        array(
            'default' => 'uppercase',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'primarymenu_dd_google_font_transform',
				array(
					'label' => 'Text Transform (Case)',
					'description'      => '',
					'section'    => 'section_primarymenu_fonts',
					'settings'   => 'primarymenu_dd_google_font_transform',
					'type'        => 'select',
					'priority'	 => 14,
					'choices'     => array(                    
						'none'   => __( 'none', 'primadonna' ),
						'lowercase'    => __( 'lowercase', 'primadonna' ),
						'capitalize'    => __( 'capitalize', 'primadonna' ),
						'uppercase'    => __( 'uppercase', 'primadonna' ),
			),
        ))
	);

	// Bg color
	$wp_customize->add_setting(
		'primarymenu_dd_bg_google_font_color',
		array(
			'default'     => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'primarymenu_dd_bg_google_font_color',
			array(
				'label'      => 'Background Color',
				'section'    => 'section_primarymenu_fonts',
				'settings'   => 'primarymenu_dd_bg_google_font_color',
				'priority'	 => 15
			)
		)
	);

    // Font color
	$wp_customize->add_setting(
		'primarymenu_dd_google_font_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'primarymenu_dd_google_font_color',
			array(
				'label'      => 'Color',
				'section'    => 'section_primarymenu_fonts',
				'settings'   => 'primarymenu_dd_google_font_color',
				'priority'	 => 16
			)
		)
	);

	// Font hover color
	$wp_customize->add_setting(
		'primarymenu_dd_google_font_color_hover',
		array(
			'default'     => '#8495a6',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'primarymenu_dd_google_font_color_hover',
			array(
				'label'      => 'Hover Color',
				'section'    => 'section_primarymenu_fonts',
				'settings'   => 'primarymenu_dd_google_font_color_hover',
				'priority'	 => 17
			)
		)
	);

//__Site Title & Description Fonts Section__//

$wp_customize->add_section('section_sitetitle_fonts', array(
	'title'		=> esc_html__('Site Title & Description', 'primadonna'),
	'priority'	=> 4,
	'panel' => 'panel_fonts',

));

	// Site title Font Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'sitetitle_font_title', array(
        'label' => __('Site Title', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_sitetitle_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 1
        ) )
	);

	// Font Family
    $wp_customize->add_setting( 'sitetitle_google_font_list', array(
        'default'           => 'Montserrat',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control( new Google_Font_Dropdown_Custom_Control( $wp_customize, 'sitetitle_google_font_list', array(
        'label'      => 'Font Family',
        'section'    => 'section_sitetitle_fonts',
        'settings'   => 'sitetitle_google_font_list',
        'priority'	 => 2,
    )));

    // Font Size
    $wp_customize->add_setting(
   		'sitetitle_google_font_size',
        array(
            'default'     => '70',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'sitetitle_google_font_size',
				array(
					'label'      => 'Font Size',
					'section'    => 'section_sitetitle_fonts',
					'settings'   => 'sitetitle_google_font_size',
					'type'		 => 'number',
					'priority'	 => 3,
				)
			)
		);

    // Font weight
    $wp_customize->add_setting(
        'sitetitle_google_font_weight',
        array(
            'default' => '700',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'sitetitle_google_font_weight',
				array(
					'label' => 'Font Weight',
					'description'      => 'Some font weights will not apply to certain fonts. See https://fonts.google.com/ for more info about each font in the list.',
					'section'    => 'section_sitetitle_fonts',
					'settings'   => 'sitetitle_google_font_weight',
					'type'        => 'select',
					'priority'	 => 4,
					'choices'     => array(                    
						'100'   => __( '100', 'primadonna' ),
						'200'    => __( '200', 'primadonna' ),
						'300'    => __( '300', 'primadonna' ),
						'400'    => __( 'normal', 'primadonna' ),
						'500'    => __( '500', 'primadonna' ),
						'600'    => __( '600', 'primadonna' ),
						'700'    => __( 'bold', 'primadonna' ),
						'800'    => __( '800', 'primadonna' ),
						'900'    => __( '900', 'primadonna' ),
			),
        ))
	);

	// Letter Spacing
    $wp_customize->add_setting(
   		'sitetitle_google_font_spacing',
        array(
            'default'     => '2',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'sitetitle_google_font_spacing',
				array(
					'label'      => 'Letter Spacing',
					'section'    => 'section_sitetitle_fonts',
					'settings'   => 'sitetitle_google_font_spacing',
					'type'		 => 'number',
					'priority'	 => 5,
				)
			)
		);

	// Text transform
    $wp_customize->add_setting(
        'sitetitle_google_font_transform',
        array(
            'default' => 'capitalize',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'sitetitle_google_font_transform',
				array(
					'label' => 'Text Transform (Case)',
					'description'      => '',
					'section'    => 'section_sitetitle_fonts',
					'settings'   => 'sitetitle_google_font_transform',
					'type'        => 'select',
					'priority'	 => 6,
					'choices'     => array(                    
						'none'   => __( 'none', 'primadonna' ),
						'lowercase'    => __( 'lowercase', 'primadonna' ),
						'capitalize'    => __( 'capitalize', 'primadonna' ),
						'uppercase'    => __( 'uppercase', 'primadonna' ),
			),
        ))
	);

	// Text align
    $wp_customize->add_setting(
        'sitetitle_google_font_align',
        array(
            'default' => 'center',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'sitetitle_google_font_align',
				array(
					'label' => 'Text Align',
					'description'      => '',
					'section'    => 'section_sitetitle_fonts',
					'settings'   => 'sitetitle_google_font_align',
					'type'        => 'select',
					'priority'	 => 7,
					'choices'     => array(                    
						'left'   => __( 'left', 'primadonna' ),
						'center'    => __( 'center', 'primadonna' ),
						'right'    => __( 'right', 'primadonna' ),
			),
        ))
	);

    // Font color
	$wp_customize->add_setting(
		'sitetitle_google_font_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'sitetitle_google_font_color',
			array(
				'label'      => 'Color',
				'section'    => 'section_sitetitle_fonts',
				'settings'   => 'sitetitle_google_font_color',
				'priority'	 => 8
			)
		)
	);

	// Font hover color
	$wp_customize->add_setting(
		'sitetitle_google_font_color_hover',
		array(
			'default'     => '#8495a6',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'sitetitle_google_font_color_hover',
			array(
				'label'      => ' Hover Color',
				'section'    => 'section_sitetitle_fonts',
				'settings'   => 'sitetitle_google_font_color_hover',
				'priority'	 => 9
			)
		)
	);

	// Site description Font Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'sitedesc_font_title', array(
        'label' => __('Site Description (Tagline)', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_sitetitle_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 10
        ) )
	);

	// Font Family
    $wp_customize->add_setting( 'sitedesc_google_font_list', array(
        'default'           => 'Open Sans',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control( new Google_Font_Dropdown_Custom_Control( $wp_customize, 'sitedesc_google_font_list', array(
        'label'      => 'Font Family',
        'section'    => 'section_sitetitle_fonts',
        'settings'   => 'sitedesc_google_font_list',
        'priority'	 => 11,
    )));

    // Font Size
    $wp_customize->add_setting(
   		'sitedesc_google_font_size',
        array(
            'default'     => '14',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'sitedesc_google_font_size',
				array(
					'label'      => 'Font Size',
					'section'    => 'section_sitetitle_fonts',
					'settings'   => 'sitedesc_google_font_size',
					'type'		 => 'number',
					'priority'	 => 12,
				)
			)
		);

    // Font weight
    $wp_customize->add_setting(
        'sitedesc_google_font_weight',
        array(
            'default' => '400',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'sitedesc_google_font_weight',
				array(
					'label' => 'Font Weight',
					'description'      => 'Some font weights will not apply to certain fonts. See https://fonts.google.com/ for more info about each font in the list.',
					'section'    => 'section_sitetitle_fonts',
					'settings'   => 'sitedesc_google_font_weight',
					'type'        => 'select',
					'priority'	 => 13,
					'choices'     => array(                    
						'100'   => __( '100', 'primadonna' ),
						'200'    => __( '200', 'primadonna' ),
						'300'    => __( '300', 'primadonna' ),
						'400'    => __( 'normal', 'primadonna' ),
						'500'    => __( '500', 'primadonna' ),
						'600'    => __( '600', 'primadonna' ),
						'700'    => __( 'bold', 'primadonna' ),
						'800'    => __( '800', 'primadonna' ),
						'900'    => __( '900', 'primadonna' ),
			),
        ))
	);

	// Letter Spacing
    $wp_customize->add_setting(
   		'sitedesc_google_font_spacing',
        array(
            'default'     => '2',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'sitedesc_google_font_spacing',
				array(
					'label'      => 'Letter Spacing',
					'section'    => 'section_sitetitle_fonts',
					'settings'   => 'sitedesc_google_font_spacing',
					'type'		 => 'number',
					'priority'	 => 14,
				)
			)
		);

	// Text transform
    $wp_customize->add_setting(
        'sitedesc_google_font_transform',
        array(
            'default' => 'uppercase',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'sitedesc_google_font_transform',
				array(
					'label' => 'Text Transform (Case)',
					'description'      => '',
					'section'    => 'section_sitetitle_fonts',
					'settings'   => 'sitedesc_google_font_transform',
					'type'        => 'select',
					'priority'	 => 15,
					'choices'     => array(                    
						'none'   => __( 'none', 'primadonna' ),
						'lowercase'    => __( 'lowercase', 'primadonna' ),
						'capitalize'    => __( 'capitalize', 'primadonna' ),
						'uppercase'    => __( 'uppercase', 'primadonna' ),
			),
        ))
	);

	// Text align
    $wp_customize->add_setting(
        'sitedesc_google_font_align',
        array(
            'default' => 'center',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'sitedesc_google_font_align',
				array(
					'label' => 'Text Align',
					'description'      => '',
					'section'    => 'section_sitetitle_fonts',
					'settings'   => 'sitedesc_google_font_align',
					'type'        => 'select',
					'priority'	 => 16,
					'choices'     => array(                    
						'left'   => __( 'left', 'primadonna' ),
						'center'    => __( 'center', 'primadonna' ),
						'right'    => __( 'right', 'primadonna' ),
			),
        ))
	);

    // Font color
	$wp_customize->add_setting(
		'sitedesc_google_font_color',
		array(
			'default'     => '#888888',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'sitedesc_google_font_color',
			array(
				'label'      => 'Color',
				'section'    => 'section_sitetitle_fonts',
				'settings'   => 'sitedesc_google_font_color',
				'priority'	 => 17
			)
		)
	);

//__Header Right Menu Fonts Section__//

$wp_customize->add_section('section_headermenu_fonts', array(
	'title'		=> esc_html__('Header Right Menu', 'primadonna'),
	'priority'	=> 5,
	'panel' => 'panel_fonts',

));

	// Header Menu Font Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'headermenu_font_title', array(
        'label' => __('Top Links', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_headermenu_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 1
        ) )
	);

	// Font Family
    $wp_customize->add_setting( 'headermenu_google_font_list', array(
        'default'           => 'Montserrat',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control( new Google_Font_Dropdown_Custom_Control( $wp_customize, 'headermenu_google_font_list', array(
        'label'      => 'Font Family',
        'section'    => 'section_headermenu_fonts',
        'settings'   => 'headermenu_google_font_list',
        'priority'	 => 2,
    )));

    // Font Size
    $wp_customize->add_setting(
   		'headermenu_google_font_size',
        array(
            'default'     => '12',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'headermenu_google_font_size',
				array(
					'label'      => 'Font Size',
					'section'    => 'section_headermenu_fonts',
					'settings'   => 'headermenu_google_font_size',
					'type'		 => 'number',
					'priority'	 => 3,
				)
			)
		);

    // Font weight
    $wp_customize->add_setting(
        'headermenu_google_font_weight',
        array(
            'default' => '400',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'headermenu_google_font_weight',
				array(
					'label' => 'Font Weight',
					'description'      => 'Some font weights will not apply to certain fonts. See https://fonts.google.com/ for more info about each font in the list.',
					'section'    => 'section_headermenu_fonts',
					'settings'   => 'headermenu_google_font_weight',
					'type'        => 'select',
					'priority'	 => 4,
					'choices'     => array(                    
						'100'   => __( '100', 'primadonna' ),
						'200'    => __( '200', 'primadonna' ),
						'300'    => __( '300', 'primadonna' ),
						'400'    => __( 'normal', 'primadonna' ),
						'500'    => __( '500', 'primadonna' ),
						'600'    => __( '600', 'primadonna' ),
						'700'    => __( 'bold', 'primadonna' ),
						'800'    => __( '800', 'primadonna' ),
						'900'    => __( '900', 'primadonna' ),
			),
        ))
	);

	// Letter Spacing
    $wp_customize->add_setting(
   		'headermenu_google_font_spacing',
        array(
            'default'     => '1',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'headermenu_google_font_spacing',
				array(
					'label'      => 'Letter Spacing',
					'section'    => 'section_headermenu_fonts',
					'settings'   => 'headermenu_google_font_spacing',
					'type'		 => 'number',
					'priority'	 => 5,
				)
			)
		);

	// Text transform
    $wp_customize->add_setting(
        'headermenu_google_font_transform',
        array(
            'default' => 'uppercase',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'headermenu_google_font_transform',
				array(
					'label' => 'Text Transform (Case)',
					'description'      => '',
					'section'    => 'section_headermenu_fonts',
					'settings'   => 'headermenu_google_font_transform',
					'type'        => 'select',
					'priority'	 => 6,
					'choices'     => array(                    
						'none'   => __( 'none', 'primadonna' ),
						'lowercase'    => __( 'lowercase', 'primadonna' ),
						'capitalize'    => __( 'capitalize', 'primadonna' ),
						'uppercase'    => __( 'uppercase', 'primadonna' ),
			),
        ))
	);

    // Font color
	$wp_customize->add_setting(
		'headermenu_google_font_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'headermenu_google_font_color',
			array(
				'label'      => 'Color',
				'section'    => 'section_headermenu_fonts',
				'settings'   => 'headermenu_google_font_color',
				'priority'	 => 7
			)
		)
	);

	// Font hover color
	$wp_customize->add_setting(
		'headermenu_google_font_color_hover',
		array(
			'default'     => '#8495a6',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'headermenu_google_font_color_hover',
			array(
				'label'      => ' Hover Color',
				'section'    => 'section_headermenu_fonts',
				'settings'   => 'headermenu_google_font_color_hover',
				'priority'	 => 8
			)
		)
	);

	// Header Right Menu Font Title - Drop Downs
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'headermenu_dd_font_title', array(
        'label' => __('Drop Down Links', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_headermenu_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 9
        ) )
	);

	// Font Family
    $wp_customize->add_setting( 'headermenu_dd_google_font_list', array(
        'default'           => 'Montserrat',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control( new Google_Font_Dropdown_Custom_Control( $wp_customize, 'headermenu_dd_google_font_list', array(
        'label'      => 'Font Family',
        'section'    => 'section_headermenu_fonts',
        'settings'   => 'headermenu_dd_google_font_list',
        'priority'	 => 10,
    )));

    // Font Size
    $wp_customize->add_setting(
   		'headermenu_dd_google_font_size',
        array(
            'default'     => '10',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'headermenu_dd_google_font_size',
				array(
					'label'      => 'Font Size',
					'section'    => 'section_headermenu_fonts',
					'settings'   => 'headermenu_dd_google_font_size',
					'type'		 => 'number',
					'priority'	 => 11,
				)
			)
		);

    // Font weight
    $wp_customize->add_setting(
        'headermenu_dd_google_font_weight',
        array(
            'default' => '400',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'headermenu_dd_google_font_weight',
				array(
					'label' => 'Font Weight',
					'description'      => 'Some font weights will not apply to certain fonts. See https://fonts.google.com/ for more info about each font in the list.',
					'section'    => 'section_headermenu_fonts',
					'settings'   => 'headermenu_dd_google_font_weight',
					'type'        => 'select',
					'priority'	 => 12,
					'choices'     => array(                    
						'100'   => __( '100', 'primadonna' ),
						'200'    => __( '200', 'primadonna' ),
						'300'    => __( '300', 'primadonna' ),
						'400'    => __( 'normal', 'primadonna' ),
						'500'    => __( '500', 'primadonna' ),
						'600'    => __( '600', 'primadonna' ),
						'700'    => __( 'bold', 'primadonna' ),
						'800'    => __( '800', 'primadonna' ),
						'900'    => __( '900', 'primadonna' ),
			),
        ))
	);

	// Letter Spacing
    $wp_customize->add_setting(
   		'headermenu_dd_google_font_spacing',
        array(
            'default'     => '1',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'headermenu_dd_google_font_spacing',
				array(
					'label'      => 'Letter Spacing',
					'section'    => 'section_headermenu_fonts',
					'settings'   => 'headermenu_dd_google_font_spacing',
					'type'		 => 'number',
					'priority'	 => 13,
				)
			)
		);

	// Text transform
    $wp_customize->add_setting(
        'headermenu_dd_google_font_transform',
        array(
            'default' => 'uppercase',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'headermenu_dd_google_font_transform',
				array(
					'label' => 'Text Transform (Case)',
					'description'      => '',
					'section'    => 'section_headermenu_fonts',
					'settings'   => 'headermenu_dd_google_font_transform',
					'type'        => 'select',
					'priority'	 => 14,
					'choices'     => array(                    
						'none'   => __( 'none', 'primadonna' ),
						'lowercase'    => __( 'lowercase', 'primadonna' ),
						'capitalize'    => __( 'capitalize', 'primadonna' ),
						'uppercase'    => __( 'uppercase', 'primadonna' ),
			),
        ))
	);

	// Bg color
	$wp_customize->add_setting(
		'headermenu_dd_bg_google_font_color',
		array(
			'default'     => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'headermenu_dd_bg_google_font_color',
			array(
				'label'      => 'Background Color',
				'section'    => 'section_headermenu_fonts',
				'settings'   => 'headermenu_dd_bg_google_font_color',
				'priority'	 => 15
			)
		)
	);

    // Font color
	$wp_customize->add_setting(
		'headermenu_dd_google_font_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'headermenu_dd_google_font_color',
			array(
				'label'      => 'Color',
				'section'    => 'section_headermenu_fonts',
				'settings'   => 'headermenu_dd_google_font_color',
				'priority'	 => 16
			)
		)
	);

	// Font hover color
	$wp_customize->add_setting(
		'headermenu_dd_google_font_color_hover',
		array(
			'default'     => '#8495a6',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'headermenu_dd_google_font_color_hover',
			array(
				'label'      => 'Hover Color',
				'section'    => 'section_headermenu_fonts',
				'settings'   => 'headermenu_dd_google_font_color_hover',
				'priority'	 => 17
			)
		)
	);

//__Secondary Menu Fonts Section__//

$wp_customize->add_section('section_secmenu_fonts', array(
	'title'		=> esc_html__('Secondary Menu', 'primadonna'),
	'priority'	=> 6,
	'panel' => 'panel_fonts',

));

	// Background color
	$wp_customize->add_setting(
		'secmenu_bg_color',
		array(
			'default'     => 'transparent',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'secmenu_bg_color',
			array(
				'label'      => ' Background Color',
				'section'    => 'section_secmenu_fonts',
				'settings'   => 'secmenu_bg_color',
				'priority'	 => 1
			)
		)
	);

	// Border color
	$wp_customize->add_setting(
		'secmenu_border_color',
		array(
			'default'     => '#eeeeee',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'secmenu_border_color',
			array(
				'label'      => ' Border Color',
				'section'    => 'section_secmenu_fonts',
				'settings'   => 'secmenu_border_color',
				'priority'	 => 2
			)
		)
	);

	// Secondary Menu Font Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'secmenu_font_title', array(
        'label' => __('Top Links', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_secmenu_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 3
        ) )
	);

	// Font Family
    $wp_customize->add_setting( 'secmenu_google_font_list', array(
        'default'           => 'Montserrat',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control( new Google_Font_Dropdown_Custom_Control( $wp_customize, 'secmenu_google_font_list', array(
        'label'      => 'Font Family',
        'section'    => 'section_secmenu_fonts',
        'settings'   => 'secmenu_google_font_list',
        'priority'	 => 4,
    )));

    // Font Size
    $wp_customize->add_setting(
   		'secmenu_google_font_size',
        array(
            'default'     => '12',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'secmenu_google_font_size',
				array(
					'label'      => 'Font Size',
					'section'    => 'section_secmenu_fonts',
					'settings'   => 'secmenu_google_font_size',
					'type'		 => 'number',
					'priority'	 => 5,
				)
			)
		);

    // Font weight
    $wp_customize->add_setting(
        'secmenu_google_font_weight',
        array(
            'default' => '400',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'secmenu_google_font_weight',
				array(
					'label' => 'Font Weight',
					'description'      => 'Some font weights will not apply to certain fonts. See https://fonts.google.com/ for more info about each font in the list.',
					'section'    => 'section_secmenu_fonts',
					'settings'   => 'secmenu_google_font_weight',
					'type'        => 'select',
					'priority'	 => 5,
					'choices'     => array(                    
						'100'   => __( '100', 'primadonna' ),
						'200'    => __( '200', 'primadonna' ),
						'300'    => __( '300', 'primadonna' ),
						'400'    => __( 'normal', 'primadonna' ),
						'500'    => __( '500', 'primadonna' ),
						'600'    => __( '600', 'primadonna' ),
						'700'    => __( 'bold', 'primadonna' ),
						'800'    => __( '800', 'primadonna' ),
						'900'    => __( '900', 'primadonna' ),
			),
        ))
	);

	// Letter Spacing
    $wp_customize->add_setting(
   		'secmenu_google_font_spacing',
        array(
            'default'     => '1',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'secmenu_google_font_spacing',
				array(
					'label'      => 'Letter Spacing',
					'section'    => 'section_secmenu_fonts',
					'settings'   => 'secmenu_google_font_spacing',
					'type'		 => 'number',
					'priority'	 => 7,
				)
			)
		);

	// Text transform
    $wp_customize->add_setting(
        'secmenu_google_font_transform',
        array(
            'default' => 'uppercase',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'secmenu_google_font_transform',
				array(
					'label' => 'Text Transform (Case)',
					'description'      => '',
					'section'    => 'section_secmenu_fonts',
					'settings'   => 'secmenu_google_font_transform',
					'type'        => 'select',
					'priority'	 => 8,
					'choices'     => array(                    
						'none'   => __( 'none', 'primadonna' ),
						'lowercase'    => __( 'lowercase', 'primadonna' ),
						'capitalize'    => __( 'capitalize', 'primadonna' ),
						'uppercase'    => __( 'uppercase', 'primadonna' ),
			),
        ))
	);

    // Font color
	$wp_customize->add_setting(
		'secmenu_google_font_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'secmenu_google_font_color',
			array(
				'label'      => 'Color',
				'section'    => 'section_secmenu_fonts',
				'settings'   => 'secmenu_google_font_color',
				'priority'	 => 9
			)
		)
	);

	// Font hover color
	$wp_customize->add_setting(
		'secmenu_google_font_color_hover',
		array(
			'default'     => '#8495a6',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'secmenu_google_font_color_hover',
			array(
				'label'      => ' Hover Color',
				'section'    => 'section_secmenu_fonts',
				'settings'   => 'secmenu_google_font_color_hover',
				'priority'	 => 10
			)
		)
	);

	// Secondary Menu Font Title - Drop Downs
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'secmenu_dd_font_title', array(
        'label' => __('Drop Down Links', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_secmenu_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 11
        ) )
	);

	// Font Family
    $wp_customize->add_setting( 'secmenu_dd_google_font_list', array(
        'default'           => 'Montserrat',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control( new Google_Font_Dropdown_Custom_Control( $wp_customize, 'secmenu_dd_google_font_list', array(
        'label'      => 'Font Family',
        'section'    => 'section_secmenu_fonts',
        'settings'   => 'secmenu_dd_google_font_list',
        'priority'	 => 12,
    )));

    // Font Size
    $wp_customize->add_setting(
   		'secmenu_dd_google_font_size',
        array(
            'default'     => '10',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'secmenu_dd_google_font_size',
				array(
					'label'      => 'Font Size',
					'section'    => 'section_secmenu_fonts',
					'settings'   => 'secmenu_dd_google_font_size',
					'type'		 => 'number',
					'priority'	 => 13,
				)
			)
		);

    // Font weight
    $wp_customize->add_setting(
        'secmenu_dd_google_font_weight',
        array(
            'default' => '400',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'secmenu_dd_google_font_weight',
				array(
					'label' => 'Font Weight',
					'description'      => 'Some font weights will not apply to certain fonts. See https://fonts.google.com/ for more info about each font in the list.',
					'section'    => 'section_secmenu_fonts',
					'settings'   => 'secmenu_dd_google_font_weight',
					'type'        => 'select',
					'priority'	 => 14,
					'choices'     => array(                    
						'100'   => __( '100', 'primadonna' ),
						'200'    => __( '200', 'primadonna' ),
						'300'    => __( '300', 'primadonna' ),
						'400'    => __( 'normal', 'primadonna' ),
						'500'    => __( '500', 'primadonna' ),
						'600'    => __( '600', 'primadonna' ),
						'700'    => __( 'bold', 'primadonna' ),
						'800'    => __( '800', 'primadonna' ),
						'900'    => __( '900', 'primadonna' ),
			),
        ))
	);

	// Letter Spacing
    $wp_customize->add_setting(
   		'secmenu_dd_google_font_spacing',
        array(
            'default'     => '1',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'secmenu_dd_google_font_spacing',
				array(
					'label'      => 'Letter Spacing',
					'section'    => 'section_secmenu_fonts',
					'settings'   => 'secmenu_dd_google_font_spacing',
					'type'		 => 'number',
					'priority'	 => 15,
				)
			)
		);

	// Text transform
    $wp_customize->add_setting(
        'secmenu_dd_google_font_transform',
        array(
            'default' => 'uppercase',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'secmenu_dd_google_font_transform',
				array(
					'label' => 'Text Transform (Case)',
					'description'      => '',
					'section'    => 'section_secmenu_fonts',
					'settings'   => 'secmenu_dd_google_font_transform',
					'type'        => 'select',
					'priority'	 => 16,
					'choices'     => array(                    
						'none'   => __( 'none', 'primadonna' ),
						'lowercase'    => __( 'lowercase', 'primadonna' ),
						'capitalize'    => __( 'capitalize', 'primadonna' ),
						'uppercase'    => __( 'uppercase', 'primadonna' ),
			),
        ))
	);

	// Bg color
	$wp_customize->add_setting(
		'secmenu_dd_bg_google_font_color',
		array(
			'default'     => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'secmenu_dd_bg_google_font_color',
			array(
				'label'      => 'Background Color',
				'section'    => 'section_secmenu_fonts',
				'settings'   => 'secmenu_dd_bg_google_font_color',
				'priority'	 => 17
			)
		)
	);

    // Font color
	$wp_customize->add_setting(
		'secmenu_dd_google_font_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'secmenu_dd_google_font_color',
			array(
				'label'      => 'Color',
				'section'    => 'section_secmenu_fonts',
				'settings'   => 'secmenu_dd_google_font_color',
				'priority'	 => 18
			)
		)
	);

	// Font hover color
	$wp_customize->add_setting(
		'secmenu_dd_google_font_color_hover',
		array(
			'default'     => '#8495a6',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'secmenu_dd_google_font_color_hover',
			array(
				'label'      => 'Hover Color',
				'section'    => 'section_secmenu_fonts',
				'settings'   => 'secmenu_dd_google_font_color_hover',
				'priority'	 => 19
			)
		)
	);

//__Slider Fonts Section__//

$wp_customize->add_section('section_slider_fonts', array(
	'title'		=> esc_html__('Slider', 'primadonna'),
	'priority'	=> 7,
	'panel' => 'panel_fonts',

));

	// Overlay Bg

	$wp_customize->add_setting(
		'slider_overlay_bg',
		array(
			'default'     => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'slider_overlay_bg',
			array(
				'label'      => 'Overlay Background Color',
				'section'    => 'section_slider_fonts',
				'settings'   => 'slider_overlay_bg',
				'priority'	 => 1
			)
		)
	);

	// Category Color

	$wp_customize->add_setting(
		'slider_category_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'slider_category_color',
			array(
				'label'      => 'Categories Color',
				'section'    => 'section_slider_fonts',
				'settings'   => 'slider_category_color',
				'priority'	 => 2
			)
		)
	);

	// Category Hover Color

	$wp_customize->add_setting(
		'slider_category_color_hover',
		array(
			'default'     => '#8495a6',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'slider_category_color_hover',
			array(
				'label'      => 'Categories Hover Color',
				'section'    => 'section_slider_fonts',
				'settings'   => 'slider_category_color_hover',
				'priority'	 => 3
			)
		)
	);

	// Post Title Color

	$wp_customize->add_setting(
		'slider_post_title_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'slider_post_title_color',
			array(
				'label'      => 'Post Title Color',
				'section'    => 'section_slider_fonts',
				'settings'   => 'slider_post_title_color',
				'priority'	 => 4
			)
		)
	);

	// Post Title Hover Color

	$wp_customize->add_setting(
		'slider_post_title_color_hover',
		array(
			'default'     => '#8495a6',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'slider_post_title_color_hover',
			array(
				'label'      => 'Post Title Hover Color',
				'section'    => 'section_slider_fonts',
				'settings'   => 'slider_post_title_color_hover',
				'priority'	 => 5
			)
		)
	);

	// Post Excerpt Color

	$wp_customize->add_setting(
		'slider_post_excerpt_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'slider_post_excerpt_color',
			array(
				'label'      => 'Post Excerpt Color (Genesis Slider)',
				'section'    => 'section_slider_fonts',
				'settings'   => 'slider_post_excerpt_color',
				'priority'	 => 6
			)
		)
	);

//__Promo Boxes Fonts Section__//

$wp_customize->add_section('section_promo_fonts', array(
	'title'		=> esc_html__('Promo Boxes', 'primadonna'),
	'priority'	=> 8,
	'panel' => 'panel_fonts',

));

	// Overlay Bg

	$wp_customize->add_setting(
		'promo_overlay_bg',
		array(
			'default'     => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'promo_overlay_bg',
			array(
				'label'      => 'Overlay Background Color',
				'section'    => 'section_promo_fonts',
				'settings'   => 'promo_overlay_bg',
				'priority'	 => 1
			)
		)
	);

	// Overlay Color

	$wp_customize->add_setting(
		'promo_overlay_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'promo_overlay_color',
			array(
				'label'      => 'Overlay Text Color',
				'section'    => 'section_promo_fonts',
				'settings'   => 'promo_overlay_color',
				'priority'	 => 2
			)
		)
	);

	// Font Size
    $wp_customize->add_setting(
   		'promo_google_font_size',
        array(
            'default'     => '14',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'promo_google_font_size',
				array(
					'label'      => 'Font Size',
					'section'    => 'section_promo_fonts',
					'settings'   => 'promo_google_font_size',
					'type'		 => 'number',
					'priority'	 => 4,
				)
			)
		);


//__Headings Fonts Section__//

$wp_customize->add_section('section_headings_fonts', array(
	'title'		=> esc_html__('Headings', 'primadonna'),
	'priority'	=> 9,
	'panel' => 'panel_fonts',

));

	// Font Family
    $wp_customize->add_setting( 'headings_google_font_list', array(
        'default'           => 'Montserrat',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control( new Google_Font_Dropdown_Custom_Control( $wp_customize, 'headings_google_font_list', array(
        'label'      => 'Font Family',
        'section'    => 'section_headings_fonts',
        'settings'   => 'headings_google_font_list',
        'priority'	 => 1,
    )));

      // Font weight
    $wp_customize->add_setting(
        'headings_google_font_weight',
        array(
            'default' => '400',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'headings_google_font_weight',
				array(
					'label' => 'Font Weight',
					'description'      => 'Some font weights will not apply to certain fonts. See https://fonts.google.com/ for more info about each font in the list.',
					'section'    => 'section_headings_fonts',
					'settings'   => 'headings_google_font_weight',
					'type'        => 'select',
					'priority'	 => 2,
					'choices'     => array(                    
						'100'   => __( '100', 'primadonna' ),
						'200'    => __( '200', 'primadonna' ),
						'300'    => __( '300', 'primadonna' ),
						'400'    => __( 'normal', 'primadonna' ),
						'500'    => __( '500', 'primadonna' ),
						'600'    => __( '600', 'primadonna' ),
						'700'    => __( 'bold', 'primadonna' ),
						'800'    => __( '800', 'primadonna' ),
						'900'    => __( '900', 'primadonna' ),
			),
        ))
	);

	// Letter Spacing
    $wp_customize->add_setting(
   		'headings_google_font_spacing',
        array(
            'default'     => '1',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'headings_google_font_spacing',
				array(
					'label'      => 'Letter Spacing',
					'section'    => 'section_headings_fonts',
					'settings'   => 'headings_google_font_spacing',
					'type'		 => 'number',
					'priority'	 => 3,
				)
			)
		);

	// Text transform
    $wp_customize->add_setting(
        'headings_google_font_transform',
        array(
            'default' => 'uppercase',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'headings_google_font_transform',
				array(
					'label' => 'Text Transform (Case)',
					'description'      => '',
					'section'    => 'section_headings_fonts',
					'settings'   => 'headings_google_font_transform',
					'type'        => 'select',
					'priority'	 => 4,
					'choices'     => array(                    
						'none'   => __( 'none', 'primadonna' ),
						'lowercase'    => __( 'lowercase', 'primadonna' ),
						'capitalize'    => __( 'capitalize', 'primadonna' ),
						'uppercase'    => __( 'uppercase', 'primadonna' ),
			),
        ))
	);

    // Font color
	$wp_customize->add_setting(
		'headings_google_font_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'headings_google_font_color',
			array(
				'label'      => 'Color',
				'section'    => 'section_headings_fonts',
				'settings'   => 'headings_google_font_color',
				'priority'	 => 5
			)
		)
	);

	// Post Headings 
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'post_headings_font_title', array(
        'label' => __('Post Headings', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_headings_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 6
        ) )
	);

	// h1 Font Size
    $wp_customize->add_setting(
   		'h1_headings_google_font_size',
        array(
            'default'     => '26',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'h1_headings_google_font_size',
				array(
					'label'      => 'h1 Font Size',
					'section'    => 'section_headings_fonts',
					'settings'   => 'h1_headings_google_font_size',
					'type'		 => 'number',
					'priority'	 => 7,
				)
			)
		);

    // h2 Font Size
    $wp_customize->add_setting(
   		'h2_headings_google_font_size',
        array(
            'default'     => '21',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'h2_headings_google_font_size',
				array(
					'label'      => 'h2 Font Size',
					'section'    => 'section_headings_fonts',
					'settings'   => 'h2_headings_google_font_size',
					'type'		 => 'number',
					'priority'	 => 8,
				)
			)
		);

    // h3 Font Size
    $wp_customize->add_setting(
   		'h3_headings_google_font_size',
        array(
            'default'     => '18',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'h3_headings_google_font_size',
				array(
					'label'      => 'h3 Font Size',
					'section'    => 'section_headings_fonts',
					'settings'   => 'h3_headings_google_font_size',
					'type'		 => 'number',
					'priority'	 => 9,
				)
			)
		);

    // h4 Font Size
    $wp_customize->add_setting(
   		'h4_headings_google_font_size',
        array(
            'default'     => '15',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'h4_headings_google_font_size',
				array(
					'label'      => 'h4 Font Size',
					'section'    => 'section_headings_fonts',
					'settings'   => 'h4_headings_google_font_size',
					'type'		 => 'number',
					'priority'	 => 10,
				)
			)
		);

    // h5 Font Size
    $wp_customize->add_setting(
   		'h5_headings_google_font_size',
        array(
            'default'     => '13',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'h5_headings_google_font_size',
				array(
					'label'      => 'Font Size',
					'section'    => 'section_headings_fonts',
					'settings'   => 'h5_headings_google_font_size',
					'type'		 => 'number',
					'priority'	 => 11,
				)
			)
		);

    // h6 Font Size
    $wp_customize->add_setting(
   		'h6_headings_google_font_size',
        array(
            'default'     => '11',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'h6_headings_google_font_size',
				array(
					'label'      => 'h6 Font Size',
					'section'    => 'section_headings_fonts',
					'settings'   => 'h6_headings_google_font_size',
					'type'		 => 'number',
					'priority'	 => 12,
				)
			)
		);

//__Body Fonts Section__//

$wp_customize->add_section('section_general_fonts', array(
	'title'		=> esc_html__('Body', 'primadonna'),
	'priority'	=> 10,
	'panel' => 'panel_fonts',

));

	// Body Font Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'body_font_title', array(
        'label' => __('Body Font', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_general_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 1
        ) )
	);
 
	// Body Font Family
    $wp_customize->add_setting( 'body_google_font_list', array(
        'default'           => 'Open Sans',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control( new Google_Font_Dropdown_Custom_Control( $wp_customize, 'body_google_font_list', array(
        'label'      => 'Font Family',
        'section'    => 'section_general_fonts',
        'settings'   => 'body_google_font_list',
        'priority'	 => 2,
    )));

    // Body Font Size
    $wp_customize->add_setting(
   		'body_google_font_size',
        array(
            'default'     => '14',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'body_google_font_size',
				array(
					'label'      => 'Font Size',
					'section'    => 'section_general_fonts',
					'settings'   => 'body_google_font_size',
					'type'		 => 'number',
					'priority'	 => 3,
				)
			)
		);

    // Body font weight
    $wp_customize->add_setting(
        'body_google_font_weight',
        array(
            'default' => '400',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'body_google_font_weight',
				array(
					'label' => 'Font Weight',
					'description'      => 'Some font weights will not apply to certain fonts. See https://fonts.google.com/ for more info about each font in the list.',
					'section'    => 'section_general_fonts',
					'settings'   => 'body_google_font_weight',
					'type'        => 'select',
					'priority'	 => 4,
					'choices'     => array(                    
						'100'   => __( '100', 'primadonna' ),
						'200'    => __( '200', 'primadonna' ),
						'300'    => __( '300', 'primadonna' ),
						'400'    => __( 'normal', 'primadonna' ),
						'500'    => __( '500', 'primadonna' ),
						'600'    => __( '600', 'primadonna' ),
						'700'    => __( 'bold', 'primadonna' ),
						'800'    => __( '800', 'primadonna' ),
						'900'    => __( '900', 'primadonna' ),
			),
        ))
	);

	// Body Line Height
    $wp_customize->add_setting(
   		'body_google_font_lh',
        array(
            'default'     => '24',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'body_google_font_lh',
				array(
					'label'      => 'Line Height',
					'section'    => 'section_general_fonts',
					'settings'   => 'body_google_font_lh',
					'type'		 => 'number',
					'priority'	 => 5,
				)
			)
		);

    // Body font color
	$wp_customize->add_setting(
		'body_google_font_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'body_google_font_color',
			array(
				'label'      => 'Color',
				'section'    => 'section_general_fonts',
				'settings'   => 'body_google_font_color',
				'priority'	 => 6
			)
		)
	);	

//__Posts Header Fonts Section__//

$wp_customize->add_section('section_post_header_fonts', array(
	'title'		=> esc_html__('Posts: Header', 'primadonna'),
	'priority'	=> 11,
	'panel' => 'panel_fonts',

));

	// Post Titles Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'posts_title_title', array(
        'label' => __('Post Title Font', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_post_header_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 1
        ) )
	);

    // Font Size
    $wp_customize->add_setting(
   		'posttitle_google_font_size',
        array(
            'default'     => '26',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'posttitle_google_font_size',
				array(
					'label'      => 'Font Size',
					'section'    => 'section_post_header_fonts',
					'settings'   => 'posttitle_google_font_size',
					'type'		 => 'number',
					'priority'	 => 3,
				)
			)
		);

    // Font weight
    $wp_customize->add_setting(
        'posttitle_google_font_weight',
        array(
            'default' => '400',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'posttitle_google_font_weight',
				array(
					'label' => 'Font Weight',
					'description'      => 'Some font weights will not apply to certain fonts. See https://fonts.google.com/ for more info about each font in the list.',
					'section'    => 'section_post_header_fonts',
					'settings'   => 'posttitle_google_font_weight',
					'type'        => 'select',
					'priority'	 => 4,
					'choices'     => array(                    
						'100'   => __( '100', 'primadonna' ),
						'200'    => __( '200', 'primadonna' ),
						'300'    => __( '300', 'primadonna' ),
						'400'    => __( 'normal', 'primadonna' ),
						'500'    => __( '500', 'primadonna' ),
						'600'    => __( '600', 'primadonna' ),
						'700'    => __( 'bold', 'primadonna' ),
						'800'    => __( '800', 'primadonna' ),
						'900'    => __( '900', 'primadonna' ),
			),
        ))
	);

	// Letter Spacing
    $wp_customize->add_setting(
   		'posttitle_google_font_spacing',
        array(
            'default'     => '1',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'posttitle_google_font_spacing',
				array(
					'label'      => 'Letter Spacing',
					'section'    => 'section_post_header_fonts',
					'settings'   => 'posttitle_google_font_spacing',
					'type'		 => 'number',
					'priority'	 => 5,
				)
			)
		);

	// Text transform
    $wp_customize->add_setting(
        'posttitle_google_font_transform',
        array(
            'default' => 'uppercase',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'posttitle_google_font_transform',
				array(
					'label' => 'Text Transform (Case)',
					'description'      => '',
					'section'    => 'section_post_header_fonts',
					'settings'   => 'posttitle_google_font_transform',
					'type'        => 'select',
					'priority'	 => 6,
					'choices'     => array(                    
						'none'   => __( 'none', 'primadonna' ),
						'lowercase'    => __( 'lowercase', 'primadonna' ),
						'capitalize'    => __( 'capitalize', 'primadonna' ),
						'uppercase'    => __( 'uppercase', 'primadonna' ),
			),
        ))
	);

    // Font color
	$wp_customize->add_setting(
		'posttitle_google_font_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'posttitle_google_font_color',
			array(
				'label'      => 'Color',
				'section'    => 'section_post_header_fonts',
				'settings'   => 'posttitle_google_font_color',
				'priority'	 => 7
			)
		)
	);

	// Font hover color
	$wp_customize->add_setting(
		'posttitle_google_font_color_hover',
		array(
			'default'     => '#8495a6',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'posttitle_google_font_color_hover',
			array(
				'label'      => 'Hover Color',
				'section'    => 'section_post_header_fonts',
				'settings'   => 'posttitle_google_font_color_hover',
				'priority'	 => 8
			)
		)
	);

	// Post Categories & Date Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'posts_meta_title', array(
        'label' => __('Meta Font - Categories & Date', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_post_header_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 9
        ) )
	);

	// Font Family
    $wp_customize->add_setting( 'postmeta_google_font_list', array(
        'default'           => 'Open Sans',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control( new Google_Font_Dropdown_Custom_Control( $wp_customize, 'postmeta_google_font_list', array(
        'label'      => 'Font Family',
        'section'    => 'section_post_header_fonts',
        'settings'   => 'postmeta_google_font_list',
        'priority'	 => 10,
    )));

        // Font weight
    $wp_customize->add_setting(
        'postmeta_google_font_weight',
        array(
            'default' => '500',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'postmeta_google_font_weight',
				array(
					'label' => 'Font Weight',
					'description'      => 'Some font weights will not apply to certain fonts. See https://fonts.google.com/ for more info about each font in the list.',
					'section'    => 'section_post_header_fonts',
					'settings'   => 'postmeta_google_font_weight',
					'type'        => 'select',
					'priority'	 => 11,
					'choices'     => array(                    
						'100'   => __( '100', 'primadonna' ),
						'200'    => __( '200', 'primadonna' ),
						'300'    => __( '300', 'primadonna' ),
						'400'    => __( 'normal', 'primadonna' ),
						'500'    => __( '500', 'primadonna' ),
						'600'    => __( '600', 'primadonna' ),
						'700'    => __( 'bold', 'primadonna' ),
						'800'    => __( '800', 'primadonna' ),
						'900'    => __( '900', 'primadonna' ),
			),
        ))
	);

	// Letter Spacing
    $wp_customize->add_setting(
   		'postmeta_google_font_spacing',
        array(
            'default'     => '1',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'postmeta_google_font_spacing',
				array(
					'label'      => 'Letter Spacing',
					'section'    => 'section_post_header_fonts',
					'settings'   => 'postmeta_google_font_spacing',
					'type'		 => 'number',
					'priority'	 => 12,
				)
			)
		);

	// Text transform
    $wp_customize->add_setting(
        'postmeta_google_font_transform',
        array(
            'default' => 'uppercase',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'postmeta_google_font_transform',
				array(
					'label' => 'Text Transform (Case)',
					'description'      => '',
					'section'    => 'section_post_header_fonts',
					'settings'   => 'postmeta_google_font_transform',
					'type'        => 'select',
					'priority'	 => 13,
					'choices'     => array(                    
						'none'   => __( 'none', 'primadonna' ),
						'lowercase'    => __( 'lowercase', 'primadonna' ),
						'capitalize'    => __( 'capitalize', 'primadonna' ),
						'uppercase'    => __( 'uppercase', 'primadonna' ),
			),
        ))
	);

	// Post Categories Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'posts_cats_title', array(
        'label' => __('Categories', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_post_header_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 14
        ) )
	);

	// Font Size
    $wp_customize->add_setting(
   		'postcats_google_font_size',
        array(
            'default'     => '11',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'postcats_google_font_size',
				array(
					'label'      => 'Font Size',
					'section'    => 'section_post_header_fonts',
					'settings'   => 'postcats_google_font_size',
					'type'		 => 'number',
					'priority'	 => 15,
				)
			)
		);

	// Font color
	$wp_customize->add_setting(
		'postcats_google_font_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'postcats_google_font_color',
			array(
				'label'      => 'Color',
				'section'    => 'section_post_header_fonts',
				'settings'   => 'postcats_google_font_color',
				'priority'	 => 16
			)
		)
	);

	// Post Date Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'posts_date_title', array(
        'label' => __('Date', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_post_header_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 17
        ) )
	);

	// Font Size
    $wp_customize->add_setting(
   		'postdate_google_font_size',
        array(
            'default'     => '10',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'postdate_google_font_size',
				array(
					'label'      => 'Font Size',
					'section'    => 'section_post_header_fonts',
					'settings'   => 'postdate_google_font_size',
					'type'		 => 'number',
					'priority'	 => 18,
				)
			)
		);

	// Font color
	$wp_customize->add_setting(
		'postdate_google_font_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'postdate_google_font_color',
			array(
				'label'      => 'Color',
				'section'    => 'section_post_header_fonts',
				'settings'   => 'postdate_google_font_color',
				'priority'	 => 19
			)
		)
	);

//__Posts Read More Fonts Section__//

$wp_customize->add_section('section_post_readmore_fonts', array(
	'title'		=> esc_html__('Posts: Read More', 'primadonna'),
	'priority'	=> 12,
	'panel' => 'panel_fonts',

));

	// Bg color
	$wp_customize->add_setting(
		'readmore_bg_google_font_color',
		array(
			'default'     => '#transparent',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'readmore_bg_google_font_color',
			array(
				'label'      => 'Background Color',
				'section'    => 'section_post_readmore_fonts',
				'settings'   => 'readmore_bg_google_font_color',
				'priority'	 => 1
			)
		)
	);

	// Bg color Hover
	$wp_customize->add_setting(
		'readmore_bg_hover_google_font_color',
		array(
			'default'     => '#transparent',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'readmore_bg_hover_google_font_color',
			array(
				'label'      => 'Background Hover Color',
				'section'    => 'section_post_readmore_fonts',
				'settings'   => 'readmore_bg_hover_google_font_color',
				'priority'	 => 2
			)
		)
	);

	// Text color
	$wp_customize->add_setting(
		'readmore_google_font_color',
		array(
			'default'     => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'readmore_google_font_color',
			array(
				'label'      => 'Text Color',
				'section'    => 'section_post_readmore_fonts',
				'settings'   => 'readmore_google_font_color',
				'priority'	 => 3
			)
		)
	);

	// Text hover color
	$wp_customize->add_setting(
		'readmore_hover_google_font_color',
		array(
			'default'     => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'readmore_hover_google_font_color',
			array(
				'label'      => 'Text Hover Color',
				'section'    => 'section_post_readmore_fonts',
				'settings'   => 'readmore_hover_google_font_color',
				'priority'	 => 4
			)
		)
	);

	// Read More fonts
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'posts_read_more_title', array(
        'label' => __('Font', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_post_readmore_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 5
        ) )
	);

	// Font Family
    $wp_customize->add_setting( 'readmore_google_font_list', array(
        'default'           => 'Open Sans',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control( new Google_Font_Dropdown_Custom_Control( $wp_customize, 'readmore_google_font_list', array(
        'label'      => 'Font Family',
        'section'    => 'section_post_readmore_fonts',
        'settings'   => 'readmore_google_font_list',
        'priority'	 => 6,
    )));

    // Font Size
    $wp_customize->add_setting(
   		'readmore_google_font_size',
        array(
            'default'     => '11',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'readmore_google_font_size',
				array(
					'label'      => 'Font Size',
					'section'    => 'section_post_readmore_fonts',
					'settings'   => 'readmore_google_font_size',
					'type'		 => 'number',
					'priority'	 => 7,
				)
			)
		);

    // Font weight
    $wp_customize->add_setting(
        'readmore_google_font_weight',
        array(
            'default' => '400',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'readmore_google_font_weight',
				array(
					'label' => 'Font Weight',
					'description'      => 'Some font weights will not apply to certain fonts. See https://fonts.google.com/ for more info about each font in the list.',
					'section'    => 'section_post_readmore_fonts',
					'settings'   => 'readmore_google_font_weight',
					'type'        => 'select',
					'priority'	 => 11,
					'choices'     => array(                    
						'100'   => __( '100', 'primadonna' ),
						'200'    => __( '200', 'primadonna' ),
						'300'    => __( '300', 'primadonna' ),
						'400'    => __( 'normal', 'primadonna' ),
						'500'    => __( '500', 'primadonna' ),
						'600'    => __( '600', 'primadonna' ),
						'700'    => __( 'bold', 'primadonna' ),
						'800'    => __( '800', 'primadonna' ),
						'900'    => __( '900', 'primadonna' ),
			),
        ))
	);

	// Letter Spacing
    $wp_customize->add_setting(
   		'readmore_google_font_spacing',
        array(
            'default'     => '1',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'readmore_google_font_spacing',
				array(
					'label'      => 'Letter Spacing',
					'section'    => 'section_post_readmore_fonts',
					'settings'   => 'readmore_google_font_spacing',
					'type'		 => 'number',
					'priority'	 => 12,
				)
			)
		);

	// Text transform
    $wp_customize->add_setting(
        'readmore_google_font_transform',
        array(
            'default' => 'uppercase',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'readmore_google_font_transform',
				array(
					'label' => 'Text Transform (Case)',
					'description'      => '',
					'section'    => 'section_post_readmore_fonts',
					'settings'   => 'readmore_google_font_transform',
					'type'        => 'select',
					'priority'	 => 13,
					'choices'     => array(                    
						'none'   => __( 'none', 'primadonna' ),
						'lowercase'    => __( 'lowercase', 'primadonna' ),
						'capitalize'    => __( 'capitalize', 'primadonna' ),
						'uppercase'    => __( 'uppercase', 'primadonna' ),
			),
        ))
	);



//__Posts Footer Fonts Section__//

$wp_customize->add_section('section_post_footer_fonts', array(
	'title'		=> esc_html__('Posts: Footer', 'primadonna'),
	'priority'	=> 13,
	'panel' => 'panel_fonts',

));

	// Post Labels Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'posts_footer_labels_title', array(
        'label' => __('Post Tags', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_post_footer_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 1
        ) )
	);

    // Font Size
	$wp_customize->add_setting(
   		'postlabels_google_font_size',
        array(
            'default'     => '10',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
		new Customize_Number_Control(
			$wp_customize,
			'postlabels_google_font_size',
			array(
				'label'      => 'Font Size',
				'section'    => 'section_post_footer_fonts',
				'settings'   => 'postlabels_google_font_size',
				'type'		 => 'number',
				'priority'	 => 2,
			)
		)
	);

    // Font weight
    $wp_customize->add_setting(
        'postlabels_google_font_weight',
        array(
            'default' => '500',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'postlabels_google_font_weight',
				array(
					'label' => 'Font Weight',
					'description'      => 'Some font weights will not apply to certain fonts. See https://fonts.google.com/ for more info about each font in the list.',
					'section'    => 'section_post_footer_fonts',
					'settings'   => 'postlabels_google_font_weight',
					'type'        => 'select',
					'priority'	 => 3,
					'choices'     => array(                    
						'100'   => __( '100', 'primadonna' ),
						'200'    => __( '200', 'primadonna' ),
						'300'    => __( '300', 'primadonna' ),
						'400'    => __( 'normal', 'primadonna' ),
						'500'    => __( '500', 'primadonna' ),
						'600'    => __( '600', 'primadonna' ),
						'700'    => __( 'bold', 'primadonna' ),
						'800'    => __( '800', 'primadonna' ),
						'900'    => __( '900', 'primadonna' ),
			),
        ))
	);

	// Letter Spacing
    $wp_customize->add_setting(
   		'postlabels_google_font_spacing',
        array(
            'default'     => '1',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'postlabels_google_font_spacing',
				array(
					'label'      => 'Letter Spacing',
					'section'    => 'section_post_footer_fonts',
					'settings'   => 'postlabels_google_font_spacing',
					'type'		 => 'number',
					'priority'	 => 4,
				)
			)
		);

	// Text transform
    $wp_customize->add_setting(
        'postlabels_google_font_transform',
        array(
            'default' => 'uppercase',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'postlabels_google_font_transform',
				array(
					'label' => 'Text Transform (Case)',
					'description'      => '',
					'section'    => 'section_post_footer_fonts',
					'settings'   => 'postlabels_google_font_transform',
					'type'        => 'select',
					'priority'	 => 5,
					'choices'     => array(                    
						'none'   => __( 'none', 'primadonna' ),
						'lowercase'    => __( 'lowercase', 'primadonna' ),
						'capitalize'    => __( 'capitalize', 'primadonna' ),
						'uppercase'    => __( 'uppercase', 'primadonna' ),
			),
        ))
	);

    // Font color
	$wp_customize->add_setting(
		'postlabels_google_font_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'postlabels_google_font_color',
			array(
				'label'      => 'Color',
				'section'    => 'section_post_footer_fonts',
				'settings'   => 'postlabels_google_font_color',
				'priority'	 => 6
			)
		)
	);

	// BG color
	$wp_customize->add_setting(
		'postlabels_bg_google_font_color',
		array(
			'default'     => '#fafafa',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'postlabels_bg_google_font_color',
			array(
				'label'      => 'Background Color',
				'section'    => 'section_post_footer_fonts',
				'settings'   => 'postlabels_bg_google_font_color',
				'priority'	 => 7
			)
		)
	);

	// Font hover color
	$wp_customize->add_setting(
		'postlabels_google_font_color_hover',
		array(
			'default'     => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'postlabels_google_font_color_hover',
			array(
				'label'      => 'Hover Color',
				'section'    => 'section_post_footer_fonts',
				'settings'   => 'postlabels_google_font_color_hover',
				'priority'	 => 8
			)
		)
	);

	// Bg hover color
	$wp_customize->add_setting(
		'postlabels_bg_google_font_color_hover',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'postlabels_bg_google_font_color_hover',
			array(
				'label'      => 'Background Hover Color',
				'section'    => 'section_post_footer_fonts',
				'settings'   => 'postlabels_bg_google_font_color_hover',
				'priority'	 => 9
			)
		)
	);

	// Post Footer Meta Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'posts_footer_meta_title', array(
        'label' => __('Footer Meta', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_post_footer_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 10
        ) )
	);

	// Border color
	$wp_customize->add_setting(
		'post_footer_border_color',
		array(
			'default'     => '#eeeeee',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'post_footer_border_color',
			array(
				'label'      => 'Footer Border Color',
				'section'    => 'section_post_footer_fonts',
				'settings'   => 'post_footer_border_color',
				'priority'	 => 11
			)
		)
	);

	// Font Family
    $wp_customize->add_setting( 'footermeta_google_font_list', array(
        'default'           => 'Open Sans',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control( new Google_Font_Dropdown_Custom_Control( $wp_customize, 'footermeta_google_font_list', array(
        'label'      => 'Font Family',
        'section'    => 'section_post_footer_fonts',
        'settings'   => 'footermeta_google_font_list',
        'priority'	 => 12,
    )));

    // Font Size
    $wp_customize->add_setting(
   		'postfooter_google_font_size',
        array(
            'default'     => '14',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'postfooter_google_font_size',
				array(
					'label'      => 'Font Size',
					'section'    => 'section_post_footer_fonts',
					'settings'   => 'postfooter_google_font_size',
					'type'		 => 'number',
					'priority'	 => 13,
				)
			)
		);

    // Font weight
    $wp_customize->add_setting(
        'postfooter_google_font_weight',
        array(
            'default' => '500',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'postfooter_google_font_weight',
				array(
					'label' => 'Font Weight',
					'description'      => 'Some font weights will not apply to certain fonts. See https://fonts.google.com/ for more info about each font in the list.',
					'section'    => 'section_post_footer_fonts',
					'settings'   => 'postfooter_google_font_weight',
					'type'        => 'select',
					'priority'	 => 14,
					'choices'     => array(                    
						'100'   => __( '100', 'primadonna' ),
						'200'    => __( '200', 'primadonna' ),
						'300'    => __( '300', 'primadonna' ),
						'400'    => __( 'normal', 'primadonna' ),
						'500'    => __( '500', 'primadonna' ),
						'600'    => __( '600', 'primadonna' ),
						'700'    => __( 'bold', 'primadonna' ),
						'800'    => __( '800', 'primadonna' ),
						'900'    => __( '900', 'primadonna' ),
			),
        ))
	);

	// Text transform
    $wp_customize->add_setting(
        'postfooter_google_font_transform',
        array(
            'default' => 'none',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'postfooter_google_font_transform',
				array(
					'label' => 'Text Transform (Case)',
					'description'      => '',
					'section'    => 'section_post_footer_fonts',
					'settings'   => 'postfooter_google_font_transform',
					'type'        => 'select',
					'priority'	 => 15,
					'choices'     => array(                    
						'none'   => __( 'none', 'primadonna' ),
						'lowercase'    => __( 'lowercase', 'primadonna' ),
						'capitalize'    => __( 'capitalize', 'primadonna' ),
						'uppercase'    => __( 'uppercase', 'primadonna' ),
			),
        ))
	);

    // Font color
	$wp_customize->add_setting(
		'postfooter_google_font_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'postfooter_google_font_color',
			array(
				'label'      => 'Color',
				'section'    => 'section_post_footer_fonts',
				'settings'   => 'postfooter_google_font_color',
				'priority'	 => 16
			)
		)
	);

	// Post Shares Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'posts_shares_meta_title', array(
        'label' => __('Post Shares & Author Social', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_post_footer_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 17
        ) )
	);

	// Font color
	$wp_customize->add_setting(
		'postshares_google_font_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'postshares_google_font_color',
			array(
				'label'      => 'Color',
				'section'    => 'section_post_footer_fonts',
				'settings'   => 'postshares_google_font_color',
				'priority'	 => 18
			)
		)
	);

	// Font hover color
	$wp_customize->add_setting(
		'postshares_google_font_color_hover',
		array(
			'default'     => '#8495a6',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'postshares_google_font_color_hover',
			array(
				'label'      => 'Hover Color',
				'section'    => 'section_post_footer_fonts',
				'settings'   => 'postshares_google_font_color_hover',
				'priority'	 => 19
			)
		)
	);

	// Font Size
    $wp_customize->add_setting(
   		'postshares_google_font_size',
        array(
            'default'     => '14',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'postshares_google_font_size',
				array(
					'label'      => 'Font Size',
					'section'    => 'section_post_footer_fonts',
					'settings'   => 'postshares_google_font_size',
					'type'		 => 'number',
					'priority'	 => 20,
				)
			)
		);

    // Post Separator Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'posts_separator_title', array(
        'label' => __('Post Section Separator', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_post_footer_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 21
        ) )
	);

	// Separator color
	$wp_customize->add_setting(
		'post_separator_color',
		array(
			'default'     => '#eeeeee',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'post_separator_color',
			array(
				'label'      => 'Post Separator Color',
				'section'    => 'section_post_footer_fonts',
				'settings'   => 'post_separator_color',
				'priority'	 => 22
			)
		)
	);

//__Comments Fonts Section__//

$wp_customize->add_section('section_post_comments_fonts', array(
	'title'		=> esc_html__('Posts: Comments', 'primadonna'),
	'priority'	=> 14,
	'panel' => 'panel_fonts',

));

	// Comment author color
	$wp_customize->add_setting(
		'comments_author_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'comments_author_color',
			array(
				'label'      => 'Comment Author Color',
				'section'    => 'section_post_comments_fonts',
				'settings'   => 'comments_author_color',
				'priority'	 => 1
			)
		)
	);

	// Comment border
	$wp_customize->add_setting(
		'comments_border_color',
		array(
			'default'     => '#eeeeee',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'comments_border_color',
			array(
				'label'      => 'Comment Border Color',
				'section'    => 'section_post_comments_fonts',
				'settings'   => 'comments_border_color',
				'priority'	 => 2
			)
		)
	);

	// Edit & Reply BG
	$wp_customize->add_setting(
		'comments_reply_bg_color',
		array(
			'default'     => '#999999',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'comments_reply_bg_color',
			array(
				'label'      => 'Edit & Reply Background Color',
				'section'    => 'section_post_comments_fonts',
				'settings'   => 'comments_reply_bg_color',
				'priority'	 => 3
			)
		)
	);

	// Leave Comments Border
	$wp_customize->add_setting(
		'comments_border_color',
		array(
			'default'     => '#eeeeee',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'comments_border_color',
			array(
				'label'      => 'Leave a Comment Border Color',
				'section'    => 'section_post_comments_fonts',
				'settings'   => 'comments_border_color',
				'priority'	 => 4
			)
		)
	);


//__Sidebar Fonts Section__//

$wp_customize->add_section('section_sidebar_fonts', array(
	'title'		=> esc_html__('Sidebar', 'primadonna'),
	'priority'	=> 15,
	'panel' => 'panel_fonts',

));

	// Widget title Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'widget_titles_title', array(
        'label' => __('Widget Title Colors', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_sidebar_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 1
        ) )
	);

	// Font color
	$wp_customize->add_setting(
		'sidebar_title_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'sidebar_title_color',
			array(
				'label'      => 'Title Color',
				'section'    => 'section_sidebar_fonts',
				'settings'   => 'sidebar_title_color',
				'priority'	 => 2
			)
		)
	);

	// Border color
	$wp_customize->add_setting(
		'sidebar_border_color',
		array(
			'default'     => '#eeeeee',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'sidebar_border_color',
			array(
				'label'      => 'Border Color',
				'section'    => 'section_sidebar_fonts',
				'settings'   => 'sidebar_border_color',
				'priority'	 => 3
			)
		)
	);

	// Bg color
	$wp_customize->add_setting(
		'sidebar_bg_color',
		array(
			'default'     => '',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'sidebar_bg_color',
			array(
				'label'      => 'Background Color',
				'section'    => 'section_sidebar_fonts',
				'settings'   => 'sidebar_bg_color',
				'priority'	 => 4
			)
		)
	);

	// Arrow color
	$wp_customize->add_setting(
		'sidebar_arrow_color',
		array(
			'default'     => '',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'sidebar_arrow_color',
			array(
				'label'      => 'Title Arrow Color',
				'section'    => 'section_sidebar_fonts',
				'settings'   => 'sidebar_arrow_color',
				'priority'	 => 5
			)
		)
	);

	// Widget title font Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'widget_fonts_title', array(
        'label' => __('Widget Title Font', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_sidebar_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 6
        ) )
	);

	// Font Family
    $wp_customize->add_setting( 'sidebar_google_font_list', array(
        'default'           => 'Montserrat',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control( new Google_Font_Dropdown_Custom_Control( $wp_customize, 'sidebar_google_font_list', array(
        'label'      => 'Font Family',
        'section'    => 'section_sidebar_fonts',
        'settings'   => 'sidebar_google_font_list',
        'priority'	 => 7,
    )));

    // Font Size
    $wp_customize->add_setting(
   		'sidebar_google_font_size',
        array(
            'default'     => '14',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'sidebar_google_font_size',
				array(
					'label'      => 'Font Size',
					'section'    => 'section_sidebar_fonts',
					'settings'   => 'sidebar_google_font_size',
					'type'		 => 'number',
					'priority'	 => 8,
				)
			)
		);

    // Font weight
    $wp_customize->add_setting(
        'sidebar_google_font_weight',
        array(
            'default' => '400',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'sidebar_google_font_weight',
				array(
					'label' => 'Font Weight',
					'description'      => 'Some font weights will not apply to certain fonts. See https://fonts.google.com/ for more info about each font in the list.',
					'section'    => 'section_sidebar_fonts',
					'settings'   => 'sidebar_google_font_weight',
					'type'        => 'select',
					'priority'	 => 9,
					'choices'     => array(                    
						'100'   => __( '100', 'primadonna' ),
						'200'    => __( '200', 'primadonna' ),
						'300'    => __( '300', 'primadonna' ),
						'400'    => __( 'normal', 'primadonna' ),
						'500'    => __( '500', 'primadonna' ),
						'600'    => __( '600', 'primadonna' ),
						'700'    => __( 'bold', 'primadonna' ),
						'800'    => __( '800', 'primadonna' ),
						'900'    => __( '900', 'primadonna' ),
			),
        ))
	);

	// Letter Spacing
    $wp_customize->add_setting(
   		'sidebar_google_font_spacing',
        array(
            'default'     => '1',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'sidebar_google_font_spacing',
				array(
					'label'      => 'Letter Spacing',
					'section'    => 'section_sidebar_fonts',
					'settings'   => 'sidebar_google_font_spacing',
					'type'		 => 'number',
					'priority'	 => 10,
				)
			)
		);

	// Text transform
    $wp_customize->add_setting(
        'sidebar_google_font_transform',
        array(
            'default' => 'uppercase',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'sidebar_google_font_transform',
				array(
					'label' => 'Text Transform (Case)',
					'description'      => '',
					'section'    => 'section_sidebar_fonts',
					'settings'   => 'sidebar_google_font_transform',
					'type'        => 'select',
					'priority'	 => 11,
					'choices'     => array(                    
						'none'   => __( 'none', 'primadonna' ),
						'lowercase'    => __( 'lowercase', 'primadonna' ),
						'capitalize'    => __( 'capitalize', 'primadonna' ),
						'uppercase'    => __( 'uppercase', 'primadonna' ),
			),
        ))
	);

	// Newsletter Widget  Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'newsletter_widget_title', array(
        'label' => __('Newsletter Widget', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_sidebar_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 12
        ) )
	);

	// Title color
	$wp_customize->add_setting(
		'newsletter_title_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'newsletter_title_color',
			array(
				'label'      => 'Newsletter Title Color',
				'section'    => 'section_sidebar_fonts',
				'settings'   => 'newsletter_title_color',
				'priority'	 => 13
			)
		)
	);

	// Background color
	$wp_customize->add_setting(
		'newsletter_bg_color',
		array(
			'default'     => '#fafafa',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'newsletter_bg_color',
			array(
				'label'      => 'Newsletter Background Color',
				'section'    => 'section_sidebar_fonts',
				'settings'   => 'newsletter_bg_color',
				'priority'	 => 14
			)
		)
	);

	// Text color
	$wp_customize->add_setting(
		'newsletter_text_color',
		array(
			'default'     => '#999999',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'newsletter_text_color',
			array(
				'label'      => 'Newsletter Text Color',
				'section'    => 'section_sidebar_fonts',
				'settings'   => 'newsletter_text_color',
				'priority'	 => 15
			)
		)
	);

	// button bg color
	$wp_customize->add_setting(
		'newsletter_buttonbg_color',
		array(
			'default'     => 'transparent',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'newsletter_buttonbg_color',
			array(
				'label'      => 'Button Background Color',
				'section'    => 'section_sidebar_fonts',
				'settings'   => 'newsletter_buttonbg_color',
				'priority'	 => 16
			)
		)
	);

	// button bg color hover
	$wp_customize->add_setting(
		'newsletter_buttonbg_hover_color',
		array(
			'default'     => 'transparent',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'newsletter_buttonbg_hover_color',
			array(
				'label'      => 'Button Background Hover Color',
				'section'    => 'section_sidebar_fonts',
				'settings'   => 'newsletter_buttonbg_hover_color',
				'priority'	 => 17
			)
		)
	);

	// button text color
	$wp_customize->add_setting(
		'newsletter_button_text_color',
		array(
			'default'     => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'newsletter_button_text_color',
			array(
				'label'      => 'Button Text Color',
				'section'    => 'section_sidebar_fonts',
				'settings'   => 'newsletter_button_text_color',
				'priority'	 => 18
			)
		)
	);

	// button text hover color
	$wp_customize->add_setting(
		'newsletter_button_text_hover_color',
		array(
			'default'     => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'newsletter_button_text_hover_color',
			array(
				'label'      => 'Button Text Hover Color',
				'section'    => 'section_sidebar_fonts',
				'settings'   => 'newsletter_button_text_hover_color',
				'priority'	 => 19
			)
		)
	);

	// Tag Cloud Widget Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'tagcloud_widget_title', array(
        'label' => __('Tag Cloud Widget', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_sidebar_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 20
        ) )
	);

	// Text color
	$wp_customize->add_setting(
		'tagcloud_text_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'tagcloud_text_color',
			array(
				'label'      => 'Text Color',
				'section'    => 'section_sidebar_fonts',
				'settings'   => 'tagcloud_text_color',
				'priority'	 => 21
			)
		)
	);

	// Bg color
	$wp_customize->add_setting(
		'tagcloud_bg_color',
		array(
			'default'     => '#fafafa',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'tagcloud_bg_color',
			array(
				'label'      => 'Background Color',
				'section'    => 'section_sidebar_fonts',
				'settings'   => 'tagcloud_bg_color',
				'priority'	 => 22
			)
		)
	);



//__Footer Menu Fonts Section__//

$wp_customize->add_section('section_footer_menu_fonts', array(
	'title'		=> esc_html__('Footer Menu', 'primadonna'),
	'priority'	=> 16,
	'panel' => 'panel_fonts',

));

	// Background color
	$wp_customize->add_setting(
		'footer_menu_bg_color',
		array(
			'default'     => 'transparent',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'footer_menu_bg_color',
			array(
				'label'      => ' Background Color',
				'section'    => 'section_footer_menu_fonts',
				'settings'   => 'footer_menu_bg_color',
				'priority'	 => 1
			)
		)
	);

	// Font Family
    $wp_customize->add_setting( 'footer_menu_google_font_list', array(
        'default'           => 'Montserrat',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control( new Google_Font_Dropdown_Custom_Control( $wp_customize, 'footer_menu_google_font_list', array(
        'label'      => 'Font Family',
        'section'    => 'section_footer_menu_fonts',
        'settings'   => 'footer_menu_google_font_list',
        'priority'	 => 4,
    )));

    // Font Size
    $wp_customize->add_setting(
   		'footer_menu_google_font_size',
        array(
            'default'     => '12',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'footer_menu_google_font_size',
				array(
					'label'      => 'Font Size',
					'section'    => 'section_footer_menu_fonts',
					'settings'   => 'footer_menu_google_font_size',
					'type'		 => 'number',
					'priority'	 => 5,
				)
			)
		);

    // Font weight
    $wp_customize->add_setting(
        'footer_menu_google_font_weight',
        array(
            'default' => '400',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'footer_menu_google_font_weight',
				array(
					'label' => 'Font Weight',
					'description'      => 'Some font weights will not apply to certain fonts. See https://fonts.google.com/ for more info about each font in the list.',
					'section'    => 'section_footer_menu_fonts',
					'settings'   => 'footer_menu_google_font_weight',
					'type'        => 'select',
					'priority'	 => 5,
					'choices'     => array(                    
						'100'   => __( '100', 'primadonna' ),
						'200'    => __( '200', 'primadonna' ),
						'300'    => __( '300', 'primadonna' ),
						'400'    => __( 'normal', 'primadonna' ),
						'500'    => __( '500', 'primadonna' ),
						'600'    => __( '600', 'primadonna' ),
						'700'    => __( 'bold', 'primadonna' ),
						'800'    => __( '800', 'primadonna' ),
						'900'    => __( '900', 'primadonna' ),
			),
        ))
	);

	// Letter Spacing
    $wp_customize->add_setting(
   		'footer_menu_google_font_spacing',
        array(
            'default'     => '1',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'footer_menu_google_font_spacing',
				array(
					'label'      => 'Letter Spacing',
					'section'    => 'section_footer_menu_fonts',
					'settings'   => 'footer_menu_google_font_spacing',
					'type'		 => 'number',
					'priority'	 => 7,
				)
			)
		);

	// Text transform
    $wp_customize->add_setting(
        'footer_menu_google_font_transform',
        array(
            'default' => 'uppercase',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'footer_menuu_google_font_transform',
				array(
					'label' => 'Text Transform (Case)',
					'description'      => '',
					'section'    => 'section_footer_menu_fonts',
					'settings'   => 'footer_menu_google_font_transform',
					'type'        => 'select',
					'priority'	 => 8,
					'choices'     => array(                    
						'none'   => __( 'none', 'primadonna' ),
						'lowercase'    => __( 'lowercase', 'primadonna' ),
						'capitalize'    => __( 'capitalize', 'primadonna' ),
						'uppercase'    => __( 'uppercase', 'primadonna' ),
			),
        ))
	);

    // Font color
	$wp_customize->add_setting(
		'footer_menu_google_font_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'footer_menu_google_font_color',
			array(
				'label'      => 'Color',
				'section'    => 'section_footer_menu_fonts',
				'settings'   => 'footer_menu_google_font_color',
				'priority'	 => 9
			)
		)
	);

	// Font hover color
	$wp_customize->add_setting(
		'footer_menu_google_font_color_hover',
		array(
			'default'     => '#8495a6',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'footer_menu_google_font_color_hover',
			array(
				'label'      => ' Hover Color',
				'section'    => 'section_footer_menu_fonts',
				'settings'   => 'footer_menu_google_font_color_hover',
				'priority'	 => 10
			)
		)
	);

//__Footer Fonts Section__//

$wp_customize->add_section('section_footer_fonts', array(
	'title'		=> esc_html__('Footer', 'primadonna'),
	'priority'	=> 17,
	'panel' => 'panel_fonts',

));

	// Background color
	$wp_customize->add_setting(
		'footer_bg_color',
		array(
			'default'     => '#fafafa',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'footer_bg_color',
			array(
				'label'      => 'Background Color',
				'section'    => 'section_footer_fonts',
				'settings'   => 'footer_bg_color',
				'priority'	 => 1
			)
		)
	);

	// Text color
	$wp_customize->add_setting(
		'footer_text_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'footer_text_color',
			array(
				'label'      => 'Text Color',
				'section'    => 'section_footer_fonts',
				'settings'   => 'footer_text_color',
				'priority'	 => 2
			)
		)
	);

	// Footer Widget  Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'footer_widget_tittle_title', array(
        'label' => __('Widget Titles', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_footer_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 3
        ) )
	);

	// Font Family
    $wp_customize->add_setting( 'footer_google_font_list', array(
        'default'           => 'Montserrat',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control( new Google_Font_Dropdown_Custom_Control( $wp_customize, 'footer_google_font_list', array(
        'label'      => 'Font Family',
        'section'    => 'section_footer_fonts',
        'settings'   => 'footer_google_font_list',
        'priority'	 => 4,
    )));

    // Font Size
    $wp_customize->add_setting(
   		'footer_google_font_size',
        array(
            'default'     => '13',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'footer_google_font_size',
				array(
					'label'      => 'Font Size',
					'section'    => 'section_footer_fonts',
					'settings'   => 'footer_google_font_size',
					'type'		 => 'number',
					'priority'	 => 5,
				)
			)
		);

    // Font weight
    $wp_customize->add_setting(
        'footer_google_font_weight',
        array(
            'default' => '400',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'footer_google_font_weight',
				array(
					'label' => 'Font Weight',
					'description'      => 'Some font weights will not apply to certain fonts. See https://fonts.google.com/ for more info about each font in the list.',
					'section'    => 'section_footer_fonts',
					'settings'   => 'footer_google_font_weight',
					'type'        => 'select',
					'priority'	 => 6,
					'choices'     => array(                    
						'100'   => __( '100', 'primadonna' ),
						'200'    => __( '200', 'primadonna' ),
						'300'    => __( '300', 'primadonna' ),
						'400'    => __( 'normal', 'primadonna' ),
						'500'    => __( '500', 'primadonna' ),
						'600'    => __( '600', 'primadonna' ),
						'700'    => __( 'bold', 'primadonna' ),
						'800'    => __( '800', 'primadonna' ),
						'900'    => __( '900', 'primadonna' ),
			),
        ))
	);

	// Letter Spacing
    $wp_customize->add_setting(
   		'footer_google_font_spacing',
        array(
            'default'     => '1',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'footer_google_font_spacing',
				array(
					'label'      => 'Letter Spacing',
					'section'    => 'section_footer_fonts',
					'settings'   => 'footer_google_font_spacing',
					'type'		 => 'number',
					'priority'	 => 7,
				)
			)
		);

	// Text transform
    $wp_customize->add_setting(
        'footer_google_font_transform',
        array(
            'default' => 'uppercase',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'footer_google_font_transform',
				array(
					'label' => 'Text Transform (Case)',
					'description'      => '',
					'section'    => 'section_footer_fonts',
					'settings'   => 'footer_google_font_transform',
					'type'        => 'select',
					'priority'	 => 8,
					'choices'     => array(                    
						'none'   => __( 'none', 'primadonna' ),
						'lowercase'    => __( 'lowercase', 'primadonna' ),
						'capitalize'    => __( 'capitalize', 'primadonna' ),
						'uppercase'    => __( 'uppercase', 'primadonna' ),
			),
        ))
	);

	// Font color
	$wp_customize->add_setting(
		'footer_widget_title_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'footer_widget_title_color',
			array(
				'label'      => 'Color',
				'section'    => 'section_footer_fonts',
				'settings'   => 'footer_widget_title_color',
				'priority'	 => 9
			)
		)
	);

	// Newsletter Widget Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'footer_newsletter_title', array(
        'label' => __('Newsletter Widget', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_footer_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 10
        ) )
	);

		// button bg color
	$wp_customize->add_setting(
		'footer_newsletter_buttonbg_color',
		array(
			'default'     => '#8495a6',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'footer_newsletter_buttonbg_color',
			array(
				'label'      => 'Button Background Color',
				'section'    => 'section_footer_fonts',
				'settings'   => 'footer_newsletter_buttonbg_color',
				'priority'	 => 11
			)
		)
	);

	// button bg color hover
	$wp_customize->add_setting(
		'footer_newsletter_buttonbg_hover_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'footer_newsletter_buttonbg_hover_color',
			array(
				'label'      => 'Button Background Hover Color',
				'section'    => 'section_footer_fonts',
				'settings'   => 'footer_newsletter_buttonbg_hover_color',
				'priority'	 => 12
			)
		)
	);

	// button text color
	$wp_customize->add_setting(
		'footer_newsletter_button_text_color',
		array(
			'default'     => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'footer_newsletter_button_text_color',
			array(
				'label'      => 'Button Text Color',
				'section'    => 'section_footer_fonts',
				'settings'   => 'footer_newsletter_button_text_color',
				'priority'	 => 13
			)
		)
	);

	// button text hover color
	$wp_customize->add_setting(
		'footer_newsletter_button_text_hover_color',
		array(
			'default'     => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'footer_newsletter_button_text_hover_color',
			array(
				'label'      => 'Button Text Hover Color',
				'section'    => 'section_footer_fonts',
				'settings'   => 'footer_newsletter_button_text_hover_color',
				'priority'	 => 14
			)
		)
	);

//__Footer Copyright Section__//

$wp_customize->add_section('section_footer_copyright_fonts', array(
	'title'		=> esc_html__('Footer Copyright', 'primadonna'),
	'priority'	=> 18,
	'panel' => 'panel_fonts',

));

	// Bg color
	$wp_customize->add_setting(
		'footer_copyright_bg_color',
		array(
			'default'     => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'footer_copyright_bg_color',
			array(
				'label'      => 'Background Color',
				'section'    => 'section_footer_copyright_fonts',
				'settings'   => 'footer_copyright_bg_color',
				'priority'	 => 1
			)
		)
	);

	// Font color
	$wp_customize->add_setting(
		'footer_copyright_font_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'footer_copyright_font_color',
			array(
				'label'      => 'Text Color',
				'section'    => 'section_footer_copyright_fonts',
				'settings'   => 'footer_copyright_font_color',
				'priority'	 => 2
			)
		)
	);

//__Home Page Section__//

$wp_customize->add_section('section_home_page_fonts', array(
	'title'		=> esc_html__('Home Page', 'primadonna'),
	'priority'	=> 19,
	'panel' => 'panel_fonts',

));

	// Widget Titles Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'homepage_widget_title', array(
        'label' => __('Widget Titles', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_home_page_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 1
        ) )
	);

	// Font Family
    $wp_customize->add_setting( 'homepage_widget_google_font_list', array(
        'default'           => 'Montserrat',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control( new Google_Font_Dropdown_Custom_Control( $wp_customize, 'homepage_widget_google_font_list', array(
        'label'      => 'Font Family',
        'section'    => 'section_home_page_fonts',
        'settings'   => 'homepage_widget_google_font_list',
        'priority'	 => 2,
    )));

    // Font Size
    $wp_customize->add_setting(
   		'homepage_widget_google_font_size',
        array(
            'default'     => '24',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'homepage_widget_google_font_size',
				array(
					'label'      => 'Font Size',
					'section'    => 'section_home_page_fonts',
					'settings'   => 'homepage_widget_google_font_size',
					'type'		 => 'number',
					'priority'	 => 3,
				)
			)
		);

    // Font weight
    $wp_customize->add_setting(
        'homepage_widget_google_font_weight',
        array(
            'default' => '400',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'homepage_widget_google_font_weight',
				array(
					'label' => 'Font Weight',
					'description'      => 'Some font weights will not apply to certain fonts. See https://fonts.google.com/ for more info about each font in the list.',
					'section'    => 'section_home_page_fonts',
					'settings'   => 'homepage_widget_google_font_weight',
					'type'        => 'select',
					'priority'	 => 4,
					'choices'     => array(                    
						'100'   => __( '100', 'primadonna' ),
						'200'    => __( '200', 'primadonna' ),
						'300'    => __( '300', 'primadonna' ),
						'400'    => __( 'normal', 'primadonna' ),
						'500'    => __( '500', 'primadonna' ),
						'600'    => __( '600', 'primadonna' ),
						'700'    => __( 'bold', 'primadonna' ),
						'800'    => __( '800', 'primadonna' ),
						'900'    => __( '900', 'primadonna' ),
			),
        ))
	);

	// Letter Spacing
    $wp_customize->add_setting(
   		'homepage_widget_google_font_spacing',
        array(
            'default'     => '1',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'homepage_widget_google_font_spacing',
				array(
					'label'      => 'Letter Spacing',
					'section'    => 'section_home_page_fonts',
					'settings'   => 'homepage_widget_google_font_spacing',
					'type'		 => 'number',
					'priority'	 => 5,
				)
			)
		);

	// Text transform
    $wp_customize->add_setting(
        'homepage_widget_google_font_transform',
        array(
            'default' => 'uppercase',
            'sanitize_callback' => 'primadonna_sanitize_text',
        )
	);

	$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'homepage_widget_google_font_transform',
				array(
					'label' => 'Text Transform (Case)',
					'description'      => '',
					'section'    => 'section_home_page_fonts',
					'settings'   => 'homepage_widget_google_font_transform',
					'type'        => 'select',
					'priority'	 => 6,
					'choices'     => array(                    
						'none'   => __( 'none', 'primadonna' ),
						'lowercase'    => __( 'lowercase', 'primadonna' ),
						'capitalize'    => __( 'capitalize', 'primadonna' ),
						'uppercase'    => __( 'uppercase', 'primadonna' ),
			),
        ))
	);

	// Font color
	$wp_customize->add_setting(
		'homepage_widget_title_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'homepage_widget_title_color',
			array(
				'label'      => 'Color',
				'section'    => 'section_home_page_fonts',
				'settings'   => 'homepage_widget_title_color',
				'priority'	 => 7
			)
		)
	);

	// Slider Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'homepage_slider_title', array(
        'label' => __('Slider', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_home_page_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 8
        ) )
	);

	// Title Font Size
    $wp_customize->add_setting(
   		'hp_slider_google_font_size',
        array(
            'default'     => '22',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'hp_slider_google_font_size',
				array(
					'label'      => 'Post Title Font Size',
					'section'    => 'section_home_page_fonts',
					'settings'   => 'hp_slider_google_font_size',
					'type'		 => 'number',
					'priority'	 => 9,
				)
			)
		);

    // Categories Font Size
    $wp_customize->add_setting(
   		'hp_slidercats_google_font_size',
        array(
            'default'     => '12',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'hp_slidercats_google_font_size',
				array(
					'label'      => 'Post Category Font Size',
					'section'    => 'section_home_page_fonts',
					'settings'   => 'hp_slidercats_google_font_size',
					'type'		 => 'number',
					'priority'	 => 10,
				)
			)
		);

    // Excerpt Font Size
    $wp_customize->add_setting(
   		'hp_sliderex_google_font_size',
        array(
            'default'     => '14',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'hp_sliderex_google_font_size',
				array(
					'label'      => 'Post Category Font Size',
					'section'    => 'section_home_page_fonts',
					'settings'   => 'hp_sliderex_google_font_size',
					'type'		 => 'number',
					'priority'	 => 11,
				)
			)
		);

    // Newsletter Widget Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'homepage_newsletter_title', array(
        'label' => __('Newsletter Widget', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_home_page_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 12
        ) )
	);

	// Bg color
	$wp_customize->add_setting(
		'homepage_newsletter_bg_color',
		array(
			'default'     => 'transparent',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'homepage_newsletter_bg_color',
			array(
				'label'      => 'Background Color',
				'section'    => 'section_home_page_fonts',
				'settings'   => 'homepage_newsletter_bg_color',
				'priority'	 => 13
			)
		)
	);

	// Border color
	$wp_customize->add_setting(
		'homepage_newsletter_border_color',
		array(
			'default'     => '#eeeeee',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'homepage_newsletter_border_color',
			array(
				'label'      => 'Border Color',
				'section'    => 'section_home_page_fonts',
				'settings'   => 'homepage_newsletter_border_color',
				'priority'	 => 14
			)
		)
	);

	// title color
	$wp_customize->add_setting(
		'homepage_newsletter_title_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'homepage_newsletter_title_color',
			array(
				'label'      => 'Title Color',
				'section'    => 'section_home_page_fonts',
				'settings'   => 'homepage_newsletter_title_color',
				'priority'	 => 15
			)
		)
	);

	// text color
	$wp_customize->add_setting(
		'homepage_newsletter_text_color',
		array(
			'default'     => '#999999',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'homepage_newsletter_text_color',
			array(
				'label'      => 'Text Color',
				'section'    => 'section_home_page_fonts',
				'settings'   => 'homepage_newsletter_text_color',
				'priority'	 => 16
			)
		)
	);

	// button bg color
	$wp_customize->add_setting(
		'homepage_newsletter_buttonbg_color',
		array(
			'default'     => '#8495a6',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'homepage_newsletter_buttonbg_color',
			array(
				'label'      => 'Button Background Color',
				'section'    => 'section_home_page_fonts',
				'settings'   => 'homepage_newsletter_buttonbg_color',
				'priority'	 => 17
			)
		)
	);

	// button bg color hover
	$wp_customize->add_setting(
		'homepage_newsletter_buttonbg_hover_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'homepage_newsletter_buttonbg_hover_color',
			array(
				'label'      => 'Button Background Hover Color',
				'section'    => 'section_home_page_fonts',
				'settings'   => 'homepage_newsletter_buttonbg_hover_color',
				'priority'	 => 18
			)
		)
	);

	// button text color
	$wp_customize->add_setting(
		'homepage_newsletter_button_text_color',
		array(
			'default'     => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'homepage_newsletter_button_text_color',
			array(
				'label'      => 'Button Text Color',
				'section'    => 'section_home_page_fonts',
				'settings'   => 'homepage_newsletter_button_text_color',
				'priority'	 => 19
			)
		)
	);

	// button text hover color
	$wp_customize->add_setting(
		'homepage_newsletter_button_text_hover_color',
		array(
			'default'     => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'homepage_newsletter_button_text_hover_color',
			array(
				'label'      => 'Button Text Hover Color',
				'section'    => 'section_home_page_fonts',
				'settings'   => 'homepage_newsletter_button_text_hover_color',
				'priority'	 => 20
			)
		)
	);

//__Blog Page Section__//

$wp_customize->add_section('section_blog_page_fonts', array(
	'title'		=> esc_html__('Blog Page', 'primadonna'),
	'priority'	=> 20,
	'panel' => 'panel_fonts',

));

	// Slider Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'blog_slider_title', array(
        'label' => __('Slider', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_blog_page_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 1
        ) )
	);

	// Title Font Size
    $wp_customize->add_setting(
   		'blog_slider_google_font_size',
        array(
            'default'     => '22',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'blog_slider_google_font_size',
				array(
					'label'      => 'Post Title Font Size',
					'section'    => 'section_blog_page_fonts',
					'settings'   => 'blog_slider_google_font_size',
					'type'		 => 'number',
					'priority'	 => 2,
				)
			)
		);

    // Categories Font Size
    $wp_customize->add_setting(
   		'blog_slidercats_google_font_size',
        array(
            'default'     => '12',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'blog_slidercats_google_font_size',
				array(
					'label'      => 'Post Category Font Size',
					'section'    => 'section_blog_page_fonts',
					'settings'   => 'blog_slidercats_google_font_size',
					'type'		 => 'number',
					'priority'	 => 3,
				)
			)
		);

    // Excerpt Font Size
    $wp_customize->add_setting(
   		'blog_sliderex_google_font_size',
        array(
            'default'     => '14',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'blog_sliderex_google_font_size',
				array(
					'label'      => 'Post Category Font Size',
					'section'    => 'section_blog_page_fonts',
					'settings'   => 'blog_sliderex_google_font_size',
					'type'		 => 'number',
					'priority'	 => 4,
				)
			)
		);

    // Newsletter Widget Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'blog_newsletter_title', array(
        'label' => __('Newsletter Widget', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_blog_page_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 5
        ) )
	);

	// Bg color
	$wp_customize->add_setting(
		'blog_newsletter_bg_color',
		array(
			'default'     => 'transparent',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'blog_newsletter_bg_color',
			array(
				'label'      => 'Background Color',
				'section'    => 'section_blog_page_fonts',
				'settings'   => 'blog_newsletter_bg_color',
				'priority'	 => 6
			)
		)
	);

	// Border color
	$wp_customize->add_setting(
		'blog_newsletter_border_color',
		array(
			'default'     => '#eeeeee',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'blog_newsletter_border_color',
			array(
				'label'      => 'Border Color',
				'section'    => 'section_blog_page_fonts',
				'settings'   => 'blog_newsletter_border_color',
				'priority'	 => 7
			)
		)
	);

	// title color
	$wp_customize->add_setting(
		'blog_newsletter_title_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'blog_newsletter_title_color',
			array(
				'label'      => 'Title Color',
				'section'    => 'section_blog_page_fonts',
				'settings'   => 'blog_newsletter_title_color',
				'priority'	 => 8
			)
		)
	);

	// text color
	$wp_customize->add_setting(
		'blog_newsletter_text_color',
		array(
			'default'     => '#999999',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'blog_newsletter_text_color',
			array(
				'label'      => 'Text Color',
				'section'    => 'section_blog_page_fonts',
				'settings'   => 'blog_newsletter_text_color',
				'priority'	 => 9
			)
		)
	);

	// button bg color
	$wp_customize->add_setting(
		'blog_newsletter_buttonbg_color',
		array(
			'default'     => '#8495a6',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'blog_newsletter_buttonbg_color',
			array(
				'label'      => 'Button Background Color',
				'section'    => 'section_blog_page_fonts',
				'settings'   => 'blog_newsletter_buttonbg_color',
				'priority'	 => 10
			)
		)
	);

	// button bg color hover
	$wp_customize->add_setting(
		'blog_newsletter_buttonbg_hover_color',
		array(
			'default'     => '#302b2b',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'blog_newsletter_buttonbg_hover_color',
			array(
				'label'      => 'Button Background Hover Color',
				'section'    => 'section_blog_page_fonts',
				'settings'   => 'blog_newsletter_buttonbg_hover_color',
				'priority'	 => 11
			)
		)
	);

	// button text color
	$wp_customize->add_setting(
		'blog_newsletter_button_text_color',
		array(
			'default'     => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'blog_newsletter_button_text_color',
			array(
				'label'      => 'Button Text Color',
				'section'    => 'section_blog_page_fonts',
				'settings'   => 'blog_newsletter_button_text_color',
				'priority'	 => 12
			)
		)
	);

	// button text hover color
	$wp_customize->add_setting(
		'blog_newsletter_button_text_hover_color',
		array(
			'default'     => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'blog_newsletter_button_text_hover_color',
			array(
				'label'      => 'Button Text Hover Color',
				'section'    => 'section_blog_page_fonts',
				'settings'   => 'blog_newsletter_button_text_hover_color',
				'priority'	 => 13
			)
		)
	);

	// Grid, List & Masonry titles Title
	$wp_customize->add_setting('primadonna_options[info]', array(
            'type'              => 'info_control',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'esc_attr',            
        )
    );

    $wp_customize->add_control( new Primadonna_Info( $wp_customize, 'grid_titles_title', array(
        'label' => __('Grid, List, Masonry Post Titles', 'primadonna'),
        'description' => __( '', 'primadonna' ),
        'section' => 'section_blog_page_fonts',
        'settings' => 'primadonna_options[info]',
        'priority' => 14
        ) )
	);

	// Grid Font Size
    $wp_customize->add_setting(
   		'blog_grid_google_font_size',
        array(
            'default'     => '20',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'blog_grid_google_font_size',
				array(
					'label'      => 'Grid Layout - Post Title Font Size',
					'section'    => 'section_blog_page_fonts',
					'settings'   => 'blog_grid_google_font_size',
					'type'		 => 'number',
					'priority'	 => 15,
				)
			)
		);

    // List Font Size
    $wp_customize->add_setting(
   		'blog_list_google_font_size',
        array(
            'default'     => '20',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'blog_list_google_font_size',
				array(
					'label'      => 'List Layout - Post Title Font Size',
					'section'    => 'section_blog_page_fonts',
					'settings'   => 'blog_list_google_font_size',
					'type'		 => 'number',
					'priority'	 => 16,
				)
			)
		);

    // Masonry Font Size
    $wp_customize->add_setting(
   		'blog_masonry_google_font_size',
        array(
            'default'     => '20',
            'sanitize_callback' => 'primadonna_sanitize_integer',
        )
    );

    $wp_customize->add_control(
			new Customize_Number_Control(
				$wp_customize,
				'blog_masonry_google_font_size',
				array(
					'label'      => 'Maronry Layout - Post Title Font Size',
					'section'    => 'section_blog_page_fonts',
					'settings'   => 'blog_masonry_google_font_size',
					'type'		 => 'number',
					'priority'	 => 17,
				)
			)
		);

///////////////////////////////////////////////////////////////////
// Sanitizer functions for Customizer
//////////////////////////////////////////////////////////////////
function primadonna_sanitize_text( $input ) {
    return wp_kses_post( force_balance_tags( $input ) );
}

function primadonna_sanitize_checkbox( $input ) {
    if ( $input == true ) {
        return true;
    } else {
        return '';
    }
}

function primadonna_sanitize_homepage_layout( $input ) {
    $valid = array(
				'full'   => 'Full Post Layout',
				'grid'  => 'Grid Post Layout',
				'full_grid'  => '1 Full Post then Grid Layout',
				'list'  => 'List Post Layout',
				'full_list'  => '1 Full Post then List Layout',
				'masonry' => 'Masonry Post Layout',
				'full_masonry'  => '1 Full Post then Masonry Layout'
    );
 
    if ( array_key_exists( $input, $valid ) ) {
        return $input;
    } else {
        return '';
    }
}

function primadonna_sanitize_post_summary( $input ) {
    $valid = array(
				'full'   => 'Use Read More Tag',
				'excerpt'  => 'Use Excerpt',
    );
 
    if ( array_key_exists( $input, $valid ) ) {
        return $input;
    } else {
        return '';
    }
}

function primadonna_sanitize_featured_layout( $input ) {
    $valid = array(
				'none' => 'No Slider',
				'boxed'   => 'Boxed Slider',
				'full'  => 'Fullwidth Slider',
				'carousel'  => 'Carousel Slider',
				'split' => '2/3 + 1/3 - Slider + Widget'
    );
 
    if ( array_key_exists( $input, $valid ) ) {
        return $input;
    } else {
        return '';
    }
}

function primadonna_sanitize_integer( $input ) {
    if( is_numeric( $input ) ) {
        return intval( $input );
    }
}

}

add_action( 'customize_register', 'primadonna_register_theme_customizer' );



