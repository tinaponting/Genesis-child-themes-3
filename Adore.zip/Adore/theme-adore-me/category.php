<?php
// Force full width content
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

// Load JS that sets equal heights for Posts on non-touchscreen devices
add_action( 'wp_enqueue_scripts', 'adore_enqueue_category_script' );
function adore_enqueue_category_script() {
	if ( wp_is_mobile() ) {
		return;
	}
	wp_enqueue_script( 'set-heights', get_stylesheet_directory_uri() .'/js/set-heights.js' , array( 'jquery' ), '1.0.0', true );
}

/**
 * Display as Columns
 *
 */
function be_portfolio_post_class( $classes ) {
	
	if ( is_main_query() ) { // conditional to ensure that column classes do not apply to Featured widgets
		$columns = 3; // Set the number of columns here
		$column_classes = array( '', '', 'one-half', 'one-third', 'one-fourth', 'one-fifth', 'one-sixth' );
		$classes[] = $column_classes[$columns];
		global $wp_query;
		if( 0 == $wp_query->current_post || 0 == $wp_query->current_post % $columns )
			$classes[] = 'first';
	}
	
	return $classes;
}
add_filter( 'post_class', 'be_portfolio_post_class' );

// Remove post info
remove_action( 'genesis_entry_header', 'genesis_post_info', 9 );

// Remove the post image
remove_action( 'genesis_entry_header', 'adore_show_featured_image', 8 );

// Display featured image above title
add_action ( 'genesis_entry_header', 'adore_category_featured_image', 7 );
function adore_category_featured_image() {
	$title = apply_filters( 'genesis_post_title_text', get_the_title() );
	
	if ( $image = genesis_get_image( 'format=url&size=vertical-entry-image' ) ) {
		printf( '<div class="category-thumbnail"><a href="%s" rel="bookmark"><img src="%s" alt="%s" /></a></div>', get_permalink(), $image, the_title_attribute( 'echo=0' ) );
		
			echo '<div class="overlay"><a href="' . get_permalink() . '">';
			echo '<h1 class="entry-title">' . $title . '</h1>';
			echo '<p class="more-link">View <i>the</i> Post &raquo;</p>';
			echo '</a></div>';
	
	}
			
}

// Remove the post content
remove_action( 'genesis_entry_content', 'genesis_do_post_content' );

// Remove entry meta from entry footer incl. markup
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

// Remove the entry title
remove_action( 'genesis_entry_header', 'genesis_do_post_title' );

// Remove post content navigation (for multi-page posts)
remove_action( 'genesis_entry_content', 'genesis_do_post_content_nav', 12 );

genesis();