<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Ludwig' );
define( 'CHILD_THEME_VERSION', '1.1' );

//* Enqueue Google Fonts
add_action( 'wp_enqueue_scripts', 'genesis_custom_google_fonts' );
function genesis_custom_google_fonts() {

	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Raleway:400,500,600,700,800,900,300', array(), CHILD_THEME_VERSION );

}

//* Enqueue scripts and styles
add_action( 'wp_enqueue_scripts', 'genesis_scripts_styles_mobile_responsive' );
function genesis_scripts_styles_mobile_responsive() {

	wp_enqueue_script( 'responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_style( 'dashicons' );
}

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Move primary menu into header right area
remove_action( 'genesis_after_header','genesis_do_nav' ) ;
add_action( 'genesis_header_right','genesis_do_nav' );

//* Unregister secondary navigation menu
add_theme_support( 'genesis-menus', array( 'primary' => __( 'Primary Navigation Menu', 'genesis' ) ) );

//* Remove header-right and alt sidebar
unregister_sidebar( 'header-right' );
unregister_sidebar( 'sidebar-alt' );

//* Unregister layout settings
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );

//* Remove Genesis child theme style sheet
remove_action( 'genesis_meta', 'genesis_load_stylesheet' );

//* Enqueue Genesis child theme style sheet at higher priority
add_action( 'wp_enqueue_scripts', 'genesis_enqueue_main_stylesheet', 15 );

//* Display author box on archive pages & single posts
add_filter( 'get_the_author_genesis_author_box_archive', '__return_true' );
add_filter( 'get_the_author_genesis_author_box_single', '__return_true' );

//* Remove comment form allowed tags
add_filter( 'comment_form_defaults', 'genesis_remove_comment_form_allowed_tags' );
function genesis_remove_comment_form_allowed_tags( $defaults ) {

	$defaults['comment_notes_after'] = '';
	return $defaults;

}