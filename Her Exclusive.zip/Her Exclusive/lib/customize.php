<?php
/**
 * Her Exclusive.
 * @package Her Exclusive
 */

add_action( 'customize_register', 'her_customizer_register' );
/**
 * Register settings and controls with the Customizer.
 *
 * @since 1.0.0
 * 
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function her_customizer_register() {

	global $wp_customize;

	$images = apply_filters( 'her_images', array( '1', '5' ) );

	$wp_customize->add_section( 'her-settings', array(
		'description' => __( 'Use the included default images or personalize your site by uploading your own images.<br /><br />The default images are <strong>1600 pixels wide and 1000 pixels tall</strong>.', 'her-exclusive' ),
		'title'       => __( 'Front Page Background Images', 'her-exclusive' ),
		'priority'    => 35,
	) );

	foreach( $images as $image ) {

		$wp_customize->add_setting( $image .'-her-image', array(
			'default'           => sprintf( '%s/images/bg-%s.jpg', get_stylesheet_directory_uri(), $image ),
			'sanitize_callback' => 'esc_url_raw',
			'type'              => 'option',
		) );

		$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, $image .'-her-image', array(
			'label'    => sprintf( __( 'Featured Section %s Image:', 'her-exclusive' ), $image ),
			'section'  => 'her-settings',
			'settings' => $image .'-her-image',
			'priority' => $image+1,
		) ) );

	}
	
	
	
	
	
	$wp_customize->add_setting(
		'her_title_color',
		array(
			'default'           => her_customizer_get_default_title_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'her_title_color',
			array(
				'description' => __( 'Change the Title color.', 'her-exclusive' ),
				'label'       => __( 'Title Color', 'her-exclusive' ),
				'section'     => 'colors',
				'settings'    => 'her_title_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'her_description_color',
		array(
			'default'           => her_customizer_get_default_description_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'her_description_color',
			array(
				'description' => __( 'Change the Description Tagline color.', 'her-exclusive' ),
				'label'       => __( 'Tagline Color', 'her-exclusive' ),
				'section'     => 'colors',
				'settings'    => 'her_description_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'her_accent_color',
		array(
			'default'           => her_customizer_get_default_accent_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'her_accent_color',
			array(
				'description' => __( 'Change the default link color.', 'her-exclusive' ),
				'label'       => __( 'Link Color', 'her-exclusive' ),
				'section'     => 'colors',
				'settings'    => 'her_accent_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'her_accent_hover_color',
		array(
			'default'           => her_customizer_get_default_accent_hover_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'her_accent_hover_color',
			array(
				'description' => __( 'Change the default link hover color.', 'her-exclusive' ),
				'label'       => __( 'Link Hover Color', 'her-exclusive' ),
				'section'     => 'colors',
				'settings'    => 'her_accent_hover_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'her_headings_color',
		array(
			'default'           => her_customizer_get_default_headings_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'her_headings_color',
			array(
				'description' => __( 'Change the font color for the headings, post titles, widget titles and more.', 'her-exclusive' ),
				'label'       => __( 'Heading Color', 'her-exclusive' ),
				'section'     => 'colors',
				'settings'    => 'her_headings_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'her_body_color',
		array(
			'default'           => her_customizer_get_default_body_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'her_body_color',
			array(
				'description' => __( 'Change the body font color.', 'her-exclusive' ),
				'label'       => __( 'Body Font Color', 'her-exclusive' ),
				'section'     => 'colors',
				'settings'    => 'her_body_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'her_button_color',
		array(
			'default'           => her_customizer_get_default_button_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'her_button_color',
			array(
				'description' => __( 'Change the default button color.', 'her-exclusive' ),
				'label'       => __( 'Button Color', 'her-exclusive' ),
				'section'     => 'colors',
				'settings'    => 'her_button_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'her_button_font_color',
		array(
			'default'           => her_customizer_get_default_button_font_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'her_button_font_color',
			array(
				'description' => __( 'Change the default button font color.', 'her-exclusive' ),
				'label'       => __( 'Button Font Color', 'her-exclusive' ),
				'section'     => 'colors',
				'settings'    => 'her_button_font_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'her_double_border_color',
		array(
			'default'           => her_customizer_get_default_double_border_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'her_double_border_color',
			array(
				'description' => __( 'Change the double border color.', 'her-exclusive' ),
				'label'       => __( 'Double Border Color', 'her-exclusive' ),
				'section'     => 'colors',
				'settings'    => 'her_double_border_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'her_textbox2_color',
		array(
			'default'           => her_customizer_get_default_textbox2_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'her_textbox2_color',
			array(
				'description' => __( 'Change the pink call to action box color.', 'her-exclusive' ),
				'label'       => __( 'Pink Call to Action Box', 'her-exclusive' ),
				'section'     => 'colors',
				'settings'    => 'her_textbox2_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'her_textbox2_font_color',
		array(
			'default'           => her_customizer_get_default_textbox2_font_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'her_textbox2_font_color',
			array(
				'description' => __( 'Change the pink, call to action box font color.', 'her-exclusive' ),
				'label'       => __( 'Pink Call to Action Font Color', 'her-exclusive' ),
				'section'     => 'colors',
				'settings'    => 'her_textbox2_font_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'her_textbox3_color',
		array(
			'default'           => her_customizer_get_default_textbox3_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'her_textbox3_color',
			array(
				'description' => __( 'Change the black, call to action box color.', 'her-exclusive' ),
				'label'       => __( 'Black Call to Action Box', 'her-exclusive' ),
				'section'     => 'colors',
				'settings'    => 'her_textbox3_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'her_textbox3_font_color',
		array(
			'default'           => her_customizer_get_default_textbox3_font_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'her_textbox3_font_color',
			array(
				'description' => __( 'Change the black, call to action box font color.', 'her-exclusive' ),
				'label'       => __( 'Black Call to Action Font Color', 'her-exclusive' ),
				'section'     => 'colors',
				'settings'    => 'her_textbox3_font_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'her_textbox4_color',
		array(
			'default'           => her_customizer_get_default_textbox4_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'her_textbox4_color',
			array(
				'description' => __( 'Change the grey, call to action box color.', 'her-exclusive' ),
				'label'       => __( 'Grey Call to Action Box', 'her-exclusive' ),
				'section'     => 'colors',
				'settings'    => 'her_textbox4_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'her_textbox4_font_color',
		array(
			'default'           => her_customizer_get_default_textbox4_font_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'her_textbox4_font_color',
			array(
				'description' => __( 'Change the grey, call to action box font color.', 'her-exclusive' ),
				'label'       => __( 'Grey Call to Action Font Color', 'her-exclusive' ),
				'section'     => 'colors',
				'settings'    => 'her_textbox4_font_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'her_front_page_3_color',
		array(
			'default'           => her_customizer_get_default_front_page_3_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'her_front_page_3_color',
			array(
				'description' => __( 'Change the front page 3 background color.', 'her-exclusive' ),
				'label'       => __( 'Front Page 3 Background Color', 'her-exclusive' ),
				'section'     => 'colors',
				'settings'    => 'her_front_page_3_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'her_front_page_3_font_color',
		array(
			'default'           => her_customizer_get_default_front_page_3_font_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'her_front_page_3_font_color',
			array(
				'description' => __( 'Change the front page 3 font color.', 'her-exclusive' ),
				'label'       => __( 'Front Page 3 Font Color', 'her-exclusive' ),
				'section'     => 'colors',
				'settings'    => 'her_front_page_3_font_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'her_widget_above_footer_color',
		array(
			'default'           => her_customizer_get_default_widget_above_footer_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'her_widget_above_footer_color',
			array(
				'description' => __( 'Change the Widget Above Footer background color.', 'her-exclusive' ),
				'label'       => __( 'Widget Above Footer Background Color', 'her-exclusive' ),
				'section'     => 'colors',
				'settings'    => 'her_widget_above_footer_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'her_widget_above_footer_font_color',
		array(
			'default'           => her_customizer_get_default_widget_above_footer_font_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'her_widget_above_footer_font_color',
			array(
				'description' => __( 'Change the Widget Above Footer font color.', 'her-exclusive' ),
				'label'       => __( 'Widget Above Footer Font Color', 'her-exclusive' ),
				'section'     => 'colors',
				'settings'    => 'her_widget_above_footer_font_color',
			)
		)
	);

}
