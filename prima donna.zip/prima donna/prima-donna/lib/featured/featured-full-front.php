<div class="featured-area-full">
			
	<div id="owl-demo" class="owl-carousel">
		
			<?php
				
				$featured_cat = get_theme_mod( 'primadonna_front_featured_cat_setting' );
				$get_featured_posts = get_theme_mod('primadonna_front_featured_id_setting');
				$number = get_theme_mod( 'primadonna_front_featured_slider_slides_setting' );
				
				if($get_featured_posts) {
					$featured_posts = explode(',', $get_featured_posts);
					$args = array( 'showposts' => $number, 'post_type' => array('post', 'page'), 'post__in' => $featured_posts, 'orderby' => 'post__in' );
				} else {
					$args = array( 'cat' => $featured_cat, 'showposts' => $number );
				}
				
			?>
			
			<?php $feat_query = new WP_Query( $args ); ?>

			<?php if ($feat_query->have_posts()) : while ($feat_query->have_posts()) : $feat_query->the_post(); ?>
			<div class="item">
				<a href="<?php echo get_permalink() ?>"><?php the_post_thumbnail('full-slider'); ?></a>
				
				<div class="feat-overlay" onclick="location.href='<?php echo get_permalink(); ?>';">
					<div class="feat-text">
						<span class="cat"><?php the_category(', '); ?></span>
						<h3><a href="<?php echo get_permalink() ?>"><?php the_title(); ?></a></h3>
						<?php if(get_theme_mod('primadonna_front_slider_read_more_setting')) : ?>
							<a href="<?php echo get_permalink(); ?>" class="feat-more"><?php echo get_theme_mod('primadonna_front_slider_read_more_setting'); ?></a>
						<?php else : ?>
							<a href="<?php echo get_permalink(); ?>" class="feat-more"><?php _e( 'Read More', 'primadonna' ); ?></a>
						<?php endif; ?>
					</div>
				</div>

			</div>
		<?php endwhile; endif; ?>
	
	</div>
	
</div>