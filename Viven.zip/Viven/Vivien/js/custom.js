// Custom Script
(function ($){
	$(document).ready(function() {
		// window width
		var screen_width = $( window ).width();
		// Mobile Menu
		$( '.mobile_menu_wrap' ).click(function(){
			$( 'nav.nav-primary' ).slideToggle();
		});
		

		//Sticky Nav
		jQuery( window ).scroll(function() {
			if( jQuery(this).scrollTop() > 300 ){ 
				jQuery(".zp_sticky_nav").slideDown(200);
			}else{
				jQuery(".zp_sticky_nav").slideUp(200);
			}
		});

	


})(jQuery);


jQuery(function( $ ){
 
    var .image_section = [[0, 0], [100, 0], [100, 80], [0, 100]];
    $('.image-section').clipPath(.image_section, {
        isPercentage: true,
        svgDefId: '.image-section'
    });
 
});