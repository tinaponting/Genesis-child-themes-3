<?php
/**
 * Her Exclusive.
 * @package Her Exclusive
 */

/**
 * Get default accent color for Customizer.
 * Abstracted here since at least two functions use it.
 *
 * @since 1.0.0
 *
 * @return string Hex color code for accent color.
 */
function her_customizer_get_default_title_color() {
	return '#222222';
}

function her_customizer_get_default_description_color() {
	return '#222222';
}

function her_customizer_get_default_accent_color() {
	return '#e7d4c6';
}

function her_customizer_get_default_accent_hover_color() {
	return '#222222';
}

function her_customizer_get_default_headings_color() {
	return '#222222';
}

function her_customizer_get_default_body_color() {
	return '#222222';
}

function her_customizer_get_default_button_color() {
	return '#e7d4c6';
}

function her_customizer_get_default_button_font_color() {
	return '#222222';
}

function her_customizer_get_default_double_border_color() {
	return '#f5f5f5';
}

function her_customizer_get_default_textbox2_color() {
	return '#feece8';
}

function her_customizer_get_default_textbox2_font_color() {
	return '#222222';
}

function her_customizer_get_default_textbox3_color() {
	return '#222222';
}

function her_customizer_get_default_textbox3_font_color() {
	return '#ffffff';
}

function her_customizer_get_default_textbox4_color() {
	return '#f5f5f5';
}

function her_customizer_get_default_textbox4_font_color() {
	return '#222222';
}


function her_customizer_get_default_front_page_3_color() {
	return '#f5f5f5';
}

function her_customizer_get_default_front_page_3_font_color() {
	return '#222222';
}

function her_customizer_get_default_widget_above_footer_color() {
	return '#f5f5f5';
}

function her_customizer_get_default_widget_above_footer_font_color() {
	return '#222222';
}
