( function( $ ) {

    // init Isotope
    var $grid = $( '.content' ).isotope({

        // specifies which child elements will be used as item elements in the layout
        itemSelector: '.entry',

        // sets item positions in percent values, rather than pixel values
        percentPosition: true,

        // lays out items to (mostly) maintain horizontal left-to-right order
        horizontalOrder: true,

        masonry: {

            // use outer width of grid-sizer for columnWidth
            columnWidth: '.grid-sizer',

            // adds horizontal space between item elements
            gutter: '.gutter-sizer'
        }
    });

    // filter items on button click
    $( '.filter-button-group' ).on( 'click', 'button', function() {
        var filterValue = $( this ).attr( 'data-filter' );

        $grid.isotope({ filter: filterValue });

        $( this )
            .parent( 'div' )
            .find( 'button' )
            .removeClass( 'active' );

        $( this ).addClass( 'active' );
    });

    // layout Isotope after each image loads
    $grid.imagesLoaded().progress( function() {
        $grid.isotope( 'layout' );
    });
}( jQuery ) );