<?php
/**
 * Chef Pro.
 * @package Chef
 */

add_filter( 'genesis_theme_settings_defaults', 'chef_pro_theme_defaults' );
/**
* Updates theme settings on reset.
*
* @since 2.2.3
*/
function chef_pro_theme_defaults( $defaults ) {

	$defaults['blog_cat_num']              = 9;
	$defaults['content_archive']           = 'full';
	$defaults['content_archive_limit']     = 90;
	$defaults['content_archive_thumbnail'] = 'featured-square';
	$defaults['posts_nav']                 = 'numeric';
	$defaults['site_layout']               = 'content-sidebar';

	return $defaults;

}

add_action( 'after_switch_theme', 'chef_pro_theme_setting_defaults' );
/**
* Updates theme settings on activation.
*
* @since 2.2.3
*/
function chef_pro_theme_setting_defaults() {

	if ( function_exists( 'genesis_update_settings' ) ) {

		genesis_update_settings( array(
			'blog_cat_num'              => 9,
			'content_archive'           => 'full',
			'content_archive_limit'     => 90,
			'content_archive_thumbnail' => 'featured-square',
			'posts_nav'                 => 'numeric',
			'site_layout'               => 'content-sidebar',
		) );

	}

	update_option( 'posts_per_page', 9 );

}

add_action( 'genesis_admin_before_metaboxes', 'chef_pro_remove_unwanted_genesis_metaboxes' );
/**
 * Remove header metabox in Genesis Theme Settings
 */
function chef_pro_remove_unwanted_genesis_metaboxes() {
	remove_meta_box( 'genesis-theme-settings-header', 'toplevel_page_genesis', 'main' );
}
