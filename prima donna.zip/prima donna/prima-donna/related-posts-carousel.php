<?php
function ll_rp_carousel($atts, $content = null) {
	global $post;
	$randomid = rand();
	extract(shortcode_atts(array(
		'title' => '',
		'visible' => '3',
		'posts' => '5',
		'category' => ''
	), $atts));
	ob_start();
?> 
	
	<script>
	jQuery(document).ready(function(){
	jQuery("#posts-carousel-<?php echo $randomid ?>").owlCarousel({
		responsiveClass:true,
		responsive:{
			0:{
				items:1,
				nav:true
			},
			600:{
				items:3,
				nav:true
			},
			1000:{
				items:4,
				nav:true,
				loop:false
			}
		},
		margin: 10,
		dots : false,
		nav: true,
		navText: [
			"<i class='icon-chevron-left icon-white'></i>",
			"<i class='icon-chevron-right icon-white'</i>"
		],
	
		});
	});
	</script>
							  
	<div class="related-container">
		<span class="rltd-main-ttl"><h4>RELATED POSTS</h4></span>	
		<div id="posts-carousel-<?php echo $randomid ?>" class="owl-carousel">
		<?php
			$args = array(
				'post_status' => 'publish',
				'post_type' => 'post',
				'category_name' => $category,
				'posts_per_page' => $posts
			);
			$recentPosts = new WP_Query( $args );
				if ( $recentPosts->have_posts() ) : ?>
					<?php while ( $recentPosts->have_posts() ) : $recentPosts->the_post(); ?>
							<div class="slider-content">
								<div class="grow grow-image">
									<?php if ( has_post_thumbnail() ) {
										the_post_thumbnail( 'Related_Posts' );
									} else {
										echo '<img src="' . get_stylesheet_directory_uri() . '/images/placeholder_related.jpg" />';
									};	?>	 
								</div>	
								<a href="<?php echo esc_url( the_permalink() ); ?>" title="<?php echo esc_attr( the_title() ); ?>" class="rltd-ttl-cntnr">				
								<div class="rltd-ttl-algnr">
									<div class="rltd-ttl"><?php echo wp_trim_words( get_the_title(),15 ); ?></div>
								<span class="excrpt-date"><?php echo do_shortcode("[post_date]"); ?></span>
								<span class="plus-sign"><i class="fa fa-plus-circle"></i></span>
								</div>
								</a>
							</div><!-- .slider-content -->
					
					
					<?php endwhile; // end of the loop. ?>
						
					<?php
	   
					endif; 
					wp_reset_query();
					
					?>
		</div><!-- .owl-carousel -->
	</div><!-- .container -->
	<div class="clearfix"></div>
	<?php
		$content = ob_get_contents();
		ob_end_clean();	
		return $content;
}

add_shortcode("related_carousel","ll_rp_carousel");