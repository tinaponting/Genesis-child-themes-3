<?php
/**
 * Ellie Jane.
 * @package Ellie Jane
 */

/**
 * Add widget support for homepage. If no widgets active, display the default loop.
 *
 * @since 3.0.0
 */

add_action( 'genesis_meta', 'ellie_home_genesis_meta' );
function ellie_home_genesis_meta() {

	if ( is_active_sidebar( 'slider-content' ) || is_active_sidebar( 'home-page-2' ) || is_active_sidebar( 'home-page-3' ) ) {

		// Add body class
		add_filter( 'body_class', 'ellie_body_class' );

		// Add widgets on Front Page.
		add_action( 'genesis_before_content_sidebar_wrap', 'ellie_homepage_widgets', 1 );
		
		//* Remove default loop & sidebar (remove the // symbols in front of the next two lines to remove the default blog loop and sidebar from the homepage of Ellie Jane.)
		//remove_action( 'genesis_loop', 'genesis_do_loop' );
		//remove_action( 'genesis_sidebar', 'genesis_do_sidebar' ); 

	}

}

// Add body class to homepage.
function ellie_body_class( $classes ) {
			$classes[] = 'ellie-jane-home';
			return $classes;
}


//* Add Widgets to Homepage
function ellie_homepage_widgets() {

if( !is_paged()) {

	echo '<h2 class="screen-reader-text">' . __( 'Main Content', 'ellie-jane' ) . '</h2>';

	genesis_widget_area( 'slider-content', array(
		'before' => '<div class="slider-content widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );

	genesis_widget_area( 'home-page-2', array(
		'before' => '<div class="home-page-2 widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );

	genesis_widget_area( 'home-page-3', array(
		'before' => '<div class="home-page-3 flexible-widgets'. custom_widget_area_class( 'home-page-3' ) .' widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );

	}
}

// Run the Genesis loop.
genesis();