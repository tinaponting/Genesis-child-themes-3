<?php
/**
 * sweets Landing Page.
 * @package      Hello Sweets
 */

/*
Template Name: Landing
*/

//* Add custom body class to the head
add_filter( 'body_class', 'sweets_add_body_class' );
function sweets_add_body_class( $classes ) {

   $classes[] = 'sweets-landing';
   return $classes;

}

//* Force full width content layout
add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );

//* Remove navigation
remove_action( 'genesis_before_header', 'genesis_do_nav' );
remove_action( 'genesis_before_footer', 'genesis_do_subnav');

//* Remove breadcrumbs
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );

//* Remove site footer widgets
remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );



//* Run the Genesis loop
genesis();
