<?php
/**
 * This file adds all the settings for the Custom Lookbook archive template of the Prima Donna theme.
 * @package      Prima Donna
 */

/*
Template Name: Lookbook
*/

//* Reposition Featured Images - Moves FI above title
 remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
 add_action( 'genesis_before_entry_content', 'genesis_do_post_image', 5 );

 //* Remove Featured image (if set in Theme Settings)
add_filter( 'genesis_pre_get_option_content_archive_thumbnail', 'primadonna_no_post_image' );
function primadonna_no_post_image() {
	return '0';
}
//* Display centered wide featured image for First Post 
add_action( 'genesis_before_entry_content', 'primadonna_show_featured_image', 8 );
function primadonna_show_featured_image() {
	if ( ! has_post_thumbnail() ) {
		return;
	}
		$image_args = array(
			'size' => 'square-entry-image',
			'attr' => array(
				'class' => 'alignnone',
			),
		);

	$image = genesis_get_image( $image_args );

	echo '<div class="home-featured-image"><a href="' . get_permalink() . '">' . $image .'</a></div>';
}

 //* Customize the post info function
add_filter( 'genesis_post_info', 'primadonna_post_info_filter_lookbook' );
function primadonna_post_info_filter_lookbook($post_info) {
if ( !is_page() ) {
	$post_info = '[post_date]';
	return $post_info;
}}

 //* Remove the post content
remove_action( 'genesis_entry_content', 'genesis_do_post_content' );

//* Remove the entry meta in the entry footer (requires HTML5 theme support)
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

remove_action( 'genesis_after_entry_content', 'primadonna_shop_the_post' );

//** Grid Layout **//
add_filter( 'body_class', 'primadonna_grid_body_class' );
function primadonna_grid_body_class( $classes ) {
	
	$classes[] = 'grid';
	return $classes;
	
}

function primadonna_grid_post_class( $classes ) {
	// Don't run on single posts or pages
	if( is_singular() )
		return $classes;
	$classes[] = 'one-third';
	global $wp_query;
	if( 0 == $wp_query->current_post || 0 == $wp_query->current_post % 3 )
		$classes[] = 'first';
	return $classes;
}

add_filter( 'post_class', 'primadonna_grid_post_class' );


genesis();
