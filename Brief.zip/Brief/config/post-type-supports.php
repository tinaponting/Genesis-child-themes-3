<?php
/**
 * Brief child theme.
 * @package Brief
 */

return [
	'post' => [
		'genesis-singular-images',
	],
	'page' => [
		'genesis-singular-images',
	],
];
