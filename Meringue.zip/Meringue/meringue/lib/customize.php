<?php
/**
 * Customizer additions.
 * @package      Meringue
 */
 
/**
 * Get default primary titles color for Customizer.
 *
 * Abstracted here since at least two functions use it.
 *
 * @since 1.0.0
 *
 * @return string Hex color code for Primary Color.
 */
function meringue_customizer_get_default_primary_color() {
	return '#6c385a';
}
 
add_action( 'customize_register', 'meringue_customizer_register' );
/**
 * Register settings and controls with the Customizer.
 *
 * @since 1.0.0
 * 
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function meringue_customizer_register() {

	global $wp_customize;
	
	
	$wp_customize->add_setting(
		'meringue_primary_color',
		array(
			'default' => meringue_customizer_get_default_primary_color(),
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'meringue_primary_color',
			array(
				'description' => __( 'Change the default primary color.', 'meringue' ),
			    'label'    => __( 'Primary Color', 'meringue' ),
			    'section'  => 'colors',
			    'settings' => 'meringue_primary_color',
			)
		)
	);

}

add_action( 'wp_enqueue_scripts', 'meringue_css' );
/**
* Checks the settings for the above color options.
* If any of these value are set the appropriate CSS is output
*
* @since 1.0.0
*/
function meringue_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';

	$color = get_theme_mod( 'meringue_primary_color', meringue_customizer_get_default_primary_color() );


	$css = '';
		
	$css .= ( meringue_customizer_get_default_primary_color() !== $color ) ? sprintf( '
		
		.meringue a,
		.meringue h5,
		.meringue button,
		.meringue input[type="button"],
		.meringue input[type="reset"],
		.meringue input[type="submit"],
		.meringue .button,
		.meringue .author-box-title,
		.meringue .search-form input[type="submit"],
		.meringue .entry-title a:hover,
		.meringue .entry-title a:focus,
		.meringue .above-header .enews-widget .widgettitle,
		.meringue .content .enews-widget .widgettitle,
		.meringue .featured-content a:hover,
		.meringue .enews-widget input[type="submit"],
		.meringue .nav-primary .genesis-nav-menu a:hover,
		.meringue .nav-primary .genesis-nav-menu a:focus,
		.meringue .nav-primary .genesis-nav-menu .current-menu-item > a,
		.meringue .nav-primary .genesis-nav-menu .sub-menu a:hover,
		.meringue .nav-primary .genesis-nav-menu .sub-menu a:focus,
		.meringue .nav-primary .genesis-nav-menu .sub-menu .current-menu-item > a,
		.meringue .nav-secondary .genesis-nav-menu a:hover,
		.meringue .nav-secondary .genesis-nav-menu a:focus,
		.meringue .nav-secondary .genesis-nav-menu .current-menu-item > a,
		.meringue .nav-secondary .genesis-nav-menu .sub-menu a:hover,
		.meringue .nav-secondary .genesis-nav-menu .sub-menu a:focus,
		.meringue .nav-secondary .genesis-nav-menu .sub-menu .current-menu-item > a,
		.meringue .adjacent-entry-pagination a:hover,
		.meringue .recipe-index .sidebar li a:hover,
		.meringue .recipe-index .sidebar li:before,
		.meringue .recipe-index .pagination-next a,
		.meringue .entry-header .entry-categories a,
		.meringue .sidebar .entry-header .entry-comments-link a:hover,
		.meringue .entry-tags:before,
		.meringue .entry-footer .entry-meta a:hover,
		.meringue .sidebar .entry-header .entry-comments-link:before,
		.meringue .archive-pagination li a:hover,
		.meringue .archive-pagination li a:focus,
		.meringue .archive-pagination .active a,
		.meringue .comment-reply-link,
		.meringue .footer-widgets a:hover,
		.meringue .genesis-nav-menu.responsive-menu li a:hover,
		.meringue .genesis-nav-menu.responsive-menu .current-menu-item > a,
		.meringue .nav-primary .genesis-nav-menu.responsive-menu .sub-menu a:hover,
		.meringue .genesis-nav-menu.responsive-menu > .menu-item-has-children:before,
		.meringue .content .share-filled .facebook .count,
		.meringue .content .share-filled .facebook .count:hover,
		.meringue .content .share-filled .googlePlus .count,
		.meringue .content .share-filled .googlePlus .count:hover,
		.meringue .content .share-filled .linkedin .count,
		.meringue .content .share-filled .linkedin .count:hover,
		.meringue .content .share-filled .pinterest .count,
		.meringue .content .share-filled .pinterest .count:hover,
		.meringue .content .share-filled .stumbleupon .count,
		.meringue .content .share-filled .stumbleupon .count:hover,
		.meringue .content .share-filled .twitter .count,
		.meringue .content .share-filled .twitter .count:hover,
		.meringue .read-more,
		.meringue .more-from-category a {
			color: %1$s;
		}

		.meringue .below-header .entry-title a:hover,
		.meringue #sb_instagram .sbi_follow_btn a,
		.meringue .easyrecipe .ui-button .ui-button-text,
		.meringue .easyrecipe .ERSTimeHeading,
		.meringue .easyrecipe .ERSAuthor,
		.meringue .easyrecipe .ERSCategory,
		.meringue .easyrecipe .ERSCuisine,
		.meringue .easyrecipe .ERSServes,
		.meringue .easyrecipe .ERSIngredients li.ingredient:before,
		.meringue div.easyrecipe .ERSSectionHead,
		.woocommerce .sidebar li a:hover,
		.woocommerce .sidebar li:before,
		.woocommerce .woocommerce-message:before,
		.woocommerce-page .woocommerce-message:before,
		.woocommerce .woocommerce-info:before,
		.woocommerce-page .woocommerce-info:before,
		.woocommerce .woocommerce-error:before,
		.woocommerce-page .woocommerce-error:before,
		.woocommerce #content div.product p.price,
		.woocommerce #content div.product span.price,
		.woocommerce div.product p.price,
		.woocommerce div.product span.price,
		.woocommerce-page #content div.product p.price,
		.woocommerce-page #content div.product span.price,
		.woocommerce-page div.product p.price,
		.woocommerce-page div.product span.price,
		.home span.amount,
		.home ins,
		.woocommerce ul.products li.product .price,
		.woocommerce-page ul.products li.product .price,
		.woocommerce ul.products li.product span.amount,
		.woocommerce-page ul.products li.product span.amount,
		.woocommerce #content nav.woocommerce-pagination ul li a:focus,
		.woocommerce #content nav.woocommerce-pagination ul li a:hover,
		.woocommerce #content nav.woocommerce-pagination ul li span.current,
		.woocommerce nav.woocommerce-pagination ul li a:focus,
		.woocommerce nav.woocommerce-pagination ul li a:hover,
		.woocommerce nav.woocommerce-pagination ul li span.current,
		.woocommerce-page #content nav.woocommerce-pagination ul li a:focus,
		.woocommerce-page #content nav.woocommerce-pagination ul li a:hover,
		.woocommerce-page #content nav.woocommerce-pagination ul li span.current,
		.woocommerce-page nav.woocommerce-pagination ul li a:focus,
		.woocommerce-page nav.woocommerce-pagination ul li a:hover,
		.woocommerce-page nav.woocommerce-pagination ul li span.current,
		.woocommerce #content input.button,
		.woocommerce #respond input#submit,
		.woocommerce a.button,
		.woocommerce button.button,
		.woocommerce input.button,
		.woocommerce-page #content input.button,
		.woocommerce-page #respond input#submit,
		.woocommerce-page a.button,
		.woocommerce-page button.button,
		.woocommerce-page input.button,
		.woocommerce #content input.button.disabled,
		.woocommerce #content input.button:disabled,
		.woocommerce #respond input#submit.disabled,
		.woocommerce #respond input#submit:disabled,
		.woocommerce a.button.disabled,
		.woocommerce a.button:disabled,
		.woocommerce button.button.disabled,
		.woocommerce button.button:disabled,
		.woocommerce input.button.disabled,
		.woocommerce input.button:disabled,
		.woocommerce-page #content input.button.disabled,
		.woocommerce-page #content input.button:disabled,
		.woocommerce-page #respond input#submit.disabled,
		.woocommerce-page #respond input#submit:disabled,
		.woocommerce-page a.button.disabled,
		.woocommerce-page a.button:disabled,
		.woocommerce-page button.button.disabled,
		.woocommerce-page button.button:disabled,
		.woocommerce-page input.button.disabled,
		.woocommerce-page input.button:disabled,
		.woocommerce #content table.cart a.remove,
		.woocommerce table.cart a.remove,
		.woocommerce-page #content table.cart a.remove,
		.woocommerce-page table.cart a.remove,
		.woocommerce.widget_top_rated_products a:hover,
		.woocommerce .widget_layered_nav ul li.chosen a,
		.woocommerce-page .widget_layered_nav ul li.chosen a,
		.woocommerce li span.amount {
			color: %1$s!important;
		}

		.meringue .recipe-index-top {
			background: %1$s;
		}

		.meringue .tabber-widget-basic-light ul.tabber-widget-tabs a.selected,
		.meringue .tabber-widget-basic-light ul.tabber-widget-tabs a.selected:hover {
			background-color: %1$s!important;
		}

		.woocommerce .widget_price_filter .ui-slider .ui-slider-handle,
		.woocommerce-page .widget_price_filter .ui-slider .ui-slider-handle {
			background-color: %1$s!important;
		}

		.meringue .content .share-filled .facebook .share,
		.meringue .content .share-filled .googlePlus .share,
		.meringue .content .share-filled .linkedin .share,
		.meringue .content .share-filled .pinterest .share,
		.meringue .content .share-filled .stumbleupon .share,
		.meringue .content .share-filled .twitter .share,
		.meringue .tabber-widget-basic-light ul.tabber-widget-tabs a:hover,
		.woocommerce #payment div.payment_box,
		.woocommerce-page #payment div.payment_box,
		.woocommerce ul.products li.product .onsale,
		.woocommerce span.onsale {
			background: %1$s!important;
		}

		.meringue button,
		.meringue input[type="button"],
		.meringue input[type="reset"],
		.meringue input[type="submit"],
		.meringue .button, 
		.meringue .enews-widget input[type="submit"],
		.meringue .read-more,
		.meringue .more-from-category a,
		.meringue .genesis-nav-menu .sub-menu,
		.meringue .recipe-index .pagination-next a,
		.meringue .entry-header .entry-categories,
		.meringue .comment-reply-link,
		.meringue .content .share-filled .facebook .count,
		.meringue .content .share-filled .facebook .count:hover,
		.meringue .content .share-filled .googlePlus .count,
		.meringue .content .share-filled .googlePlus .count:hover,
		.meringue .content .share-filled .linkedin .count,
		.meringue .content .share-filled .linkedin .count:hover,
		.meringue .content .share-filled .pinterest .count,
		.meringue .content .share-filled .pinterest .count:hover,
		.meringue .content .share-filled .stumbleupon .count,
		.meringue .content .share-filled .stumbleupon .count:hover,
		.meringue .content .share-filled .twitter .count,
		.meringue .content .share-filled .twitter .count:hover {
			border-color: %1$s;
		}

		.meringue .sidebar .widgettitle span,
		.meringue .content .widgettitle span {
			border-bottom: 3px solid %1$s!important;
		}


		.woocommerce #payment div.payment_box input.input-text,
		.woocommerce #payment div.payment_box textarea,
		.woocommerce-page #payment div.payment_box input.input-text,
		.woocommerce-page #payment div.payment_box textarea {
			border-top-color: %1$s;
		}

		.woocommerce #content input.button,
		.woocommerce #respond input#submit,
		.woocommerce-page #content input.button,
		.woocommerce-page #respond input#submit,
		.woocommerce-page a.button,
		.woocommerce-page button.button,
		.woocommerce-page input.button,
		.woocommerce #content input.button.disabled,
		.woocommerce #content input.button:disabled,
		.woocommerce #respond input#submit.disabled,
		.woocommerce #respond input#submit:disabled,
		.woocommerce a.button.disabled,
		.woocommerce a.button:disabled,
		.woocommerce button.button.disabled,
		.woocommerce button.button:disabled,
		.woocommerce input.button.disabled,
		.woocommerce input.button:disabled,
		.woocommerce-page #content input.button.disabled,
		.woocommerce-page #content input.button:disabled,
		.woocommerce-page #respond input#submit.disabled,
		.woocommerce-page #respond input#submit:disabled,
		.woocommerce-page a.button.disabled,
		.woocommerce-page a.button:disabled,
		.woocommerce-page button.button.disabled,
		.woocommerce-page button.button:disabled,
		.woocommerce-page input.button.disabled,
		.woocommerce-page input.button:disabled,
		.woocommerce #payment div.payment_box input.input-text,
		.woocommerce #payment div.payment_box textarea,
		.woocommerce-page #payment div.payment_box input.input-text,
		.woocommerce-page #payment div.payment_box textarea,
		.meringue #sb_instagram .sbi_follow_btn a,
		.meringue .easyrecipe .ERSTimes,
		.meringue .easyrecipe .ERSSavePrint .ERSPrintBtnSpan .ERSPrintBtn {
			border-color: %1$s!important;
		}

		
		', $color ) : '';
		
		
	if ( meringue_customizer_get_default_primary_color() !== $color_primary  ) {
		$css .= '
		}
		';
	}

	if( $css ){
		wp_add_inline_style( $handle, $css );
	}

}
