<?php
remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_loop', 'hd_es_404' );

function hd_es_404() {
	if(is_404()){
		$pag_404 = get_field('pag_404', 'option');
		if($pag_404){
			$pagina = get_post($pag_404);
			setup_postdata( $pagina, $more_link_text, $stripteaser );
			echo '<h1 class="entry-title">'. get_the_title($pag_404) .'</h1>';
			the_content();
			wp_reset_postdata( $pagina );
		}else{
			echo '<h1 class="entry-title">'. __('Page not found', 'flamingo_theme') .'</h1>';
			echo '<img src="'. get_stylesheet_directory_uri() .'/images/error-404.svg" alt="" class="img404" />';
			echo '<p class="p404">'. __('Could not find the page you are looking for.', 'flamingo_theme') .'<br />';
			echo __('Please, try again!', 'flamingo_theme') .'</p>';
		}
	}
}

genesis();