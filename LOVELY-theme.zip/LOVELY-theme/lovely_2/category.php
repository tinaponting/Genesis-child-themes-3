<?php
/**
 * This file adds the category archive template.
 *
 */

//* Force full width content layout
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

//* Remove the breadcrumb navigation
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );

//* Remove the post info function
remove_action( 'genesis_entry_header', 'genesis_post_info', 5 );

//* Remove the post content
remove_action( 'genesis_entry_content', 'genesis_do_post_content' );

//* Remove the post image
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );


//* Add portfolio body class to the head
add_filter( 'body_class', 'nambahin_class' );
function nambahin_class( $classes ) {
   $classes[] = 'layout-kolom';
   return $classes;
}

//* title
function ea_default_term_title( $value, $term_id, $meta_key, $single ) {
	if( ( is_category() || is_tag() || is_tax() ) && 'headline' == $meta_key && ! is_admin() ) {
	
		// Grab the current value, be sure to remove and re-add the hook to avoid infinite loops
		remove_action( 'get_term_metadata', 'ea_default_term_title', 10 );
		$value = get_term_meta( $term_id, 'headline', true );
		add_action( 'get_term_metadata', 'ea_default_term_title', 10, 4 );
		// Use term name if empty
		if( empty( $value ) ) {
			$term = get_term_by( 'term_taxonomy_id', $term_id );
			$value = $term->name;
		}
	
	}
	return $value;		
}
add_filter( 'get_term_metadata', 'ea_default_term_title', 10, 4 );


/*** Bentuk Kolom ***/
function be_portfolio_post_class( $classes ) {
	$columns = 3; // Set the number of columns here

	$column_classes = array( '', '', 'one-half', 'one-third', 'one-fourth', 'one-fifth', 'one-sixth' );
	$classes[] = $column_classes[$columns];
	global $wp_query;
	if( 0 == $wp_query->current_post || 0 == $wp_query->current_post % $columns )
		$classes[] = 'first';

	return $classes;
}
add_filter( 'post_class', 'be_portfolio_post_class' );



//* Tambahin Featured Imagenya
add_action( 'genesis_entry_header', 'archive_cat_feat_image', 1 );
function archive_cat_feat_image() {
if ( $image = genesis_get_image( 'format=url&size=cat_image' ) ) {
        printf( '<div class="cat_archive_featimg"><a href="%s" rel="bookmark"><img src="%s" alt="%s" /></a></div>', get_permalink(), $image, the_title_attribute( 'echo=0' ) );

    }
}

//* Remove the post meta function
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

genesis();
