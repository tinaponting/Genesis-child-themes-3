<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Enqueue Lato Google font
add_action( 'wp_enqueue_scripts', 'genesis_sample_google_fonts' );
function genesis_sample_google_fonts() {
	wp_enqueue_style( 'google-font-lato', '//fonts.googleapis.com/css?family=Glegoo|Sanchez:400italic,400', array(), CHILD_THEME_VERSION );
}

//* Create additional color style options
add_theme_support( 'genesis-style-selector', array(
	'delightful-summer'	=>	__( 'Summer', 'jade' ),
	'delightful-nautical'	=>	__( 'Nautical', 'jade' ),
	'delightful-vintage'	=>	__( 'Vintage', 'jade' ),
) );

//* Add new image sizes
add_image_size( 'home-bottom', 150, 150, TRUE );
add_image_size( 'home-middle', 336, 190, TRUE );
add_image_size( 'home-top', 708, 400, TRUE );
add_image_size( 'portfolio', 336, 190, TRUE );

//* Add HTML5 markup structure
add_theme_support( 'html5' );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom header
add_theme_support( 'custom-header' );

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Add the newsletter widget after the post content
add_action( 'genesis_entry_footer', 'custom_add_newsletter_box' );
function custom_add_newsletter_box() {
if ( is_singular( 'post' ) )
genesis_widget_area( 'newsletter', array(
'before' => '<div class="newsletter">',
) );
}

//* Customize the credits 
add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');
function custom_footer_creds_text() {
    echo '<div class="creds"><p>';
    echo 'Copyright &copy; ';
    echo date('Y');
    echo ' &middot; <a target="_blank" href="https://exempel.se">EXEMPEL</a> by <a target="_blank" href="https://exempel.se">EXEMPEL</a>';
    echo '</p></div>';

}

//* Register widget areas
genesis_register_sidebar( array(
	'id'				=> 'home-top',
	'name'			=> __( 'Home - Top', 'delightful' ),
	'description'	=> __( 'This is the top section of the homepage.', 'delightful' ),
) );
genesis_register_sidebar( array(
	'id'				=> 'home-middle-left',
	'name'			=> __( 'Home - Middle Left', 'delightful' ),
	'description'	=> __( 'This is the middle left section of the homepage.', 'delightful' ),
) );
genesis_register_sidebar( array(
	'id'				=> 'home-middle-right',
	'name'			=> __( 'Home - Middle Right', 'delightful' ),
	'description'	=> __( 'This is the middle right section of the homepage.', 'delightful' ),
) );
genesis_register_sidebar( array(
	'id'				=> 'home-bottom',
	'name'			=> __( 'Home - Bottom', 'delightful' ),
	'description'	=> __( 'This is the bottom section of the homepage.', 'delightful' ),
) );
genesis_register_sidebar( array(
	'id'				=> 'newsletter',
	'name'			=> __( 'Newsletter', 'delightful' ),
	'description'	=> __( 'This is the newsletter section at the bottom of single posts.', 'delightful' ),
) );
genesis_register_sidebar( array(
	'id'				=> 'portfolio',
	'name'			=> __( 'Portfolio', 'delightful' ),
	'description'	=> __( 'This is the portfolio section of the portfolio page.', 'delightful' ),
) );
