<?php
/**
 * This file adds the Custom Search to the Prima Donna Theme.
 * @package      Prima Donna
 */
 
//* Adds a CSS class to the body element
add_filter( 'body_class', 'primadonna_archives_body_class' );
function primadonna_archives_body_class( $classes ) {

	$classes[] = 'primadonna-archives';
	return $classes;
}

// Force full page layout if sidebar disabled
$disablesidebar = get_theme_mod( 'primadonna_archive_sidebar_setting', 'false' );
if ( $disablesidebar === 'false' ) {
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
}

//* Reposition Featured Images - Moves FI above title
$filayout = get_theme_mod( 'primadonna_fi_setting', 'true' );
if ( $filayout === 'false' ) {
 remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
 add_action( 'genesis_entry_header', 'genesis_do_post_image', 5 );
}

//* Make sure content limit (if set in Theme Settings) doesn't apply
add_filter( 'genesis_pre_get_option_content_archive_limit', 'primadonna_no_content_limit' );
function primadonna_no_content_limit() {
	return '0';
}

add_action( 'genesis_before_content', 'genesis_do_search_title' );
/**
 * Echo the title with the search term.
 *
 * @since 1.9.0
 */
function genesis_do_search_title() {

	$title = sprintf( '<div class="archive-description"><h1 class="archive-title">%s %s</h1></div>', apply_filters( 'genesis_search_title_text', __( 'Search Results for:', 'genesis' ) ), get_search_query() );

	echo apply_filters( 'genesis_search_title_output', $title ) . "\n";

}

//* Blog Layout *//


//** Grid Layout **//
$gridlayout = get_theme_mod( 'primadonna_archive_setting', 'full' );
if ( $gridlayout === 'grid' ) {

add_filter( 'body_class', 'primadonna_grid_body_class' );
function primadonna_grid_body_class( $classes ) {
	
	$classes[] = 'grid';
	return $classes;
	
}
//* Remove Featured image (if set in Theme Settings)
add_filter( 'genesis_pre_get_option_content_archive_thumbnail', 'primadonna_no_post_image' );
function primadonna_no_post_image() {
	return '0';
}
//* Display centered wide featured image for First Post and left aligned thumbnail for the next five
add_action( 'genesis_entry_header', 'primadonna_show_featured_image', 8 );
function primadonna_show_featured_image() {
	if ( ! has_post_thumbnail() ) {
		return;
	}
		$image_args = array(
			'size' => 'horizontal-entry-image',
			'attr' => array(
				'class' => 'alignnone',
			),
		);

	$image = genesis_get_image( $image_args );

	echo '<div class="home-featured-image"><a href="' . get_permalink() . '">' . $image .'</a></div>';
}
//* Show Excerpts regardless of Theme Settings
add_filter( 'genesis_pre_get_option_content_archive', 'primadonna_show_excerpts' );
function primadonna_show_excerpts() {
	return 'excerpts';
}

//* Modify the length of post excerpts
add_filter( 'excerpt_length', 'primadonna_excerpt_length' );
function primadonna_excerpt_length( $length ) {
	return 35; // pull first 35 words
}
add_filter('excerpt_more', 'primadonna_grid_excerpt_more');
function primadonna_grid_excerpt_more($more) {
	return '... <a class="more-link" href="' . get_permalink() . '">[Continue Reading]</a>';
}
$fullgridlayout = get_theme_mod( 'primadonna_archive_column_setting', '2col' );
if ( $fullgridlayout === '2col' ) {
function primadonna_grid_post_class( $classes ) {
	// Don't run on single posts or pages
	if( is_singular() )
		return $classes;
	$classes[] = 'one-half';
	global $wp_query;
	if( 0 == $wp_query->current_post || 0 == $wp_query->current_post % 2 )
		$classes[] = 'first';
	return $classes;
}
}

$fullgridlayout = get_theme_mod( 'primadonna_archive_column_setting', '2col' );
if ( $fullgridlayout === '3col' ) {
function primadonna_grid_post_class( $classes ) {
	// Don't run on single posts or pages
	if( is_singular() )
		return $classes;
	$classes[] = 'one-third';
	global $wp_query;
	if( 0 == $wp_query->current_post || 0 == $wp_query->current_post % 3 )
		$classes[] = 'first';
	return $classes;
}
}
add_filter( 'post_class', 'primadonna_grid_post_class' );
}


//** First Full then Grid Layout **//
$fullgridlayout = get_theme_mod( 'primadonna_archive_setting', 'full' );
if ( $fullgridlayout === 'full_grid' ) {

add_filter( 'body_class', 'primadonna_grid_body_class' );
function primadonna_grid_body_class( $classes ) {
	
	$classes[] = 'full-grid';
	return $classes;
	
}
//* Remove Featured image (if set in Theme Settings)
add_filter( 'genesis_pre_get_option_content_archive_thumbnail', 'primadonna_no_post_image' );
function primadonna_no_post_image() {
	return '0';
}
//* Display centered wide featured image for First Post and left aligned thumbnail for the next five
add_action( 'genesis_entry_header', 'primadonna_show_featured_image', 8 );
function primadonna_show_featured_image() {
	if ( ! has_post_thumbnail() ) {
		return;
	}

	global $wp_query;

	if( ( $wp_query->current_post <= 0 ) ) {
		$image_args = array(
			'size' => 'full-thumbnail',
			'attr' => array(
				'class' => 'aligncenter',
			),
		);
	
	} else {
		$image_args = array(
			'size' => 'horizontal-entry-image',
			'attr' => array(
				'class' => 'alignnone',
			),
		);
	}

	$image = genesis_get_image( $image_args );

	echo '<div class="home-featured-image"><a href="' . get_permalink() . '">' . $image .'</a></div>';
}
//* Show Excerpts regardless of Theme Settings
add_filter( 'genesis_pre_get_option_content_archive', 'primadonna_show_excerpts' );
function primadonna_show_excerpts() {
	return 'excerpts';
}

//* Modify the length of post excerpts
add_filter( 'excerpt_length', 'primadonna_excerpt_length' );
function primadonna_excerpt_length( $length ) {
	return 35; // pull first 35 words
}
add_filter('excerpt_more', 'primadonna_grid_excerpt_more');
function primadonna_grid_excerpt_more($more) {
	return '... <a class="more-link" href="' . get_permalink() . '">[Continue Reading]</a>';
}
$fullgridlayout = get_theme_mod( 'primadonna_archive_column_setting', '2col' );
if ( $fullgridlayout === '2col' ) {
function primadonna_grid_post_class( $classes ) {
	// Don't run on single posts or pages
	if( is_singular() )
		return $classes;
	$classes[] = 'one-half';
	global $wp_query;
	if( 0 == $wp_query->current_post)
		$classes[] = 'first-post';
	if(  1 == $wp_query->current_post % 2)
		$classes[] = 'first';
	return $classes;
}
}
$fullgridlayout = get_theme_mod( 'primadonna_archive_column_setting', '2col' );
if ( $fullgridlayout === '3col' ) {
function primadonna_grid_post_class( $classes ) {
	// Don't run on single posts or pages
	if( is_singular() )
		return $classes;
	$classes[] = 'one-third';
	global $wp_query;
	if( 0 == $wp_query->current_post)
		$classes[] = 'first-post';
	if(  1 == $wp_query->current_post % 3)
		$classes[] = 'first';
	return $classes;
}
}
add_filter( 'post_class', 'primadonna_grid_post_class' );
}


//** List Layout **/
$listlayout = get_theme_mod( 'primadonna_archive_setting', 'full' );
if ( $listlayout === 'list' ) {

add_filter( 'body_class', 'primadonna_list_body_class' );
function primadonna_list_body_class( $classes ) {
	
	$classes[] = 'list';
	return $classes;
	
}
//* Remove Featured image (if set in Theme Settings)
add_filter( 'genesis_pre_get_option_content_archive_thumbnail', 'primadonna_no_post_image' );
function primadonna_no_post_image() {
	return '0';
}

//* Show Excerpts regardless of Theme Settings
add_filter( 'genesis_pre_get_option_content_archive', 'primadonna_show_excerpts' );
function primadonna_show_excerpts() {
	return 'excerpts';
}

//* Modify the length of post excerpts
add_filter( 'excerpt_length', 'primadonna_excerpt_length' );
function primadonna_excerpt_length( $length ) {
	return 45; // pull first 45 words
}

add_filter('excerpt_more', 'primadonna_list_excerpt_more');
function primadonna_list_excerpt_more($more) {
	return '... <a class="more-link" href="' . get_permalink() . '">[read more]</a>';
}

//* Display centered wide featured image for First Post and left aligned thumbnail for the next five
add_action( 'genesis_entry_header', 'primadonna_show_featured_image', 8 );
function primadonna_show_featured_image() {
	if ( ! has_post_thumbnail() ) {
		return;
	}
		$image_args = array(
			'size' => 'square-entry-image',
			'attr' => array(
				'class' => 'alignleft',
			),
		);

	$image = genesis_get_image( $image_args );

	echo '<div class="home-featured-image"><a href="' . get_permalink() . '">' . $image .'</a></div>';
}

}


//** 1st Full Then List Layout **/
$fulllistlayout = get_theme_mod( 'primadonna_archive_setting', 'full' );
if ( $fulllistlayout === 'full_list' ) {

add_filter( 'body_class', 'primadonna_list_body_class' );
function primadonna_list_body_class( $classes ) {
	
	$classes[] = 'list-full';
	return $classes;
	
}
//* Remove Featured image (if set in Theme Settings)
add_filter( 'genesis_pre_get_option_content_archive_thumbnail', 'primadonna_no_post_image' );
function primadonna_no_post_image() {
	return '0';
}

//* Show Excerpts regardless of Theme Settings
add_filter( 'genesis_pre_get_option_content_archive', 'primadonna_show_excerpts' );
function primadonna_show_excerpts() {
	return 'excerpts';
}

//* Modify the length of post excerpts
add_filter( 'excerpt_length', 'primadonna_excerpt_length' );
function primadonna_excerpt_length( $length ) {
	return 45; // pull first 45 words
}

add_filter('excerpt_more', 'primadonna_list_excerpt_more');
function primadonna_list_excerpt_more($more) {
	return '... <a class="more-link" href="' . get_permalink() . '">[read more]</a>';
}

//* Display centered wide featured image for First Post and left aligned thumbnail for the next five
add_action( 'genesis_entry_header', 'primadonna_show_featured_image', 8 );
function primadonna_show_featured_image() {
	if ( ! has_post_thumbnail() ) {
		return;
	}

	global $wp_query;

	if( ( $wp_query->current_post <= 0 ) ) {
		$image_args = array(
			'size' => 'full-thumbnail',
			'attr' => array(
				'class' => 'aligncenter',
			),
		);
	
	} else {
		$image_args = array(
			'size' => 'square-entry-image',
			'attr' => array(
				'class' => 'alignleft',
			),
		);
	}

	$image = genesis_get_image( $image_args );

	echo '<div class="home-featured-image"><a href="' . get_permalink() . '">' . $image .'</a></div>';
}
}

//** Masonry Layout **//
$masonrylayout = get_theme_mod( 'primadonna_archive_setting', 'full' );
if ( $masonrylayout === 'masonry' ) {

//Add Masonry body class
add_filter( 'body_class', 'primadonna_masonry_body_class' );
function primadonna_masonry_body_class( $classes ) {
	
	$classes[] = 'masonry-posts-archive';
	return $classes;	
}
add_action( 'wp_enqueue_scripts', 'primadonna_masonry_enqueue_scripts' );
function primadonna_masonry_enqueue_scripts() {
wp_enqueue_script( 'masonry' );
wp_enqueue_script( 'masonry-init', get_stylesheet_directory_uri() . '/js/masonry-init-archive.js', array( 'jquery-masonry' ) ); 
}

//* Remove Featured image (if set in Theme Settings)
add_filter( 'genesis_pre_get_option_content_archive_thumbnail', 'primadonna_no_post_image' );
function primadonna_no_post_image() {
	return '0';
}
//* Display centered wide featured image for First Post and left aligned thumbnail for the next five
add_action( 'genesis_entry_header', 'primadonna_show_featured_image', 8 );
function primadonna_show_featured_image() {
	if ( ! has_post_thumbnail() ) {
		return;
	}
		$image_args = array(
			'size' => 'full-thumbnail',
			'attr' => array(
				'class' => 'alignnone',
			),
		);

	$image = genesis_get_image( $image_args );

	echo '<div class="home-featured-image"><a href="' . get_permalink() . '">' . $image .'</a></div>';
}
//* Show Excerpts regardless of Theme Settings
add_filter( 'genesis_pre_get_option_content_archive', 'primadonna_show_excerpts' );
function primadonna_show_excerpts() {
	return 'excerpts';
}

//* Modify the length of post excerpts
add_filter( 'excerpt_length', 'primadonna_excerpt_length' );
function primadonna_excerpt_length( $length ) {
	return 45; // pull first 65 words
}
add_filter('excerpt_more', 'primadonna_list_excerpt_more');
function primadonna_list_excerpt_more($more) {
	return '... <a class="more-link" href="' . get_permalink() . '">[read more]</a>';
}
}

//** First Full then Masonry Layout **//
$fullmasonrylayout = get_theme_mod( 'primadonna_archive_setting', 'full' );
if ( $fullmasonrylayout === 'full_masonry' ) {

//Add Masonry body class
add_filter( 'body_class', 'primadonna_masonry_body_class' );
function primadonna_masonry_body_class( $classes ) {
	
	$classes[] = 'masonry-posts-full-archive';
	return $classes;	
}
add_action( 'wp_enqueue_scripts', 'primadonna_masonry_enqueue_scripts' );
function primadonna_masonry_enqueue_scripts() {
wp_enqueue_script( 'masonry' );
wp_enqueue_script( 'masonry-init', get_stylesheet_directory_uri() . '/js/masonry-init-full-archive.js', array( 'jquery-masonry' ) ); 
}
//* Remove Featured image (if set in Theme Settings)
add_filter( 'genesis_pre_get_option_content_archive_thumbnail', 'primadonna_no_post_image' );
function primadonna_no_post_image() {
	return '0';
}
//* Display centered wide featured image for First Post and left aligned thumbnail for the next five
add_action( 'genesis_entry_header', 'primadonna_show_featured_image', 8 );
function primadonna_show_featured_image() {
	if ( ! has_post_thumbnail() ) {
		return;
	}
		$image_args = array(
			'size' => 'full-thumbnail',
			'attr' => array(
				'class' => 'alignnone',
			),
		);

	$image = genesis_get_image( $image_args );

	echo '<div class="home-featured-image"><a href="' . get_permalink() . '">' . $image .'</a></div>';
}

//* Show Excerpts regardless of Theme Settings
add_filter( 'genesis_pre_get_option_content_archive', 'primadonna_show_excerpts' );
function primadonna_show_excerpts() {
	return 'excerpts';
}

//* Modify the length of post excerpts
add_filter( 'excerpt_length', 'primadonna_excerpt_length' );
function primadonna_excerpt_length( $length ) {
	return 45; // pull first 45 words
}
add_filter('excerpt_more', 'primadonna_list_excerpt_more');
function primadonna_list_excerpt_more($more) {
	return '... <a class="more-link" href="' . get_permalink() . '">[read more]</a>';
}
}


//* Remove entry meta
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

genesis();