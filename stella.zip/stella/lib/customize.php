<?php
function bcs_body_bg() {
	return '#ffffff';
}
function bcs_nav_bg() {
	return '#eeeeee';
}
function bcs_body_text() {
	return '#333333';
}
function bcs_logo_text() {
	return '#333333';
}
function bcs_post_header_text() {
	return '#333333';
}
function bcs_widget_header_text() {
	return '#333333';
}
function bcs_widget_header_bg() {
	return '#eeeeee';
}
function bcs_header_text() {
	return '#333333';
}
function bcs_link_text() {
	return '#606060';
}
function bcs_button_text_color() {
	return '#333333';
}
function bcs_button_color() {
	return '#eeeeee';
}
function bcs_cta_text_color() {
	return '#333333';
}
function bcs_cta_color() {
	return '#eeeeee';
}
function bcs_footer_color() {
	return '#eeeeee';
}

add_action( 'customize_register', 'bcs_customizer_register' );

function bcs_customizer_register() {

	global $wp_customize;

	//* Body Background
	$wp_customize->add_setting(
		'bcs_body_bg_color',
		array(
			'default'           => bcs_body_bg(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'bcs_body_bg_color',
			array(
				'description' => __( 'Change the background color of the site.' ),
			    'label'       => __( 'Body Background', 'bcs-theme' ),
			    'section'     => 'colors',
			    'settings'    => 'bcs_body_bg_color',
			)
		)
	);

	//* Navigation Background
	$wp_customize->add_setting(
		'bcs_nav_bg_color',
		array(
			'default'           => bcs_nav_bg(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'bcs_nav_bg_color',
			array(
				'description' => __( 'Change the background color of the navigation bar.' ),
			    'label'       => __( 'Navigation Background', 'bcs-theme' ),
			    'section'     => 'colors',
			    'settings'    => 'bcs_nav_bg_color',
			)
		)
	);

	//* Body Text Color
	$wp_customize->add_setting(
		'bcs_body_text_color',
		array(
			'default'           => bcs_body_text(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'bcs_body_text_color',
			array(
				'description' => __( 'Change the body text color.' ),
			    'label'       => __( 'Body', 'bcs-theme' ),
			    'section'     => 'colors',
			    'settings'    => 'bcs_body_text_color',
			)
		)
	);

	//* Logo Text Color
	$wp_customize->add_setting(
		'bcs_logo_text_color',
		array(
			'default'           => bcs_logo_text(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'bcs_logo_text_color',
			array(
				'description' => __( 'Change the logo & description color.' ),
			    'label'       => __( 'Logo/Description', 'bcs-theme' ),
			    'section'     => 'colors',
			    'settings'    => 'bcs_logo_text_color',
			)
		)
	);

	//* Post Header Text Color
	$wp_customize->add_setting(
		'bcs_post_header_text_color',
		array(
			'default'           => bcs_post_header_text(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'bcs_post_header_text_color',
			array(
				'description' => __( 'Change the post header color.' ),
			    'label'       => __( 'Post Header', 'bcs-theme' ),
			    'section'     => 'colors',
			    'settings'    => 'bcs_post_header_text_color',
			)
		)
	);

	//* Widget Header Text Color
	$wp_customize->add_setting(
		'bcs_widget_header_text_color',
		array(
			'default'           => bcs_widget_header_text(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'bcs_widget_header_text_color',
			array(
				'description' => __( 'Change the widget header color.' ),
			    'label'       => __( 'Widget Header', 'bcs-theme' ),
			    'section'     => 'colors',
			    'settings'    => 'bcs_widget_header_text_color',
			)
		)
	);

	//* Widget Header Background Color
	$wp_customize->add_setting(
		'bcs_widget_header_bg_color',
		array(
			'default'           => bcs_widget_header_bg(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'bcs_widget_header_bg_color',
			array(
				'description' => __( 'Change the widget header background color.' ),
			    'label'       => __( 'Widget Header Background', 'bcs-theme' ),
			    'section'     => 'colors',
			    'settings'    => 'bcs_widget_header_bg_color',
			)
		)
	);

	//* Header Text Color
	$wp_customize->add_setting(
		'bcs_header_text_color',
		array(
			'default'           => bcs_header_text(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'bcs_header_text_color',
			array(
				'description' => __( 'Change the header color (H1-H6).' ),
			    'label'       => __( 'Header', 'bcs-theme' ),
			    'section'     => 'colors',
			    'settings'    => 'bcs_header_text_color',
			)
		)
	);

	//* Link Text Color
	$wp_customize->add_setting(
		'bcs_link_text_color',
		array(
			'default'           => bcs_link_text(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'bcs_link_text_color',
			array(
				'description' => __( 'Change the default link color.' ),
			    'label'       => __( 'Default Link', 'bcs-theme' ),
			    'section'     => 'colors',
			    'settings'    => 'bcs_link_text_color',
			)
		)
	);

	//* Post Button Text Color
	$wp_customize->add_setting(
		'bcs_button_text_color',
		array(
			'default'           => bcs_button_text_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'bcs_button_text_color',
			array(
				'description' => __( 'Change the button text color.' ),
			    'label'       => __( 'Button', 'bcs-theme' ),
			    'section'     => 'colors',
			    'settings'    => 'bcs_button_text_color',
			)
		)
	);

	//* Post Button Background/Outline Color
	$wp_customize->add_setting(
		'bcs_button_bg_color',
		array(
			'default'           => bcs_button_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'bcs_button_bg_color',
			array(
				'description' => __( 'Change the button background color.' ),
			    'label'       => __( 'Button Background', 'bcs-theme' ),
			    'section'     => 'colors',
			    'settings'    => 'bcs_button_bg_color',
			)
		)
	);

	//* CTA Text Color
	$wp_customize->add_setting(
		'bcs_cta_text_color',
		array(
			'default'           => bcs_cta_text_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'bcs_cta_text_color',
			array(
				'description' => __( 'Change the CTA text color.' ),
			    'label'       => __( 'CTA', 'bcs-theme' ),
			    'section'     => 'colors',
			    'settings'    => 'bcs_cta_text_color',
			)
		)
	);

	//* CTA Background Color
	$wp_customize->add_setting(
		'bcs_cta_bg_color',
		array(
			'default'           => bcs_cta_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'bcs_cta_bg_color',
			array(
				'description' => __( 'Change the CTA background color.' ),
			    'label'       => __( 'CTA Background', 'bcs-theme' ),
			    'section'     => 'colors',
			    'settings'    => 'bcs_cta_bg_color',
			)
		)
	);

	//* CTA Background Color
	$wp_customize->add_setting(
		'bcs_footer_bg_color',
		array(
			'default'           => bcs_footer_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'bcs_footer_bg_color',
			array(
				'description' => __( 'Change the footer background color.' ),
			    'label'       => __( 'Footer Background', 'bcs-theme' ),
			    'section'     => 'colors',
			    'settings'    => 'bcs_footer_bg_color',
			)
		)
	);

}
