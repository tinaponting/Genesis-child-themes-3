<?php
/**
* Load theme widgets.
* @package     Vivien Theme
* @subpackage  Genesis
*/
// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}



add_action( 'widgets_init', 'vivien_include_widgets', 10 );



//* Load all the required widget class files.



function vivien_include_widgets() {

	if ( class_exists( 'vivien_Featured_Posts' ) ) {

		return;

	}

	$widgets_dir = trailingslashit( get_stylesheet_directory() ) . 'includes/widgets/';

	require_once $widgets_dir . 'vivien-featured-posts.php';

}



add_action( 'widgets_init', 'vivien_register_widgets', 11 );



//* Unregister the default Genesis Featured Posts widget and register all of



function vivien_register_widgets() {

	if ( ! class_exists( 'vivien_Featured_Posts' ) ) {

		return;

	}

	unregister_widget( 'Genesis_Featured_Post' );

	register_widget( 'vivien_Featured_Posts' );

}

