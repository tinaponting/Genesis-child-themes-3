<?php
/**
 * Her Exclusive.
 * @package Her Exclusive
 */
// Start the engine.
include_once( get_template_directory() . '/lib/init.php' );

// Setup Theme.
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );

// Helper functions.
include_once( get_stylesheet_directory() . '/lib/helper-functions.php' );

// Include customizer CSS.
include_once( get_stylesheet_directory() . '/lib/output.php' );

// Add image upload and color select to theme customizer.
require_once( get_stylesheet_directory() . '/lib/customize.php' );

// Add the required WooCommerce functions.
include_once( get_stylesheet_directory() . '/lib/woocommerce/woocommerce-setup.php' );

// Add the required WooCommerce custom CSS.
include_once( get_stylesheet_directory() . '/lib/woocommerce/woocommerce-output.php' );

// Include notice to install Genesis Connect for WooCommerce.
include_once( get_stylesheet_directory() . '/lib/woocommerce/woocommerce-notice.php' );

//* Install Plugins
require_once( get_stylesheet_directory() . '/lib/plugins/tgm-plugin-activation/register-plugins.php' );

// Set Localization (do not remove).
add_action( 'after_setup_theme', 'her_localization_setup' );
function her_localization_setup(){
	load_child_theme_textdomain( 'her-exclusive', get_stylesheet_directory() . '/languages' );
}

// Child theme (do not remove).
define( 'CHILD_THEME_NAME', 'Her Exclusive' );
define( 'CHILD_THEME_VERSION', '1.0' );

// Enqueue scripts and styles.
add_action( 'wp_enqueue_scripts', 'her_enqueue_scripts_styles' );
function her_enqueue_scripts_styles() {

	wp_enqueue_style( 'her-fonts', '//fonts.googleapis.com/css?family=Cormorant+Garamond:400,400i,500,700|Raleway:700&display=swap', array(), CHILD_THEME_VERSION );
	wp_enqueue_style( 'her-ionicons', '//code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css', array(), CHILD_THEME_VERSION );

	wp_enqueue_script( 'her-match-height', get_stylesheet_directory_uri() . '/js/match-height.js', array( 'jquery' ), '0.5.2', true );
	wp_enqueue_script( 'her-global', get_stylesheet_directory_uri() . '/js/global.js', array( 'jquery', 'her-match-height' ), '1.0.0', true );

	$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
	wp_enqueue_script( 'her-responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menus' . $suffix . '.js', array( 'jquery' ), CHILD_THEME_VERSION, true );
	wp_localize_script(
		'her-responsive-menu',
		'genesis_responsive_menu',
		her_responsive_menu_settings()
	);

}

// Define our responsive menu settings.
function her_responsive_menu_settings() {

	$settings = array(
		'mainMenu'         => __( 'Menu', 'her-exclusive' ),
		'menuIconClass'    => 'ionicons-before ion-ios-drag',
		'subMenu'          => __( 'Submenu', 'her-exclusive' ),
		'subMenuIconClass' => 'ionicons-before ion-chevron-down',
		'menuClasses'      => array(
			'others' => array(
				'.nav-primary',
			),
		),
	);

	return $settings;

}

// Add HTML5 markup structure.
add_theme_support( 'html5', array( 'caption', 'comment-form', 'comment-list', 'gallery', 'search-form' ) );

// Add accessibility support.
add_theme_support( 'genesis-accessibility', array( 'drop-down-menu', 'headings', 'rems', 'search-form', 'skip-links' ) );

// Enqueue Font Awesome.
add_action( 'wp_enqueue_scripts', 'custom_load_font_awesome' );
function custom_load_font_awesome() {
    wp_enqueue_script( 'font-awesome', 'https://use.fontawesome.com/releases/v5.0.1/js/all.js', array(), null );
}

// Add support for custom header.
add_theme_support( 'custom-header', array(
	'width'           => 700,
	'height'          => 228,
	'header-selector' => '.site-title a',
	'header-text'     => false,
	'flex-height'     => true,
) );

// Add image sizes.
add_image_size( 'square-image', 400, 400, TRUE );
add_image_size( 'vertical-image', 400, 600, TRUE );
add_image_size( 'horizontal-image', 700, 450, TRUE );
add_image_size( 'isotope-image', 600, 0, true );

// Add support for after entry widget.
add_theme_support( 'genesis-after-entry-widget-area' );

// Remove secondary sidebar.
unregister_sidebar( 'sidebar-alt' );

// Remove site layouts.
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );

// Remove output of primary navigation right extras.
remove_filter( 'genesis_nav_items', 'genesis_nav_right', 10, 2 );
remove_filter( 'wp_nav_menu_items', 'genesis_nav_right', 10, 2 );

// Remove navigation meta box.
add_action( 'genesis_theme_settings_metaboxes', 'her_remove_genesis_metaboxes' );
function her_remove_genesis_metaboxes( $_genesis_theme_settings_pagehook ) {
	remove_meta_box( 'genesis-theme-settings-nav', $_genesis_theme_settings_pagehook, 'main' );
}

// Remove skip link for primary navigation.
add_filter( 'genesis_skip_links_output', 'her_skip_links_output' );
function her_skip_links_output( $links ) {

	if ( isset( $links['genesis-nav-primary'] ) ) {
		unset( $links['genesis-nav-primary'] );
	}

	return $links;

}

// Rename primary and secondary navigation menus.
add_theme_support( 'genesis-menus', array( 'primary' => __( 'Header Menu', 'her-exclusive' ), 'secondary' => __( 'Footer Menu', 'her-exclusive' ) ) );

// Reposition the secondary navigation menu.
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_footer', 'genesis_do_subnav', 5 );

// Reduce secondary navigation menu to one level depth.
add_filter( 'wp_nav_menu_args', 'her_secondary_menu_args' );
function her_secondary_menu_args( $args ) {

	if ( 'secondary' != $args['theme_location'] ) {
		return $args;
	}

	$args['depth'] = 1;

	return $args;

}

//* Add Title & Caption to Soliloquy Slider
add_filter( 'soliloquy_output_caption', 'her_soliloquy_title_before_caption', 10, 5 );
function her_soliloquy_title_before_caption( $caption, $id, $slide, $data, $i ) {
     
    // Check if current slide has a title specified
    if ( isset( $slide['title'] ) && !empty( $slide['title'] ) ) {
        $caption = '<h4 class="title">' . $slide['title'] . '</h4>'; 
	$caption .= '<div class="caption">' . $slide['caption'] . '</h4>';  
        } 
        return $caption;
}

// Add between posts area after 2nd entry.
add_action( 'genesis_after_entry', 'her_between_posts_area' );
function her_between_posts_area() {
	global $wp_query;
	$counter = $wp_query->current_post;
	if ( 1 == $counter ) {
		genesis_widget_area( 'ad-between-posts', array(
			'before' => '<div class="ad-between-posts">',
			'after'  => '</div>',
		) );
	}
}

// Modify size of the Gravatar in the author box.
add_filter( 'genesis_author_box_gravatar_size', 'her_author_box_gravatar' );
function her_author_box_gravatar( $size ) {
	return 100;
}

// Modify size of the Gravatar in the entry comments.
add_filter( 'genesis_comment_list_args', 'her_comments_gravatar' );
function her_comments_gravatar( $args ) {

	$args['avatar_size'] = 60;

	return $args;

}

//* Position featured image above title
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
add_action( 'genesis_entry_header', 'genesis_do_post_image', 1 );

//* Position post info above post title
remove_action( 'genesis_entry_header', 'genesis_post_info', 12);
add_action( 'genesis_entry_header', 'genesis_post_info', 9 );

//* Customize the Post Info Function
add_filter( 'genesis_post_info', 'her_post_info_filter' );
function her_post_info_filter( $post_info ) {

	$post_info = '[post_date before="on "] &middot [post_comments] [post_edit]';
    return $post_info;

}

//* Load Entry Navigation
add_action( 'genesis_entry_footer', 'genesis_prev_next_post_nav' );

//* Customizing Default Home Page Post Limit
add_action( 'pre_get_posts',  'change_posts_number_home_page'  );
function change_posts_number_home_page( $query ) {

   if ($query->is_home() && $query->is_main_query() ) {
        $query->set( 'posts_per_page', 4 );

    return $query;
    }
}

//* Customize the credits
add_filter('genesis_pre_get_option_footer_text', 'her_footer_creds_text');
function her_footer_creds_text( $creds ) {
    $creds = '<div class="creds">Copyright [footer_copyright] &middot; [footer_site_title] &middot; Design by <a target="_blank" href="https://exempel.se/">EXEMPEL</a></div>';
    return $creds;
}

// Add To Top button
add_action( 'genesis_before', 'genesis_to_top');
	function genesis_to_top() {
	 echo '<a href="#0" class="to-top" title="Back To Top"><i class="fas fa-chevron-up"></i></a>';
}


// Setup widget counts.
function her_count_widgets( $id ) {

	$sidebars_widgets = wp_get_sidebars_widgets();

	if ( isset( $sidebars_widgets[ $id ] ) ) {
		return count( $sidebars_widgets[ $id ] );
	}

}

// Determine the widget area class.
function her_widget_area_class( $id ) {

	$count = her_count_widgets( $id );

	$class = '';

	if ( $count == 1 ) {
		$class .= ' widget-full';
	} elseif ( $count % 3 == 1 ) {
		$class .= ' widget-thirds';
	} elseif ( $count % 4 == 1 ) {
		$class .= ' widget-fourths';
	} elseif ( $count % 2 == 0 ) {
		$class .= ' widget-halves uneven';
	} else {
		$class .= ' widget-halves';
	}

	return $class;

}

// Hook Widget Area Above Footer
add_action( 'genesis_before_footer', 'her_widget_above_footer', 1 ); 
function her_widget_above_footer() {

    genesis_widget_area( 'widget-above-footer', array(
		'before' => '<div id="widget-above-footer" class="widget-above-footer"><div class="solid-section widget-area fadeup-effect"><div class="wrap">',
		'after'  => '</div></div></div>',
    ) );

}

//* Add Page Widget Area to Content
add_action( 'genesis_entry_footer', 'her_instagram_menu_add_page_content' );
function her_instagram_menu_add_page_content() {
	if ( is_page_template( 'instagram_landing.php' ) ) {
	
		genesis_widget_area ('instagram-landing-page-widget', array(
        'before' => '<div class="instagram-landing-page-widget"><div class="wrap">',
        'after' => '</div></div>',
	) );
		
	}
}

// Add support for 3-column footer widgets.
add_theme_support( 'genesis-footer-widgets', 3 );


add_action( 'pre_get_posts', 'her_change_posts_per_page' );
/**
 * Set all the entries to appear on Lookbook CPT archive page.
 * @param object $query data.
 *
 */
function her_change_posts_per_page( $query ) {

    if ( $query->is_main_query() && ! is_admin() && is_post_type_archive( 'portfolio' ) ) {
            $query->set( 'posts_per_page', '-1' );
            $query->set( 'no_found_rows', 'true' );
    }

}

// Add Archive Settings option to Portfolio CPT.
add_post_type_support( 'portfolio', 'genesis-cpt-archives-settings' );


// Display Header Left widget area before .title-area
add_action( 'genesis_header', 'her_header_left', 9 );
function her_header_left() {
	genesis_widget_area( 'header-left', array(
		'before'	=> '<div class="header-left one-third first">',
		'after'		=> '</div>',
	) );
}

// Add "one-third" class to .title-area and .header-widget-area
add_filter( 'genesis_attr_title-area', 'custom_attributes_one_third' );
add_filter( 'genesis_attr_header-widget-area', 'custom_attributes_one_third' );

function custom_attributes_one_third( $attributes ) {

	$attributes['class'] .= ' one-third';

	return $attributes;

}

// Register widget areas.
genesis_register_widget_area( array(
		'id'          => 'header-left',
		'name'        => __( 'Header Left', 'her-exclusive' ),
		'description' => __( 'This is the header left widget area', 'her-exclusive' ),
	) );
genesis_register_sidebar( array(
		'id' => 'ad-between-posts',
		'name' => __( 'Ad Between Posts', 'her-exclusive' ),
		'description' => __( 'This widget shows after the 2nd blog post on the blog page.', 'her-exclusive' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-1',
	'name'        => __( 'Front Page 1', 'her-exclusive' ),
	'description' => __( 'This is the front page 1 section.', 'her-exclusive' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-2',
	'name'        => __( 'Front Page 2', 'her-exclusive' ),
	'description' => __( 'This is the front page 2 section.', 'her-exclusive' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-3',
	'name'        => __( 'Front Page 3', 'her-exclusive' ),
	'description' => __( 'This is the front page 3 section.', 'her-exclusive' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-4',
	'name'        => __( 'Front Page 4', 'her-exclusive' ),
	'description' => __( 'This is the front page 4 section.', 'her-exclusive' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-5',
	'name'        => __( 'Front Page 5', 'her-exclusive' ),
	'description' => __( 'This is the front page 5 section.', 'her-exclusive' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-6',
	'name'        => __( 'Front Page 6', 'her-exclusive' ),
	'description' => __( 'This is the front page 6 section. Used for the blog area.', 'her-exclusive' ),
) );
genesis_register_sidebar( array(
	'id'          => 'widget-above-footer',
	'name'        => __( 'Widget Above Footer', 'her-exclusive' ),
	'description' => __( 'This is the widget section above the footer.', 'her-exclusive' ),
) );
genesis_register_sidebar( array(
	'id'		  => 'instagram-landing-page-widget',
	'name'		  => __( 'Instagram Page', 'her-exclusive' ),
	'description' => __( 'This is the widget area for your Instagram Page.', 'her-exclusive' ),
) );
genesis_register_sidebar( array(
	'id'          => 'category-index',
	'name'        => __( 'Category Index', 'her-exclusive' ),
	'description' => __( 'This widget area appears on the Category Index page', 'her-exclusive' ),
) );


add_action( 'after_setup_theme', 'genesis_child_gutenberg_support' );
/**
 * Adds Gutenberg opt-in features and styling.
 *
 * @since 2.7.0
 */
function genesis_child_gutenberg_support() { // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedFunctionFound -- using same in all child themes to allow action to be unhooked.
        require_once get_stylesheet_directory() . '/lib/gutenberg/init.php';
}
