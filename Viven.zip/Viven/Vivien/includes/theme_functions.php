<?php
/*------------------------------------------------------------------------------------
Theme Functions
------------------------------------------------------------------------------------*/

/** Add new Images Size */
add_image_size(  'Square', 100, 100, TRUE  );
add_image_size(  'Blog', 700, 280, TRUE  );
add_image_size(  'latest_portfolio_widget', 75, 75, TRUE  );
add_image_size(  'portfolio_single', 1140, 500, TRUE  );
add_image_size(  '2col', 564, 415, TRUE  );
add_image_size(  '3col', 384, 307, TRUE  );
add_image_size(  '4col', 255, 172, TRUE  );

/*
* Portfolio Template Function
*
* Displays the portfolio items according to
* columns, num items, filter, pagination
*
* @param integer $columns - Number of Columns
* @param integer $num_items - Number of items to display
* @param boolean $filter -  to either have a filter or not
* @param boolean $pagination -  to either have a pagination or not
*/
function zp_portfolio_template(  $columns, $num_items, $filter, $pagination  ){
	global $post, $paged, $wp_query;

	if(  $columns == 2  ){
		$column='2col';
		$num_post = $num_items;
	}else if(  $columns == 3  ){
		$column='3col';
		$num_post = $num_items;
	}else if(  $columns == 4  ){
		$column='4col';
		$num_post = $num_items;
	}else{
		$column='3col';
		$num_post = $num_items;
	}

	$html='';

	printf( '<article %s>', genesis_attr( 'entry' ) );

	//Portfolio titles

	/** Portfolio category archive title */
	if( is_tax( 'portfolio_category'  ) ){
		$portfolio_taxonomy_label = ( genesis_get_option( 'zp_portfolio_categories_label' ,  ZP_SETTINGS_FIELD ));
		$portfolio_title = $portfolio_taxonomy_label.single_tag_title( '',FALSE );
	}elseif( is_post_type_archive( 'portfolio' )  ){
		$portfolio_title = post_type_archive_title( '',false );
	}else{
		$portfolio_title = get_the_title();
	}

	if( !is_home())
		printf( '<header class="entry-header"><h1 itemprop="headline" class="entry-title">%s</h1></header>', $portfolio_title );

		if(  $filter  ){
			echo '<div id="options" class="clearfix">';
			echo '<ul id="portfolio-categories" class="option-set" data-option-key="filter"><li><a href="#" data-option-value="*" class="selected">show all</a></li>';

			$term_args = array(
				'orderby' => 'name',
				'order' => 'ASC',
				'taxonomy' => 'portfolio_category'
			);

			$categories = get_categories( $term_args );
			foreach( $categories as $category ) :
				$tms=str_replace( " ","-",$category->name );
				echo '<li><a class="active" href="#" data-option-value=".'.$category->slug.'">'.$category->name.'</a></li>';
			endforeach;

			echo '</ul></div>';
		}

		// check if it is the taxonomy page
		if(  !is_tax(  'portfolio_category'  )  ){
			$paged = get_query_var( 'paged' );

			$args= array(
				'posts_per_page' =>$num_post,
				'post_type' => 'portfolio',
				'paged' => $paged,
				'orderby' => 'date',
				'order' => 'DESC'
			);

			query_posts( $args );
		}?>

		<div id="container" style="height: auto; width: 100%;">

		<?php
		if(  have_posts(  )  ) {
			while (  have_posts(  )  ) {
				the_post(  );

				$t=get_the_title(  );
				$permalink=get_permalink(  );

				$icon='';
				$thumbnail= wp_get_attachment_url(  get_post_thumbnail_id(  $post->ID  )  );
				$portfolio_thumb = wp_get_attachment_image_src( get_post_thumbnail_id(  $post->ID  ), $column );

				//get the image title

				$openLink='<div class="portfolio_image">';
				$closeLink='</div>';

				if(  $filter  ){
					$span_icon='<div class="icon" style="display:none" ><h4><a href="'.$permalink.'" class="item-desc">'.$t.'</a></h4></div>';
				}else{
					$span_icon='<div class="icon" style="display:none" ><h4><a href="'.wp_get_attachment_url(  get_post_thumbnail_id(  $post->ID  )  ).'" rel="prettyPhoto[pp_gal]" title="'.$t.'" class="item-desc">'.$t.'</a></h4></div>';
				}

				$terms=wp_get_post_terms( $post->ID, 'portfolio_category' );
				$term_string='';

				foreach( $terms as $term ){
					$term_string.=( $term->slug ).',';
				}

				$term_string=substr( $term_string, 0, strlen( $term_string )-1 );
				$samp=str_replace( " ","-",$term_string );
				$string = str_replace( ","," ",$samp );
				$finale= $string." ";

				//generate the final item HTML
				$html.= '<div class="element element-'.$column.' '.$finale.'" data-filter="'.$finale.'">'.$openLink.''.$span_icon.'<img src="'.$portfolio_thumb[0].'" title="'.get_the_title(  ).'" alt="'.$t.'" />'.$closeLink.'</div>';
			}
		}

		echo $html;
		?>
		</div>
	<?php

	if(  $pagination  )
		genesis_posts_nav();

	echo '</article>';

	wp_reset_query(  );
}

/*
* Related Portfolio Function
*
* Displays related portfolio in the single portfolio page
*/
function zp_related_portfolio(){
	global $post;

	$terms = get_the_terms( $post->ID , 'portfolio_category' );
	$term_ids = array_values( wp_list_pluck( $terms,'term_id' ) );
	$args=array(
		'post_type' => 'portfolio',
		'tax_query' => array(
			array(
				'taxonomy' => 'portfolio_category',
				'field' => 'id',
				'terms' => $term_ids,
				'operator'=> 'IN'
			)),
		'posts_per_page' => 3,
		'orderby' => 'rand',
		'post__not_in'=>array( $post->ID )
	);

	query_posts( $args );
	?>

	<div class = "related_portfolio">
		<h4><?php echo genesis_get_option( 'zp_related_portfolio_title' , ZP_SETTINGS_FIELD ); ?></h4>
	</div>

	<div class="related_container">
		<?php
			if( have_posts() ) {
				while ( have_posts() ) {
					the_post();
					$t = get_the_title();
					$permalink=get_permalink();
					$description= substr(get_the_excerpt(), 0, 100);
					$thumbnail= wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) );
					$portfolio_thumb = wp_get_attachment_image_src( get_post_thumbnail_id(  $post->ID  ), '3col' );
					$date = get_the_date( 'F j, Y' );
				?>

				<div class="element element-3col">
					<div class="portfolio_image">
						<div style="display: none;" class="icon">
							<h4><a class="item-desc" href="<?php echo $permalink; ?>"><?php echo $t; ?></a></h4>
						</div>
						<img src="<?php echo $portfolio_thumb[0]; ?>" title="<?php echo $t; ?>" alt="<?php echo $t; ?>" />
					</div>
				</div>
			<?php
			}
		}
		wp_reset_query(  );
	?>
	</div>
	<?php }

/*
* Portfolio Shortcode Function
*
* function for portfolio shortcode
*
* @param integer $columns - Number of Columns
* @param integer $num_items - Number of items to display
* @param string $type -  portfolio or gallery
* @param boolean $filter -  to either have a filter or not
*/
function  zp_portfolio_shortcode(  $columns, $num_items, $type, $filter  ){
	global $post, $paged;

	if(  $columns == 2  ){
		$column='2col';
		$num_post = $num_items;
	}else if(  $columns == 3  ){
		$column='3col';
		$num_post = $num_items;
	}else if(  $columns == 4  ){
		$column='4col';
		$num_post = $num_items;
	}else{
		$column='3col';
		$num_post = $num_items;
	}

	$html='';
	$output = '';
	$output .= '<div class="portfolio_shortcode">';
	if(  $filter  ){
		$output .= '<div id="options" class="clearfix">';
		$output .= '<ul id="portfolio-categories" class="option-set" data-option-key="filter"><li><a href="#" data-option-value="*" class="selected">show all</a></li>';

		$term_args = array(
			'orderby' => 'name',
			'order' => 'ASC',
			'taxonomy' => 'portfolio_category'
		);

		$categories = get_categories( $term_args );
		foreach( $categories as $category ) :
			$tms=str_replace( " ","-",$category->name );
			$output .= '<li><a class="active" href="#" data-option-value=".'.$category->slug.'">'.$category->name.'</a></li>';
		endforeach;

		$output .= '</ul></div>';
	}

	// check if it is the taxonomy page
	if(  !is_tax(  'portfolio_category'  )  ){
		$paged = get_query_var( 'paged' );

		$args= array(
			'posts_per_page' =>$num_post,
			'post_type' => 'portfolio',
			'paged' => $paged,
			'orderby' => 'date',
			'order' => 'DESC'
		);

		query_posts( $args );
	}

	$output .= '<div id="container" style="height: auto; width: 100%;">';
	if(  have_posts(  )  ) {
		while (  have_posts(  )  ) {
			the_post(  );
			$t=get_the_title(  );
			$permalink=get_permalink(  );

			$icon='';

			$thumbnail= wp_get_attachment_url(  get_post_thumbnail_id(  $post->ID  )  );
			$portfolio_thumb = wp_get_attachment_image_src( get_post_thumbnail_id(  $post->ID  ), $column );

			//get the image title

			$openLink='<div class="portfolio_image">';
			$closeLink='</div>';

			$type = ( $type == 'portfolio' )? true : false;

			if(  $type  ){
				$span_icon='<div class="icon" style="display:none" ><h4><a href="'.$permalink.'" class="item-desc">'.$t.'</a></h4></div>';
			}else{
				$span_icon='<div class="icon" style="display:none" ><h4><a href="'.wp_get_attachment_url(  get_post_thumbnail_id(  $post->ID  )  ).'" rel="prettyPhoto[pp_gal]" title="'.$t.'" class="item-desc">'.$t.'</a></h4></div>';
			}

			$terms=wp_get_post_terms( $post->ID, 'portfolio_category' );
			$term_string='';
			foreach( $terms as $term ){
				$term_string.=( $term->slug ).',';
			}

			$term_string=substr( $term_string, 0, strlen( $term_string )-1 );
			$samp=str_replace( " ","-",$term_string );
			$string = str_replace( ","," ",$samp );
			$finale= $string." ";


			//generate the final item HTML
			$html.= '<div class="element element-'.$column.' '.$finale.'" data-filter="'.$finale.'">'.$openLink.''.$span_icon.'<img src="'.$portfolio_thumb[0].'" title="'.get_the_title(  ).'" alt="'.$t.'" />'.$closeLink.'</div>';
		}
	}
	$output .= $html;
	$output .= '</div>';
	$output .= '</div>';
	wp_reset_query(  );

	return $output;
}

/*
* Function that returns portfolio required values
*
* Displays the portfolio items according to
* columns, num items, filter, pagination
*
* @param integer $columns - Number of columns
*/
function zp_portfolio_items_values( $columns ){
	$values = array();

	if(  $columns == 2  ){
		$values['class'] = '2col';
	}

	if(  $columns == 3  ){
		$values['class'] = '3col';
	}

	if(  $columns == 4  ){
		$values['class'] = '4col';
	}

	return $values;
}


/*
* Return Comment Number
*/
function zp_custom_comment_number(  ){
	global $post;

	$num_comments = get_comments_number();

	if ( $num_comments == 0 ) {
		$comments = __('No Comments', 'absolute');
	} elseif ( $num_comments > 1 ) {
		$comments = $num_comments . __(' Comments','absolute' );
	} else {
		$comments = __('1 Comment','absolute' );
	}

	return $comments;
}