<?php
	
	$resalte = get_field('color_principal', 'option');
	if(empty($resalte)){
		$resalte = '#ff9575';
		update_field('color_principal', $resalte, 'options');
	}
	$texto = get_field('color_texto', 'option');
	if(empty($texto)){
		$texto = '#535353';
		update_field('color_texto', $texto, 'options');
	}

	echo '<style type="text/css">';
	
	echo '
		BODY,
		A:hover,
		input,
		select,
		textarea,
		.menu-primary LI A,
		.responsive-menu-icon::before,
		.nav-secondary LI A,
		SPAN.redes A,
		.pagination LI.active A,
		.entry-comments H3,
		#respond H3,
		.entry-comments .comment-author SPAN A,
		.comment-reply A,
		.post .entry-header H2.entry-title A,
		.wpb_content_element .wpb_tabs_nav li.ui-tabs-active a,
		H3.ui-accordion-header-active A,
		.pie-redes A,
		.pie-redes A I,
		.footer-widgets .widget.widget_nav_menu A,
		.site-footer .creds P A,
		.navegacion .siguiente A,
		.navegacion .anterior A,
		.genesis-nav-menu.responsive-mnu > .menu-item-has-children:before,
		BODY div.wpcf7-validation-errors,
		DIV div.wpcf7-mail-sent-ok {
			color: '. $texto .';
		}
		::-moz-placeholder {
			color: '. $texto .';
		}
		::-webkit-input-placeholder {
			color: '. $texto .';
		}
		.vcp_portafolio H3 {
			color: '. $texto .' !important;
		}
	';
	
	echo '
		input[type="button"],
		input[type="reset"],
		input[type="submit"],
		.button,
		.navegacion .boton A,
		A.vc_btn,
		A.vc_btn3 {
			border-color: '. $texto .';
		}
	';
	
	echo '
		::-moz-selection {
			background: '. $texto .';
		}
		::selection {
			background: '. $texto .';
		}
		.addthis_sharing_toolbox A:hover .at-icon {
			fill: '. $texto .';
		}
	';
	
	echo '
		A,
		H3,
		H5,
		.menu-primary a:hover,
		.menu-primary .sub-menu .current-menu-item > a:hover,
		.menu-primary LI.menu-item-has-children:hover > A,
		.menu-primary .sub-menu LI A:hover,
		.menu-primary .sub-menu LI.current-menu-item A,
		.responsive-menu-icon:hover::before,
		.nav-secondary LI A:hover,
		.nav-secondary .current-menu-item > a,
		.nav-secondary LI.menu-item-has-children:hover > A,
		SPAN.redes A:hover,
		.entry-comments .comment-author SPAN A:hover,
		.vc_toggle H4,
		BODY span.wpcf7-not-valid-tip,
		.pie-redes A:hover,
		.pie-redes A:hover I,
		.footer-widgets .widget.widget_nav_menu A:hover,
		.site-footer .creds A:hover,
		.vcp_post .vc_gitem-post-data-source-post_categories,
		.single-post .etiquetas A:hover,
		.navegacion .siguiente A:hover,
		.navegacion .anterior A:hover,
		.genesis-nav-menu.responsive-menu LI.current-menu-item > A,
		.vcp_post .vc_gitem-post-data-source-post_excerpt A.more-link,
		.area-superior .redes A:hover {
			color: '. $resalte .';
		}
	';
	
	echo '
		input:hover[type="button"],
		input:hover[type="reset"],
		input:hover[type="submit"],
		.navegacion .boton A:hover,
		.vc_toggle_square.vc_toggle_color_inverted .vc_toggle_icon::before,
		.vc_toggle_square.vc_toggle_color_inverted .vc_toggle_icon::after,
		.vc_grid-filter LI.vc_grid-filter-item.vc_active {
			background: '. $resalte .' !important;
		}
		.pagination LI A:hover,
		.comment-reply A:hover,
		BODY .vc_images_carousel .vc_carousel-indicators .vc_active,
		DIV div.wpcf7-mail-sent-ok {
			background: '. $resalte .';
		}
	';
	
	echo '
		input:focus,
		textarea:focus,
		input:hover[type="button"],
		input:hover[type="reset"],
		input:hover[type="submit"],
		.navegacion .boton A:hover,
		.vc_toggle_square.vc_toggle_color_inverted .vc_toggle_icon {
			border-color: '. $resalte .' !important;
		}
		.entry-header .entry-title:after,
		.archive .content H1.archive-title:after,
		.search .content H1.archive-title:after,
		.pagination LI A:hover,
		.entry-comments H3:after,
		#respond H3:after,
		.sidebar .widget .widget-title:after,
		BODY .vc_images_carousel .vc_carousel-indicators .vc_active,
		.vcp_post .vc_gitem-post-data-source-post_title H2:after,
		.single-post .etiquetas A:hover {
			border-color: '. $resalte .';
		}
	';
	
	echo '
		.addthis_sharing_toolbox A .at-icon {
			fill: '. $resalte .';
		}
	';
	
	echo '
		H6,
		.entry-comments .comment-meta TIME A,
		.single-post .etiquetas A {
			color: rgba('. hd_hex2rgb($texto) .', 0.55);
		}
		.menu-primary .current-menu-item > a {
			color: rgba('. hd_hex2rgb($texto) .', 0.35);
		}
	';
	
	echo '
		.area-superior,
		.nav-secondary .sub-menu LI A,
		.nav-secondary .sub-menu LI A:hover,
		BODY div.wpcf7-validation-errors,
		DIV div.wpcf7-mail-sent-ok,
		.footer-widgets,
		.site-footer {
			background: rgba('. hd_hex2rgb($resalte) .', 0.19);
		}
		.comment-list LI.bypostauthor {
			border-color: rgba('. hd_hex2rgb($resalte) .', 0.6);
		}
	';
	
	echo '
		@media only screen and (max-width: 970px) {
			.nav-secondary .genesis-nav-menu.responsive-menu .menu-item {
				background: rgba('. hd_hex2rgb($resalte) .', 0.19);
				}
		}
	';
	
	$columnas_pie = get_field('columnas_pie', 'option');
	if(empty($columnas_pie)){
		$columnas_pie = '4';
		update_field('columnas_pie', $columnas_pie, 'options');
	}
	if($columnas_pie == 0) 
		echo '.site-footer { background: #fff; }';
	
	echo '</style>';

?>