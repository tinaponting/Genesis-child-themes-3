<?php
/**
 * Kylee More.
 * @package Kylee More
 */

/**
 * Get default accent color for Customizer.
 * Abstracted here since at least two functions use it.
 * @return string Hex color code for accent color.
 */
function kylee_customizer_get_default_accent_color() {
	return '#f7f4f3';
}

function kylee_customizer_get_default_accent_font_color() {
	return '#222222';
}

function kylee_customizer_get_default_link_color() {
	return '#b1b1b1';
}

function kylee_customizer_get_default_site_title_color() {
	return '#222222';
}

function kylee_customizer_get_default_site_description_color() {
	return '#222222';
}

function kylee_customizer_get_default_heading_color() {
	return '#222222';
}

function kylee_customizer_get_default_body_font_color() {
	return '#222222';
}

function kylee_customizer_get_default_button_color() {
	return '#000000';
}

function kylee_customizer_get_default_button_font_color() {
	return '#ffffff';
}

/**
 * Generate a hex value that has appropriate contrast
 * against the inputted value.
 * @return string Hex color code for contrasting color.
 */
function kylee_color_contrast( $color ) {

	$hexcolor = str_replace( '#', '', $color );
	$red      = hexdec( substr( $hexcolor, 0, 2 ) );
	$green    = hexdec( substr( $hexcolor, 2, 2 ) );
	$blue     = hexdec( substr( $hexcolor, 4, 2 ) );

	$luminosity = ( ( $red * 0.2126 ) + ( $green * 0.7152 ) + ( $blue * 0.0722 ) );

	return ( $luminosity > 128 ) ? '#000000' : '#ffffff';

}
