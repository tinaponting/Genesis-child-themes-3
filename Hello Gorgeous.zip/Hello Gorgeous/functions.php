<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Setup Theme
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );

//* Set Localization (do not remove)
load_child_theme_textdomain( 'hyd', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/languages', 'hyd' ) );

//* Add Image upload and Color select to WordPress Theme Customizer
require_once( get_stylesheet_directory() . '/lib/customize.php' );

//* Include Customizer CSS
include_once( get_stylesheet_directory() . '/lib/output.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Hello Gorgeous' );
define( 'CHILD_THEME_VERSION', '1.0.0' );

//* Enqueue scripts and styles
add_action( 'wp_enqueue_scripts', 'hyd_enqueue_scripts_styles' );
function hyd_enqueue_scripts_styles() {

	wp_enqueue_script( 'hyd-global', get_bloginfo( 'stylesheet_directory' ) . '/js/global.js', array( 'jquery' ), '1.0.0' );
	wp_enqueue_script( 'hyd-fadeup-script', get_stylesheet_directory_uri() . '/js/fadeup.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_style( 'dashicons' );
	wp_enqueue_style( 'hyd-google-fonts', '//fonts.googleapis.com/css?family=Satisfy|Lato:300,400,400italic,700,700italic,900,900italic|Playfair+Display:400,400italic,700,700italic,900,900italic|Open+Sans:400,400italic,600,700,600italic,700italic', array(), CHILD_THEME_VERSION );
	wp_enqueue_style( 'ionicons', '//code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css', array(), CHILD_THEME_VERSION );
}

// Load Font Awesome
add_action( 'wp_enqueue_scripts', 'enqueue_font_awesome' );
function enqueue_font_awesome() {

	wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css' );
}


//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add new image sizes
add_image_size( 'featured-page', 1140, 400, TRUE );
add_image_size( 'featured-images', 774, 774, true );
add_image_size( 'pinterest-style', 400, 600, true );

//* Add support for a 4-column footer widget area
add_theme_support( 'genesis-footer-widgets', 3 );

//* Unregister the header right widget area
unregister_sidebar( 'header-right' );

//* Left and Right Menu widgets
add_action( 'genesis_header', 'menu_bar' );
function menu_bar() {

	echo '<div class="menu-bar">';

	genesis_widget_area( 'leftmenu', array(
		'before' => '<div class="leftmenu">',
		'after' => '</div>',
	) );

	genesis_widget_area( 'rightmenu', array(
		'before' => '<div class="rightmenu">',
		'after' => '</div>',
	) );

	echo '</div></div>';

}
//* Rename menus
add_theme_support( 'genesis-menus', array(
'primary' => __( 'Left Navigation Menu', 'hyd' ),
'secondary' => __( 'Right Navigation Menu', 'hyd' ),
'sticky' => __( 'Sticky Menu', 'hyd' )
) );

//* Sticky Menu
add_action( 'genesis_before', 'hyd_sticky_menu', 7 );
function hyd_sticky_menu() {

	echo '<div class="sticky-wrap">';
	printf( '<nav %s>', genesis_attr( 'nav-sticky' ) );

	wp_nav_menu( array(
		'theme_location' => 'sticky',
		'container'      => false,
		'depth'          => 1,
		'fallback_cb'    => false,
		'menu_class'     => 'genesis-nav-menu',

	) );

	echo '</nav></div>';

}

//* Reduce the sticky navigation menu to one level depth
add_filter( 'wp_nav_menu_args', 'hyd_sticky_menu_args' );
function hyd_sticky_menu_args( $args ){

	if( 'sticky' != $args['theme_location'] ){
		return $args;
	}

	$args['depth'] = 1;
	return $args;

}

//* Add widget to sticky navigation
add_filter( 'genesis_nav_items', 'hyd_social_icons', 10, 2 );
add_filter( 'wp_nav_menu_items', 'hyd_social_icons', 10, 2 );

function hyd_social_icons($menu, $args) {
	$args = (array)$args;
	if ( 'sticky' !== $args['theme_location'] )
		return $menu;
	ob_start();
	genesis_widget_area('nav-social-menu');
	$social = ob_get_clean();
	return $menu . $social;
}


//* Hook menus
add_action( 'genesis_after_header', 'hyd_menus_container' );
function hyd_menus_container() {

	echo '<div class="navigation-container">';
	do_action( 'hyd_menus' );
	echo '</div>';

}

//* Relocate Primary (Left) Navigation
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'hyd_menus', 'genesis_do_nav' );

//* Relocate Secondary (Right) Navigation
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'hyd_menus', 'genesis_do_subnav' );

//* Remove output of primary navigation right extras
remove_filter( 'genesis_nav_items', 'genesis_nav_right', 10, 2 );
remove_filter( 'wp_nav_menu_items', 'genesis_nav_right', 10, 2 );

//* Hooks widget area before footer
add_action( 'genesis_before_footer', 'hyd_social_bar'  );
function hyd_social_bar() {{

    genesis_widget_area( 'social-bar', array(
		'before' => '<div class="social-bar widget-area"><div class="social-wrap">',
		'after'  => '</div></div>',
    ) );

}}


//* Customize the credits
		add_filter( 'genesis_footer_creds_text', 'hyd_footer_creds_text' );
		function hyd_footer_creds_text() {

		    echo '<div class="creds"><p>';
		    echo 'Copyright &copy; ';
		    echo date('Y');
				echo ' &middot; ';
				echo get_bloginfo( 'name' );
		    echo ' &middot; <a target="_blank" href="https://exempel.se">EXEMPEL</a>';
		    echo '</p></div>';

		}

//* Hooks widget area before footer
add_action( 'genesis_before_footer', 'hyd_flex_footer' );
function hyd_flex_footer() {{

    genesis_widget_area( 'flex-footer', array(
		'before' => '<div class="flex-footer widget-area"><div class="flex-wrap">',
		'after'  => '</div></div>',
    ) );

}}

//* Unregister layout settings
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );

//* Unregister secondary sidebar
unregister_sidebar( 'sidebar-alt' );

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'width'           => 700,
	'height'          => 400,
	'header-selector' => '.site-title a',
	'header-text'     => false,
) );

//* Add support for structural wraps
add_theme_support( 'genesis-structural-wraps', array(
	'header',
	'nav',
	'subnav',
	'grid',
	'footer-widgets',
	'footer',
) );

//* Modify the size of the Gravatar in the author box
add_filter( 'genesis_author_box_gravatar_size', 'hyd_author_box_gravatar' );
function hyd_author_box_gravatar( $size ) {

	return 176;

}

//* Modify the size of the Gravatar in the entry comments
add_filter( 'genesis_comment_list_args', 'hyd_comments_gravatar' );
function hyd_comments_gravatar( $args ) {

	$args['avatar_size'] = 120;

	return $args;

}

//* Remove comment form allowed tags
add_filter( 'comment_form_defaults', 'hyd_remove_comment_form_allowed_tags' );
function hyd_remove_comment_form_allowed_tags( $defaults ) {

	$defaults['comment_field'] = '<p class="comment-form-comment"><label for="comment">' . _x( 'Comment', 'noun', 'hyd' ) . '</label> <textarea id="comment" name="comment" cols="45" rows="8" aria-required="true"></textarea></p>';
	$defaults['comment_notes_after'] = '';

	return $defaults;

}

//* Genesis Previous/Next Post Post Navigation
add_action( 'genesis_before_comments', 'hyd_prev_next_post_nav' );

function hyd_prev_next_post_nav() {

	if ( is_single() ) {

		echo '<div class="prev-next-navigation">';
		previous_post_link( '<div class="previous">%link</div>', '%title' );
		next_post_link( '<div class="next">%link</div>', '%title' );
		echo '</div><!-- .prev-next-navigation -->';
	}
}

//* Add support for after entry widget
add_theme_support( 'genesis-after-entry-widget-area' );

//* Add Theme Support for WooCommerce
add_theme_support( 'genesis-connect-woocommerce' );

//* Add Gallery Support for WooCommerce

add_action( 'after_setup_theme', 'hyd_setup' );

function hyd_setup() {
add_theme_support( 'wc-product-gallery-zoom' );
add_theme_support( 'wc-product-gallery-lightbox' );
add_theme_support( 'wc-product-gallery-slider' );
}

//* Remove Related Products
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );

//* Change number or products per row to 3
add_filter('loop_shop_columns', 'loop_columns');
if (!function_exists('loop_columns')) {
	function loop_columns() {
		return 3; // 3 products per row
	}
}

//* Remove Add to Cart on Archives
add_action( 'woocommerce_after_shop_loop_item', 'hyd_remove_add_to_cart_buttons', 1 );
function hyd_remove_add_to_cart_buttons() {

    remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart' );

}

//* Remove Product Description from Single Product Page
add_filter( 'woocommerce_product_description_heading', 'remove_product_description_heading' );
function remove_product_description_heading() {
return '';
}

//* Display 20 products per page
add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 20;' ), 20 );


//* Setup widget counts
function hyd_count_widgets( $id ) {
	global $sidebars_widgets;

	if ( isset( $sidebars_widgets[ $id ] ) ) {
		return count( $sidebars_widgets[ $id ] );
	}

}

function hyd_widget_area_class( $id ) {
	$count = hyd_count_widgets( $id );

	$class = '';

	if( $count == 1 ) {
		$class .= ' widget-full';
	} elseif( $count % 3 == 1 ) {
		$class .= ' widget-thirds';
	} elseif( $count % 4 == 1 ) {
		$class .= ' widget-fourths';
	} elseif( $count % 2 == 0 ) {
		$class .= ' widget-halves uneven';
	} else {
		$class .= ' widget-halves';
	}
	return $class;

}

//* Relocate the post info
remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );
add_action( 'genesis_entry_header', 'genesis_post_info', 5 );

//* Customize the entry meta in the entry header
add_filter( 'genesis_post_info', 'hyd_post_info_filter' );
function hyd_post_info_filter( $post_info ) {

    $post_info = '[post_date] [post_edit]';

    return $post_info;

}

// Add Archive Settings option to Portolio CPT
add_post_type_support( 'portfolio', 'genesis-cpt-archives-settings' );

// Define a custom image size for images on Portfolio archives
add_image_size( 'portfolio', 500, 400, true );

/**
 * Template Redirect
 * Use archive-portfolio.php for portfolio category and tag taxonomy archives.
 */
add_filter( 'template_include', 'hyd_template_redirect' );
function hyd_template_redirect( $template ) {

	if ( is_tax( 'portfolio_category' ) || is_tax( 'portfolio_tag' ) )
		$template = get_query_template( 'archive-portfolio' );
	return $template;

}

add_action( 'pre_get_posts', 'hyd_change_portfolio_posts_per_page' );
/**
 * Set all the entries to appear on Portfolio archive page
 */
function hyd_change_portfolio_posts_per_page( $query ) {

	if( $query->is_main_query() && !is_admin() && is_post_type_archive( 'portfolio' ) ) {
			$query->set( 'posts_per_page', '-1' );
	}

}

//* Customize the entry meta in the entry footer
add_filter( 'genesis_post_meta', 'hyd_post_meta_filter' );
function hyd_post_meta_filter( $post_meta ) {

	$post_meta = 'By: [post_author_posts_link] [post_categories before=" &middot;  Filed Under: "]  [post_tags before=" &middot; Tagged: "]';

	return $post_meta;

}

//* Register widget areas
genesis_register_sidebar( array(
'id' => 'nav-social-menu',
'name' => __( 'Sticky Social Icons', 'hyd' ),
'description' => __( 'Sticky Social Icons.', 'hyd' ),
) );
genesis_register_sidebar( array(
	'id'          => 'leftmenu',
	'name'        => __( 'Header Left', 'hyd' ),
	'description' => __( 'This is the area to the left of the header/logo', 'hyd' ),
) );
genesis_register_sidebar( array(
	'id'          => 'rightmenu',
	'name'        => __( 'Header Right', 'hyd' ),
	'description' => __( 'This is the area to the right of the header/logo', 'hyd' ),
) );
genesis_register_sidebar( array(
	'id'           => 'left-large',
	'name'         => __( 'Left Large', 'darling' ),
	'description'  => __( 'This is the Left Large Box - size 400x450', 'darling' ),
) );
genesis_register_sidebar( array(
	'id'           => 'left-medium',
	'name'         => __( 'Left Medium', 'darling' ),
	'description'  => __( 'This is the Left Medium Box - size 400x300', 'darling' ),
) );
genesis_register_sidebar( array(
	'id'           => 'right-medium',
	'name'         => __( 'Right Medium', 'darling' ),
	'description'  => __( 'This is the Right Medium Box - size 400x300', 'darling' ),
) );
genesis_register_sidebar( array(
	'id'           => 'right-small',
	'name'         => __( 'Right Small', 'darling' ),
	'description'  => __( 'This is the Right Small Box - size 285x300', 'darling' ),
) );
genesis_register_sidebar( array(
	'id'           => 'right-large',
	'name'         => __( 'Right Large', 'darling' ),
	'description'  => __( 'This is the Right Large Box - size 700x450', 'darling' ),
) );
genesis_register_sidebar( array(
	'id'          => 'home-badge',
	'name'        => __( 'Home Badge', 'hyd' ),
	'description' => __( 'Place your Badge/Stamp under the home slider. Best presized at 400W x 400H', 'hyd' ),
) );
genesis_register_sidebar( array(
	'id'          => 'home-welcome',
	'name'        => __( 'Welcome Section', 'hyd' ),
	'description' => __( 'Welcome Section right below grid.', 'hyd' ),
) );
genesis_register_sidebar( array(
	'id'           => 'home-calltoaction',
	'name'         => __( 'Call to Action', 'hyd' ),
	'description'  => __( 'This is the all to action widget area on the home page', 'hyd' ),
) );
genesis_register_sidebar( array(
	'id'           => 'home-services',
	'name'         => __( 'Home Services', 'hyd' ),
	'description'  => __( 'Styled to highlight service boxes, or use as a flexible widget area', 'hyd' ),
) );
genesis_register_sidebar( array(
	'id'           => 'home-featured',
	'name'         => __( 'Home Featured', 'hyd' ),
	'description'  => __( 'This is the featured widget area on the home page', 'hyd' ),
) );
genesis_register_sidebar( array(
	'id'          => 'social-bar',
	'name'        => __( 'Social Bar', 'hyd' ),
	'description' => __( 'This is the full width Social Bar above the footer.', 'hyd' ),
) );
genesis_register_sidebar( array(
	'id'          => 'portfolioblurb',
	'name'        => __( 'Portfolio Archive Page Widget', 'hyd' ),
	'description' => __( 'This widget appears above your portfolio items on your Portfolio archive page.', 'hyd' ),
) );
genesis_register_sidebar( array(
	'id'          => 'flex-footer',
	'name'        => __( 'Flex Footer', 'hyd' ),
	'description' => __( 'Use this for a Traditional 3 Column Footer', 'hyd' ),
) );
