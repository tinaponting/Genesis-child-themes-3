<?php
/**
 * Kylee More.
 * @package Kylee More
 */

add_action( 'customize_register', 'kylee_customizer_register' );
/**
 * Register settings and controls with the Customizer.
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function kylee_customizer_register( $wp_customize ) {

	$wp_customize->add_setting(
		'kylee_accent_color',
		array(
			'default'           => kylee_customizer_get_default_accent_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'kylee_accent_color',
			array(
				'description' => __( 'Change the default color for the subscribe box, footer area, instagram page, pagination, and more.', 'kylee-more' ),
				'label'       => __( 'Accent Color', 'kylee-more' ),
				'section'     => 'colors',
				'settings'    => 'kylee_accent_color',
			)
		)
	);
	
	
	$wp_customize->add_setting(
		'kylee_accent_font_color',
		array(
			'default'           => kylee_customizer_get_default_accent_font_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'kylee_accent_font_color',
			array(
				'description' => __( 'Change the default font color for the subscribe box, footer area, pagination, and more.', 'kylee-more' ),
				'label'       => __( 'Accent Font Color', 'kylee-more' ),
				'section'     => 'colors',
				'settings'    => 'kylee_accent_font_color',
			)
		)
	);
	
	
	$wp_customize->add_setting(
		'kylee_link_color',
		array(
			'default'           => kylee_customizer_get_default_link_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'kylee_link_color',
			array(
				'description' => __( 'Change the default color for links.', 'kylee-more' ),
				'label'       => __( 'Link Color', 'kylee-more' ),
				'section'     => 'colors',
				'settings'    => 'kylee_link_color',
			)
		)
	);
	
	
	$wp_customize->add_setting(
		'kylee_site_title_color',
		array(
			'default'           => kylee_customizer_get_default_site_title_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'kylee_site_title_color',
			array(
				'description' => __( 'Change the default color for the site title.', 'kylee-more' ),
				'label'       => __( 'Site Title Color', 'kylee-more' ),
				'section'     => 'colors',
				'settings'    => 'kylee_site_title_color',
			)
		)
	);
	
	
	$wp_customize->add_setting(
		'kylee_site_description_color',
		array(
			'default'           => kylee_customizer_get_default_site_description_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'kylee_site_description_color',
			array(
				'description' => __( 'Change the default color for the site description.', 'kylee-more' ),
				'label'       => __( 'Site Description Color', 'kylee-more' ),
				'section'     => 'colors',
				'settings'    => 'kylee_site_description_color',
			)
		)
	);
	
	
	$wp_customize->add_setting(
		'kylee_heading_color',
		array(
			'default'           => kylee_customizer_get_default_heading_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'kylee_heading_color',
			array(
				'description' => __( 'Change the default color for the headings.', 'kylee-more' ),
				'label'       => __( 'Heading Color', 'kylee-more' ),
				'section'     => 'colors',
				'settings'    => 'kylee_heading_color',
			)
		)
	);
	
	
	$wp_customize->add_setting(
		'kylee_body_font_color',
		array(
			'default'           => kylee_customizer_get_default_body_font_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'kylee_body_font_color',
			array(
				'description' => __( 'Change the default color for the body font.', 'kylee-more' ),
				'label'       => __( 'Body Font Color', 'kylee-more' ),
				'section'     => 'colors',
				'settings'    => 'kylee_body_font_color',
			)
		)
	);
	
	
	$wp_customize->add_setting(
		'kylee_button_color',
		array(
			'default'           => kylee_customizer_get_default_button_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'kylee_button_color',
			array(
				'description' => __( 'Change the default button color.', 'kylee-more' ),
				'label'       => __( 'Button Color', 'kylee-more' ),
				'section'     => 'colors',
				'settings'    => 'kylee_button_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'kylee_button_font_color',
		array(
			'default'           => kylee_customizer_get_default_button_font_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'kylee_button_font_color',
			array(
				'description' => __( 'Change the default button font color.', 'kylee-more' ),
				'label'       => __( 'Button Font Color', 'kylee-more' ),
				'section'     => 'colors',
				'settings'    => 'kylee_button_font_color',
			)
		)
	);
	
}
