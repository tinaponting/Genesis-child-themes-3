<?php
/**
 * Her Exclusive.
 * @package Her Exclusive
 */
add_action( 'genesis_meta', 'her_front_page_genesis_meta' );
/**
 * Add widget support for homepage. If no widgets active, display the default loop.
 *
 * @since 1.0.0
 */
function her_front_page_genesis_meta() {

	if ( is_active_sidebar( 'front-page-1' ) || is_active_sidebar( 'front-page-2' ) || is_active_sidebar( 'front-page-3' ) || is_active_sidebar( 'front-page-4' ) || is_active_sidebar( 'front-page-5' ) || is_active_sidebar( 'front-page-6' ) ) {

		// Enqueue scripts.
		add_action( 'wp_enqueue_scripts', 'her_enqueue_front_script_styles', 1 );
		function her_enqueue_front_script_styles() {

			wp_enqueue_script( 'her-front-scripts', get_stylesheet_directory_uri() . '/js/front-page.js', array( 'jquery' ), CHILD_THEME_VERSION, true );

			wp_enqueue_style( 'her-front-styles', get_stylesheet_directory_uri() . '/css/style-front.css' );

		}

		// Add front-page body class.
		add_filter( 'body_class', 'her_body_class' );
		function her_body_class( $classes ) {

			$classes[] = 'front-page';

			return $classes;

		}

		// Force full width content layout.
		add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );

		// Remove breadcrumbs.
		remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );
		
		// Remove the default Genesis loop.
		remove_action( 'genesis_loop', 'genesis_do_loop' );

		// Add front page widgets.
		add_action( 'genesis_after_header', 'her_front_page_widgets' );

	}

}

// Add markup for front page widgets.
function her_front_page_widgets() {
	
	if ( get_query_var( 'paged' ) >= 2 )
		return;

	echo '<h2 class="screen-reader-text">' . __( 'Main Content', 'her-exclusive' ) . '</h2>';
	
	genesis_widget_area( 'front-page-1', array(
		'before' => '<div id="front-page-1" class="front-page-1"><div class="image-section widget-area fadeup-effect"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );
	
	genesis_widget_area( 'front-page-2', array(
		'before' => '<div id="front-page-2" class="front-page-2"><div class="solid-section flexible-widgets widget-area fadeup-effect' . her_widget_area_class( 'front-page-2' ) . '"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );
	
	genesis_widget_area( 'front-page-3', array(
		'before' => '<div id="front-page-3" class="front-page-3"><div class="solid-section flexible-widgets widget-area fadeup-effect' . her_widget_area_class( 'front-page-3' ) . '">',
		'after'  => '</div></div>',
	) );
	
	genesis_widget_area( 'front-page-4', array(
		'before' => '<div id="front-page-4" class="front-page-4"><div class="solid-section flexible-widgets widget-area fadeup-effect' . her_widget_area_class( 'front-page-4' ) . '"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );

	genesis_widget_area( 'front-page-5', array(
		'before' => '<div id="front-page-5" class="front-page-5"><div class="image-section flexible-widgets widget-area fadeup-effect' . her_widget_area_class( 'front-page-5' ) . '"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );
	
	genesis_widget_area( 'front-page-6', array(
		'before' => '<div id="front-page-6" class="front-page-6"><div class="solid-section widget-area fadeup-effect' . her_widget_area_class( 'front-page-6' ) . '"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );

}


// Run the Genesis loop.
genesis();
