jQuery(function($){

	var $container = $( ".content" );

	$container.imagesLoaded(function(){
		$container.masonry({
			// use outer width of grid-sizer for columnWidth
			columnWidth: '.grid-sizer',

			gutter: '.gutter-sizer',

			itemSelector: ".entry",

			percentPosition: true,
		});
	});

});
