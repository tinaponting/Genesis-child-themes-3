<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Setup Theme
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );

//* Add Color Selection to WordPress Theme Customizer
require_once( get_stylesheet_directory() . '/lib/customize.php' );

//* Set Localization (do not remove)
load_child_theme_textdomain( 'exquisite', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/languages', 'exquisite' ) );


//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', __( 'Exquisite Damask Theme', 'exquisite' ) );
define( 'CHILD_THEME_VERSION', '1.0' );

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* woocommerce
add_theme_support( 'genesis-connect-woocommerce' );

//* Add WooCommerce Gallery Options
add_action( 'after_setup_theme', 'exquisite_woo_gallery' );
function exquisite_woo_gallery() {
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
}

//* Enqueue Scripts
add_action( 'wp_enqueue_scripts', 'exquisite_load_scripts' );
function exquisite_load_scripts() {
	
	wp_enqueue_script( 'exquisite-responsive-menu', get_bloginfo( 'stylesheet_directory' ) . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0' );
	
	wp_enqueue_style( 'dashicons' );
	
	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Lora|Satisfy', array(), CHILD_THEME_VERSION );

	wp_enqueue_script( 'digital-fadeup-script', get_stylesheet_directory_uri() . '/js/fadeup.js', array( 'jquery' ), '1.0.0', true );
	
}

//* Add new image sizes
add_image_size( 'home-large', 820, 560, TRUE );
add_image_size( 'home-small', 266, 160, TRUE );
add_image_size( 'featured-post', 375, 250, TRUE );

// Full Width Header and Nav
	remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
	remove_action( 'genesis_header', 'genesis_do_header' );
	remove_action( 'genesis_header', 'genesis_header_markup_close', 15 );
	remove_action( 'genesis_after_header', 'genesis_do_nav' );
	remove_action( 'genesis_after_header', 'genesis_do_subnav' );

	add_action( 'genesis_before', 'genesis_header_markup_open', 5 );
	add_action( 'genesis_before', 'genesis_do_header' );
	add_action( 'genesis_before', 'genesis_header_markup_close', 15 );
	add_action( 'genesis_before', 'genesis_do_nav', 2 );
	add_action( 'genesis_before', 'genesis_do_subnav', 20 );  

//* Making Footer Area Full Width
	remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );
	add_action( 'genesis_after', 'genesis_footer_widget_areas' );

	remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
	remove_action( 'genesis_footer', 'genesis_do_footer' );
	remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );

	add_action( 'genesis_after', 'genesis_footer_markup_open', 11 );
	add_action( 'genesis_after', 'genesis_do_footer', 12 );
	add_action( 'genesis_after', 'genesis_footer_markup_close', 13 );

//* Customize search form input box text
add_filter( 'genesis_search_text', 'exquisite_search_text' );
function exquisite_search_text( $text ) {
	return esc_attr( 'Search...' );
}


//* Add Navigation Description
add_filter( 'walker_nav_menu_start_el', 'exquisite_add_description', 10, 2 );
function exquisite_add_description( $item_output, $item ) {

    $description = $item->post_content;
    if (' ' !== $description ) {
        return preg_replace( '/(<a.*)</', '$1' . '<span class="menu-description">' . $description . '</span><', $item_output) ;
    }
    else {
        return $item_output;
    };

}

//* Add widget to secondary navigation
add_filter( 'genesis_nav_items', 'exquisite_social_icons', 10, 2 );
add_filter( 'wp_nav_menu_items', 'exquisite_social_icons', 10, 2 );

function exquisite_social_icons($menu, $args) {
	$args = (array)$args;
	if ( 'primary' !== $args['theme_location'] )
		return $menu;
	ob_start();
	genesis_widget_area('nav-social-menu');
	$social = ob_get_clean();
	return $menu . $social;
}

//* Remove Widgets
function remove_some_widgets(){

     unregister_sidebar( 'header-right' );
     unregister_sidebar( 'sidebar-alt' );
     unregister_sidebar( 'after-entry' );
}
add_action( 'widgets_init', 'remove_some_widgets', 11 );

//* Unregister Layouts
	genesis_unregister_layout( 'content-sidebar-sidebar' ); 
	genesis_unregister_layout( 'sidebar-sidebar-content' ); 
	genesis_unregister_layout( 'sidebar-content-sidebar' );

//* Modify the Genesis content limit read more link
add_filter( 'get_the_content_more_link', 'sp_read_more_link' );
function sp_read_more_link() {
	return '... <a class="more-link" href="' . get_permalink() . '">Continue Reading...</a>';
}

//* Add Title & Caption to Soliloquy Slider
add_filter( 'soliloquy_output_caption', 'sol_soliloquy_title_before_caption', 10, 5 );
function sol_soliloquy_title_before_caption( $caption, $id, $slide, $data, $i ) {
     
    // Check if current slide has a title specified
    if ( isset( $slide['title'] ) && !empty( $slide['title'] ) ) {
        $caption = '<h4 class="title">' . $slide['title'] . '</h4>'; 
	$caption .= '<div class="caption">' . $slide['caption'] . '</h4>';  
        } 
        return $caption;
}

//* Customize the credits
add_filter( 'genesis_footer_creds_text', 'sp_footer_creds_text' );
function sp_footer_creds_text() {
	echo '<div class="creds"><p>';
	echo ' Theme Design By <a href="https://exempel.se" title="Exempel">Exempel sajt</a> &middot; ';
	echo 'Copyright &copy; ';
	echo date('Y');
	echo '</p></div>';
}

//* Remove the post info function
remove_action( 'genesis_before_post_content', 'genesis_post_info' );

//* Customize the entry meta in the entry header (requires HTML5 theme support)
add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
	$post_info = '[post_date] [post_comments] [post_edit]';
	return $post_info;
}

//* Customize the post meta function
add_filter( 'genesis_post_meta', 'post_meta_filter' );
function post_meta_filter($post_meta) {
	$post_meta = '[post_comments] </br> [post_categories before="Filed Under: "] [post_tags before="Tagged: "] [post_edit]';
	return $post_meta;
}

//* Add support for custom background
add_theme_support( 'custom-background', array(
	'default-image' => '',
	'default-color' => 'ebe7e6',
) );

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'header_image'    => '',
	'header-selector' => '.site-title a',
	'header-text'     => false,
	'height'          => 200,
	'width'           => 1240,
) );

//* Rename Section Header Image in Customize 
function my_custom_header_title( $wp_customize ) {
    $wp_customize->get_section( 'header_image' )->title = __( 'Header Logo', 'exquisite' );
}
add_action( 'customize_register', 'my_custom_header_title');

//* Modify the size of the Gravatar in the author box
add_filter( 'genesis_author_box_gravatar_size', 'exquisite_author_box_gravatar' );
function exquisite_author_box_gravatar( $size ) {

	return 96;
		
}

//* Modify the size of the Gravatar in the entry comments
add_filter( 'genesis_comment_list_args', 'exquisite_comments_gravatar' );
function exquisite_comments_gravatar( $args ) {

	$args['avatar_size'] = 60;
	return $args;
	
}

//* Remove comment form allowed tags
add_filter( 'comment_form_defaults', 'exquisite_remove_comment_form_allowed_tags' );
function exquisite_remove_comment_form_allowed_tags( $defaults ) {
	
	$defaults['comment_notes_after'] = '';
	return $defaults;

}

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Add Fourth Footer Area
add_action( 'genesis_after', 'exquisite_bottom_bar', 10 );
function exquisite_bottom_bar() {

	echo '<div class="bottom-bar-widget">';

	genesis_widget_area( 'bottom-bar', array(
		'before' => '<div class="bottom-bar widget-area"><div class="wrap">',
		'after' => '</div></div>',
	) );

	echo '</div>';
}

//* Add support for after entry widget
add_theme_support( 'genesis-after-entry-widget-area' );

//* Relocate after entry widget
remove_action( 'genesis_after_entry', 'genesis_after_entry_widget_area' );
add_action( 'genesis_after_entry', 'genesis_after_entry_widget_area', 5 );

//* Add Archive Settings option to Portolio CPT
add_post_type_support( 'portfolio', 'genesis-cpt-archives-settings' );

//* Define a custom image size for Portfolio images
add_image_size( 'portfolio', 380, 250, true );

/**
 * Template Redirect
 * Use archive-portfolio.php for portfolio category and tag taxonomy archives.
 */
add_filter( 'template_include', 'exquisite_template_redirect' );
function exquisite_template_redirect( $template ) {

	if ( is_tax( 'portfolio_category' ) || is_tax( 'portfolio_tag' ) )
		$template = get_query_template( 'archive-portfolio' );
	return $template;

}

/**
 * Template Redirect
 * Use archive-portfolio.php for portfolio category and tag taxonomy archives.
 */
add_filter( 'template_include', 'custom_portfolio_archives_template', 99 );
function custom_portfolio_archives_template( $template ) {

	if ( is_tax( 'portfolio_category' ) || is_tax( 'portfolio_tag' ) ) {
		$new_template = locate_template( array( 'archive-portfolio.php' ) );
		if ( '' != $new_template ) {
			return $new_template ;
		}
	}

	return $template;
}

add_action( 'pre_get_posts', 'exquisite_change_portfolio_archive_posts_per_page' );
/**
 * Change Posts Per Page for Portfolio Archive
 * @param object $query data
 *
 */
function exquisite_change_portfolio_archive_posts_per_page( $query ) {

	if( $query->is_main_query() && !is_admin() && is_post_type_archive( 'portfolio' ) ) {
		$query->set( 'posts_per_page', '-1' );
	}

}

//* Register widget areas
genesis_register_sidebar( array(
	'id'          	=> 'nav-social-menu',
	'name'        	=> __( 'Nav Bar Social Media Icons', 'exquisite' ),
	'description' 	=> __( 'This is where to place your social media icons that go on the top Navigation Bar.', 'exquisite' ),
) );
genesis_register_sidebar( array(
	'id'          => 'home-slider',
	'name'        => __( 'Home Slider', 'exquisite' ),
	'description' => __( 'This is the slider section of the homepage.', 'exquisite' ),
) );
genesis_register_sidebar( array(
	'id'          => 'announcement-bar',
	'name'        => __( 'Home Announcement', 'exquisite' ),
	'description' => __( 'This is the Announcement Bar after the slider on the homepage.', 'exquisite' ),
) );

genesis_register_sidebar( array(
	'id'          => 'featured-flex-posts',
	'name'        => __( 'Home Featured Posts', 'exquisite' ),
	'description' => __( 'This is the featured posts section after the announcement bar on the homepage.', 'exquisite' ),
) );

genesis_register_sidebar( array(
	'id'          => 'home-testimonial',
	'name'        => __( 'Home Testimonial', 'exquisite' ),
	'description' => __( 'This is the testimonial section after the featured posts.', 'exquisite' ),
) );

genesis_register_sidebar( array(
	'id'          => 'featured-products',
	'name'        => __( 'Home Featured Products', 'exquisite' ),
	'description' => __( 'This is the Featured Product section after the testimonials.', 'exquisite' ),
) );

genesis_register_sidebar( array(
	'id'          => 'bottom-bar',
	'name'        => __( 'Bottom Bar', 'exquisite' ),
	'description' => __( 'This is the bottom bar after the footer widgets. Can be used for a wide Instagram Widget.', 'exquisite' ),
) );