<?php
/**
 * Chef Pro.
 * @package Chef
 */

add_action( 'customize_register', 'chef_pro_customizer_register' );
/**
 * Register settings and controls with the Customizer.
 *
 * @since 2.2.3
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function chef_pro_customizer_register( $wp_customize ) {

	$wp_customize->add_setting(
		'chef_pro_link_color',
		array(
			'default'           => chef_pro_customizer_get_default_link_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'chef_pro_link_color',
			array(
				'description' => __( 'Change the color of post info links, hover color of linked titles, hover color of menu items, and more.', 'chef-pro' ),
				'label'       => __( 'Link Color', 'chef-pro' ),
				'section'     => 'colors',
				'settings'    => 'chef_pro_link_color',
			)
		)
	);

	$wp_customize->add_setting(
		'chef_pro_accent_color',
		array(
			'default'           => chef_pro_customizer_get_default_accent_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'chef_pro_accent_color',
			array(
				'description' => __( 'Change the default hovers color for button.', 'chef-pro' ),
				'label'       => __( 'Accent Color', 'chef-pro' ),
				'section'     => 'colors',
				'settings'    => 'chef_pro_accent_color',
			)
		)
	);

	$wp_customize->add_section( 'front_page_hero_background' , array(
		'title'      => __( 'Hero Background','chef-pro' ),
		'priority'   => 70,
	) );

	$wp_customize->add_setting( 'hero_bg', array(
		'default'     => get_stylesheet_directory_uri() . '/images/hero-bg.jpg',
	) );

	$wp_customize->add_control( new WP_Customize_Image_Control(
		$wp_customize, 'hero_background_image', array(
			  'section'    => 'front_page_hero_background',
			  'settings'   => 'hero_bg',
			  )
	) );

}

add_action( "customize_register", "chef_pro_theme_customize_register" );
function chef_pro_theme_customize_register( $wp_customize ) {
	$wp_customize->remove_control("background_color");
	$wp_customize->remove_section("background_image");
}
