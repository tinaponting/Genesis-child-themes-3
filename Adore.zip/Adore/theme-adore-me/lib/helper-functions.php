<?php
/**
 * Adore Me.
 * @package Adore Me
 */

/**
 * Get default color for Customizer.
 * Abstracted here since at least two functions use it.
 *
 * @return string Hex color code.
 */
function adore_customizer_get_default_link_color() {
	return '#bca17a';
}

function adore_customizer_get_default_body_font() {
	return '#222222';
}

function adore_customizer_get_default_headings_font() {
	return '#222222';
}

function adore_customizer_get_default_site_title_color() {
	return '#222222';
}

function adore_customizer_get_default_site_description_color() {
	return '#222222';
}

function adore_customizer_get_default_header_menu() {
	return '#f3e9e7';
}

function adore_customizer_get_default_header_menu_font() {
	return '#222222';
}

function adore_customizer_get_default_header_after_menu_font() {
	return '#222222';
}

function adore_customizer_get_default_textbox_one() {
	return '#f3e9e7';
}

function adore_customizer_get_default_textbox_one_font() {
	return '#222222';
}

function adore_customizer_get_default_textbox_two() {
	return '#333333';
}

function adore_customizer_get_default_textbox_two_font() {
	return '#ffffff';
}

function adore_customizer_get_default_featured_image_bg() {
	return '#F3E9E7';
}

function adore_customizer_get_default_featured_image_entry() {
	return '#222222';
}

function adore_customizer_get_default_sidebar_border() {
	return '#F3E9E7';
}

function adore_customizer_get_default_frontpage_four() {
	return '#333333';
}

function adore_customizer_get_default_frontpage_four_font() {
	return '#ffffff';
}
