<?php
//* Install Necessary Plugins
/**
 * This file represents an example of the code that themes would use to register
 * the required plugins.
 * @package    TGM-Plugin-Activation
 * @subpackage Example
 */
/**
 * Include the TGM_Plugin_Activation class.
 */
require_once dirname( __FILE__ ) . '/lib/tgmpa/class-tgm-plugin-activation.php';
add_action( 'tgmpa_register', 'my_theme_register_required_plugins' );
/**
 * Register the required plugins for this theme.
 */
function my_theme_register_required_plugins() {
	$plugins = array(
		array(
			'name'=> 'Genesis Grid',
			'slug'=> 'genesis-grid-loop',
			'required'=> true,
			),
		    array(
			'name'=> 'Genesis Simple Edits',
			'slug'=> 'genesis-simple-edits',
			'required'=> true,
			),
		    array(
			'name'=> 'Instagram Slider Widget',
			'slug'=> 'instagram-slider-widget',
			'required'=> true,
		),
	       array(
			'name'=> 'OTF Regenerate Thumbnails',
			'slug'=> 'otf-regenerate-thumbnails',
			'required'=> true,
		),
			array(
			'name'=> 'Simple Social Icons',
			'slug'=> 'simple-social-icons',
			'required'=> true,
		),
			array(
			'name'=> 'Contact Form Clean And Simple',
			'slug'=> 'clean-and-simple-contact-form-by-meg-nicholas',
			'required'=> true,
		),	);

	/*
	 * Array of configuration settings. Amend each line as needed.
	 * Only uncomment the strings in the config array if you want to customize the strings.
	 */
	$config = array(
		'id'=> 'tgmpa',           
		'default_path'=> '',               
		'menu'=> 'tgmpa-install-plugins', 
		'parent_slug'=> 'themes.php',           
		'capability'=> 'edit_theme_options',    
		'has_notices'=> true,                   
		'dismissable'=> true,                
		'dismiss_msg'=> '',                    
		'is_automatic'=> false,               
		'message'=> '',                     

	);
	tgmpa( $plugins, $config );
}