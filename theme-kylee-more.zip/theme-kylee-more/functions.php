<?php
/**
 * Kylee More.
 * @package Kylee More
 */

// Start the engine.
include_once( get_template_directory() . '/lib/init.php' );

// Setup Theme.
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );

// Helper functions.
include_once( get_stylesheet_directory() . '/lib/helper-functions.php' );

// Include customizer CSS.
include_once( get_stylesheet_directory() . '/lib/output.php' );

// Add image upload and color select to theme customizer.
require_once( get_stylesheet_directory() . '/lib/customize.php' );

// Set Localization (do not remove).
add_action( 'after_setup_theme', 'kylee_localization_setup' );
function kylee_localization_setup(){
	load_child_theme_textdomain( 'kylee-more', get_stylesheet_directory() . '/languages' );
}

// Child theme (do not remove).
define( 'CHILD_THEME_NAME', 'Kylee More' );
define( 'CHILD_THEME_URL', 'https://studiomommy.com/' );
define( 'CHILD_THEME_VERSION', '4.0' );

// Enqueue scripts and styles.
add_action( 'wp_enqueue_scripts', 'kylee_enqueue_scripts_styles' );
function kylee_enqueue_scripts_styles() {

	wp_enqueue_style( 'kylee-fonts', '//fonts.googleapis.com/css?family=Prata|Poppins:400,700&display=swap', array(), CHILD_THEME_VERSION );
	wp_enqueue_style( 'kylee-ionicons', '//code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css', array(), CHILD_THEME_VERSION );
	wp_enqueue_script( 'match-height', get_stylesheet_directory_uri() . '/js/jquery.matchHeight-min.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_script( 'match-height-init', get_stylesheet_directory_uri() . '/js/matchheight-init.js', array( 'match-height' ), '1.0.0', true );
	
	$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
	wp_enqueue_script( 'kylee-responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menus' . $suffix . '.js', array( 'jquery' ), CHILD_THEME_VERSION, true );
	wp_localize_script(
		'kylee-responsive-menu',
		'genesis_responsive_menu',
		kylee_responsive_menu_settings()
	);

}



// Define our responsive menu settings.
function kylee_responsive_menu_settings() {

	$settings = array(
		'mainMenu'         => __( 'Menu', 'kylee-more' ),
		'menuIconClass'    => 'ionicons-before ion-ios-drag',
		'subMenu'          => __( 'Submenu', 'kylee-more' ),
		'subMenuIconClass' => 'ionicons-before ion-chevron-down',
		'menuClasses'      => array(
			'others' => array(
				'.nav-primary',
			),
		),
	);

	return $settings;

}

// Add HTML5 markup structure.
add_theme_support( 'html5', array( 'caption', 'comment-form', 'comment-list', 'gallery', 'search-form' ) );

// Add accessibility support.
add_theme_support( 'genesis-accessibility', array( 'drop-down-menu', 'headings', 'rems', 'search-form', 'skip-links' ) );

// Add support for custom header.
add_theme_support( 'custom-header', array(
	'width'           => 800,
	'height'          => 400,
	'header-selector' => '.site-title a',
	'header-text'     => false,
	'flex-height'     => true,
) );

// Add image sizes.
add_image_size( 'square-image', 400, 400, TRUE );
add_image_size( 'vertical-image', 400, 600, TRUE );
add_image_size( 'horizontal-image', 800, 450, TRUE );

// Add support for after entry widget.
add_theme_support( 'genesis-after-entry-widget-area' );

// Remove header right widget area.
unregister_sidebar( 'header-right' );

// Remove secondary sidebar.
unregister_sidebar( 'sidebar-alt' );

// Remove site layouts.
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );

// Remove output of primary navigation right extras.
remove_filter( 'genesis_nav_items', 'genesis_nav_right', 10, 2 );
remove_filter( 'wp_nav_menu_items', 'genesis_nav_right', 10, 2 );

// Remove navigation meta box.
add_action( 'genesis_theme_settings_metaboxes', 'kylee_remove_genesis_metaboxes' );
function kylee_remove_genesis_metaboxes( $_genesis_theme_settings_pagehook ) {
	remove_meta_box( 'genesis-theme-settings-nav', $_genesis_theme_settings_pagehook, 'main' );
}

// Remove skip link for primary navigation.
add_filter( 'genesis_skip_links_output', 'kylee_skip_links_output' );
function kylee_skip_links_output( $links ) {

	if ( isset( $links['genesis-nav-primary'] ) ) {
		unset( $links['genesis-nav-primary'] );
	}

	return $links;

}

// Rename primary and secondary navigation menus.
add_theme_support( 'genesis-menus', array( 'primary' => __( 'Header Menu', 'kylee-more' ), 'secondary' => __( 'Footer Menu', 'kylee-more' ) ) );

// Reposition the secondary navigation menu.
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before_header', 'genesis_do_nav' );

// Reposition the secondary navigation menu.
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_footer', 'genesis_do_subnav', 5 );

//Add Search Box to Nav.
add_filter( 'wp_nav_menu_items', 'custom_nav_search', 10, 2 );
/**
* Add search box to nav menu.
*/
function custom_nav_search( $items, $args ) {

    if ( 'primary' === $args->theme_location ) { // affect only Primary Navigation Menu.
        $items .= '<li class="menu-item search">' . get_search_form( false ) . '</li>';
    }

    return $items;

}

// Reduce secondary navigation menu to one level depth.
add_filter( 'wp_nav_menu_args', 'kylee_secondary_menu_args' );
function kylee_secondary_menu_args( $args ) {

	if ( 'secondary' != $args['theme_location'] ) {
		return $args;
	}

	$args['depth'] = 1;

	return $args;

}

//* Add Title & Caption to Soliloquy Slider
add_filter( 'soliloquy_output_caption', 'kylee_soliloquy_title_before_caption', 10, 5 );
function kylee_soliloquy_title_before_caption( $caption, $id, $slide, $data, $i ) {
     
    // Check if current slide has a title specified
    if ( isset( $slide['title'] ) && !empty( $slide['title'] ) ) {
        $caption = '<h4 class="title">' . $slide['title'] . '</h4>'; 
	$caption .= '<div class="caption">' . $slide['caption'] . '</h4>';  
        } 
        return $caption;
}

//* Position post info above post title
remove_action( 'genesis_entry_header', 'genesis_post_info', 12);
add_action( 'genesis_entry_header', 'genesis_post_info', 9 );

//* Customize the Post Info Function
add_filter( 'genesis_post_info', 'kylee_post_info_filter' );
function kylee_post_info_filter( $post_info ) {

	$post_info = '[post_categories before="<i>in</i> " sep=",  "] &middot [post_date]';
    return $post_info;

}

//* Remove the entry meta in the entry footer (requires HTML5 theme support)
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

//* Add even/odd post class for Posts in Posts page, Archives and Search results
add_filter( 'post_class', 'sk_even_odd_post_class' );
function sk_even_odd_post_class( $classes ) {

	global $wp_query;

	if ( is_home() || is_archive() || is_search() ) {
		$classes[] = ($wp_query->current_post % 2 == 0) ? 'odd' : 'even';
	}

	return $classes;

}

//* Modify the Genesis content limit read more link
add_filter( 'get_the_content_more_link', 'sp_read_more_link' );
function sp_read_more_link() {
	return '... <a class="more-link" href="' . get_permalink() . '">Read <i>the</i> Post...</a>';
}

// Change posts per page in the design category
add_action( 'pre_get_posts', 'kylee_cat_posts_per_page' );
function kylee_cat_posts_per_page( $query ) {
    if( $query->is_main_query() && is_category() && ! is_admin() ) {
        $query->set( 'posts_per_page', '9' );
    }
}


// Modify size of the Gravatar in the author box.
add_filter( 'genesis_author_box_gravatar_size', 'kylee_author_box_gravatar' );
function kylee_author_box_gravatar( $size ) {
	return 100;
}

// Modify size of the Gravatar in the entry comments.
add_filter( 'genesis_comment_list_args', 'kylee_comments_gravatar' );
function kylee_comments_gravatar( $args ) {

	$args['avatar_size'] = 60;

	return $args;

}

//* Load Entry Navigation
add_action( 'genesis_entry_footer', 'genesis_prev_next_post_nav' );

// Hook Widget Area Above Footer
add_action( 'genesis_before_footer', 'kylee_widget_above_footer', 1 ); 
function kylee_widget_above_footer() {

    genesis_widget_area( 'widget-above-footer', array(
		'before' => '<div class="widget-above-footer widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );

}

//* Customize the credits
add_filter('genesis_pre_get_option_footer_text', 'kylee_footer_creds_text');
function kylee_footer_creds_text( $creds ) {
    $creds = '<div class="creds">Copyright [footer_copyright] &middot; [footer_site_title] &middot; EXEMPEL <a target="_blank" href="https://exempel.se/">EXEMPEL</a></div>';
    return $creds;
}

// Setup widget counts.
function kylee_count_widgets( $id ) {

	$sidebars_widgets = wp_get_sidebars_widgets();

	if ( isset( $sidebars_widgets[ $id ] ) ) {
		return count( $sidebars_widgets[ $id ] );
	}

}

// Determine the widget area class.
function kylee_widget_area_class( $id ) {

	$count = kylee_count_widgets( $id );

	$class = '';

	if ( $count == 1 ) {
		$class .= ' widget-full';
	} elseif ( $count % 3 == 1 ) {
		$class .= ' widget-thirds';
	} elseif ( $count % 4 == 1 ) {
		$class .= ' widget-fourths';
	} elseif ( $count % 2 == 0 ) {
		$class .= ' widget-halves uneven';
	} else {
		$class .= ' widget-halves';
	}

	return $class;

}

add_action( 'after_setup_theme', 'genesis_child_gutenberg_support' );
/**
 * Adds Gutenberg opt-in features and styling.
 *
 * @since 2.7.0
 */
function genesis_child_gutenberg_support() { // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedFunctionFound -- using same in all child themes to allow action to be unhooked.
        require_once get_stylesheet_directory() . '/lib/gutenberg/init.php';
}

// Add To Top button
add_action( 'genesis_before', 'genesis_to_top');
	function genesis_to_top() {
	 echo '<a href="#0" class="to-top" title="Back To Top">Top</a>';
}


//* Add Page Widget Area to Content
add_action( 'genesis_entry_footer', 'kylee_instagram_menu_add_page_content' );
function kylee_instagram_menu_add_page_content() {
	if ( is_page_template( 'instagram_landing.php' ) ) {
	
		genesis_widget_area ('instagram-landing-page-widget', array(
        'before' => '<div class="instagram-landing-page-widget"><div class="wrap">',
        'after' => '</div></div>',
	) );
		
	}
}


// Add support for 3-column footer widgets.
add_theme_support( 'genesis-footer-widgets', 3 );

// Register widget areas.
genesis_register_sidebar( array(
	'id'          => 'front-page-1',
	'name'        => __( 'Front Page 1', 'kylee-more' ),
	'description' => __( 'This is the Front Page 1 section on the homepage.', 'kylee-more' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-2',
	'name'        => __( 'Front Page 2', 'kylee-more' ),
	'description' => __( 'This is the Front Page 2 section on the homepage.', 'kylee-more' ),
) );
genesis_register_sidebar( array(
	'id'		=> 'instagram-landing-page-widget',
	'name'		=> __( 'Instagram Page', 'kylee-more' ),
	'description'	=> __( 'This is the widget area for your Instagram Page.', 'kylee-more' ),
) );
genesis_register_sidebar( array(
	'id'          => 'widget-above-footer',
	'name'        => __( 'Widget Above Footer', 'kylee-more' ),
	'description' => __( 'This is the Instagram widget section in the footer (shows your 4 recent Instagram images).', 'kylee-more' ),
) );