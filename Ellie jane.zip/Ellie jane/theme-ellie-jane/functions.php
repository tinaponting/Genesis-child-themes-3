<?php
/**
 * Ellie Jane.
 * @package Ellie Jane
 */

// Start the engine.
include_once( get_template_directory() . '/lib/init.php' );

// Setup Theme.
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );

// Set Localization (do not remove).
add_action( 'after_setup_theme', 'ellie_localization_setup' );
function ellie_localization_setup(){
	load_child_theme_textdomain( 'ellie-jane', get_stylesheet_directory() . '/languages' );
}

// Add the theme helper functions.
include_once( get_stylesheet_directory() . '/lib/helper-functions.php' );

// Add Color select to WordPress Theme Customizer.
require_once( get_stylesheet_directory() . '/lib/customize.php' );

// Include Customizer CSS.
include_once( get_stylesheet_directory() . '/lib/output.php' );

// Add WooCommerce support.
include_once( get_stylesheet_directory() . '/lib/woocommerce/woocommerce-setup.php' );

// Add the WooCommerce customizer CSS.
include_once( get_stylesheet_directory() . '/lib/woocommerce/woocommerce-output.php' );

// Include notice to install Genesis Connect for WooCommerce.
include_once( get_stylesheet_directory() . '/lib/woocommerce/woocommerce-notice.php' );

// Child theme (do not remove).
define( 'CHILD_THEME_NAME', __( 'Ellie Jane', 'ellie-jane' ) );
define( 'CHILD_THEME_VERSION', '3.5' );

// Add HTML5 markup structure.
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );

// Add Accessibility support.
add_theme_support( 'genesis-accessibility', array( 'drop-down-menu', 'headings', 'rems', 'search-form', 'skip-links' ) );

// Enqueue Scripts.
add_action( 'wp_enqueue_scripts', 'ellie_load_scripts' );
function ellie_load_scripts() {

	wp_enqueue_style( 'dashicons' );

	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Raleway:400,700|Source+Sans+Pro:400,600,700&display=swap', array(), CHILD_THEME_VERSION );

	$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
	wp_enqueue_script( 'ellie-responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menus' . $suffix . '.js', array( 'jquery' ), CHILD_THEME_VERSION, true );
	wp_localize_script(
		'ellie-responsive-menu',
		'genesis_responsive_menu',
		ellie_responsive_menu_settings()
	);

}

// Define our responsive menu settings.
function ellie_responsive_menu_settings() {

	$settings = array(
		'mainMenu'    => __( 'Menu', 'ellie-jane' ),
		'subMenu'     => __( 'Submenu', 'ellie-jane' ),
		'menuClasses' => array(
			'combine' => array(
				'.nav-primary',
				'.nav-header',
			),
			'others'  => array( '.nav-secondary' ),
		),
	);

	return $settings;

}

// Add image sizes.
add_image_size( 'featured-image', 720, 400, TRUE );
add_image_size( 'home-small', 266, 160, TRUE );
add_image_size( 'square-entry-image', 400, 400, TRUE );
add_image_size( 'portfolio', 410, 250, TRUE );

// Add support for custom background.
add_theme_support( 'custom-background', array(
	'default-image' => '',
	'default-color' => 'ffffff',
) );

// Add support for custom header.
add_theme_support( 'custom-header', array(
	'flex-height'     => true,
	'header_image'    => '',
	'header-selector' => '.site-title a',
	'header-text'     => false,
	'height'          => 400,
	'width'           => 800,
) );

//* Remove Widgets
function remove_some_widgets(){

     // Unregsiter some of the TwentyTen sidebars
     unregister_sidebar( 'header-right' );
     unregister_sidebar( 'sidebar-alt' );
}
add_action( 'widgets_init', 'remove_some_widgets', 11 );

//* Unregister Layouts
genesis_unregister_layout( 'content-sidebar-sidebar' ); 
genesis_unregister_layout( 'sidebar-sidebar-content' ); 
genesis_unregister_layout( 'sidebar-content-sidebar' );

// Rename menus.
add_theme_support( 'genesis-menus', array( 
	'primary' => __( 'Before Header Menu', 'ellie-jane' ), 
	'secondary' => __( 'Footer Menu', 'ellie-jane' ) 
) );

// Remove output of primary navigation right extras.
remove_filter( 'genesis_nav_items', 'genesis_nav_right', 10, 2 );
remove_filter( 'wp_nav_menu_items', 'genesis_nav_right', 10, 2 );

// Remove navigation meta box.
add_action( 'genesis_theme_settings_metaboxes', 'ellie_remove_genesis_metaboxes' );
function ellie_remove_genesis_metaboxes( $_genesis_theme_settings_pagehook ) {
	remove_meta_box( 'genesis-theme-settings-nav', $_genesis_theme_settings_pagehook, 'main' );
}

// Add ID to secondary navigation.
add_filter( 'genesis_attr_nav-secondary', 'ellie_add_nav_secondary_id' );
function ellie_add_nav_secondary_id( $attributes ) {

	$attributes['id'] = 'genesis-nav-secondary';

	return $attributes;

}

// Remove skip link for primary navigation.
add_filter( 'genesis_skip_links_output', 'ellie_skip_links_output' );
function ellie_skip_links_output( $links ) {

	if ( isset( $links['genesis-nav-primary'] ) ) {
		unset( $links['genesis-nav-primary'] );
	}

	$new_links = $links;
	array_splice( $new_links, 0 );

	if ( has_nav_menu( 'secondary' ) ) {
		$new_links['genesis-nav-secondary'] = __( 'Skip to secondary menu', 'ellie-jane' );
	}

	return array_merge( $new_links, $links );

}

// Reposition the primary navigation.
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before_header', 'genesis_do_nav' );

//* Reposition the secondary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_footer', 'genesis_do_subnav', 5 );

//* Reduce the secondary navigation menu to one level depth
add_filter( 'wp_nav_menu_args', 'ellie_secondary_menu_args' );
function ellie_secondary_menu_args( $args ){

	if( 'secondary' != $args['theme_location'] )
	return $args;

	$args['depth'] = 1;
	return $args;

}

// Open wrap within site-container.
add_action( 'genesis_before_header', 'ellie_open_site_container_wrap' );
function ellie_open_site_container_wrap() {

	echo '<div class="site-container-wrap">';

}

//* Add Title & Caption to Soliloquy Slider
add_filter( 'soliloquy_output_caption', 'ellie_soliloquy_title_before_caption', 10, 5 );
function ellie_soliloquy_title_before_caption( $caption, $id, $slide, $data, $i ) {
     
    // Check if current slide has a title specified
    if ( isset( $slide['title'] ) && !empty( $slide['title'] ) ) {
        $caption = '<h4 class="title">' . $slide['title'] . '</h4>'; 
	$caption .= '<div class="caption">' . $slide['caption'] . '</h4>';  
        } 
        return $caption;
}

//* Remove Archive Description
remove_action( 'genesis_before_loop', 'genesis_do_blog_template_heading' );
remove_action( 'genesis_before_loop', 'genesis_do_taxonomy_title_description', 15 );

//* Position featured image above title
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
add_action( 'genesis_entry_header', 'genesis_do_post_image', 1 );

//* Position post info above post title
remove_action( 'genesis_entry_header', 'genesis_post_info', 12);
add_action( 'genesis_entry_header', 'genesis_post_info', 9 );

//* Customize the Post Info Function
add_filter( 'genesis_post_info', 'ellie_post_info_filter' );
function ellie_post_info_filter( $post_info ) {

	$post_info = '[post_categories before="in " sep=" &middot "] &middot [post_comments] [post_date before="on "]';
    return $post_info;

}

//* Modify the Genesis content limit read more link
add_filter( 'get_the_content_more_link', 'adore_read_more_link' );
function adore_read_more_link() {
	return '... <a class="more-link" href="' . get_permalink() . '">Read More</a>';
}

// Modify the size of the Gravatar in the author box.
add_filter( 'genesis_author_box_gravatar_size', 'ellie_author_box_gravatar' );
function ellie_author_box_gravatar( $size ) {
	return 96;
}

// Modify the size of the Gravatar in the entry comments.
add_filter( 'genesis_comment_list_args', 'ellie_comments_gravatar' );
function ellie_comments_gravatar( $args ) {

	$args['avatar_size'] = 60;

	return $args;

}

// Close wrap within site-container.
add_action( 'genesis_before_footer', 'ellie_close_site_container_wrap' );
function ellie_close_site_container_wrap() {
	echo '</div>';
}

// Add support for 3-column footer widgets.
add_theme_support( 'genesis-footer-widgets', 3 );

//* Hooks Widget Area Above Content
add_action( 'genesis_after_header', 'ellie_widget_above_content'  ); 
function ellie_widget_above_content() {

if ( !is_home() ) {

    genesis_widget_area( 'widget-above-content', array(
		'before' => '<div class="widget-above-content widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );

	}
}

//* Hooks Widget Area Below Footer
add_action( 'genesis_before_footer', 'ellie_widget_below_footer', 10 ); 
function ellie_widget_below_footer() {

    genesis_widget_area( 'widget-below-footer', array(
		'before' => '<div class="widget-below-footer widget-area">',
		'after'  => '</div>',
    ) );

}

// Add support for after entry widget.
add_theme_support( 'genesis-after-entry-widget-area' );

// Relocate after entry widget.
remove_action( 'genesis_after_entry', 'genesis_after_entry_widget_area' );
add_action( 'genesis_after_entry', 'genesis_after_entry_widget_area', 5 );

//* Customize the credits
add_filter('genesis_pre_get_option_footer_text', 'ellie_footer_creds_text');
function ellie_footer_creds_text( $creds ) {
    $creds = '<div class="creds">Copyright [footer_copyright] &middot; [footer_site_title] &middot; EXEMPEL <a target="_blank" href="https://exempel.se/">Exempel</a></div>';
    return $creds;
}

//* Setup widget counts
function custom_count_widgets( $id ) {
	global $sidebars_widgets;

	if ( isset( $sidebars_widgets[ $id ] ) ) {
		return count( $sidebars_widgets[ $id ] );
	}

}

function custom_widget_area_class( $id ) {
	$count = custom_count_widgets( $id );

	$class = '';

	if( $count == 1 ) {
		$class .= ' widget-full';
	} elseif( $count % 3 == 0 ) {
		$class .= ' widget-thirds';
	} elseif( $count % 4 == 0 ) {
		$class .= ' widget-fourths';
	} elseif( $count % 2 == 1 ) {
		$class .= ' widget-halves uneven';
	} else {
		$class .= ' widget-halves';
	}

	return $class;

}

// Register widget areas.
genesis_register_sidebar( array(
	'id'          => 'slider-content',
	'name'        => __( 'Home Slider', 'ellie-jane' ),
	'description' => __( 'This is the slider section of the homepage.', 'ellie-jane' ),
) );
genesis_register_sidebar( array(
	'id'          => 'home-page-2',
	'name'        => __( 'Home Widget 2', 'ellie-jane' ),
	'description' => __( 'This is the section after the slider on the homepage. Use this for your Subscribe Box.', 'ellie-jane' ),
) );
genesis_register_sidebar( array(
	'id'          => 'home-page-3',
	'name'        => __( 'Home Widget 3', 'ellie-jane' ),
	'description' => __( 'This is the section after the subscribe box on the homepage.', 'ellie-jane' ),
) );
genesis_register_sidebar( array(
	'id'            => 'widget-above-content',
	'name'          => __( 'Widget Above Content', 'ellie-jane' ),
	'description'   => __( 'This widget area appears on top of all page content.', 'ellie-jane' ),
) );
genesis_register_sidebar( array(
	'id'            => 'widget-below-footer',
	'name'          => __( 'Widget Below Footer', 'ellie-jane' ),
	'description'   => __( 'This widget area appears below the footer widgets. Can be used for your Instagram widget.', 'ellie-jane' ),
) );

// Add Archive Settings option to Portolio CPT
add_post_type_support( 'portfolio', 'genesis-cpt-archives-settings' );

/**
 * Template Redirect
 * Use archive-portfolio.php for portfolio category and tag taxonomy archives.
 */
add_filter( 'template_include', 'ellie_template_redirect' );
function ellie_template_redirect( $template ) {

	if ( is_tax( 'portfolio_category' ) || is_tax( 'portfolio_tag' ) )
		$template = get_query_template( 'archive-portfolio' );
	return $template;

}

/**
 * Template Redirect
 * Use archive-portfolio.php for portfolio category and tag taxonomy archives.
 */
add_filter( 'template_include', 'custom_portfolio_archives_template', 99 );
function custom_portfolio_archives_template( $template ) {

	if ( is_tax( 'portfolio_category' ) || is_tax( 'portfolio_tag' ) ) {
		$new_template = locate_template( array( 'archive-portfolio.php' ) );
		if ( '' != $new_template ) {
			return $new_template ;
		}
	}

	return $template;
}

add_action( 'pre_get_posts', 'ellie_change_portfolio_archive_posts_per_page' );
/**
 * Change Posts Per Page for Portfolio Archive
 * @param object $query data
 *
 */
function ellie_change_portfolio_archive_posts_per_page( $query ) {

	if( $query->is_main_query() && !is_admin() && is_post_type_archive( 'portfolio' ) ) {
		$query->set( 'posts_per_page', '-1' );
	}

}