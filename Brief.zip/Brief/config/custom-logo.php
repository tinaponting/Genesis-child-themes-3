<?php
/**
 * Brief child theme.
 * @package Brief
 */

/**
 * Custom Logo configuration.
 */
return array(
	'flex-height' => true,
	'flex-width'  => true,
);
