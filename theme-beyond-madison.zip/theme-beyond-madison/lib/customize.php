<?php
/**
 * Customizer Additions.
 * @package      Beyond Madison
 */
 
/**
 * Get default Title, Description, Post, and Body Text color for Customizer.
 *
 * Abstracted here since at least two functions use it.
 *
 * @since 1.0.0
 *
 * @return string Hex color code for body text color.
 */

function beyond_customizer_get_default_body_text_color() {
	return '#404040';
}
function beyond_customizer_get_default_title_color() {
	return '#404040';
}
function beyond_customizer_get_default_description_color() {
	return '#404040';
}
function beyond_customizer_get_default_post_title_color() {
	return '#404040';
}

/**
 * Get default button color for Customizer.
 *
 * Abstracted here since at least two functions use it.
 *
 * @since 1.0.0
 *
 * @return string Hex color code for button color.
 */
function beyond_customizer_get_default_button_color() {
	return '#404040';
}

/**
 * Get default link color for Customizer.
 *
 * Abstracted here since at least two functions use it.
 *
 * @since 1.0.0
 *
 * @return string Hex color code for button color.
 */
function beyond_customizer_get_default_link_color() {
	return '#f9b1ab';
}
 
add_action( 'customize_register', 'beyond_customizer_register' );
/**
 * Register settings and controls with the Customizer.
 *
 * @since 1.0.0
 * 
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function beyond_customizer_register() {

	global $wp_customize;
	
	$wp_customize->add_setting(
		'beyond_body_text_color',
		array(
			'default' => beyond_customizer_get_default_body_text_color(),
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'beyond_body_text_color',
			array(
				'description' => __( 'Change the default body text color.', 'beyond' ),
			    'label'    => __( 'Body Text Color', 'beyond' ),
			    'section'  => 'colors',
			    'settings' => 'beyond_body_text_color',
			)
		)
	);

	$wp_customize->add_setting(
		'beyond_title_color',
		array(
			'default' => beyond_customizer_get_default_title_color(),
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'beyond_title_color',
			array(
				'description' => __( 'Change the default site title color.', 'beyond' ),
			    'label'    => __( 'Site Title Color', 'beyond' ),
			    'section'  => 'colors',
			    'settings' => 'beyond_title_color',
			)
		)
	);

	$wp_customize->add_setting(
		'beyond_description_color',
		array(
			'default' => beyond_customizer_get_default_description_color(),
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'beyond_description_color',
			array(
			    'description' => __( 'Change the default description color.', 'beyond' ),
			    'label'    => __( 'Description Color', 'beyond' ),
			    'section'  => 'colors',
			    'settings' => 'beyond_description_color',
			)
		)
	);

	$wp_customize->add_setting(
		'beyond_post_title_color',
		array(
			'default' => beyond_customizer_get_default_post_title_color(),
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'beyond_post_title_color',
			array(
				'description' => __( 'Change the default post, widget, and menu bar title color.', 'beyond' ),
			    'label'    => __( 'All Other Title Colors', 'beyond' ),
			    'section'  => 'colors',
			    'settings' => 'beyond_post_title_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'beyond_button_color',
		array(
			'default' => beyond_customizer_get_default_button_color(),
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'beyond_button_color',
			array(
				'description' => __( 'Change the default button and social media icon color.', 'beyond' ),
			    'label'    => __( 'Button Color', 'beyond' ),
			    'section'  => 'colors',
			    'settings' => 'beyond_button_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'beyond_link_color',
		array(
			'default' => beyond_customizer_get_default_link_color(),
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'beyond_link_color',
			array(
				'description' => __( 'Change the default link color.', 'beyond' ),
			    'label'    => __( 'Link Color', 'beyond' ),
			    'section'  => 'colors',
			    'settings' => 'beyond_link_color',
			)
		)
	);

}

add_action( 'wp_enqueue_scripts', 'beyond_css' );
/**
* Checks the settings for the button color, link color, and header
* If any of these value are set the appropriate CSS is output
*
* @since 1.0.0
*/
function beyond_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';

	$color = get_theme_mod( 'beyond_body_text_color', beyond_customizer_get_default_body_text_color() );
	$color_title = get_theme_mod( 'beyond_title_color', beyond_customizer_get_default_title_color() );
	$color_description = get_theme_mod( 'beyond_description_color', beyond_customizer_get_default_description_color() );
	$color_post = get_theme_mod( 'beyond_post_title_color', beyond_customizer_get_default_post_title_color() );
	$color_button = get_theme_mod( 'beyond_button_color', beyond_customizer_get_default_button_color() );
	$color_link = get_theme_mod( 'beyond_link_color', beyond_customizer_get_default_link_color() );

	$css = '';
		
	$css .= ( beyond_customizer_get_default_body_text_color() !== $color ) ? sprintf( '
		
		body,
		.site-footer,
		.entry-time,
		.subscribe-bar .enews-widget p {
			color: %1$s;
		}
		
		', $color ) : '';

	$css .= ( beyond_customizer_get_default_title_color() !== $color_title ) ? sprintf( '
		
		.site-title a, .site-title a:hover {
			color: %1$s;
		}
		
		', $color_title ) : '';
	
	$css .= ( beyond_customizer_get_default_description_color() !== $color_description ) ? sprintf( '
		
		.site-description {
			color: %1$s;
		}
		
		', $color_description ) : '';

	$css .= ( beyond_customizer_get_default_post_title_color() !== $color_post ) ? sprintf( '
		
		h1, h2, h3, h4, h5, h6,
		.genesis-nav-menu a,
		.genesis-nav-menu .current-menu-item > a,
		.genesis-nav-menu .sub-menu a, .genesis-nav-menu > li:hover .sub-menu a,
		.entry-title a, .sidebar .widget-title a {
			color: %1$s;
		}
		
		', $color_post ) : '';

	$css .= ( beyond_customizer_get_default_button_color() !== $color_button ) ? sprintf( '

		.subscribe-bar .enews-widget input[type="submit"],
		.enews-widget input[type="submit"],
		.featured-flex-pages .featured-content .entry .more-link,
		.archive-pagination li a,
		button, input[type="button"], 
		input[type="reset"], 
		input[type="submit"], 
		.button, 
		.entry-content .button {
			background-color: %1$s;
		}
		
		.featured-flex-posts .featured-content .entry .more-link {
			background-color: %1$s;
		}

		#sb_instagram .sbi_follow_btn a,
		#sb_instagram .sbi_follow_btn a:hover,
		.woocommerce #respond input#submit, 
		.woocommerce a.button, 
		.woocommerce button.button, 
		.woocommerce input.button {
			background-color: %1$s !important;
		}

		.woocommerce #respond input#submit.alt, 
		.woocommerce a.button.alt, 
		.woocommerce button.button.alt, 
		.woocommerce input.button.alt {
			background-color: %1$s !important;
		}

		#sharing_email .sharing_send, 
		.sd-content ul li .option a.share-ustom, 
		.sd-content ul li a.sd-button, .sd-content ul li.advanced a.share-more, 
		.sd-content ul li.preview-item div.option.option-smart-off a, 
		.sd-social-icon .sd-content ul li a.sd-button, 
		.sd-social-icon-text .sd-content ul li a.sd-button, 
		.sd-social-official .sd-content > ul > li .digg_button > a, 
		.sd-social-official .sd-content > ul > li > a.sd-button, 
		.sd-social-text .sd-content ul li a.sd-button {
			background-color: %1$s !important;
		}

		.simple-social-icons .social-bloglovin a,
		.simple-social-icons .social-dribbble a,
		.simple-social-icons .social-email a,
		.simple-social-icons .social-facebook a,
		.simple-social-icons .social-flickr a,
		.simple-social-icons .social-github a,
		.simple-social-icons .social-gplus a,
		.simple-social-icons .social-instagram a,
		.simple-social-icons .social-linkedin a,
		.simple-social-icons .social-pinterest a,
		.simple-social-icons .social-rss a,
		.simple-social-icons .social-stumbleupon a,
		.simple-social-icons .social-tumblr a,
		.simple-social-icons .social-twitter a,
		.simple-social-icons .social-vimeo a,
		.simple-social-icons .social-youtube a {
			background-color: %1$s !important;
		}

		.simple-social-icons .social-bloglovin a:hover,
		.simple-social-icons .social-dribbble a:hover,
		.simple-social-icons .social-email a:hover,
		.simple-social-icons .social-facebook a:hover,
		.simple-social-icons .social-flickr a:hover,
		.simple-social-icons .social-github a:hover,
		.simple-social-icons .social-gplus a:hover,
		.simple-social-icons .social-instagram a:hover,
		.simple-social-icons .social-linkedin a:hover,
		.simple-social-icons .social-pinterest a:hover,
		.simple-social-icons .social-rss a:hover,
		.simple-social-icons .social-stumbleupon a:hover,
		.simple-social-icons .social-tumblr a:hover,
		.simple-social-icons .social-twitter a:hover,
		.simple-social-icons .social-vimeo a:hover,
		.simple-social-icons .social-youtube a:hover {
			color: %1$s !important;
		}
		
		', $color_button ) : '';
		
	$css .= ( beyond_customizer_get_default_link_color() !== $color_link ) ? sprintf( '

		a,
		a.more-link,
		blockquote::before,
		.site-footer a {
			color: %1$s;
		}
		
		.woocommerce div.product p.price,
		.woocommerce div.product span.price,
		.woocommerce ul.products li.product .price {
			color: %1$s !important;
		}
		
		', $color_link ) : '';
		
		
	if ( beyond_customizer_get_default_body_text_color() !== $color || beyond_customizer_get_default_title_color() !== $color_title || beyond_customizer_get_default_description_color() !== $color_description || beyond_customizer_get_default_post_title_color() !== $color_post || beyond_customizer_get_default_button_color() !== $color_button || beyond_customizer_get_default_link_color() !== $color_link ) {
		$css .= '
		}
		';
	}

	if( $css ){
		wp_add_inline_style( $handle, $css );
	}

}