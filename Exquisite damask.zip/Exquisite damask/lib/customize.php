<?php
/**
 * Customizer Additions.
 * @package      Exquisite Damask
 */
 
/**
 * Get default color for Customizer.
 *
 * Abstracted here since at least two functions use it.
 *
 * @since 1.0.0
 *
 * @return string Hex color code.
 */
function exquisite_customizer_get_default_damask_background_color() {
	return '#3C3C3B';
}

function exquisite_customizer_get_default_title_color() {
	return '#ebe7e6';
}

function exquisite_customizer_get_default_link_color() {
	return '#b7a9a1';
}

function exquisite_customizer_get_default_button_color() {
	return '#464646';
}

function exquisite_customizer_get_default_primary_menu_description() {
	return '#999999';
}

function exquisite_customizer_get_default_secondary_menu_description() {
	return '#999999';
}
 
add_action( 'customize_register', 'exquisite_customizer_register' );

/**
 * Register settings and controls with the Customizer.
 *
 * @since 1.0.0
 * 
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function exquisite_customizer_register() {

	global $wp_customize;
	
	$wp_customize->add_setting(
		'exquisite_damask_background_color',
		array(
			'default' => exquisite_customizer_get_default_damask_background_color(),
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'exquisite_damask_background_color',
			array(
				'description' => __( 'Change the default Damask Background color.', 'exquisite' ),
			    'label'    => __( 'Damask Background Color', 'exquisite' ),
			    'section'  => 'colors',
			    'settings' => 'exquisite_damask_background_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'exquisite_title_color',
		array(
			'default' => exquisite_customizer_get_default_title_color(),
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'exquisite_title_color',
			array(
				'description' => __( 'Change the default text color for all the light colored font (Title, Description, Primary Navigation, etc).', 'exquisite' ),
			    'label'    => __( 'Light Colored Font on Damask Background', 'exquisite' ),
			    'section'  => 'colors',
			    'settings' => 'exquisite_title_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'exquisite_link_color',
		array(
			'default' => exquisite_customizer_get_default_link_color(),
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'exquisite_link_color',
			array(
				'description' => __( 'Change the default link color.', 'exquisite' ),
			    'label'    => __( 'Link Color', 'exquisite' ),
			    'section'  => 'colors',
			    'settings' => 'exquisite_link_color',
			)
		)
	);

	$wp_customize->add_setting(
		'exquisite_button_color',
		array(
			'default' => exquisite_customizer_get_default_button_color(),
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'exquisite_button_color',
			array(
				'description' => __( 'Change the default button color (Read More, Post Comment, Add to Cart, etc.).', 'exquisite' ),
			    'label'    => __( 'Button Color', 'exquisite' ),
			    'section'  => 'colors',
			    'settings' => 'exquisite_button_color',
			)
		)
	);

	$wp_customize->add_setting(
		'exquisite_primary_menu_description',
		array(
			'default' => exquisite_customizer_get_default_primary_menu_description(),
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'exquisite_primary_menu_description',
			array(
				'description' => __( 'Change the default color for the Menu Description in the top Navigation Bar.', 'exquisite' ),
			    'label'    => __( 'Menu Description in Top Nav Bar', 'exquisite' ),
			    'section'  => 'colors',
			    'settings' => 'exquisite_primary_menu_description',
			)
		)
	);

	$wp_customize->add_setting(
		'exquisite_secondary_menu_description',
		array(
			'default' => exquisite_customizer_get_default_secondary_menu_description(),
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'exquisite_secondary_menu_description',
			array(
				'description' => __( 'Change the default color for the Menu Description in the 2nd Navigation Bar (below the Header).', 'exquisite' ),
			    'label'    => __( 'Menu Description in 2nd Nav Bar', 'exquisite' ),
			    'section'  => 'colors',
			    'settings' => 'exquisite_secondary_menu_description',
			)
		)
	);

}

add_action( 'wp_enqueue_scripts', 'exquisite_css' );
/**
* Checks the settings for the title color, link color, and header
* If any of these value are set the appropriate CSS is output
*
* @since 1.0.0
*/
function exquisite_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';

	$color = get_theme_mod( 'exquisite_damask_background_color', exquisite_customizer_get_default_damask_background_color() );
	$color_title = get_theme_mod( 'exquisite_title_color', exquisite_customizer_get_default_title_color() );
	$color_link = get_theme_mod( 'exquisite_link_color', exquisite_customizer_get_default_link_color() );
	$color_button = get_theme_mod( 'exquisite_button_color', exquisite_customizer_get_default_button_color() );
	$color_primary_menu_description = get_theme_mod( 'exquisite_primary_menu_description', exquisite_customizer_get_default_primary_menu_description() );
	$color_secondary_menu_description = get_theme_mod( 'exquisite_secondary_menu_description', exquisite_customizer_get_default_secondary_menu_description() );
	
	$css = '';
		
	$css .= ( exquisite_customizer_get_default_damask_background_color() !== $color ) ? sprintf( '
		
		.site-header,
		.nav-primary,
		.home-testimonial,
		.announcement-bar,
		.site-footer {
			background-color: %1$s;
		}
		
		', $color ) : '';

	$css .= ( exquisite_customizer_get_default_title_color() !== $color_title ) ? sprintf( '

		.site-title a,
		.site-title a:hover,
		.site-description,
		.genesis-nav-menu,
		.genesis-nav-menu a,
		.genesis-nav-menu .current-menu-item > a,
		.home-testimonial .widget-title,
		.home-testimonial .textwidget,
		.home-testimonial .testimonial_rotator .testimonial_rotator_slide_title,
		.home-testimonial .testimonial_rotator .testimonial_rotator_quote,
		.home-testimonial .testimonial_rotator.template-default .testimonial_rotator_author_info p,
		.announcement-bar .widget-title,
		.announcement-bar .textwidget,
		.site-footer,
		.site-footer a {
			color: %1$s;
		}
		
		', $color_title ) : '';
		
	$css .= ( exquisite_customizer_get_default_link_color() !== $color_link ) ? sprintf( '

		a {
			color: %1$s;
		}

		.soliloquy-container .soliloquy-caption a.soliloquy-button {
			color: %1$s !important;
		}
		
		.woocommerce div.product p.price,
		.woocommerce div.product span.price,
		.woocommerce ul.products li.product .price {
			color: %1$s !important;
		}
		
		', $color_link ) : '';

	$css .= ( exquisite_customizer_get_default_button_color() !== $color_button ) ? sprintf( '

		button,
		input[type="button"],
		input[type="reset"],
		input[type="submit"],
		.button,
		.entry-content .button,
		.featuredpost .more-link,
		.featured-flex-posts .featured-content .entry .more-link,
		.featured-flex-posts .enews-widget input[type="submit"],
		.archive-pagination li a {
			background-color: %1$s;
		}

		.woocommerce span.onsale,
		.woocommerce #respond input#submit.alt, .woocommerce a.button.alt, 
		.woocommerce button.button.alt, .woocommerce input.button.alt,
		.woocommerce #respond input#submit, 
		.woocommerce a.button, 
		.woocommerce button.button, 
		.woocommerce input.button {
			background-color: %1$s !important;
		}
		
		', $color_button ) : '';

	$css .= ( exquisite_customizer_get_default_primary_menu_description() !== $color_primary_menu_description ) ? sprintf( '

		.nav-primary .menu-description {
			color: %1$s;
		}
		
		', $color_primary_menu_description ) : '';

	$css .= ( exquisite_customizer_get_default_secondary_menu_description() !== $color_secondary_menu_description ) ? sprintf( '

		.nav-secondary .menu-description {
			color: %1$s;
		}
		
		', $color_secondary_menu_description ) : '';
		
		
	if ( exquisite_customizer_get_default_damask_background_color() !== $color || exquisite_customizer_get_default_title_color() !== $color_title || exquisite_customizer_get_default_link_color() !== $color_link || exquisite_customizer_get_default_button_color() !== $color_button || exquisite_customizer_get_default_primary_menu_description() !== $color_primary_menu_description || exquisite_customizer_get_default_secondary_menu_description() !== $color_secondary_menu_description ) {
		$css .= '
		}
		';
	}

	if( $css ){
		wp_add_inline_style( $handle, $css );
	}

}
