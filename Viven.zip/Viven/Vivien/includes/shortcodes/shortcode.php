<?php
/**
* This file contains all the shortcodes and 
* TinyMCE formatting buttons functionality.
*/
//* Tab Shortcode

function show_tabs( $atts, $content = null ) {
	extract( shortcode_atts( array( 
		'titles' => '',
	 ), $atts ) );

	wp_enqueue_script(  'jquery_Tools'  );

	$output='';	
	$output .= '<script type="text/javascript">
		jQuery.noConflict();
		jQuery(document).ready(function(jQuery) {   
			jQuery( function( ) {
				jQuery( "ul.tab" ).tabs( "div.panes > div" );
			} );					
		});
	</script>';	

	$titlearr=explode( ',',$titles );	
	$output .= '<div class="tabs-container"><ul class="tab ">';

	foreach( $titlearr as $title ){
		$output.='<li class="w3"><a href="#">'.$title.'</a></li>';
	}

	$output.='</ul><div class="panes">'.do_shortcode( $content ).'</div></div>';	

	//removing extra <br>

	$Old     = array( '<br />', '<br>' );
	$New     = array( '','' );
	$output = str_replace( $Old, $New, $output );		
	return $output;
}

add_shortcode( 'tabs', 'show_tabs' );

function show_pane( $atts, $content = null ) {
	return '<div>'.do_shortcode( $content ).'</div>';
}
add_shortcode( 'pane', 'show_pane' );





//*Accordion Shortcode

function ingrid_accordion(  $atts, $content = null  ){	
	extract(  shortcode_atts(  array( 
		'title'=> ''
	 ), $atts ) );	

	$output = '<div class="accordion-unit clearfix">';	

	if (  $title  ) {
		$output .= '<h4>' . $title . '</h4>';	
	}	

	$output .= do_shortcode (  $content  );
	$output .= '</div>';
	$Old     = array( '<br />', '<br>' );
	$New     = array( '','' );
	$output = str_replace( $Old, $New, $output );	
	return $output;	
}	

add_shortcode(  'accordion', 'ingrid_accordion'  );

// Accordion Item Shortcode
function ingrid_accordionitem(  $atts, $content = null  ){
	extract(  shortcode_atts(  array( 
		'title'=> ''
	 ), $atts ) );
	$output = '<div class="accordion_container"><span class="trigger-button"><span class="accordion_image"></span><span>' . $title . '</span></span>';
	$output .= '<div class="accordion">';
	$output .= do_shortcode (  $content  ) ;
	$output .= '</div></div>';	
	return $output;
}

add_shortcode(  'accordionitem', 'ingrid_accordionitem'  );


//* Service Box Shortcode

	function ingrid_servicebox(  $atts, $content = null  ){
	extract(  shortcode_atts(  array( 
		'size' => '',
		'last'=> '',
		'number'=> '',
		'title'=> '',
		'icon' => '',
		'icon_color' => '',
		'name' => '',
		'link' => '',
		'btnsize' => '',
		'rounded' => '',
		'color' => '',

	 ), $atts ) );

		if(  $last == 'true' ) {
			$last_str = " last-column";
			$clear = '<div class="clearfix"></div>';
		}else {
			$last_str="";
			$clear = '';
		}

		$rounded = ( $rounded == 'false' ) ? '' : 'rounded';	
		$icn_clr = ( $icon_color == '' )? '' : 'style="background-color: '.$icon_color.' !important;"';
		$btn='';		
		if( $name != ''){
			$btn = '<a href="'. $link . '" class=" button ' .$rounded .' '. $btnsize .'-btn '. $color . '" >' .   $name. '</a>';		
		}

		$output ='';
		$output .= '<div class="'.$size.' special-services-box'. $last_str .'">';
		$output .= '<div class="box-wrapper">';
		//$output .= '<img src="'.$icon.'" width="auto" height="auto" alt="" />';
		$output .= '<span class="service-icon" '.$icn_clr .'>'.$icon.'</span>';
		$output .= '<h1>'. $number . '<h4>'. $title . '</h4><p>'. do_shortcode( $content  ). '</p>'.$btn.'</div></div>';
		
		$Old     = array( '<br />', '<br>' );
		$New     = array( '','' );
		$output = str_replace( $Old, $New, $output );	
		return $output.$clear;
}

add_shortcode(  'servicebox', 'ingrid_servicebox'  );


//* Button Shortcode

function ingrid_buttons_shortcode(  $atts, $content = null  ) {
	extract(  shortcode_atts(  array( 
		'size' => '',
		'color' => '',
		'link' => '',
		'rounded' => '',
		'target' => ''
	 ), $atts ) );
	
	$output = '';

	if( $color == 'default' )
		$color = '';


	if (  $size == 'small'  ) {
		$size = 'small-btn ';
	}elseif (  $size == 'normal'  ) {
		$size = '';
	}elseif(  $size == 'large'  ) {
		$size = 'large-btn ';
	}else {
		$size = '';
	}

	if (  $rounded == 'true'  ){
		$rounded = 'rounded ';
	}
	
	$output .= '<a href="'. $link . '" class=" button ' .$rounded .' '. $size . $color . '" target="'.$target.'">' . do_shortcode (  $content  ) . '</a>';
	
	return $output;
}

add_shortcode(  'button', 'ingrid_buttons_shortcode'  );


//* Divider Shortcode

add_shortcode(  'hr', 'shortcode_hr'  );

function shortcode_hr( $atts, $content = null ) {
   return '<div class="shortcode-hr"></div>';
}

//* Team Shortcode

function ingrid_team(  $atts, $content = null  ){
	extract(  shortcode_atts(  array( 
		'size' => '',
		'last'=> '',
		'name'=> '',
		'title'=> '',		
		'icon' => '',
		'facebook' => '',
		'twitter' => '',
		'instagram' => '',
		'pinterest' => '',
		'skype' => '',
		'youtube' => '',
		'linkedin' => '',
		'email' => ''	
	 ), $atts ) );

	if(  $last == 'true' ) {
		$last_str = " last-column";
		$clear = '<div class="clearfix"></div>';
	}else {
		$last_str="";
		$clear = '';
	}

	$team_link='';
	if(  $facebook != ''  )
		$team_link .= '<li><a class="t_facebook hastip" title="facebook" href="'.$facebook.'"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>';
	if(  $twitter != ''  )
		$team_link .= '<li><a class="t_twitter hastip" title="twitter" href="'.$twitter.'"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>';
	if(  $instagram != ''  )
		$team_link .= '<li><a class="t_instagram hastip" title="instagram" href="'.$instagram.'"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>';
	if(  $pinterest != ''  )
		$team_link .= '<li><a class="t_pinterest hastip" title="pinterest" href="'.$pinterest.'"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a></li>';					
	if(  $email != ''  )
		$team_link .= '<li><a class="t_email hastip" title="email" href="mailto:'.$email.'"><i class="fa fa-envelope-o" aria-hidden="true"></i></a></li>';
	if(  $skype != ''  )
		$team_link .= '<li><a class="t_skype hastip" title="skype" href="'.$skype.'"><i class="fa fa-skype" aria-hidden="true"></i></a></li>';	
	if(  $youtube != ''  )
		$team_link .= '<li><a class="t_youtube hastip" title="youtube" href="'.$youtube.'"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>';
	if(  $linkedin != ''  )
		$team_link .= '<li><a class="t_linkedin hastip" title="linkedin" href="'.$linkedin.'"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>';					

	$output ='';
	$output .= '<div class="'.$size.' team'. $last_str .'">';
	$output .= '<div class="box-wrapper">';
	$output .= '<div class="team_image_block">';
	$output .= '<img src="'.$icon.'"  alt="" /></div>';
	$output .= '<h4>'. $name . '</h4><h5>'. $title . '</h5><p>'. $content . '</p>';
	$output .= '<ul class="team_socials">'. $team_link . '</ul></div></div>';

	return $output.$clear;
}

add_shortcode(  'team', 'ingrid_team'  );


//* Alert Box

function ingrid_infobox(  $atts, $content = null  ) {
	extract(  shortcode_atts(  array( 
		'type' => ''
	 ), $atts ) );

	$output='';
	$output .= '<div class="infobox_container"><div class="'.$type.'">'.$content.'</div></div><div class="clearfix"></div>';
	return $output;
}

add_shortcode(  'info_box', 'ingrid_infobox'  );


//* List Styles

function ingrid_liststyles(  $atts, $content = null  ) {
	extract(  shortcode_atts(  array( 
		'style' => ''
	 ), $atts ) );

	$output='';
	$output .= '<ul class="bullet_'.$style.' imglist">'.do_shortcode( $content ).'</ul>';

	//removing extra <br>
	$Old     = array( '<br />', '<br>' );
	$New     = array( '','' );
	$output = str_replace( $Old, $New, $output );

	return $output;
}

add_shortcode(  'list', 'ingrid_liststyles'  );

function ingrid_list_li( $atts, $content = null ) {
	return '<li>'. $content.'</li>';
}

add_shortcode( 'li', 'ingrid_list_li' );


//* Columns Wrapper

function ingrid_column_wrapper(  $atts, $content = null  ) {
	extract(  shortcode_atts(  array( 
		'num' => '',
		'last' => ''
	 ), $atts ) );

	$output='';

	$output .= '<div class="columns-wrapper">'.do_shortcode( $content ).'</div><div class="clearfix"></div>';

	//removing extra <br>
	$Old     = array( '<br />', '<br>' );
	$New     = array( '','' );
	$output = str_replace( $Old, $New, $output );

	return $output;
}

add_shortcode(  'col_wrapper', 'ingrid_column_wrapper'  );


//* 2 Columns 
 
function ingrid_2columns(  $atts, $content = null  ) {

	extract(  shortcode_atts(  array( 
	 ), $atts ) );

	$output='';

	$output .= '<div class="one-half columns">'.do_shortcode( $content ).'</div>';

	//removing extra <br>
	$Old     = array( '<br />', '<br>' );
	$New     = array( '','' );
	$output = str_replace( $Old, $New, $output );

	return $output;
}

add_shortcode(  'col2', 'ingrid_2columns'  );

function ingrid_2columns_last(  $atts, $content = null  ) {
	extract(  shortcode_atts(  array( 
	 ), $atts ) );

	$output='';
	$output .= '<div class="one-half columns nomargin">'.do_shortcode( $content ).'</div>';

	//removing extra <br>
	$Old     = array( '<br />', '<br>' );
	$New     = array( '','' );
	$output = str_replace( $Old, $New, $output );

	return $output;
}

add_shortcode(  'col2_last', 'ingrid_2columns_last'  );


//* 3 Columns 
 
function ingrid_3columns(  $atts, $content = null  ) {
	extract(  shortcode_atts(  array( 
	 ), $atts ) );

	$output='';

	$output .= '<div class="one-third columns">'.do_shortcode( $content ).'</div>';

	//removing extra <br>
	$Old     = array( '<br />', '<br>' );
	$New     = array( '','' );
	$output = str_replace( $Old, $New, $output );

	return $output;
}

add_shortcode(  'col3', 'ingrid_3columns'  );

function ingrid_3columns_last(  $atts, $content = null  ) {
	extract(  shortcode_atts(  array( 
	 ), $atts ) );

	$output='';

	$output .= '<div class="one-third columns nomargin">'.do_shortcode( $content ).'</div>';

	//removing extra <br>
	$Old     = array( '<br />', '<br>' );
	$New     = array( '','' );
	$output = str_replace( $Old, $New, $output );
	return $output;
}

add_shortcode(  'col3_last', 'ingrid_3columns_last'  );


//* 4 Columns 
 
function ingrid_4columns(  $atts, $content = null  ) {
	extract(  shortcode_atts(  array( 
	 ), $atts ) );

	$output='';
	$output .= '<div class="one-fourth columns">'.do_shortcode( $content ).'</div>';

	//removing extra <br>
	$Old     = array( '<br />', '<br>' );
	$New     = array( '','' );
	$output = str_replace( $Old, $New, $output );
	
	return $output;

}

add_shortcode(  'col4', 'ingrid_4columns'  );

function ingrid_4columns_last(  $atts, $content = null  ) {
	extract(  shortcode_atts(  array( 
   ), $atts ) );

	$output='';

	$output .= '<div class="one-fourth columns nomargin">'.do_shortcode( $content ).'</div>';

	//removing extra <br>
	$Old     = array( '<br />', '<br>' );
	$New     = array( '','' );
	$output = str_replace( $Old, $New, $output );

	return $output;
}

add_shortcode(  'col4_last', 'ingrid_4columns_last'  );

//* 2/3 Columns 
  
function ingrid_twothird_columns(  $atts, $content = null  ) {
	extract(  shortcode_atts(  array( 
		'last' => ''
	), $atts ) );

	$last = ($last == 'true' ) ? "nomargin" : ' ';
	$output='';
	$output .= '<div class="two-third columns '.$last.'">'.do_shortcode( $content ).'</div>';

	//removing extra <br>
	$Old     = array( '<br />', '<br>' );
	$New     = array( '','' );
	$output = str_replace( $Old, $New, $output );

	return $output;
}

add_shortcode(  'col2_3', 'ingrid_twothird_columns'  );


//* 3/4 Columns 
  
function ingrid_threefourth_columns(  $atts, $content = null  ) {
	extract(  shortcode_atts(  array( 
		'last' => ''
   ), $atts ) );

	$last = ($last == 'true' ) ? "nomargin" : ' ';
	$output='';

	$output .= '<div class="three-fourth columns '.$last.'">'.do_shortcode( $content ).'</div>';

	//removing extra <br>
	$Old     = array( '<br />', '<br>' );
	$New     = array( '','' );
	$output = str_replace( $Old, $New, $output );

	return $output;
}

add_shortcode(  'col3_4', 'ingrid_threefourth_columns'  );

//* DropCaps
 
function ingrid_dropcaps(  $atts, $content = null  ) {
	extract(  shortcode_atts(  array( 
	 ), $atts ) );

	$output='';
	$output .= '<span class="drop-caps">'.$content.'</span>';

	//removing extra <br>
	$Old     = array( '<br />', '<br>' );
	$New     = array( '','' );
	$output = str_replace( $Old, $New, $output );

	return $output;
}

add_shortcode(  'dropcaps', 'ingrid_dropcaps'  );


// * Call to Action Shortcode

function ingrid_calltoaction(  $atts, $content = null  ) {
	extract(  shortcode_atts(  array( 
		'link' => '',
		'button_label' => '',
		'rounded' => '',
		'btnsize' => '',
		'color' => '',
	 ), $atts ) );

	$output='';

	$rounded = ( $rounded == 'true')? 'rounded':'';
	$button = ( $link != '' )? '<a class=" cta_button button ' .$rounded .' '. $btnsize .'-btn '. $color . '" target="_blank" href="'.$link.'">'.$button_label.'</a>' : '';
	$output .= '<div class="call_to_action_box">'.$button;
	$output .= $content;
	$output .= '</div>';

	//removing extra <br>
	$Old     = array( '<p>', '</p>' );
	$New     = array( '','' );
	$output = str_replace( $Old, $New, $output );

	return $output;
}

add_shortcode(  'call_to_action', 'ingrid_calltoaction'  );


//* Horizonal Separator

function ingrid_hr(  $atts, $content = null  ) {
	extract(  shortcode_atts(  array( 
	 ), $atts ) );
	
	$output='';

	$output = '<hr />';
		
	return $output;
}

add_shortcode(  'hr', 'ingrid_hr'  );


//* Testimoial 

function ingrid_testimonial(  $atts, $content = null  ) {
	extract(  shortcode_atts(  array(
		'size' => '' 
	 ), $atts ) );

	wp_enqueue_script(  'jquery_cycle'  );

	$output='';
	$output .= '<script type="text/javascript">
		jQuery.noConflict();
		jQuery(document).ready(function(jQuery) {   
			 jQuery(".testimonial_container").cycle({
				speed: 3000,
				timeout: 2000
			 }); 
		});
	</script>';

	$output .= '<div class="'.$size.' testimonial"><div class="testimonial_container">'.do_shortcode( $content ).'</div></div>';

	//removing extra <br>
	$Old     = array( '<br />', '<br>' );
	$New     = array( '','' );
	$output = str_replace( $Old, $New, $output );

	return $output;
}

add_shortcode(  'testimonial', 'ingrid_testimonial'  );
function ingrid_testim_pane(  $atts, $content = null  ) {
	extract(  shortcode_atts(  array(
		'name' => '',
		'position' => '',
		'icon' => ''
	 ), $atts ) );

	 if(  $icon == '' )
	 	$icon = get_stylesheet_directory_uri().'/includes/shortcodes/shortcode_icons/ico-user.png';

	 $output = '';
	 $output .= '<div>';
 	 $output .= '<div class="testimonial_content"><p>'.$content.'</p></div>';
	 $output .= '<div class="signature"><img src="'.$icon.'" width="26" height="29" alt="'.$name.' " /><span class="testi_name">'.$name.'</span> '.$position.'</div>';

	 $output .= '</div>';

	return $output;

}

add_shortcode(  'testi_pane', 'ingrid_testim_pane'  );


//* Client 

function ingrid_client(  $atts, $content = null  ) {
	extract(  shortcode_atts(  array(
	 ), $atts ) );

	wp_enqueue_script(  'jquery_carouFredSel'  );
	wp_enqueue_script(  'jquery_mousewheel'  );
	wp_enqueue_script(  'jquery_touchswipe'  );
	wp_enqueue_script(  'jquery_transit'  );
	wp_enqueue_script(  'jquery_throttle'  );	 

	$output='';	 	
	$output .= '<script type="text/javascript">
		jQuery.noConflict();
		jQuery(document).ready(function(jQuery) {
			jQuery(".client_container").carouFredSel({
				auto: true,
				circular: true,
				infinite: true,
				swipe: {
					onMouse: true,
					onTouch: true
				}
			});
		});
	</script>';
	$output .= '<div class="client_carousel">';
	$output .= '<div class="client_container">'.do_shortcode( $content ).'</div>';
	$output .= '</div>';

	//removing extra <br>
	$Old     = array( '<br />', '<br>' );
	$New     = array( '','' );
	$output = str_replace( $Old, $New, $output );
	
	return $output;
}

add_shortcode(  'client', 'ingrid_client'  );
function ingrid_client_item(  $atts, $content = null  ) {
	extract(  shortcode_atts(  array(
		'name' => '',
		'link' => '',
		'image' => '',
		'width' => '',
		'height' => ''
	 ), $atts ) );

	$output='';	 
	$output .= '<a href="'.$link.'"  title="'.$name.'"><img src="'.$image.'"   alt="'.$name.'" width="'.$width.'" height="'.$height.'" /></a>';

	return $output;
}

add_shortcode(  'client_item', 'ingrid_client_item'  );


//* Add Custom Formatting Buttons

global $shortcode_button;
$shortcode_button=array( "dropcaps","hr","liststyle1","liststyle2","liststyle3","liststyle4","liststyle5","liststyle6","call_to_action", "button", "infoboxes", "twocolumns", "threecolumns", "fourcolumns");
$shortcode_button2=array( "threefourth","twothird", "tabs","accordion", "servicebox", "team" , "testimonial", "client", "portfolio" );

function add_buttons(  ) {
	if (  get_user_option( 'rich_editing' ) == 'true' ) {
		add_filter( 'mce_external_plugins', 'add_btn_tinymce_plugin_frstrow' );
		add_filter( 'mce_external_plugins', 'add_btn_tinymce_plugin_2ndrow' );
		add_filter( 'mce_buttons_3', 'register_buttons_frstrow' );
		add_filter( 'mce_buttons_4', 'register_buttons_2ndrow' );
	}
}

add_action( 'init', 'add_buttons' );
/**
 * Register the buttons
 * @param $buttons
 */
function register_buttons_frstrow( $buttons ) {
	global $shortcode_button;
	array_push( $buttons, implode( ',',$shortcode_button ) );
	return $buttons;
}

function register_buttons_2ndrow( $buttons ) {
	global $shortcode_button2;
	array_push( $buttons, implode( ',',$shortcode_button2) );
	return $buttons;
}



/*
 * Button Shortcode
 */
if (!function_exists( 'zp_button' )){
	function zp_button( $atts, $content = null ){
		extract( shortcode_atts( array(
			'link' => '',
			'size' => '',
			'type' => '',
			'target' => ''
		),$atts ));
		
		$target = ( $target != '' )? 'target="'.$target.'"' : '';
		
		$type = ( $type == '' )? 'btn-default' : 'btn-'.$type;
		
		return '<a type="button" class="btn '.$type.' '.$size.'" href="'.$link.'" '.$target.'>'.$content.'</a>';
	}
	add_shortcode( 'zp_button', 'zp_button');
}


/**
 *	Progress Bar
 */
if ( !function_exists( 'zp_progress_bar' ) ){
	function zp_progress_bar( $atts, $content = null ){
		extract( shortcode_atts( array(
			 'label' => '',
			 'value' =>'',
			 'type' => '',
			 'stripe' => ''
		), $atts ));		
		$output = '';
		
		$type = ( $type == '' )? '' : 'progress-bar-'.$type;
		
		$stripe = ( $stripe == 'true' ) ? 'progress-striped' : ''; 
		
		$output .= '<div class="zp_progress_bar progress '.$stripe.'"><div class="progress-bar '.$type.'" role="progressbar" aria-valuenow="'.$value.'" aria-valuemin="0" aria-valuemax="100" style="width: '.$value.'%;"> <span class="sr-only">'.$value.'% Complete</span></div><span class="progress-type">'.$label.'</span> <span class="progress-completed">'.$value.'%</span></div>';
		
		return $output;		
	}
	add_shortcode( 'zp_progress', 'zp_progress_bar' );
}


/**
*	Portfolio Shortcode
*/
function zp_portfolio(  $atts, $content = null  ) {
	extract(  shortcode_atts(  array(
		'type' => '',
		'columns' => '',
		'items' => '',
		'filter' => '',
		'portfolio_category' => ''
	), $atts ) );
	
	$output='';	$filter = ($filter == "true" )? true:false;
	
	$output = zp_portfolio_shortcode( $columns, $items, $type, $filter, $portfolio_category );
	return $output;
}
add_shortcode(  'portfolio', 'zp_portfolio'  );

/**
* Add the buttons
* @param $plugin_array
*/

if( !function_exists('add_btn_tinymce_plugin_frstrow') ){
	function add_btn_tinymce_plugin_frstrow( $plugin_array ) {
		global $shortcode_button;
		foreach( $shortcode_button as $btn ){
			$plugin_array[$btn] = get_stylesheet_directory_uri(  ).'/includes/shortcodes/editor-plugin.js';
		}
		return $plugin_array;
	}
}

if( !function_exists('add_btn_tinymce_plugin_2ndrow') ){
	function add_btn_tinymce_plugin_2ndrow( $plugin_array ) {
		global $shortcode_button2;
		foreach( $shortcode_button2 as $btn ){
			$plugin_array[$btn] = get_stylesheet_directory_uri(  ).'/includes/shortcodes/editor-plugin.js';
		}
		return $plugin_array;
	}
}


/*price table shortcode*/	
	function pricetable_function( $atts, $content = null ){
	extract( shortcode_atts( array(
		"size" => '',
		"last"=> '',
		"terms" => '',
		"price"=> '',
		"title" => '',
		"linkname"=> '',
		"linkurl"=> '',
		"bestprice"=>''
	), $atts));
	
		if( $last == 'true') {
		$last_str = " last-column";
		}
		else {
			$last_str="";
		}
		if( $bestprice == 'true') {
			$bp = " bestprice";
		}
		else {
			$bp="price";
		}
		
		$str ='';
		$str .= '<div class="'.$size.' pricing'. $last_str .' '.$bp.'">';
		$str .= '<div class="box-wrapper">';
		$str .= '<h3>'. $title . '</h3>';
		$str .= '<h2>'.$price.'</h2>';
		$str .= '<span class="price_terms">'.$terms.'</span>';
		$str .= $content.'<div><a class="button" href="'.$linkurl.'" target="_blank">'.$linkname.'</a></div>';
		$str .= '</div></div>';
		
		return $str;
	}
	
	add_shortcode( 'pricetable', 'pricetable_function' );