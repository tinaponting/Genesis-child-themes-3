<?php
/**
* Register Customizer settings.
* @package     Vivien Theme
* @subpackage  Genesis
*/

//* Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;

}

//* Continue if the Customizer_Library exists.

if ( class_exists( 'Customizer_Library' ) ) :
add_action( 'customize_register', 'vivien_remove_customizer_defaults' );


//* Remove unwanted default customizer sections for the vivien theme.

function vivien_remove_customizer_defaults( $wp_customize ) {
	$wp_customize->remove_section( 'colors' );

}

add_action( 'customize_register', 'vivien_register_customizer_settings' );


//* Register custom sections for the vivien theme.

function vivien_register_customizer_settings() {

	// Stores all the controls that will be added
	$options = array();

	// Stores all the sections to be added
	$sections = array();

	// Adds the sections to the $options array
	$options['sections'] = $sections;

	// Colors
	$section = 'vivien_colors';

	$sections[] = array(
		'id'          => $section,
		'title'       => __( 'Colors', 'vivien' ),
		'description' => __( 'You can customize your theme colors by changing any of the options below.', 'vivien' ),
		'priority'    => '70',

	);

	$colors = vivien_get_colors();
	$counter = 20;

	foreach ( $colors as $color => $setting ) {

		$options[ $color ] = array(
			'id'       => $color,
			'label'    => $setting['label'],
			'section'  => $section,
			'type'     => 'color',
			'default'  => $setting['default'],
			'priority' => $counter++,

		);

	}



//* Allow users to disable Google Fonts Output.

	if ( ! apply_filters( 'vivien_disable_google_fonts', false ) ) {

		// Typography

		$section = 'vivien_typography';

		$sections[] = array(
			'id'          => $section,
			'title'       => __( 'Typography', 'vivien' ),
			'description' => __( 'You can customize your website with more than 60 beautiful Google Fonts. For best results, I recommend using no more than two unique font families.', 'vivien' ),
			'priority'    => '75',

		);

		$fonts = vivien_get_fonts();
		$counter = 20;
		foreach ( $fonts as $font => $setting ) {
			$options[ $font . '_family' ] = array(

				'id'      => $font . '_family',
				'label'   => $setting['label'] . __( ' Family', 'vivien' ),
				'section' => $section,
				'type'    => 'select',
				'choices' => customizer_library_get_font_choices(),
				'default' => $setting['default_family'],

			);

			$choices = array(
				'200' => 'Extra Light',
				'300' => 'Light',
				'400' => 'Normal',
				'700' => 'Bold',
				'900' => 'Extra Bold',

			);

			$options[ $font . '_weight' ] = array(
				'id'      => $font . '_weight',
				'label'   => $setting['label'] . __( ' Weight', 'vivien' ),
				'section' => $section,
				'type'    => 'select',
				'choices' => $choices,
				'default' => $setting['default_weight'],

			);

			if ( 'disabled' !== $setting['default_size'] ) {
				$choices = array(
					'10px' => '10px',
					'11px' => '11px',
					'12px' => '12px',
					'13px' => '13px',
					'14px' => '14px',
					'15px' => '15px',
					'16px' => '16px',
					'17px' => '17px',
					'18px' => '18px',
					'19px' => '19px',
					'20px' => '20px',
					'22px' => '22px',
					'24px' => '24px',
					'26px' => '26px',
					'28px' => '28px',
					'30px' => '30px',
					'32px' => '32px',
					'34px' => '34px',
					'36px' => '36px',
					'38px' => '38px',
					'40px' => '40px',
					'42px' => '42px',
					'44px' => '44px',
					'46px' => '46px',
					'48px' => '48px',
					'50px' => '50px',
					'52px' => '52px',
					'54px' => '54px',
					'56px' => '56px',

				);

				$options[ $font . '_size' ] = array(

					'id'      => $font . '_size',
					'label'   => $setting['label'] . __( ' Size', 'vivien' ),
					'section' => $section,
					'type'    => 'select',
					'choices' => $choices,
					'default' => $setting['default_size'],

				);

			}

			if ( 'disabled' !== $setting['default_style'] ) {
				$choices = array(
					'normal' => 'Normal',
					'italic' => 'Italic',

				);

				$options[ $font . '_style' ] = array(
					'id'      => $font . '_style',
					'label'   => $setting['label'] . __( ' Style', 'vivien' ),
					'section' => $section,
					'type'    => 'select',
					'choices' => $choices,
					'default' => $setting['default_style'],

				);

			}

		}

	}


	$choices = array(

		'full'       => __( 'Full Width', 'vivien' ),
		'one_half'   => __( 'One Half', 'vivien' ),
		'one_third'  => __( 'One Third', 'vivien' ),
		'one_fourth' => __( 'One Fourth', 'vivien' ),
		'one_sixth'  => __( 'One Sixth', 'vivien' ),

	);

	$options['vivien_archive_grid'] = array(
		'id'      => 'vivien_archive_grid',
		'label'   => __( 'Archive Grid Display:', 'vivien' ),
		'section' => 'genesis_archives',
		'type'    => 'select',
		'choices' => $choices,
		'default' => 'full',
		'priority' => 0,

	);

	$options['vivien_archive_show_title'] = array(
		'id'       => 'vivien_archive_show_title',
		'label'    => __( 'Display The Title?', 'vivien' ),
		'section'  => 'genesis_archives',
		'type'     => 'checkbox',
		'default'  => 1,
		'priority' => 5,
	);

	$options['vivien_archive_show_info'] = array(
		'id'       => 'vivien_archive_show_info',
		'label'    => __( 'Display The Entry Info?', 'vivien' ),
		'section'  => 'genesis_archives',
		'type'     => 'checkbox',
		'default'  => 1,
		'priority' => 6,
	);

	$options['vivien_archive_show_content'] = array(
		'id'       => 'vivien_archive_show_content',
		'label'    => __( 'Display The Content?', 'vivien' ),
		'section'  => 'genesis_archives',
		'type'     => 'checkbox',
		'default'  => 1,
		'priority' => 7,
	);

	$options['vivien_archive_show_meta'] = array(
		'id'       => 'vivien_archive_show_meta',
		'label'    => __( 'Display The Entry Meta?', 'vivien' ),
		'section'  => 'genesis_archives',
		'type'     => 'checkbox',
		'default'  => 1,
		'priority' => 8,
	);

	$choices = array(

		'after_title'   => __( 'After Title', 'vivien' ),
		'before_title'  => __( 'Before Title', 'vivien' ),
		'after_content' => __( 'After Content', 'vivien' ),

	);

	$options['vivien_archive_image_placement'] = array(
		'id'      => 'vivien_archive_image_placement',
		'label'   => __( 'Featured Image Placement:', 'vivien' ),
		'section' => 'genesis_archives',
		'type'    => 'select',
		'choices' => $choices,
		'default' => 'after_title',

	);

	// Adds the sections to the $options array

	$options['sections'] = $sections;

	$customizer_library = Customizer_Library::Instance();

	$customizer_library->add_options( $options );

}




//* An array of the color settings used in vivien Theme.



function vivien_get_colors() {

	$colors = array(

		'vivien_element_border_color' => array(
			'default'  => '#b2a79d',
			'label'    => __( 'Element border color Color', 'vivien' ),
			'selector' => '.title-area, .nav-primary, .nav-secondary, .genesis-nav-menu .sub-menu, .front-page-6 .woocommerce ul.cart_list li img, .front-page-4 .woocommerce ul.product_list_widget li img, .navigation-container.fixed, .sidebar .widget, .sidebar h3.widget-title, .entry-footer .entry-meta, .vivien .easyrecipe, .related-list img, .entry-footer .entry-meta .entry-tags, .front-page-6 .woocommerce ul.product_list_widget li img, .front-page-4 .featured-content img, .front-page-6 .featured-content img, .gallery img, .pricing-table .one-third:nth-child(3n+2), .pricing-table .one-third:nth-child(3n+1), .pricing-table .one-third:nth-child(3n), .front-page-3 .enews input, .front-page-5 .enews input, .entry-time, .entry-author, #top-link, .pricing-table h4, .content .share-after, .entry-categories, .entry-tags, .woocommerce #content div.product .woocommerce-tabs ul.tabs li, .woocommerce div.product .woocommerce-tabs ul.tabs li, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li, .woocommerce-page div.product .woocommerce-tabs ul.tabs li, #options li a.selected, #options li a:hover, .column-header-left, .column-header-right, .imagebox::after, #top-link i, .footer-widgets .wrap, .footer-widgets-2, h1.entry-title::after, h2.entry-title::after, .authorStuff, .dateStuff, .categoryStuff, .projectStuff, .prev_project a, .next_project a, .nav-back a, .woocommerce #content div.product .woocommerce-tabs .panel, .woocommerce div.product .woocommerce-tabs .panel, .woocommerce-page #content div.product .woocommerce-tabs .panel, .woocommerce-page div.product .woocommerce-tabs .panel, .user-profile .avatar-85, .user-profile .avatar-125, .user-profile .avatar-45, .user-profile .avatar-65, .categories-top, .content .share-after',

			'rule'     => 'border-color',

		),

		'vivien_icon_color' => array(
			'default'  => '#333',
			'label'    => __( 'Icon Color: Share icons and entry meta', 'vivien' ),
			'selector' => '.entry-categories:before, .entry-comments-link::before, .entry-tags:before, .previous:before, .next:after, .woocommerce div.product form.cart .button::before, .adjacent-entry-pagination .pagination-next a::after, .adjacent-entry-pagination .pagination-previous a::before, .content .share-filled .facebook .count, .content .share-filled .facebook .count:hover, .content .share-filled .googlePlus .count, .content .share-filled .googlePlus .count:hover, .content .share-filled .linkedin .count, .content .share-filled .linkedin .count:hover, .content .share-filled .pinterest .count, .content .share-filled .pinterest .count:hover, .content .share-filled .stumbleupon .count, .content .share-filled .stumbleupon .count:hover, .content .share-filled .twitter .count, .content .share-filled .twitter .count:hover, .sharrre .share, .sharrre:hover .share',

			'rule'     => 'color',

		),

		'vivien_primary_element_color' => array(
			'default'  => '#fcf4f3',
			'label'    => __( 'Primary Element Color: Footer, services boxes, above content form action,..', 'vivien' ),
			'selector' => '.woocommerce span.onsale, .woocommerce-page span.onsale, .sidebar ul li, .archive-pagination li, .footer-widgets, .categories-top, .woocommerce-page div.product .woocommerce-tabs ul.tabs li.active,.pricing-table .one-third:nth-child(3n+2), .woocommerce .woocommerce-error, .woocommerce .woocommerce-info, .woocommerce .woocommerce-message, .woocommerce-page .woocommerce-error, .woocommerce-page .woocommerce-info, .woocommerce-page .woocommerce-message, .woocommerce #payment, .woocommerce-page #payment, .front-page-4 h4.widget-title::after, .front-page-6 h4.widget-title::after, .comment-reply a, .woocommerce #content .quantity input.qty, .woocommerce .quantity input.qty, .woocommerce-page #content .quantity input.qty, .woocommerce-page .quantity input.qty, .share-small:before, #top-link, .after-entry .enews-widget, .front-page-2 .widget_text .special-services-box, .front-page-4 .widget_text .special-services-box, .front-page-6 .widget_text .special-services-box, .front-page-8 .widget_text .special-services-box, .element-2col .icon, .gallery-2col .icon, .element-3col .icon, .gallery-3col .icon, .element-4col .icon, .gallery-4col .icon, .imagebox, .footer-widgets, .widget-above-content, .pricing-table .one-third:nth-child(3n+2), .widget-above-content, .above-footers .enews-widget, input, select, textarea, .utility-bar, .categories-top select, .categories-top .search-form input, .share-small:before',   

			'rule'     => 'background-color',

		),

		'vivien_primary_element_text_color' => array(
			'default'  => '#555',
			'label'    => __( 'Primary Element Text Color', 'vivien' ),
			'selector' => '.woocommerce span.onsale, .woocommerce-page span.onsale, .sidebar ul li, .archive-pagination li, .footer-widgets, .categories-top, .woocommerce-page div.product .woocommerce-tabs ul.tabs li.active, .woocommerce .woocommerce-error, .woocommerce .woocommerce-info, .woocommerce .woocommerce-message, .woocommerce-page .woocommerce-error, .woocommerce-page .woocommerce-info, .woocommerce-page .woocommerce-message, .woocommerce #payment, .woocommerce-page #payment, .metaItem, .footer-widgets a, .sidebar a, .categories-top h4, .pricing-table ul li, .comment-reply a, .metaItem span, .categories-top h4.widget-title, .archive-pagination a:hover, .archive-pagination li.active a, .share-small:before, .flex-footer h4.widget-title, .flex-footer .enews-widget p',

			'rule'     => 'color',

		),

		'vivien_footer_menu_color' => array(
			'default'  => '#333',
			'label'    => __( 'Footer Menu Color', 'vivien' ),
			'selector' => '.site-footer',

			'rule'     => 'background-color',

		),

		'vivien_footer_menu_text_color' => array(
			'default'  => '#fff',
			'label'    => __(  'Footer Menu Text Color', 'vivien' ),
			'selector' => '.site-footer, .site-footer .genesis-nav-menu a, .site-footer a',

			'rule'     => 'color',
		),

		'vivien_site_title_color' => array(
			'default'  => '#333',
			'label'    => __( 'Site Title Color', 'vivien' ),
			'selector' => '.site-title a, .site-title a:hover',

			'rule'     => 'color',
		),

		'vivien_text_color' => array(
			'default'  => '#333',
			'label'    => __( 'Body Text Color', 'vivien' ),
			'selector' => 'body, p',

			'rule'     => 'color',
		),

		'vivien_headings_text_color' => array(
			'default'  => '#333',
			'label'    => __( 'Headings Text Color', 'vivien' ),
			'selector' => 'h1, h2, h3, h4, h5, h6, h4.widget-title, .sidebar h3.widget-title, h1.entry-title, h2.entry-title, .front-page-4 h4.widget-title, .front-page-6 h4.widget-title',

			'rule'     => 'color',

		),

		'vivien_link_color' => array(
			'default'  => '#f4bdbd',
			'label'    => __( 'Link Color', 'vivien' ),
			'selector' => 'a, .site-footer .genesis-nav-menu a:hover, .genesis-nav-menu a:hover, .genesis-nav-menu .current-menu-item > a, .site-description', 

			'rule'     => 'color',

		),

		'vivien_link_hover_color' => array(
			'default'  => '#a7a58f',
			'label'    => __( 'Link Hover Color', 'vivien' ),
			'selector' => 'a:hover, .genesis-nav-menu a:hover, ::selection, .site-footer .genesis-nav-menu a:hover',
			'rule'     => 'color',
		),

		'vivien_button_color' => array(

			'default'  => '#333',
			'label'    => __( 'Button Color', 'vivien' ),
			'selector' => '.enews-widget input[type="submit"], .front-page-image-image-1 .enews-widget input[type="submit"], .front-page-image-3 .enews-widget input[type="submit"], .front-page-image-5 .enews-widget input[type="submit"], .button, .button-secondary, button, input[type="button"], input[type="reset"], input[type="submit"], .sidebar .enews-widget input[type="submit"], .woocommerce #content input.button, .woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce-page #content input.button, .woocommerce-page #respond input#submit, .woocommerce-page a.button, .woocommerce-page button.button, .woocommerce-page input.button, .fancybutton, .woocommerce .widget_price_filter .ui-slider .ui-slider-handle, .woocommerce-page .widget_price_filter .ui-slider .ui-slider-handle, .pricing-table a.button, ::selection, a.more-link, .more-from-category a, .content #genesis-responsive-slider a.more-link, .after-entry .enews-widget input[type="submit"], .footer-widgets .enews-widget input[type="submit"], .above-footers .enews-widget input[type="submit"]',

			'rule'     => 'background-color',

		),

		'vivien_button_text_color' => array(
			'default'  => '#fff',
			'label'    => __( 'Button Text Color', 'vivien' ),
			'selector' => '.enews-widget input[type="submit"], .front-page-image-1 .enews-widget input[type="submit"], .front-page-image-3 .enews-widget input[type="submit"], .front-page-image-5 .enews-widget input[type="submit"], .button, .button-secondary, button, input[type="button"], input[type="reset"], input[type="submit"], .sidebar .enews-widget input[type="submit"], .woocommerce #content input.button, .woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce-page #content input.button, .woocommerce-page #respond input#submit, .woocommerce-page a.button, .woocommerce-page button.button, .woocommerce-page input.button, .fancybutton, .woocommerce .widget_price_filter .price_slider_amount .button, .woocommerce-page .widget_price_filter .price_slider_amount .button, .pricing-table a.button, ::selection, a.more-link, .more-from-category a, .content #genesis-responsive-slider a.more-link, .after-entry .enews-widget input[type="submit"], .footer-widgets .enews-widget input[type="submit"], .above-footers .enews-widget input[type="submit"]',

			'rule'     => 'color',

		),

		'vivien_button_hover_color' => array(
			'default'  => '#fff',
			'label'    => __( 'Button Hover Color', 'vivien' ),
			'selector' => '.front-page-1 .enews-widget input[type="submit"]:hover, .front-page-image-3 .enews-widget input[type="submit"]:hover, .front-page-image-5 .enews-widget input[type="submit"]:hover, .button:hover, button:hover, input:hover[type="button"], .sidebar .enews-widget input:hover[type="submit"], .enews-widget input:hover[type="submit"], input:hover[type="reset"], input:hover[type="submit"], .fancybutton:hover, .woocommerce #content input.button:hover, .woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover, .woocommerce-page #content input.button:hover, .woocommerce-page #respond input#submit:hover,  .woocommerce-page a.button:hover, .woocommerce-page button.button:hover, .woocommerce-page input.button:hover, .pricing-table a.button:hover, .pricing-table h4, .woocommerce .widget_price_filter .price_slider_wrapper .ui-widget-content, .woocommerce-page .widget_price_filter .price_slider_wrapper .ui-widget-content, .after-entry .enews-widget input[type="submit"]:hover, .footer-widgets .enews-widget input[type="submit"]:hover, .woocommerce .widget_price_filter .price_slider_amount .button:hover, .woocommerce-page .widget_price_filter .price_slider_amount .button:hover, .content #genesis-responsive-slider a.more-link:hover, .above-footers .enews-widget input[type="submit"]:hover',

			'rule'     => 'background-color',

		),

		'vivien_button_text_hover_color' => array(
			'default'  => '#333',
			'label'    => __( 'Button Hover Text Color', 'vivien' ),
			'selector' => '.front-page-1 .enews-widget input[type="submit"]:hover, .sidebar .enews-widget input:hover[type="submit"], .front-page-image-3 .enews-widget input[type="submit"]:hover, .front-page-image-5 .enews-widget input[type="submit"]:hover, .button:hover, button:hover, input:hover[type="button"], .sidebar .enews-widget input:hover[type="submit"], .enews-widget input:hover[type="submit"], input:hover[type="reset"], input:hover[type="submit"], .fancybutton:hover, .woocommerce #content input.button:hover, .woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover, .woocommerce-page #content input.button:hover, .woocommerce-page #respond input#submit:hover,  .woocommerce-page a.button:hover, .woocommerce-page button.button:hover, .woocommerce-page input.button:hover, .pricing-table a.button:hover, .pricing-table h4, .after-entry .enews-widget input[type="submit"]:hover, .footer-widgets .enews-widget input[type="submit"]:hover, .woocommerce .widget_price_filter .price_slider_amount .button:hover, .woocommerce-page .widget_price_filter .price_slider_amount .button:hover, .content #genesis-responsive-slider a.more-link:hover, .above-footers .enews-widget input[type="submit"]:hover',
			'rule'     => 'color',

		),

		'vivien_button_border_color' => array(
			'default'  => '#333',
			'label'    => __( 'Button border Color', 'vivien' ),
			'selector' => '.enews-widget input[type="submit"], .front-page-image-1 .enews-widget input[type="submit"], .front-page-image-3 .enews-widget input[type="submit"], .front-page-image-5 .enews-widget input[type="submit"], .front-page-image-5 .enews-widget input[type="submit"], .button, .button-secondary, button, input[type="button"], input[type="reset"], input[type="submit"], .sidebar .enews-widget input[type="submit"], .woocommerce #content input.button, .woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce-page #content input.button, .woocommerce-page #respond input#submit, .woocommerce-page a.button, .woocommerce-page button.button, .woocommerce-page input.button, .fancybutton, .woocommerce .widget_price_filter .ui-slider .ui-slider-handle, .woocommerce-page .widget_price_filter .ui-slider .ui-slider-handle, .pricing-table a.button, .content #genesis-responsive-slider a.more-link, .after-entry .enews-widget input[type="submit"], .fancybutton, .footer-widgets .enews-widget input[type="submit"], .widget-above-content .enews-widget input[type="submit"], a.more-link, .more-from-category a, .content #genesis-responsive-slider a.more-link, .front-page-image-1 .enews input, .front-page-image-3 .enews input, .front-page-image-5 .enews input, .front-page-image-7 .enews input, .home-welcome .enews input, .footer-widgets .enews-widget input, .widget-above-content .enews input, .after-entry .enews-widget input, .above-footers .enews input, .above-footers .enews-widget input[type="submit"], .sidebar .enews-widget input',

			'rule'     => 'border-color',

		),

		'vivien_button_border_hover_color' => array(
			'default'  => '#333',
			'label'    => __( 'Button border hover Color', 'vivien' ),
			'selector' => '.front-page-1 .enews-widget input[type="submit"]:hover, .front-page-image-3 .enews-widget input[type="submit"]:hover, .front-page-image-5 .enews-widget input[type="submit"]:hover, .front-page-image-5 .enews-widget input[type="submit"]:hover, .button:hover, button:hover, input:hover[type="button"], .sidebar .enews-widget input:hover[type="submit"], .enews-widget input:hover[type="submit"], input:hover[type="reset"], input:hover[type="submit"], .fancybutton:hover, .woocommerce #content input.button:hover, .woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover, .woocommerce-page #content input.button:hover, .woocommerce-page #respond input#submit:hover, .woocommerce-page a.button:hover, .woocommerce-page button.button:hover, .woocommerce-page input.button:hover, .pricing-table a.button:hover, .content #genesis-responsive-slider a.more-link:hover, .after-entry .enews-widget input[type="submit"]:hover, .fancybutton:hover, .footer-widgets .enews-widget input[type="submit"]:hover, .widget-above-content .enews-widget input[type="submit"]:hover, a.more-link:hover, .more-from-category a:hover, .content #genesis-responsive-slider a.more-link:hover, .sidebar .enews-widget input:hover',
			
			'rule'     => 'border-color',

		),

	);

	return apply_filters( 'vivien_get_colors', $colors );

}


//* An array of the font settings used in vivien theme.

function vivien_get_fonts() {

	$fonts = array(

		'vivien_title_font' => array(

			'default_family' => 'Comfortaa',
			'default_size'   => '36px',
			'default_style'  => 'disabled',
			'default_weight' => '300',
			'label'          => __( 'Site title and Boxes', 'vivien' ),
			'selector'       => '.site-title, .box .title',

		),

		'vivien_h1_font' => array(

			'default_family' => 'Old Standard TT',
			'default_size'   => '28px',
			'default_style'  => 'normal',
			'default_weight' => '300',
			'label'          => __( 'H1 (28px) Title Font', 'vivien' ),
			'selector'       => 'h1, h1.entry-title, .entry-title, .boxes .h1tagline',

		),

		'vivien_h2_font' => array(

			'default_family' => 'Old Standard TT',
			'default_size'   => '24px',
			'default_style'  => 'normal',
			'default_weight' => '300',
			'label'          => __( 'H2 (24px) Title Font', 'vivien' ),
			'selector'       => 'h2,  h2.entry-title, .home-bottom h2.entry-title, .categories-bottom .featuredpost h2, .home .one-third h2.entry-title, .home .one-fourth h2.entry-title, .home .one-sixth h2.entry-title, .categories-bottom .featuredpost h2, .boxes .h2tagline, .woocommerce #reviews #comments h2, .woocommerce-page #reviews #comments h2',

		),

		'vivien_h3_font' => array(

			'default_family' => 'Old Standard TT',
			'default_size'   => '22px',
			'default_style'  => 'normal',
			'default_weight' => '300',
			'label'          => __( 'H3 (22px) Title Font', 'vivien' ),
			'selector'       => 'h3, .widgettitle ,.sidebar h3.widget-title, .comment-respond h3, .entry-comments h3, .woocommerce ul.products li.product h3, .woocommerce-page ul.products li.product h3, .woocommerce #reviews h3, .woocommerce-page #reviews h3',

		),

		'vivien_h4_font' => array(

			'default_family' => 'Old Standard TT',
			'default_size'   => '20px',
			'default_style'  => 'normal',
			'default_weight' => '300',
			'label'          => __( 'H4 (20px) Title Font', 'vivien' ),
			'selector'       => 'h4, .categories-top h4, h4.widget-title, .before-footer h4.widgettitle, .categories-bottom .widgettitle',

		),

		'vivien_menu_font' => array(

			'default_family' => 'Comfortaa',
			'default_size'   => '12px',
			'default_style'  => 'normal',
			'default_weight' => '700',
			'label'          => __( 'Menu Font (15px)', 'vivien' ),
			'selector'       => '.genesis-nav-menu a, .genesis-nav-menu .menu-item',

		),

		'vivien_body_font' => array(

			'default_family' => 'Comfortaa',
			'default_size'   => '13px',
			'default_style'  => 'normal',
			'default_weight' => '400',
			'label'          => __( 'Body Font (13px)', 'vivien' ),
			'selector'       => 'body, .sidebar .featuredpost article, p, .boxes .pdescription, .related-list li a, .boxes .pdescription, .boxes .title, .fancybutton, .imagebox .title',

		),

		'vivien_accent_font' => array(

			'default_family' => 'Old Standard TT',
			'default_size'   => '11px',
			'default_style'  => 'italic',
			'default_weight' => '300',
			'label'          => __( 'Accent Font (11px)', 'vivien' ),
			'selector'       => 'input, select, textarea, .wp-caption-text, .site-description, .entry-meta, .post-info, .post-meta, .entry-header .entry-meta, .entry-footer .entry-meta, a.more-link, .more-from-category a, .comment-reply a',

		),

		

	);

	return apply_filters( 'vivien_get_fonts', $fonts );

}



add_filter( 'customizer_library_font_variants', 'vivien_font_variants', 10, 3 );





//* Filters the allowed Google Font varoamts for the vivien Theme.





function vivien_font_variants( $chosen_variants, $font, $variants ) {



	// Only add "200" if it exists

	if ( in_array( '200', $variants ) ) {

		$chosen_variants[] = '200';

	}



	// Only add "300" if it exists

	if ( in_array( '300', $variants ) ) {

		$chosen_variants[] = '300';

	}



	// Only add "300italic" if it exists

	if ( in_array( '300italic', $variants ) ) {
		$chosen_variants[] = '300italic';

	}

	// Only add "900" if it exists

	if ( in_array( '900', $variants ) ) {
		$chosen_variants[] = '900';

	}



	return array_unique( $chosen_variants );



}





//* Disable standard fonts.



add_filter( 'customizer_library_all_fonts', 'customizer_library_get_google_fonts' );

add_filter( 'customizer_library_get_google_fonts', 'vivien_get_google_fonts' );





//* Filters the allowed Google Fonts for the vivien theme.



function vivien_get_google_fonts( $fonts ) {

	$fonts = array(
'Abhaya Libre' => array(
			'label'    => 'Abhaya Libre',
			'variants' => array(
				'regular',
				'400',
				'italic',
				'700',
			),

			'subsets' => array(
				'latin',
			),

		),

		'Abril Fatface' => array(
			'label'    => 'Abril Fatface',
			'variants' => array(
				'regular',
				'400',
				'italic',
				'700',
			),

			'subsets' => array(
				'latin',

			),

		),

		'Adamina' => array(
			'label'    => 'Adamina',
			'variants' => array(
				'regular',
				'400',
				'italic',
				'700',
			),

			'subsets' => array(
				'latin',

			),

		),

		'Alegreya' => array(
			'label'    => 'Alegreya',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
			),

		),

		'Alex Brush' => array(
			'label'    => 'Alex Brush',
			'variants' => array(
				'regular',
				'400',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Allura' => array(
			'label'    => 'Allura',
			'variants' => array(
				'regular',
				'400',
				'italic',
				'700',

			),

			'subsets' => array(
				'regular',
				'400',
				'italic',
				'700',
			),

		),

		'Amatic SC' => array(
			'label'    => 'Amatic SC',
			'variants' => array(
				'regular',
				'400',
				'italic',
				'700',

			),

			'subsets' => array(
				'regular',
				'400',
				'italic',
				'700',

			),

		),

		'Amiri' => array(
			'label'    => 'Amiri',
			'variants' => array(
				'regular',
				'400',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Antic' => array(
			'label'    => 'Antic',
			'variants' => array(
				'400',
				'italic',
				'700',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Antic Didone' => array(
			'label'    => 'Antic Didone',
			'variants' => array(
				'400',
				'italic',
				'700',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Antic Slab' => array(
			'label'    => 'Antic Slab',
			'variants' => array(
				'400',
				'italic',
				'700',
			),

			'subsets' => array(
				'latin',

			),

		),

		'Arapey' => array(
			'label'    => 'Arapey',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
			),

		),

		'Arimo' => array(
			'label'    => 'Arimo',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',
			),

			'subsets' => array(

				'latin',
			),

		),


		'Arizonia' => array(
			'label'    => 'Arizonia',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
			),

		),

		'Arsenal' => array(
			'label'    => 'Arsenal',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
			),

		),

		'Arvo' => array(
			'label'    => 'Arvo',
			'variants' => array(
				'regular',
			),

			'subsets' => array(
				'latin',

			),

		),

		'Bad Script' => array(
			'label'    => 'Bad Script',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'BenchNine' => array(
			'label'    => 'BenchNine',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Bentham' => array(
			'label'    => 'Bentham',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Bungee Inline' => array(
			'label'    => 'Bungee Inline',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Cardo' => array(
			'label'    => 'Cardo',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Carrois Gothic' => array(
			'label'    => 'Carrois Gothic',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Carrois Gothic SC' => array(
			'label'    => 'Carrois Gothic SC',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Cinzel' => array(
			'label'    => 'Cinzel',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Clicker Script' => array(
			'label'    => 'Clicker Script',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Cookie' => array(
			'label'    => 'Cookie',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Comfortaa' => array(
			'label'    => 'Comfortaa',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Cormorant' => array(
			'label'    => 'Cormorant',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Cormorant Garamond' => array(
			'label'    => 'Cormorant Garamond',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),
		),

		'Cormorant Infant' => array(
			'label'    => 'Cormorant Infant',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),
		),

		'Cormorant Upright' => array(
			'label'    => 'Cormorant Upright',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Cutive Mono' => array(
			'label'    => 'Cutive Mono',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Dacing Script' => array(
			'label'    => 'Dacing Script',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'David Libre' => array(
			'label'    => 'David Libre',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Delius' => array(
			'label'    => 'Delius',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Didact Gothic' => array(
			'label'    => 'Didact Gothic',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Domine' => array(
			'label'    => 'Domine',
			'variants' => array(
				'regular',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',

			),

		),

		'Dr Sugiyama' => array(
			'label'    => 'Dr Sugiyama',
			'variants' => array(
				'regular',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Dosis' => array(
			'label'    => 'Dosis',
			'variants' => array(
				'regular',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
			),

		),

		'Droid Serif' => array(
			'label'    => 'Droid Serif',
			'variants' => array(
				'regular',
				'italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'EB Garamond' => array(
			'label'    => 'EB Garamond',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Economica' => array(
			'label'    => 'Economica',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Engagement' => array(
			'label'    => 'Engagement',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Esteban' => array(
			'label'    => 'Esteban',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Frank Ruhl Libre' => array(
			'label'    => 'Frank Ruhl Libre',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Fira Mono' => array(
			'label'    => 'Fira Mono',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Fira Sans Extra Condensed' => array(
			'label'    => 'Fira Sans Extra Condensed',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Forum' => array(
			'label'    => 'Forum',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Gilda Display' => array(
			'label'    => 'Gilda Display',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Grand Hotel' => array(
			'label'    => 'Grand Hotel',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Great Vibes' => array(

			'label'    => 'Great Vibes',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Gudea' => array(

			'label'    => 'Gudea',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Handlee' => array(

			'label'    => 'Handlee',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Harmattan' => array(

			'label'    => 'Harmattan',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',
			),

		),

		'Hind' => array(
			'label'    => 'Hind',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Homemade Apple' => array(
			'label'    => 'Homemade Apple',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'IM Fell English' => array(
			'label'    => 'IM Fell English',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Istok Web' => array(
			'label'    => 'Istok Web',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Italiana' => array(
			'label'    => 'Italiana',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Josefin Sans' => array(
			'label'    => 'Josefin Sans',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Julius Sans One' => array(
			'label'    => 'Julius Sans One',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Junge' => array(
			'label'    => 'Junge',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),


		'Khula' => array(
			'label'    => 'Khula',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Kristi' => array(
			'label'    => 'Kristi',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Lancelot' => array(
			'label'    => 'Lancelot',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Lateef' => array(
			'label'    => 'Lateef',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Lato' => array(
			'label'    => 'Lato',
			'variants' => array(
				'100',
				'100italic',
				'300',
				'300italic',
				'regular',
				'italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',

			),

		),

		'Libre Baskerville' => array(
			'label'    => 'Libre Baskerville',
			'variants' => array(
				'regular',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Libre Franklin' => array(
			'label'    => 'Libre Franklin',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Life Savers' => array(
			'label'    => 'Life Savers',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Limelight' => array(

			'label'    => 'Limelight',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Lobster Two' => array(
			'label'    => 'Lobster Two',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',
			),

		),

		'Lora' => array(
			'label'    => 'Lora',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',

			),

		),

		'Lustria' => array(
			'label'    => 'Lustria',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',

			),

		),

		'Marcellus' => array(
			'label'    => 'Marcellus',
			'variants' => array(
				'300',
				'300italic',
				'400italic',
				'italic',
				'400',
				'700',
				'700italic',
				'900',

				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',
				'cyrillic-ext',

			),

		),

		'Mate' => array(
			'label'    => 'Mate',
			'variants' => array(
				'300',
				'300italic',
				'400italic',
				'italic',
				'400',
				'700',
				'700italic',
				'900',

				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',
				'cyrillic-ext',

			),

		),

		'Meddon' => array(
			'label'    => 'Meddon',
			'variants' => array(
				'300',
				'300italic',
				'400italic',
				'italic',
				'400',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',
				'cyrillic-ext',

			),

		),

		'Merienda One' => array(
			'label'    => 'Merienda One',
			'variants' => array(
				'300',
				'300italic',
				'400italic',
				'italic',
				'400',
				'700',
				'700italic',
				'900',
				'900italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',
				'cyrillic-ext',

			),

		),

		'Merriweather' => array(
			'label'    => 'Merriweather',
			'variants' => array(
				'300',
				'300italic',
				'400italic',
				'italic',
				'400',
				'700',
				'700italic',
				'900',
				'900italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',
				'cyrillic-ext',

			),

		),

		'Montserrat' => array(
			'label'    => 'Montserrat',
			'variants' => array(
				'300',
				'300italic',
				'400italic',
				'italic',
				'400',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',
				'cyrillic-ext',

			),

		),

		'Montserrat Subrayada' => array(
			'label'    => 'Montserrat Subrayada',
			'variants' => array(
				'300',
				'300italic',
				'400italic',
				'italic',
				'400',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',
				'cyrillic-ext',

			),

		),

		'Mr Bedfort' => array(
			'label'    => 'Mr Bedfort',
			'variants' => array(
				'300',
				'300italic',
				'400italic',
				'italic',
				'400',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',
				'cyrillic-ext',

			),

		),

		'Muli' => array(
			'label'    => 'Muli',
			'variants' => array(
				'300',
				'regular',
				'400',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Neuton' => array(
			'label'    => 'Neuton',
			'variants' => array(
				'200',
				'300',
				'regular',
				'italic',
				'400',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'News Cycle' => array(
			'label'    => 'News Cycle',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Noticia Text' => array(
			'label'    => 'Noticia Text',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'vietnamese',

			),

		),

		'Noto Sans' => array(
			'label'    => 'Noto Sans',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',
				'cyrillic-ext',
				'Greek',
				'Greek-ext',
				'vietnamese',

			),

		),

		'Nunito Sans' => array(
			'label'    => 'Nunito Sans',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',
				'cyrillic-ext',
				'Greek',
				'Greek-ext',
				'vietnamese',

			),

		),

		'Old Standard TT' => array(
			'label'    => 'Old Standard TT',
			'variants' => array(
				'400',
				'regular',
				'italic',
				'700',
			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Open Sans' => array(
			'label'    => 'Open Sans',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Oranienbaum' => array(
			'label'    => 'Oranienbaum',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Oswald' => array(
			'label'    => 'Oswald',
			'variants' => array(
				'300',
				'regular',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Oxygen Mono' => array(
			'label'    => 'Oxygen Mono',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(

				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Overlock' => array(
			'label'    => 'Overlock',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Pacifico' => array(
			'label'    => 'Pacifico',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',
			),

		),

		'Palanquin Dark' => array(
			'label'    => 'Palanquin Dark',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Parisienne' => array(
			'label'    => 'Parisienne',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Pavanam' => array(
			'label'    => 'Pavanam',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',
			),

		),

		'Pathway Gothic One' => array(
			'label'    => 'Pathway Gothic One',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Permanent Marker' => array(
			'label'    => 'Permanent Marker',
			'variants' => array(
				'regular',
				'italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'cyrillic',
				'latin-ext',
			),

		),

		'Philosopher' => array(
			'label'    => 'Philosopher',
			'variants' => array(
				'regular',
				'italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'cyrillic',
				'latin-ext',
			),

		),

		'Playfair Display' => array(
			'label'    => 'Playfair Display',
			'variants' => array(
				'regular',
				'italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'cyrillic',
				'latin-ext',
			),

		),

		'Poiret One' => array(
			'label'    => 'Poiret One',
			'variants' => array(
				'400',
				'regular',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Pompiere' => array(
			'label'    => 'Pompiere',
			'variants' => array(
				'400',
				'regular',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Pontano Sans' => array(
			'label'    => 'Pontano Sans',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',
			),

		),

		'Poppins' => array(
			'label'    => 'Poppins',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',
			),

		),


		'Prata' => array(
			'label'    => 'Prata',
			'variants' => array(
				'400',
				'regular',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'PT Sans' => array(
			'label'    => 'PT Sans',
			'variants' => array(
				'regular',
				'700',

			),

			'subsets' => array(
				'latin',
				'cyrillic',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'PT Sans Narrow' => array(
			'label'    => 'PT Sans Narrow',
			'variants' => array(
				'regular',
				'700',
			),

			'subsets' => array(
				'latin',
				'cyrillic',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'PT Serif' => array(
			'label'    => 'PT Serif',
			'variants' => array(
				'regular',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'cyrillic',
				'latin-ext',
				'cyrillic-ext',

			),

		),


		'Quattrocento Sans' => array(
			'label'    => 'Quattrocento Sans',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Questrial' => array(
			'label'    => 'Questrial',
			'variants' => array(
				'400',
				'regular',
				'italic',
				'700',
			),

			'subsets' => array(
				'latin',

			),

		),

		'Quicksand' => array(
			'label'    => 'Quicksand',
			'variants' => array(
				'300',
				'400',
				'700',

			),

			'subsets' => array(
				'latin',

			),

		),

		'Qwigley' => array(
			'label'    => 'Qwigley',
			'variants' => array(
				'300',
				'400',
				'700',
			),

			'subsets' => array(
				'latin',
			),

		),

		'Raleway' => array(
			'label'    => 'Raleway',
			'variants' => array(
				'100',
				'200',
				'300',
				'regular',
				'500',
				'600',
				'700',
				'800',
				'900',

			),

			'subsets' => array(
				'latin',
			),

		),

		'Rasa' => array(
			'label'    => 'Rasa',
			'variants' => array(
				'100',
				'300',
				'regular',
				'700',

			),

			'subsets' => array(
				'latin',
				'greek-ext',
				'cyrillic',
				'greek',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',
			),

		),

		'Roboto Slab' => array(
			'label'    => 'Roboto Slab',
			'variants' => array(
				'100',
				'300',
				'regular',
				'700',

			),

			'subsets' => array(
				'latin',
				'greek-ext',
				'cyrillic',
				'greek',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),



		),

		'Rochester' => array(
			'label'    => 'Rochester',
			'variants' => array(
				'100',
				'300',
				'regular',
				'700',

			),

			'subsets' => array(
				'latin',
				'greek-ext',
				'cyrillic',
				'greek',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',
			),

		),

		'Rock Salt' => array(
			'label'    => 'Rock Salt',
			'variants' => array(
				'100',
				'300',
				'regular',
				'700',

			),

			'subsets' => array(
				'latin',
				'greek-ext',
				'cyrillic',
				'greek',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',
			),

		),

		'Ropa Sans' => array(
			'label'    => 'Ropa Sans',
			'variants' => array(
				'100',
				'300',
				'regular',
				'700',

			),

			'subsets' => array(
				'latin',
				'greek-ext',
				'cyrillic',
				'greek',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',
			),

		),

		'Rouge Script' => array(
			'label'    => 'Rouge Script',
			'variants' => array(
				'100',
				'300',
				'regular',
				'700',

			),

			'subsets' => array(
				'latin',
				'greek-ext',
				'cyrillic',
				'greek',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',
			),

		),

		'Sacramento' => array(
			'label'    => 'Sacramento',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Sanchez' => array(
			'label'    => 'Sanchez',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
			),

		),

		'Satisfy' => array(
			'label'    => 'Satisfy',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Scheherazade' => array(
			'label'    => 'Scheherazade',
			'variants' => array(
				'200',
				'200italic',
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'vietnamese',
				'latin-ext',
			),

		),

		'Scope One' => array(
			'label'    => 'Scope One',
			'variants' => array(
				'200',
				'200italic',
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'vietnamese',
				'latin-ext',
			),

		),

		'Seaweed Script' => array(
			'label'    => 'Seaweed Script',
			'variants' => array(
				'200',
				'200italic',
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'vietnamese',
				'latin-ext',
			),

		),

		'Scope One' => array(
			'label'    => 'Scope One',
			'variants' => array(
				'200',
				'200italic',
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'vietnamese',
				'latin-ext',
			),

		),

		'Shadows Into Light' => array(
			'label'    => 'Shadows Into Light',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Signika' => array(
			'label'    => 'Signika',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Slavo 27px' => array(
			'label'    => 'Slavo 27px',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Source Sans Pro' => array(
			'label'    => 'Source Sans Pro',
			'variants' => array(
				'200',
				'200italic',
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'vietnamese',
				'latin-ext',

			),

		),

		'Special Elite' => array(
			'label'    => 'Special Elite',
			'variants' => array(
				'300',
				'regular',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
			),

		),

		'Sorts Mill Goudy' => array(
			'label'    => 'Sorts Mill Goudy',
			'variants' => array(
				'regular',
				'300',
				'300italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',

			),

		),

		'Sue Ellen Francisco' => array(
			'label'    => 'Sue Ellen Francisco',
			'variants' => array(
				'regular',
				'400',
				'700',
			),

			'subsets' => array(
				'latin',
			),
		),

		'Tangerine' => array(
			'label'    => 'Tangerine',
			'variants' => array(
				'regular',
				'400',
				'italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',
			),

		),

		'Tinos' => array(
			'label'    => 'Tinos',
			'variants' => array(
				'regular',
				'400',
				'italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',
			),

		),

		'Titillium Web' => array(
			'label'    => 'Titillium Web',
			'variants' => array(
				'regular',
				'400',
				'italic',
				'700',
				'700italic',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',
			),

		),

		'Unna' => array(
			'label'    => 'Unna',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',

				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',
			),

		),

		'Ubuntu' => array(
			'label'    => 'Ubuntu',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',

				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',
			),

		),

		'Varela' => array(
			'label'    => 'Varela',
			'variants' => array(
				'400',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
			),

		),

		'Vidaloka' => array(
			'label'    => 'Vidaloka',
			'variants' => array(
				'400',
				'300',
				'300italic',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Vollkorn' => array(
			'label'    => 'Vollkorn',
			'variants' => array(
				'400',
				'300',
				'300italic',
				'italic',
				'700',
			),
			'subsets' => array(
				'latin',
				'latin-ext',
			),
		),

		'Work Sans' => array(
			'label'    => 'Work Sans',
			'variants' => array(
				'400',
				'300',
				'300italic',
				'italic',
				'700',
			),

			'subsets' => array(

				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Yanone Kaffeesatz' => array(
			'label'    => 'Yanone Kaffeesatz',
			'variants' => array(
				'400',
				'300',
				'300italic',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Yeseva One' => array(
			'label'    => 'Yeseva One',
			'variants' => array(
				'400',
				'300',
				'300italic',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Yesteryear' => array(
			'label'    => 'Yesteryear',
			'variants' => array(
				'400',
				'300',
				'300italic',
				'italic',
				'700',
			),

			'subsets' => array(
				'latin',
				'latin-ext',
			),

		),



		

	);

	return $fonts;

}



endif;





