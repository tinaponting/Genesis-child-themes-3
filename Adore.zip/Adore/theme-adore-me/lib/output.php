<?php
/**
 * Adore Me.
 * @package Adore Me
 */

add_action( 'wp_enqueue_scripts', 'adore_custom_css' );
/**
 * Check to see if there is a new value for link color or the accent color, and if
 * so, print that value to the theme's main stylesheet.
 *
 * @since 3.2.0
 */
function adore_custom_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';

	$color_link   = get_theme_mod( 'adore_link_color', adore_customizer_get_default_link_color() );
	$color_body_font   = get_theme_mod( 'adore_body_font', adore_customizer_get_default_body_font() );
	$color_headings_font   = get_theme_mod( 'adore_headings_font', adore_customizer_get_default_headings_font() );
	$color_site_title_color = get_theme_mod( 'adore_site_title_color', adore_customizer_get_default_site_title_color() );
	$color_site_description_color = get_theme_mod( 'adore_site_description_color', adore_customizer_get_default_site_description_color() );
	$color_header_menu = get_theme_mod( 'adore_header_menu', adore_customizer_get_default_header_menu() );
	$color_header_menu_font = get_theme_mod( 'adore_header_menu_font', adore_customizer_get_default_header_menu_font() );
	$color_header_after_menu_font = get_theme_mod( 'adore_header_after_menu_font', adore_customizer_get_default_header_after_menu_font() );
	$color_textbox_one = get_theme_mod( 'adore_textbox_one', adore_customizer_get_default_textbox_one() );
	$color_textbox_one_font = get_theme_mod( 'adore_textbox_one_font', adore_customizer_get_default_textbox_one_font() );
	$color_textbox_two = get_theme_mod( 'adore_textbox_two', adore_customizer_get_default_textbox_two() );
	$color_textbox_two_font = get_theme_mod( 'adore_textbox_two_font', adore_customizer_get_default_textbox_two_font() );
	$color_featured_image_bg = get_theme_mod( 'adore_featured_image_bg', adore_customizer_get_default_featured_image_bg() );
	$color_featured_image_entry = get_theme_mod( 'adore_featured_image_entry', adore_customizer_get_default_featured_image_entry() );
	$color_sidebar_border = get_theme_mod( 'adore_sidebar_border', adore_customizer_get_default_sidebar_border() );
	$color_frontpage_four = get_theme_mod( 'adore_frontpage_four', adore_customizer_get_default_frontpage_four() );
	$color_frontpage_four_font = get_theme_mod( 'adore_frontpage_four_font', adore_customizer_get_default_frontpage_four_font() );
	
	$opts = apply_filters( 'adore_images', array( '2', '6' ) );

	$settings = array();

	$css = '';
	
	foreach( $opts as $opt ) {
		$settings[$opt]['image'] = preg_replace( '/^https?:/', '', get_option( $opt .'-adore-image', sprintf( '%s/images/bg-%s.jpg', get_stylesheet_directory_uri(), $opt ) ) );
	}

	foreach ( $settings as $section => $value ) {

		$background = $value['image'] ? sprintf( 'background-image: url(%s);', $value['image'] ) : '';

		if ( is_front_page() ) {
			$css .= ( ! empty( $section ) && ! empty( $background ) ) ? sprintf( '.front-page-%s { %s }', $section, $background ) : '';
		}

	}

	$css .= ( adore_customizer_get_default_link_color() !== $color_link ) ? sprintf( '

		a,
		.entry-title a:focus,
		.entry-title a:hover,
		.genesis-nav-menu li > a:focus,
		.genesis-nav-menu li > a:hover,
		.genesis-nav-menu a:focus,
		.genesis-nav-menu a:hover,
		.genesis-nav-menu .sub-menu a:focus,
		.genesis-nav-menu .sub-menu a:hover,
		.nav-primary .genesis-nav-menu a:focus,
		.nav-primary .genesis-nav-menu a:hover,
		.nav-primary .genesis-nav-menu li.menu-item-has-children:focus > a,
		.nav-primary .genesis-nav-menu li.menu-item-has-children:hover > a,
		.nav-primary .genesis-nav-menu .sub-menu a:focus,
		.nav-primary .genesis-nav-menu .sub-menu a:hover,
		.entry-comments-link::before,
		.site-footer a:hover,
		.site-footer a:focus,
		.page.page-template-page_blog .entry-title a:hover,
		.page.page-template-page_blog .entry-title a:focus,
		.nav-primary .genesis-nav-menu .sub-menu a:focus,
 		.nav-primary .genesis-nav-menu .sub-menu a:hover {
			color: %1$s;
		}
		
		@media only screen and (max-width: 800px) {
		
			.menu-toggle:focus,
			.menu-toggle:hover,
			.sub-menu-toggle:focus,
			.sub-menu-toggle:hover,
			.nav-secondary.genesis-responsive-menu .genesis-nav-menu .menu-item a:focus,
			.nav-secondary.genesis-responsive-menu .genesis-nav-menu .menu-item a:hover {
				color: %1$s;
			}
			
		}

		', $color_link ) : '';
	
	$css .= ( adore_customizer_get_default_body_font() !== $color_body_font ) ? sprintf( '

		body,
		input, select, textarea {
			color: %1$s;
		}

		', $color_body_font ) : '';
	
	$css .= ( adore_customizer_get_default_headings_font() !== $color_headings_font ) ? sprintf( '

		h1, h2, h3, h4, h5, h6 {
			color: %1$s;
		}

		', $color_headings_font ) : '';
		
	$css .= ( adore_customizer_get_default_site_title_color() !== $color_site_title_color ) ? sprintf( '

		.site-title a, .site-title a:focus, .site-title a:hover {
			color: %1$s;
		}

		', $color_site_title_color ) : '';
	
	$css .= ( adore_customizer_get_default_site_description_color() !== $color_site_description_color ) ? sprintf( '

		.site-description {
			color: %1$s;
		}

		', $color_site_description_color ) : '';
	
	$css .= ( adore_customizer_get_default_header_menu() !== $color_header_menu ) ? sprintf( '

		.nav-primary,
		.site-footer {
			background-color: %1$s;
		}
		
		.genesis-nav-menu .sub-menu {
			border-color: %1$s;
		}
		
		@media only screen and (max-width: 800px) {
		
			.menu-toggle:focus, 
			.menu-toggle:hover, 
			.sub-menu-toggle:focus, 
			.sub-menu-toggle:hover,
			.menu-toggle,
			.sub-menu-toggle {
				background: %1$s;
			}
		
		}

		', $color_header_menu ) : '';
	
	$css .= ( adore_customizer_get_default_header_menu_font() !== $color_header_menu_font ) ? sprintf( '

		.nav-primary .genesis-nav-menu a,
		.nav-primary .genesis-nav-menu .sub-menu a,
		.site-footer,
		.site-footer a {
			color: %1$s;
		}
		
		@media only screen and (max-width: 800px) {
		
			.menu-toggle,
			.sub-menu-toggle {
				color: %1$s;
			}
		
		}

		', $color_header_menu_font ) : '';
	
	$css .= ( adore_customizer_get_default_header_after_menu_font() !== $color_header_after_menu_font ) ? sprintf( '

		.genesis-nav-menu a,
		.nav-primary span.menu-description, 
		.nav-secondary span.menu-description,
		.genesis-nav-menu .sub-menu a {
			color: %1$s;
		}
		
		@media only screen and (max-width: 800px) {
			
			button#genesis-mobile-nav-secondary.menu-toggle.dashicons-before.dashicons-menu,
			.nav-secondary.genesis-responsive-menu .genesis-nav-menu .menu-item a {
				color: %1$s;
			}
		
		}

		', $color_header_after_menu_font ) : '';

	$css .= ( adore_customizer_get_default_textbox_one() !== $color_textbox_one ) ? sprintf( '

		.textbox1 {
			background-color: %1$s;
			outline-color: %1$s;
		}

		', $color_textbox_one ) : '';
	
	$css .= ( adore_customizer_get_default_textbox_one_font() !== $color_textbox_one_font ) ? sprintf( '

		.headline-title1,
		.headline1,
		.pdescription1 {
			color: %1$s;
		}

		', $color_textbox_one_font ) : '';
	
	$css .= ( adore_customizer_get_default_textbox_two() !== $color_textbox_two ) ? sprintf( '

		.textbox2 {
			background-color: %1$s;
			outline-color: %1$s;
		}

		', $color_textbox_two ) : '';
	
	$css .= ( adore_customizer_get_default_textbox_two_font() !== $color_textbox_two_font ) ? sprintf( '

		.headline-title2,
		.headline2,
		.pdescription2 {
			color: %1$s;
		}

		', $color_textbox_two_font ) : '';
	
	$css .= ( adore_customizer_get_default_featured_image_bg() !== $color_featured_image_bg ) ? sprintf( '

		.page.page-template-page_blog .entry-header,
		.entry-header,
		.archive-pagination li a,
		.after-entry {
			background: %1$s;
		}
		
		.archive-pagination li a:focus, .archive-pagination li a:hover,
		.archive-pagination li a {
			outline-color: %1$s;
		}

		', $color_featured_image_bg ) : '';
	
	$css .= ( adore_customizer_get_default_featured_image_entry() !== $color_featured_image_entry ) ? sprintf( '

		.page.page-template-page_blog .entry-header .entry-meta,
		.page.page-template-page_blog .entry-title a,
		.entry-header .entry-meta,
		.entry-title a,
		.archive-pagination li a,
		.after-entry h3,
		.after-entry p {
			color: %1$s;
		}

		', $color_featured_image_entry ) : '';
	
	$css .= ( adore_customizer_get_default_sidebar_border() !== $color_sidebar_border ) ? sprintf( '

		.sidebar .widget,
		.entry-footer .entry-meta,
		input, select, textarea,
		.comment.depth-1,
		.comment,
		.home-tabs .wrap {
			border-color: %1$s;
		}

		', $color_sidebar_border ) : '';
	
	$css .= ( adore_customizer_get_default_frontpage_four() !== $color_frontpage_four ) ? sprintf( '

		.front-page-4 {
			background-color: %1$s;
		}

		', $color_frontpage_four ) : '';
	
	$css .= ( adore_customizer_get_default_frontpage_four_font() !== $color_frontpage_four_font ) ? sprintf( '

		.front-page-4,
		.front-page-4 .widget-title,
		.front-page-4 p,
		.front-page-4 h1,
		.front-page-4 h2,
		.front-page-4 h3, 
		.front-page-4 h4, 
		.front-page-4 h5, 
		.front-page-4 h6 {
			color: %1$s;
		}

		', $color_frontpage_four_font ) : '';
	

	if ( $css ) {
		wp_add_inline_style( $handle, $css );
	}

}