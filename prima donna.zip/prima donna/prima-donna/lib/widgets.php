<?php
/**
 * This file adds all the widget spaces to the Prima Donna theme.
 * @package      Prima Donna
 */

//* Register widget areas
genesis_register_sidebar( array(
	'id'          	=> 'nav-social-menu',
	'name'        	=> __( 'Nav Social Menu', 'primadonna' ),
	'description' 	=> __( 'This is the nav social menu section.', 'primadonna' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-1',
	'name'        => __( 'Home Page 1', 'primadonna' ),
	'description' => __( 'This is the 1st widget area on the Home Page. Full width widget area.', 'primadonna' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-2',
	'name'        => __( 'Home Page 2', 'primadonna' ),
	'description' => __( 'This is the 2nd section on the home page. Boxed widget area', 'primadonna' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-3',
	'name'        => __( 'Home Page 3', 'primadonna' ),
	'description' => __( 'This is the 3rd section on the home page.', 'primadonna' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-4',
	'name'        => __( 'Home Page 4', 'primadonna' ),
	'description' => __( 'This is the 4th section on the home page.', 'primadonna' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-5',
	'name'        => __( 'Home Page 5', 'primadonna' ),
	'description' => __( 'This is the 5th section on the home page.', 'primadonna' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-6',
	'name'        => __( 'Home Page 6', 'primadonna' ),
	'description' => __( 'This is the 6th section on the home page.', 'primadonna' ),
) );
genesis_register_sidebar( array(
	'id'            => 'widget-above-content',
	'name'          => __( 'Widget Above Content', 'primadonna' ),
	'description'   => __( 'This widget area appears on the home page and at the top of all other pages', 'primadonna' ),
) );
genesis_register_sidebar( array(
	'id'            => 'widget-below-footer',
	'name'          => __( 'Widget Below Footer', 'primadonna' ),
	'description'   => __( 'This widget area appears below the footer.', 'primadonna' ),
) );
genesis_register_sidebar( array(
	'id'            => 'category-index-top',
	'name'          => __( 'Category Index Top', 'primadonna' ),
	'description'   => __( 'This widget area that appears at top of the Category Index page. Good for Category, Archive and Search widgets.', 'primadonna' ),
) );
genesis_register_sidebar( array(
	'id'            => 'category-index',
	'name'          => __( 'Category Index', 'primadonna' ),
	'description'   => __( 'This widget area for the bottom of the Category Index Page. Insert Featured Posts widgets.', 'primadonna' ),
) );
genesis_register_sidebar( array(
	'id'          	=> 'above-blog-slider',
	'name'        	=> __( 'Above Blog Slider', 'primadonna' ),
	'description' 	=> __( 'This is the above blog slider section of the home or blog page. Located in the content column of the blog', 'primadonna' ),
) );
genesis_register_sidebar( array(
	'id'          	=> 'blog-page-1',
	'name'        	=> __( 'Blog Page 1', 'primadonna' ),
	'description' 	=> __( 'This is a full width widget area above the Promo Boxes on the Blog Page.', 'primadonna' ),
) );
genesis_register_sidebar( array(
	'id'          	=> 'blog-page-2',
	'name'        	=> __( 'Blog Page 2', 'primadonna' ),
	'description' 	=> __( 'This is a boxed width widget area above the Promo Boxes on the Blog Page', 'primadonna' ),
) );
genesis_register_sidebar( array(
	'id'          	=> 'blog-page-3',
	'name'        	=> __( 'Blog Page 3', 'primadonna' ),
	'description' 	=> __( 'This is a boxed widget area below the Promo Boxes on the Blog Page', 'primadonna' ),
) );
genesis_register_sidebar( array(
	'id'          	=> 'blog-page-left',
	'name'        	=> __( 'Blog Page Left', 'primadonna' ),
	'description' 	=> __( 'This is a boxed widget area for the 2/3 + 1/3 layout, left side', 'primadonna' ),
) );
genesis_register_sidebar( array(
	'id'          	=> 'blog-page-right',
	'name'        	=> __( 'Blog Page Right', 'primadonna' ),
	'description' 	=> __( 'This is a boxed widget area for the 2/3 + 1/3 layout, right side', 'primadonna' ),
) );

