jQuery(function( $ ){

	$(document).on("scroll", function(){
		if($(document).scrollTop() > 400){
			$(".nav-primary").addClass("reveal");		
			$(".site-header").addClass("mas-grande");
		} else {
			$(".nav-primary").removeClass("reveal");
			$(".site-header").removeClass("mas-grande");
		}
	});

});