<?php
/**
 * This file adds the blog page template to the Vivien theme.
 * @package     Vivien Theme
 * @subpackage  Genesis
 */
/*
Template Name: Blog Page
*/


//* Hooks Slider Above Blog Content
add_action( 'genesis_before_loop', 'market_above_blog_slider'  ); 
function market_above_blog_slider() {
    
    genesis_widget_area( 'above-blog-slider', array(
		'before' => '<div class="above-blog-slider widget-area">',
		'after'  => '</div>',
    ) );

}

//* Remove entry meta
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );



genesis();