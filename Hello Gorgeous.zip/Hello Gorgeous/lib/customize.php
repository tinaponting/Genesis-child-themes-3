<?php
/**
 * Customizer additions.
 * @package Hello CEO
 */

/**
 * Get default colors for Customizer.
 *
 * Abstracted here since at least two functions use it.
 *
 * @since 1.0.0
 *
 * @return string Hex color code for colors.
 */
 function hyd_customizer_get_default_mintcolor_color() {
   return '#ECF7F6';
 }
 function hyd_customizer_get_default_navlink_color() {
  return '#373737';
 }
 function hyd_customizer_get_default_navhover_color() {
  return '#e1bdbd';
 }
 function hyd_customizer_get_default_linkcolor_color() {
  return '#373737';
 }
 function hyd_customizer_get_default_hovercolor_color() {
  return '#e1bdbd';
 }
 function hyd_customizer_get_default_gridsection_color() {
  return '#fff5f3';
 }
 function hyd_customizer_get_default_gridfont_color() {
  return '#777676';
 }
 function hyd_customizer_get_default_gridlink_color() {
  return '#2f414a';
 }
 function hyd_customizer_get_default_gridhover_color() {
  return '#999';
 }
 function hyd_customizer_get_default_services_color() {
  return '#f5f5f5';
 }
 function hyd_customizer_get_default_button_color() {
  return '#2f414a';
 }
 function hyd_customizer_get_default_rose_color() {
  return '#e1bdbd';
 }
 function hyd_customizer_get_default_navy_color() {
  return '#2f414a';
 }
 function hyd_customizer_get_default_sharelinks_color() {
  return '#9f9f9f';
 }

add_action( 'customize_register', 'hyd_customizer_register' );
/**
 * Register settings and controls with the Customizer.
 *
 * @since 1.0.0
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function hyd_customizer_register() {

	/**
	 * Customize Background Image Control Class
	 *
	 * @package WordPress
	 * @subpackage Customize
	 * @since 3.4.0
	 */
	class Child_hyd_Image_Control extends WP_Customize_Image_Control {

		/**
		 * Constructor.
		 *
		 * If $args['settings'] is not defined, use the $id as the setting ID.
		 *
		 * @since 3.4.0
		 * @uses WP_Customize_Upload_Control::__construct()
		 *
		 * @param WP_Customize_Manager $manager
		 * @param string $id
		 * @param array $args
		 */
		public function __construct( $manager, $id, $args ) {
			$this->statuses = array( '' => __( 'No Image', 'hyd' ) );

			parent::__construct( $manager, $id, $args );

			$this->add_tab( 'upload-new', __( 'Upload New', 'hyd' ), array( $this, 'tab_upload_new' ) );
			$this->add_tab( 'uploaded',   __( 'Uploaded', 'hyd' ),   array( $this, 'tab_uploaded' ) );

			if ( $this->setting->default )
				$this->add_tab( 'default',  __( 'Default', 'hyd' ),  array( $this, 'tab_default_background' ) );

			// Early priority to occur before $this->manager->prepare_controls();
			add_action( 'customize_controls_init', array( $this, 'prepare_control' ), 5 );
		}

		/**
		 * @since 3.4.0
		 * @uses WP_Customize_Image_Control::print_tab_image()
		 */
		public function tab_default_background() {
			$this->print_tab_image( $this->setting->default );
		}

	}

	global $wp_customize;

  $wp_customize->add_setting(
  	'hyd_mintcolor_color',
  	array(
  		'default' => hyd_customizer_get_default_mintcolor_color(),
  		'sanitize_callback' => 'sanitize_hex_color',
  	)
  );

  $wp_customize->add_control(
  	new WP_Customize_Color_Control(
  		$wp_customize,
  		'hyd_mintcolor_color',
  		array(
  			'description' => __( 'Change the Default Mint Color on Sticky Nav and mint', 'hyd' ),
  				'label'       => __( 'Site Mint Color', 'hyd' ),
  				'section'     => 'colors',
  				'settings'    => 'hyd_mintcolor_color',
  		)
  	)
  );

$wp_customize->add_setting(
	'hyd_navlink_color',
	array(
		'default' => hyd_customizer_get_default_navlink_color(),
		'sanitize_callback' => 'sanitize_hex_color',
	)
);

$wp_customize->add_control(
	new WP_Customize_Color_Control(
		$wp_customize,
		'hyd_navlink_color',
		array(
			'description' => __( 'Change the Default Sticky Nav Link Color', 'hyd' ),
				'label'       => __( 'Sticky Navigation Links', 'hyd' ),
				'section'     => 'colors',
				'settings'    => 'hyd_navlink_color',
		)
	)
);

$wp_customize->add_setting(
	'hyd_navhover_color',
	array(
		'default' => hyd_customizer_get_default_navhover_color(),
		'sanitize_callback' => 'sanitize_hex_color',
	)
);

$wp_customize->add_control(
	new WP_Customize_Color_Control(
		$wp_customize,
		'hyd_navhover_color',
		array(
			'description' => __( 'Change the Default Sticky Navigation hover color', 'hyd' ),
				'label'       => __( 'Sticky Navigation Hover', 'hyd' ),
				'section'     => 'colors',
				'settings'    => 'hyd_navhover_color',
		)
	)
);

$wp_customize->add_setting(
	'hyd_linkcolor_color',
	array(
		'default' => hyd_customizer_get_default_linkcolor_color(),
		'sanitize_callback' => 'sanitize_hex_color',
	)
);

$wp_customize->add_control(
	new WP_Customize_Color_Control(
		$wp_customize,
		'hyd_linkcolor_color',
		array(
			'description' => __( 'Change the Default Link color', 'hyd' ),
				'label'       => __( 'Main Link Color', 'hyd' ),
				'section'     => 'colors',
				'settings'    => 'hyd_linkcolor_color',
		)
	)
);

$wp_customize->add_setting(
	'hyd_hovercolor_color',
	array(
		'default' => hyd_customizer_get_default_hovercolor_color(),
		'sanitize_callback' => 'sanitize_hex_color',
	)
);

$wp_customize->add_control(
	new WP_Customize_Color_Control(
		$wp_customize,
		'hyd_hovercolor_color',
		array(
			'description' => __( 'Change the Default Hover color', 'hyd' ),
				'label'       => __( 'Main Hover Color', 'hyd' ),
				'section'     => 'colors',
				'settings'    => 'hyd_hovercolor_color',
		)
	)
);

$wp_customize->add_setting(
	'hyd_gridsection_color',
	array(
		'default' => hyd_customizer_get_default_gridsection_color(),
		'sanitize_callback' => 'sanitize_hex_color',
	)
);

$wp_customize->add_control(
	new WP_Customize_Color_Control(
		$wp_customize,
		'hyd_gridsection_color',
		array(
			'description' => __( 'Change the Grid Section and Pink hover colors', 'hyd' ),
				'label'       => __( 'Grid Section Color', 'hyd' ),
				'section'     => 'colors',
				'settings'    => 'hyd_gridsection_color',
		)
	)
);

$wp_customize->add_setting(
	'hyd_gridfont_color',
	array(
		'default' => hyd_customizer_get_default_gridfont_color(),
		'sanitize_callback' => 'sanitize_hex_color',
	)
);

$wp_customize->add_control(
	new WP_Customize_Color_Control(
		$wp_customize,
		'hyd_gridfont_color',
		array(
			'description' => __( 'Change the font color in the grid section', 'hyd' ),
				'label'       => __( 'grid Section Font Color', 'hyd' ),
				'section'     => 'colors',
				'settings'    => 'hyd_gridfont_color',
		)
	)
);

$wp_customize->add_setting(
	'hyd_gridlink_color',
	array(
		'default' => hyd_customizer_get_default_gridlink_color(),
		'sanitize_callback' => 'sanitize_hex_color_color',
	)
);

$wp_customize->add_control(
	new WP_Customize_Color_Control(
		$wp_customize,
		'hyd_gridlink_color',
		array(
			'description' => __( 'Change the grid Section Link Color', 'hyd' ),
				'label'       => __( 'grid Section Link Color', 'hyd' ),
				'section'     => 'colors',
				'settings'    => 'hyd_gridlink_color',
		)
	)
);
$wp_customize->add_setting(
	'hyd_gridhover_color',
	array(
		'default' => hyd_customizer_get_default_gridhover_color(),
		'sanitize_callback' => 'sanitize_hex_color',
	)
);

$wp_customize->add_control(
	new WP_Customize_Color_Control(
		$wp_customize,
		'hyd_gridhover_color',
		array(
			'description' => __( 'Change the grid Section Link Hover Color', 'hyd' ),
				'label'       => __( 'grid Section Link Hover', 'hyd' ),
				'section'     => 'colors',
				'settings'    => 'hyd_gridhover_color',
		)
	)
);
$wp_customize->add_setting(
	'hyd_services_color',
	array(
		'default' => hyd_customizer_get_default_services_color(),
		'sanitize_callback' => 'sanitize_hex_color',
	)
);

$wp_customize->add_control(
	new WP_Customize_Color_Control(
		$wp_customize,
		'hyd_services_color',
		array(
			'description' => __( 'Change the Default Service box color', 'hyd' ),
				'label'       => __( 'Service Box Color', 'hyd' ),
				'section'     => 'colors',
				'settings'    => 'hyd_services_color',
		)
	)
);

$wp_customize->add_setting(
	'hyd_button_color',
	array(
		'default' => hyd_customizer_get_default_button_color(),
		'sanitize_callback' => 'sanitize_hex_color',
	)
);

$wp_customize->add_control(
	new WP_Customize_Color_Control(
		$wp_customize,
		'hyd_button_color',
		array(
			'description' => __( 'Change the Default Button Color', 'hyd' ),
				'label'       => __( 'Button Color', 'hyd' ),
				'section'     => 'colors',
				'settings'    => 'hyd_button_color',
		)
	)
);

$wp_customize->add_setting(
	'hyd_rose_color',
	array(
		'default' => hyd_customizer_get_default_rose_color(),
		'sanitize_callback' => 'sanitize_hex_color',
	)
);

$wp_customize->add_control(
	new WP_Customize_Color_Control(
		$wp_customize,
		'hyd_rose_color',
		array(
			'description' => __( 'Change the Default rose Color', 'hyd' ),
				'label'       => __( 'rose Color', 'hyd' ),
				'section'     => 'colors',
				'settings'    => 'hyd_rose_color',
		)
	)
);

$wp_customize->add_setting(
	'hyd_navy_color',
	array(
		'default' => hyd_customizer_get_default_navy_color(),
		'sanitize_callback' => 'sanitize_hex_color',
	)
);

$wp_customize->add_control(
	new WP_Customize_Color_Control(
		$wp_customize,
		'hyd_navy_color',
		array(
			'description' => __( 'Change the Default navy Color', 'hyd' ),
				'label'       => __( 'navy Color', 'hyd' ),
				'section'     => 'colors',
				'settings'    => 'hyd_navy_color',
		)
	)
);

$wp_customize->add_setting(
	'hyd_sharelinks_color',
	array(
		'default' => hyd_customizer_get_default_sharelinks_color(),
		'sanitize_callback' => 'sanitize_hex_color',
	)
);

$wp_customize->add_control(
	new WP_Customize_Color_Control(
		$wp_customize,
		'hyd_sharelinks_color',
		array(
			'description' => __( 'Change the default Share This color', 'hyd' ),
				'label'       => __( 'Share This Color', 'hyd' ),
				'section'     => 'colors',
				'settings'    => 'hyd_sharelinks_color',
		)
	)
);

}
