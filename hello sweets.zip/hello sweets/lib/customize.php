<?php
/**
 * Customizer additions.
 * @package      Hello Sweets
 */

/**
 * Get default primary color for Customizer.
 *
 * Abstracted here since at least two functions use it.
 *
 * @since 1.0.0
 *
 * @return string Hex color code for primary color.
 */
function sweets_customizer_get_default_primary_color() {
	return '#e84390';
}

/**
 * Get default accent color for Customizer.
 *
 * Abstracted here since at least two functions use it.
 *
 * @since 1.0.0
 *
 * @return string Hex color code for accent color.
 */
function sweets_customizer_get_default_accent_color() {
	return '#f8c6dd';
}

/**
 * Get default highlight color for Customizer.
 *
 * Abstracted here since at least two functions use it.
 *
 * @since 1.0.0
 *
 * @return string Hex color code for highlight color.
 */
function sweets_customizer_get_default_highlight_color() {
	return '#f9f9f9';
}

add_action( 'customize_register', 'sweets_customizer_register' );
/**
 * Register settings and controls with the Customizer.
 *
 * @since 1.0.0
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function sweets_customizer_register() {

	global $wp_customize;

	$wp_customize->add_setting(
		'sweets_primary_color',
		array(
			'default' => sweets_customizer_get_default_primary_color(),
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'sweets_primary_color',
			array(
				'description' => __( 'Changes the default dark pink on links, buttons and search icon.', 'sweets' ),
			    'label'    => __( 'Primary Color', 'sweets' ),
			    'section'  => 'colors',
			    'settings' => 'sweets_primary_color',
			)
		)
	);

	$wp_customize->add_setting(
		'sweets_accent_color',
		array(
			'default' => sweets_customizer_get_default_accent_color(),
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'sweets_accent_color',
			array(
				'description' => __( 'Change the pink color in the footer, navigation icons and accent locations.', 'sweets' ),
			    'label'    => __( 'Accent Color', 'sweets' ),
			    'section'  => 'colors',
			    'settings' => 'sweets_accent_color',
			)
		)
	);

	$wp_customize->add_setting(
		'sweets_highlight_color',
		array(
			'default' => sweets_customizer_get_default_highlight_color(),
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'sweets_highlight_color',
			array(
				'description' => __( 'Change the very pale pink for the footer background and other accent areas. Best to use very pale colors', 'sweets' ),
			    'label'    => __( 'Highlight Color', 'sweets' ),
			    'section'  => 'colors',
			    'settings' => 'sweets_highlight_color',
			)
		)
	);

}

add_action( 'wp_enqueue_scripts', 'sweets_css' );
/**
* Checks the settings for the accent color, highlight color, and header
* If any of these value are set the appropriate CSS is output
*
* @since 1.0.0
*/
function sweets_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';

	$color = get_theme_mod( 'sweets_primary_color', sweets_customizer_get_default_primary_color() );
	$color_accent = get_theme_mod( 'sweets_accent_color', sweets_customizer_get_default_accent_color() );
	$color_highlight = get_theme_mod( 'sweets_highlight_color', sweets_customizer_get_default_highlight_color() );

	$css = '';

	$css .= ( sweets_customizer_get_default_primary_color() !== $color ) ? sprintf( '

	a,
	button,
	input[type="button"],
	input[type="reset"],
	input[type="submit"],
	.button,
	.entry-content .button,
	.rmtext,
a.more-link,
.genesis-nav-menu .search-form input[type="submit"],
.enews-widget input:hover[type="submit"],
a.category-block .overlay,
.overlay .entry-title,
.site-title a,
.site-title a:hover,
.genesis-nav-menu a:hover,
.genesis-nav-menu .current-menu-item > a,
.genesis-nav-menu .sub-menu::after,
.genesis-nav-menu .sub-menu a:hover,
.genesis-nav-menu .menu-item:hover::before,
.home-featured .enews-widget input[type="submit"],
.entry-content a,
.footer-widgets .enews-widget input[type="submit"]  {
		color: %1$s;
	}
.rmtext, a.more-link,
.footer-widgets .simple-social-icons ul li a:hover,
.woocommerce #respond input#submit:hover,
.woocommerce a.button:hover,
.woocommerce button.button,
.woocommerce input.button:hover,
.woocommerce .woocommerce-message::before,
.woocommerce .woocommerce-info::before,
.woocommerce div.product p.price,
.woocommerce div.product span.price,
.woocommerce ul.products li.product .price,
.woocommerce form .form-row .required,
.site-header .genesis-nav-menu .current-menu-item::before {
	 color: %1$s !important;
}

.woocommerce .woocommerce-message,
.woocommerce .woocommerce-info {
	border-top-color: %1$s !important;
}

.genesis-nav-menu .sub-menu::after {
    border-bottom-color: %1$s;
}

	.rmtext,
	a.more-link,
	.footer-widgets .enews-widget input[type="submit"],
	.footer-widgets .enews-widget input[type="submit"]:hover   {
		border: 1px solid %1$s;
	}

	.more-from-category a,
	button:hover,
	input:hover[type="button"],
	input:hover[type="reset"],
	input:hover[type="submit"],
	.button:hover,
	.entry-content .button:hover,
	.rmtext:hover,
	a.more-link:hover,
	.content .share-count,
	.woocommerce span.onsale,
	.archive-pagination li a:hover,
	.archive-pagination li.active a,
	.footer-widgets .enews-widget input[type="submit"]:hover,
	.enews-widget input[type="submit"]   {
	  background-color: %1$s;
	}

	.woocommerce #respond input#submit,
	.woocommerce a.button,
	.woocommerce button.button:hover,
	.woocommerce input.button,
.woocommerce span.onsale {
	  background-color: %1$s !important;
	}

	button,
	input[type="button"],
	input[type="reset"],
	input[type="submit"],
	.button,
	.entry-content .button,
	button:hover,
	input:hover[type="button"],
	input:hover[type="reset"],
	input:hover[type="submit"],
	.button:hover,
	.entry-content .button:hover,
	.enews-widget input:hover[type="submit"]  {
			border: 3px solid %1$s;
	}

	.archive-pagination li a:hover,
	.archive-pagination li.active a {
			border: %1$s;
	}

	.woocommerce button.button {
		border: 1px solid %1$s !important;
	}

		', $color ) : '';

	$css .= ( sweets_customizer_get_default_accent_color() !== $color_accent ) ? sprintf( '


		.genesis-nav-menu .menu-item::before,
		.entry-content a:hover,
		.footer-widgets .fa,
		a:hover {
			color: %1$s;
		}

.footer-widgets .simple-social-icons ul li a {
	color: %1$s !important;
}

		.home-calltoaction {
			border-top: 2px solid %1$s;
			border-bottom: 2px solid %1$s;
		}

		.footer-widgets {
			border-top: 3px solid %1$s;
		}

		.footer-widgets:before {
			  border-top: 14px solid %1$s;
		}

		', $color_accent ) : '';

	$css .= ( sweets_customizer_get_default_highlight_color() !== $color_highlight ) ? sprintf( '

		.author-box,
		.share-after,
		.category-description, .archive-description,
		.genesis-nav-menu .sub-menu,
		.home-top-right .textwidget,
		.home-calltoaction,
		.home-featured .enews-widget,
		.pricing-table .one-third:hover,
		.sidebar .enews-widget,
		.footer-widgets {
			background-color: %1$s;
		}

		.footer-widgets .simple-social-icons ul li a,
		.footer-widgets .simple-social-icons ul li a:hover {
			background-color: %1$s !important;
		}

		', $color_highlight ) : '';


	if ( sweets_customizer_get_default_accent_color() !== $color_accent || sweets_customizer_get_default_highlight_color() !== $color_highlight ) {
		$css .= '
		}
		';
	}

	if( $css ){
		wp_add_inline_style( $handle, $css );
	}

}
