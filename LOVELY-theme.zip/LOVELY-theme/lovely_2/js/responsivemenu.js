( function( window, $, undefined ) {
	'use strict';

	$( '.menu-primary' ).before( '<button class="menu-toggle" role="button" aria-pressed="false"></button>' ); // Add toggles to menus
	$( '.menu-primary .sub-menu' ).before( '<button class="sub-menu-toggle" role="button" aria-pressed="false"></button>' ); // Add toggles to sub menus

	//ini buat top menu
	$( '.sticky-widget .menu' ).before( '<button class="menu-toggletop" role="button" aria-pressed="false"></button>' ); // Add toggles to menus
	$( '.sticky-widget .menu .sub-menu' ).before( '<button class="sub-menu-toggletop" role="button" aria-pressed="false"></button>' ); // Add toggles to sub menus

	
	// Show/hide the navigation
	$( '.menu-toggle, .sub-menu-toggle' ).on( 'click', function() {
		var $this = $( this );
		$this.attr( 'aria-pressed', function( index, value ) {
			return 'false' === value ? 'true' : 'false';
		});

		$this.toggleClass( 'activated' );
		$this.next( '.menu-primary, .sub-menu' ).slideToggle( 'fast' );

	});
	
	//top menu
	$( '.menu-toggletop, .sub-menu-toggletop' ).on( 'click', function() {
		var $this = $( this );
		$this.attr( 'aria-pressed', function( index, value ) {
			return 'false' === value ? 'true' : 'false';
		});

		$this.toggleClass( 'activated' );
		$this.next( '.sticky-widget .menu, .sticky-widget ul.menu .sub-menu' ).slideToggle( 'fast' );

	});

})( this, jQuery );