<?php
/*========================== CUSTOMIZER ========================== */
function skyandstars_customizer( $wp_customize ) {
	// ADD SECTION
		//Layout
		$wp_customize->add_section( 'skyandstars_home_layout', array(
			'title' => __( 'Homepage Layout', 'skyandstars' ),
			'priority' => 70,
		) );
		
		//Footer
		$wp_customize->add_section( 'ss_copyright', array(
		'title' => __( 'Footer Credit', 'skyandstars' ),
		'priority' => 70,
		) );
	
	// RADIO BUTTON SANITIZE
        function theme_slug_sanitize_radio( $input, $setting ){
         
            //input must be a slug: lowercase alphanumeric characters, dashes and underscores are allowed only
            $input = sanitize_key($input);
 
            //get the list of possible radio box options 
            $choices = $setting->manager->get_control( $setting->id )->choices;
                             
            //return input if valid or return default option
            return ( array_key_exists( $input, $choices ) ? $input : $setting->default );                
             
        }
		
	// ADD SETTING
		//Layout	
		$wp_customize->add_setting( 'sky_home_layout' , array(
			'default' => 'skyfull-layout',
			'transport' => 'refresh',
			'capability' => 'manage_options',
			'sanitize_callback' => 'theme_slug_sanitize_radio',
			'priority' => 4,     
		) );
	
		//Footer	
		$wp_customize->add_setting( 'sky_copyright' , array(
			'default' => '&copy; 2017 Blog Name.  All Rights Reserved.',
			'transport' => 'refresh',
			'priority' => 4,     
		) );
		
	// CONTROL
		//Layout	
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'sky_home_layout', array(
			'type' => 'radio',
			'label' => 'Home Layout',
			'section' => 'skyandstars_home_layout',
			'settings' => 'sky_home_layout',
			'choices'        => array(
							'default'   => 'Default',
							'grid'  => 'First full width, then grid'
						)
		) ) );
	
		//Footer	
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'sky_copyright', array(
			'type' => 'text',
			'label' => 'Footer Copyright',
			'section' => 'ss_copyright',
			'settings' => 'sky_copyright'
		) ) );

	
}
add_action( 'customize_register', 'skyandstars_customizer' );