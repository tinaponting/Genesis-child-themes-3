<?php
/**
 * Adds front-end inline styles for the custom Gutenberg color palette.
 * @package Kylee More
 */

add_action( 'wp_enqueue_scripts', 'kylee_custom_gutenberg_css' );
/**
 * Output front-end inline styles for `editor-color-palette` colors.
 *
 * These colors can be changed in the Customizer, so CSS is set dynamically.
 *
 * @since 1.2.0
 */
function kylee_custom_gutenberg_css() {

	$accent_color   = get_theme_mod( 'kylee_accent_color', kylee_customizer_get_default_accent_color() );

	$css = <<<CSS
.has-accent-color {
	color: $accent_color !important;
}

.has-accent-background-color {
	background-color: $accent_color !important;
	border-color: $accent_color !important;
}


CSS;

	$handle = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';
	wp_add_inline_style( $handle, $css );

}

add_action( 'enqueue_block_editor_assets', 'kylee_custom_gutenberg_admin_css' );
/**
 * Output back-end inline styles for link state.
 *
 * Causes the custom color to apply to elements with the Gutenberg editor.
 * The custom color is set in the Customizer in the Colors panel.
 *
 * @since 1.2.0
 */
function kylee_custom_gutenberg_admin_css() {

	$accent_color = get_theme_mod( 'kylee_accent_color', kylee_customizer_get_default_accent_color() );


	$css = <<<CSS

.product-title,
.product-price {
	color: $accent_color;
}


CSS;

	wp_add_inline_style( 'Kylee-more-gutenberg-fonts', $css );

}
