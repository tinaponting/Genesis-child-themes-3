<?php
/**
 * Her Exclusive.
 * @package Her Exclusive
 */

add_action( 'wp_enqueue_scripts', 'her_css' );
/**
 * Checks the settings for the link color color, accent color, and header.
 * If any of these value are set the appropriate CSS is output.
 *
 * @since 1.0.0
 */
function her_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';

	$color_title = get_theme_mod( 'her_title_color', her_customizer_get_default_title_color() );
	$color_description = get_theme_mod( 'her_description_color', her_customizer_get_default_description_color() );
	$color_accent = get_theme_mod( 'her_accent_color', her_customizer_get_default_accent_color() );
	$color_accent_hover = get_theme_mod( 'her_accent_hover_color', her_customizer_get_default_accent_hover_color() );
	$color_headings = get_theme_mod( 'her_headings_color', her_customizer_get_default_headings_color() );
	$color_body = get_theme_mod( 'her_body_color', her_customizer_get_default_body_color() );
	$color_button = get_theme_mod( 'her_button_color', her_customizer_get_default_button_color() );
	$color_button_font = get_theme_mod( 'her_button_font_color', her_customizer_get_default_button_font_color() );
	$color_double_border = get_theme_mod( 'her_double_border_color', her_customizer_get_default_double_border_color() );
	$color_textbox2 = get_theme_mod( 'her_textbox2_color', her_customizer_get_default_textbox2_color() );
	$color_textbox2_font = get_theme_mod( 'her_textbox2_font_color', her_customizer_get_default_textbox2_font_color() );
	$color_textbox3 = get_theme_mod( 'her_textbox3_color', her_customizer_get_default_textbox3_color() );
	$color_textbox3_font = get_theme_mod( 'her_textbox3_font_color', her_customizer_get_default_textbox3_font_color() );
	$color_textbox4 = get_theme_mod( 'her_textbox4_color', her_customizer_get_default_textbox4_color() );
	$color_textbox4_font = get_theme_mod( 'her_textbox4_font_color', her_customizer_get_default_textbox4_font_color() );
	$color_front_page_3 = get_theme_mod( 'her_front_page_3_color', her_customizer_get_default_front_page_3_color() );
	$color_front_page_3_font = get_theme_mod( 'her_front_page_3_font_color', her_customizer_get_default_front_page_3_font_color() );
	$color_widget_above_footer = get_theme_mod( 'her_widget_above_footer_color', her_customizer_get_default_widget_above_footer_color() );
	$color_widget_above_footer_font = get_theme_mod( 'her_widget_above_footer_font_color', her_customizer_get_default_widget_above_footer_font_color() );

	
	$opts = apply_filters( 'her_images', array( '1', '5' ) );

	$settings = array();

	foreach( $opts as $opt ) {
		$settings[$opt]['image'] = preg_replace( '/^https?:/', '', get_option( $opt .'-her-image', sprintf( '%s/images/bg-%s.jpg', get_stylesheet_directory_uri(), $opt ) ) );
	}

	$css = '';

	foreach ( $settings as $section => $value ) {

		$background = $value['image'] ? sprintf( 'background-image: url(%s);', $value['image'] ) : '';

		if ( is_front_page() ) {
			$css .= ( ! empty( $section ) && ! empty( $background ) ) ? sprintf( '.front-page-%s { %s }', $section, $background ) : '';
		}

	}

	
	
	$css .= ( her_customizer_get_default_title_color() !== $color_title ) ? sprintf( '
	
			.site-title a,
			.site-title a:hover,
			.site-title a:focus,
			.instagram-page .site-title,
			.instagram-page .site-title a,
			.instagram-page .site-title a:hover {
				color: %1$s;
			}
	
	', $color_title ) : '';
	
	$css .= ( her_customizer_get_default_description_color() !== $color_description ) ? sprintf( '
	
			.site-description {
				color: %1$s;
			}
	
	', $color_description ) : '';
	
	$css .= ( her_customizer_get_default_accent_color() !== $color_accent ) ? sprintf( '

			a,
			.entry-title a:hover,
			.entry-title a:focus,
			.footer-widgets .featured-content .entry-meta a:hover,
			.footer-widgets .featured-content .entry-meta a:focus,
			.sidebar .featured-content .entry-meta a:hover,
			.sidebar .featured-content .entry-meta a:focus,
			.genesis-nav-menu a:hover,
			.genesis-nav-menu a:focus,
			.site-footer .genesis-nav-menu a:hover,
			.site-footer .genesis-nav-menu a:focus,
			.widget-above-footer a:hover,
			.footer-widgets-1 a:hover,
			.footer-widgets-2 a:hover,
			.footer-widgets-3 a:hover,
			.site-footer a:hover,
			.site-footer a:focus,
			.to-top:hover {
				color: %1$s;
			}
		
			@media only screen and (max-width: 800px) {
		
				.menu-toggle:focus,
				.menu-toggle:hover,
				.sub-menu-toggle:focus,
				.sub-menu-toggle:hover,
				.genesis-responsive-menu .genesis-nav-menu a:focus,
				.genesis-responsive-menu .genesis-nav-menu a:hover,
				.genesis-responsive-menu .genesis-nav-menu a:focus {
					color: %1$s;
				}
		
			}

		', $color_accent ) : '';
	
	$css .= ( her_customizer_get_default_accent_hover_color() !== $color_accent_hover ) ? sprintf( '

			a:hover,
			a:focus,
			.to-top {
				color: %1$s;
			}
		

		', $color_accent_hover ) : '';
	
	$css .= ( her_customizer_get_default_headings_color() !== $color_headings ) ? sprintf( '
	
			h1, h2, h3, h4, h5, h6,
			.front-page-3 h3,
			.genesis-nav-menu a,
			.entry-title a,
			.pricing-table h4,
			.instagram-page a {
				color: %1$s;
			}
	
	', $color_headings ) : '';
	
	$css .= ( her_customizer_get_default_body_color() !== $color_body ) ? sprintf( '
	
			body,
			.footer-widgets-1 a, 
			.footer-widgets-2 a, 
			.footer-widgets-3 a,
			.widget-above-footer a,
			.site-footer a {
				color: %1$s;
			}
	
	', $color_body ) : '';
	
	$css .= ( her_customizer_get_default_button_color() !== $color_button ) ? sprintf( '

			button,
			input[type="button"],
			input[type="reset"],
			input[type="select"],
			input[type="submit"],
			.button,
			a.more-link,
			.enews-widget input[type="submit"],
			.archive-pagination li a,
			.footer-widgets .button,
			.filter-button-group button,
			.pricing-table a.button,
			.category-index.widget-area .more-from-category a {
				background-color: %1$s;
				border-color: %1$s;
			}

			#sb_instagram #sbi_load .sbi_load_btn, 
			#sb_instagram .sbi_follow_btn a {
				background-color: %1$s !important;
				border-color: %1$s !important;
			}

		', $color_button ) : '';

	$css .= ( her_customizer_get_default_button_font_color() !== $color_button_font ) ? sprintf( '

			button,
			input[type="button"],
			input[type="reset"],
			input[type="select"],
			input[type="submit"],
			.button,
			a.more-link,
			.enews-widget input[type="submit"],
			.archive-pagination li a,
			.footer-widgets .button,
			.filter-button-group button,
			.widget-above-footer a.button,
			.pricing-table a.button,
			.category-index.widget-area .more-from-category a {
				color: %1$s;
			}
			
			#sb_instagram #sbi_load .sbi_load_btn, 
			#sb_instagram .sbi_follow_btn a {
				color: %1$s !important;
			}

		', $color_button_font ) : '';
	
	$css .= ( her_customizer_get_default_double_border_color() !== $color_double_border ) ? sprintf( '

			.genesis-nav-menu,
			.sidebar .widget,
			.portfolio-image a,
			.category-index .widget-title::after {
				border-color: %1$s;
			}
			
			@media only screen and (max-width: 800px) {
			
				.menu-toggle {
					border-color: %1$s;
				}
			
			}

		', $color_double_border ) : '';
	
	$css .= ( her_customizer_get_default_textbox2_color() !== $color_textbox2 ) ? sprintf( '
	
			.textbox2 {
    			background: %1$s;
			}

		', $color_textbox2 ) : '';
	
	$css .= ( her_customizer_get_default_textbox2_font_color() !== $color_textbox2_font ) ? sprintf( '
	
			.textbox2,
			.textbox2 h2 {
    			color: %1$s;
			}
			
		', $color_textbox2_font ) : '';
	
	$css .= ( her_customizer_get_default_textbox3_color() !== $color_textbox3 ) ? sprintf( '
	
			.textbox3 {
    			background: %1$s;
			}

		', $color_textbox3 ) : '';
	
	$css .= ( her_customizer_get_default_textbox3_font_color() !== $color_textbox3_font ) ? sprintf( '
	
			.textbox3,
			.textbox3 h2 {
    			color: %1$s;
			}
			
		', $color_textbox3_font ) : '';
	
	$css .= ( her_customizer_get_default_textbox4_color() !== $color_textbox4 ) ? sprintf( '
	
			.textbox4 {
    			background: %1$s;
			}

		', $color_textbox4 ) : '';
	
	$css .= ( her_customizer_get_default_textbox4_font_color() !== $color_textbox4_font ) ? sprintf( '
	
			.textbox4,
			.textbox4 h2 {
    			color: %1$s;
			}
			
		', $color_textbox4_font ) : '';
	
	$css .= ( her_customizer_get_default_front_page_3_color() !== $color_front_page_3 ) ? sprintf( '

			.front-page-3 {
				background-color: %1$s;
			}

		', $color_front_page_3 ) : '';
	
	$css .= ( her_customizer_get_default_front_page_3_font_color() !== $color_front_page_3_font ) ? sprintf( '

			.front-page-3,
			.front-page-3 h3 {
				color: %1$s;
			}

		', $color_front_page_3_font ) : '';
	
	$css .= ( her_customizer_get_default_widget_above_footer_color() !== $color_widget_above_footer ) ? sprintf( '

			.widget-above-footer {
				background-color: %1$s;
			}

		', $color_widget_above_footer ) : '';
	
	$css .= ( her_customizer_get_default_widget_above_footer_font_color() !== $color_widget_above_footer_font ) ? sprintf( '

			.widget-above-footer,
			.widget-above-footer h2 {
				color: %1$s;
			}

		', $color_widget_above_footer_font ) : '';
	
	if ( $css ) {
		wp_add_inline_style( $handle, $css );
	}

}
