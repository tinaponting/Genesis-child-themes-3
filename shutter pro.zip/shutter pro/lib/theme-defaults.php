<?php
 
/**
 * Style And Wit Theme Defaults
 *
 * @package      Style And Wit
 * @link         http://wackyjacquisdesigns.com/product-category/themes/
 * @author       Jacqui Layne // Wacky Jacquis Designs
 * @license      GPL-2.0+
 */



//* Fresh Theme Setting Defaults
add_filter( 'genesis_theme_settings_defaults', 'fresh_theme_defaults' );
function fresh_theme_defaults( $defaults ) {

	$defaults['blog_cat_num']              = 4;
	$defaults['content_archive']           = 'full';
	$defaults['content_archive_limit']     = 300;
	$defaults['content_archive_thumbnail'] = 1;
	$defaults['image_alignment']           = '';
	$defaults['image_size']                = 'featured';
	$defaults['posts_nav']                 = 'numeric';
	$defaults['site_layout']               = 'full-width-content';

	return $defaults;

}

//* Simple Social Icon Defaults
add_filter( 'simple_social_default_styles', 'fresh_social_default_styles' );
function fresh_social_default_styles( $defaults ) {

	$args = array(
		'alignment'              => 'aligncenter',
		'background_color'       => '#fff',
		'background_color_hover' => '#fff',
		'border_radius'          => 0,
		'border_color'           => '#fff',
		'border_color_hover'     => '#fff',
		'border_width'           => 1,
		'icon_color'             => '#5d5d5d',
		'icon_color_hover'       => '#333333',
		'size'                   => 60,
		'new_window'             => 1,
		);
		
	$args = wp_parse_args( $args, $defaults );
	
	return $args;
	
}
