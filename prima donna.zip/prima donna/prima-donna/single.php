<?php
/**
 * This file adds the Custom BLog Post tempalte to the Prima Donna Theme.
 * @package      Prima Donna
 */
 
//* This file handles single entries, but only exists for the sake of child theme forward compatibility.

// Options for hiding post sidebar globally
$disablesidebar = get_theme_mod( 'primadonna_post_sidebar_setting', 'false' );
if ( $disablesidebar === 'true' ) {
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
}

genesis();
