<?php
// Force full width content
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
add_filter( 'body_class', 'sweets_body_class' );
/**
 * Adds a css class to the body element
 *
 * @param  array $classes the current body classes
 * @return array $classes modified classes
 */
function sweets_body_class( $classes ) {
	$classes[] = 'archive-portfolio';
	return $classes;
}

//* Add the portfolio blurb section
add_action( 'genesis_before_content', 'sweets_portfolioblurb_before_content' );
function sweets_portfolioblurb_before_content() {

	genesis_widget_area( 'portfolioblurb', array(
	'before' => '<div class="portfolioblurb">',
	'after' => '</div>',
	) );

}

// Force full width content
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

// Add custom body class to the head
add_filter( 'body_class', 'sweets_body_class_masonry' );
function sweets_body_class_masonry( $classes ) {
	$classes[] = 'masonry-page';
	return $classes;
}

// Load and initialize Masonry
add_action( 'wp_enqueue_scripts', 'sweets_enqueue_masonry' );
function sweets_enqueue_masonry() {
	wp_enqueue_script( 'masonry-init', get_stylesheet_directory_uri() . '/js/masonry-init.js' , array( 'jquery', 'masonry' ), '1.0', true );
}

// Reposition breadcrumbs
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );
add_action( 'genesis_before_content', 'genesis_do_breadcrumbs' );

// Remove entry header
remove_action( 'genesis_entry_header', 'genesis_entry_header_markup_open', 5 );
remove_action( 'genesis_entry_header', 'genesis_do_post_title' );
remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );
remove_action( 'genesis_entry_header', 'genesis_entry_header_markup_close', 15 );

// Remove the post image
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );

// Remove the post content
remove_action( 'genesis_entry_content', 'genesis_do_post_content' );

// Add custom content
add_action( 'genesis_entry_content', 'sweets_do_post_content' );
function sweets_do_post_content() {
	// get the raw title
	$title = apply_filters( 'genesis_post_title_text', get_the_title() ); ?>

	<a href="<?php echo get_permalink(); ?>" class="category-block">
		<!-- Featured image -->
		<?php
			if ( $image = genesis_get_image( 'format=url&size=entry-image' ) ) {
			printf( '<img src="%s" alt="%s" />', $image, the_title_attribute( 'echo=0' ) );
		}
		?>

		<!-- Title and Excerpt Overlay -->
		<div class="overlay">
			<?php
				echo '<h1 class="entry-title">' . $title . '</h1>';
				echo '<div class="excerpt">' . get_the_excerpt() . '</div>';
				echo '<p class="more-link">More &#8230;</p>';
			?>
		</div>
	</a>
<?php }

// Remove entry footer
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

// Remove post content navigation (for multi-page posts)
remove_action( 'genesis_entry_content', 'genesis_do_post_content_nav', 12 );

// Add grid sizer and gutter sizer divs for responsive masonry
add_action( 'genesis_loop', 'sweets_add_masonry_grid_sizer', 7 );
function sweets_add_masonry_grid_sizer() {
	echo '<div class="grid-sizer"></div><div class="gutter-sizer"></div>';
}

// Modify the length of post excerpts
add_filter( 'excerpt_length', 'sp_excerpt_length' );
function sp_excerpt_length( $length ) {
	return 20; // pull first 20 words
}

// Replace the normal "[...]"" with an empty string
function new_excerpt_more( $more ) {
	return '';
}
add_filter( 'excerpt_more', 'new_excerpt_more' );

// Reposition Archive Pagination
// Moves .archive-pagination from under main.content to adjacent to it.
remove_action( 'genesis_after_endwhile', 'genesis_posts_nav' );
add_action( 'genesis_after_content', 'genesis_posts_nav' );

genesis();
