<?php
/**
 * Her Exclusive.
 * @package Her Exclusive
 */

add_filter( 'genesis_theme_settings_defaults', 'her_theme_defaults' );
/**
 * Updates theme settings on reset.
 *
 * @since 1.0.0
 */
function her_theme_defaults( $defaults ) {

	$defaults['blog_cat_num']              = 4;
	$defaults['content_archive']           = 'full';
	$defaults['content_archive_limit']     = 300;
	$defaults['content_archive_thumbnail'] = 1;
	$defaults['image_size']                = 'vertical-image';
	$defaults['image_alignment']           = 'alignleft';
	$defaults['posts_nav']                 = 'numeric';
	$defaults['site_layout']               = 'content-sidebar';

	return $defaults;

}

add_action( 'after_switch_theme', 'her_theme_setting_defaults' );
/**
 * Updates theme settings on activation.
 *
 * @since 1.0.0
 */
function her_theme_setting_defaults() {

	if ( function_exists( 'genesis_update_settings' ) ) {

		genesis_update_settings( array(
			'blog_cat_num'              => 4,
			'content_archive'           => 'full',
			'content_archive_limit'     => 300,
			'content_archive_thumbnail' => 1,
			'image_size'                => 'vertical-image',
			'image_alignment'           => 'alignleft',
			'posts_nav'                 => 'numeric',
			'site_layout'               => 'content-sidebar',
		) );

	} 

	update_option( 'posts_per_page', 9 );

}

add_filter( 'simple_social_default_styles', 'her_social_default_styles' );
/**
 * Updates Simple Social Icon settings on activation.
 *
 * @since 1.0.0
 */
function her_social_default_styles( $defaults ) {

	$args = array(
		'alignment'              => 'aligncenter',
		'background_color'       => '#e7d4c6',
		'background_color_hover' => '#ffffff',
		'border_color'           => '#e7d4c6',
		'border_color_hover'     => '#e7d4c6',
		'border_radius'          => 0,
		'border_width'           => 2,
		'icon_color'             => '#222222',
		'icon_color_hover'       => '#222222',
		'size'                   => 32,
		);

	$args = wp_parse_args( $args, $defaults );

	return $args;

}
