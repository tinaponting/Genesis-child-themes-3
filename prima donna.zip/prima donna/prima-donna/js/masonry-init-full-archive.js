jQuery(function( $ ){
$( ".masonry-posts-full-archive .post +.post" ).wrapAll( "<div class='masonry-wrap' />");
});

// Masonry layout function
jQuery(window).load(function() {	

	"use strict";
        
      $('.masonry-wrap').masonry({
  // options
})
});
