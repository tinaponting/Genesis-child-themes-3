<?php

/**
* Template Name: Landing
* Description: Template used for the landing page
*/

//* Add landing page body class to the head.
add_filter( 'body_class', 'chef_pro_add_body_class' );
function chef_pro_add_body_class( $classes ) {

	$classes[] = 'landing-page';

	return $classes;

}

//* Remove Skip Links.
remove_action ( 'genesis_before_header', 'genesis_skip_links', 5 );

//* Dequeue Skip Links Script.
add_action( 'wp_enqueue_scripts', 'chef_pro_dequeue_skip_links' );
function chef_pro_dequeue_skip_links() {

	wp_dequeue_script( 'skip-links' );

}

//* Remove the top bar.
remove_action( 'genesis_before_header', 'add_top_bar' );

//* Remove site header elements.
remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_header', 'genesis_do_header' );
remove_action( 'genesis_header', 'genesis_header_markup_close', 15 );

//* Remove navigation.
remove_theme_support( 'genesis-menus' );

//* Remove breadcrumbs.
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );

//* Remove the before footer widgets area.
remove_action( 'genesis_before_footer', 'chef_pro_before_footer_widgets', 1 );

//* Remove footer widgets.
remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );

//* Remove site footer elements.
remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );

//* Remove the after footer  widgets area.
remove_action( 'genesis_before_footer', 'chef_pro_after_footer_widgets', 15 );

//* Run the Genesis loop
genesis();
