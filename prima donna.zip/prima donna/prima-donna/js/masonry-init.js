// Masonry layout function
jQuery(window).load(function() {	

	"use strict";
        
      $('.content').masonry({
  // options
  itemSelector: '.entry',
  columnWidth: '.entry'
})
});

