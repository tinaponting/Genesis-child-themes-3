<?php

/**
* Template Name: Landing Page
*/

/* Cabecera */
remove_action( 'genesis_before', 'hd_menu_privado' );
remove_action( 'genesis_site_title', 'hd_logo' );
remove_action( 'genesis_after_header', 'genesis_do_nav' );
remove_action( 'genesis_entry_header', 'genesis_entry_header_markup_open', 5 );
remove_action( 'genesis_entry_header', 'genesis_entry_header_markup_close', 15 );
remove_action('genesis_entry_header', 'genesis_do_post_title');

/* Footer */
remove_action('genesis_before_footer', 'hd_sidebar_extra_pie', 1);
remove_theme_support( 'genesis-footer-widgets', $columnas_pie );

genesis();