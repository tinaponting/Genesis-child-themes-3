<?php
//* Add Below Header Widget Area to Homepage
add_action( 'genesis_before_content_sidebar_wrap', 'below_header'  ); 
function below_header() {
  if( is_home()) {
    genesis_widget_area( 'below-header', array(
		'before' => '<div class="below-header widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );
}
}

add_action( 'genesis_meta', 'meringue_custom_home_loop' );
 
function meringue_custom_home_loop() {
if ( is_active_sidebar( 'home-top' ) || is_active_sidebar( 'home-middle' ) || is_active_sidebar( 'home-bottom' )  ) {
 remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_loop', 'home_top' );
add_action( 'genesis_loop', 'home_middle' );
add_action( 'genesis_loop', 'home_bottom' );
}
}

function home_top() {
echo '<div class="home-top"><div class="wrap">';
genesis_widget_area( 'home-top', array(
'before' => '<div class="home-top">',
'after' => '</div>',
) );
echo '</div></div>';
}

function home_middle() {
echo '<div class="home-middle"><div class="wrap">';
genesis_widget_area( 'home-middle', array(
'before' => '<div class="home-middle">',
'after' => '</div>',
) );
echo '</div></div>';
}

function home_bottom() {
echo '<div class="home-bottom"><div class="wrap">';
genesis_widget_area( 'home-bottom', array(
'before' => '<div class="home-bottom">',
'after' => '</div>',
) );
echo '</div></div>';
}

function custom_trim_my_title( $title ) {
	if ( strlen( $title ) >= 50 && ! is_singular() ) {
		$title = substr( $title, 0, 50 ) . '...';
		return $title;
	}
	return $title;
}
add_filter( 'the_title', 'custom_trim_my_title' );


genesis();