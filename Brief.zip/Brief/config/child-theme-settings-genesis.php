<?php
/**
 * Brief settings specific to Genesis.
 * @package Brief
 */

return array(
	'blog_cat_num'              => 6,
	'breadcrumb_home'           => 0,
	'breadcrumb_front_page'     => 0,
	'breadcrumb_posts_page'     => 0,
	'breadcrumb_single'         => 0,
	'breadcrumb_page'           => 0,
	'breadcrumb_archive'        => 0,
	'breadcrumb_404'            => 0,
	'breadcrumb_attachment'     => 0,
	'content_archive'           => 'excerpts',
	'content_archive_limit'     => 0,
	'content_archive_thumbnail' => 0,
	'image_size'                => 'large',
	'image_alignment'           => 'none',
	'posts_nav'                 => 'numeric',
	'site_layout'               => 'full-width-content',
);
