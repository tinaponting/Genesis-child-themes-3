<?php
/**
 * Kylee More.
 * @package      Kylee More
 */


//* Add archive body class to the head
add_filter( 'body_class', 'archive_body_class' );
function archive_body_class( $classes ) {
   $classes[] = 'kylee-archive';
   return $classes;
}

// Force full width content.
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

//* Remove the post info function
remove_action( 'genesis_entry_header', 'genesis_post_info', 9 );
			
//* Reposition Featured Images
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
add_action( 'genesis_entry_header', 'genesis_do_post_image', 5 );
			
//* Remove the post content
remove_action( 'genesis_entry_content', 'genesis_do_post_content' );
			
//* Remove entry meta
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

genesis();