<?php
/**
* @package      Stella & Co.
*/
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Setup Theme
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );

//* Set Localization (do not remove)
load_child_theme_textdomain( 'genesis-sample', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/languages', 'genesis-sample' ) );

//* Add Image upload and Color select to WordPress Theme Customizer
require_once( get_stylesheet_directory() . '/lib/customize.php' );

//* Include Customizer CSS
include_once( get_stylesheet_directory() . '/lib/output.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Stella & Co.' );
define( 'CHILD_THEME_URL', 'https://exempel.se' );
define( 'CHILD_THEME_VERSION', '2.2.4' );

//* Enqueue Scripts and Styles
add_action( 'wp_enqueue_scripts', 'genesis_sample_enqueue_scripts_styles' );
function genesis_sample_enqueue_scripts_styles() {

	wp_enqueue_style( 'google-font-lato', '//fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i', array(), CHILD_THEME_VERSION );

	wp_enqueue_style( 'google-font-merriweather', '//fonts.googleapis.com/css?family=Merriweather:300,300i,400,400i,700,700i,900,900i', array(), CHILD_THEME_VERSION );

	wp_enqueue_style( 'google-font-trirong', '//fonts.googleapis.com/css?family=Trirong:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i', array(), CHILD_THEME_VERSION );

	wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css' );

	wp_enqueue_style( 'dashicons' );

	wp_enqueue_script( 'genesis-sample-responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0', true );

	$output = array(
		'mainMenu' => __( 'Menu', 'genesis-sample' ),
		'subMenu'  => __( 'Menu', 'genesis-sample' ),
	);

	wp_localize_script( 'genesis-sample-responsive-menu', 'genesisSampleL10n', $output );

}

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'caption', 'comment-form', 'comment-list', 'gallery', 'search-form' ) );

//* Add Accessibility support
add_theme_support( 'genesis-accessibility', array( '404-page', 'drop-down-menu', 'headings', 'rems', 'search-form', 'skip-links' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'width'           => 600,
	'height'          => 160,
	'header-selector' => '.site-title a',
	'header-text'     => false,
	'flex-height'     => true,
) );

//* Add support for after entry widget
add_theme_support( 'genesis-after-entry-widget-area' );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Unregister secondary sidebar
unregister_sidebar( 'sidebar-alt' );

//* Remove the header right widget area
unregister_sidebar( 'header-right' );

//* Remove content/sidebar/sidebar layout
genesis_unregister_layout( 'content-sidebar-sidebar' );

//* Remove sidebar/sidebar/content layout
genesis_unregister_layout( 'sidebar-sidebar-content' );
 
//* Remove sidebar/content/sidebar layout
genesis_unregister_layout( 'sidebar-content-sidebar' );

//* Reposition the primary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before_header', 'genesis_do_nav' );

//* Add the recent post slider to the home page
genesis_register_sidebar( array(
	'id'			=> 'home-slider',
	'name'			=> __( 'Home Slider', 'stella' ),
	'description'	=> __( 'This is the home page slider area.', 'stella' ),
) );

add_action( 'genesis_after_header', 'stella_home_slider' );

function stella_home_slider() {
	if ( is_home() || is_front_page() ) {
		genesis_widget_area( 'home-slider', array(
			'before' => '<div class="home-slider"><div class="wrap">',
			'after' => '</div></div>',
		) );
	}
}

//* Add the CTAs to the home page
genesis_register_sidebar( array(
	'id'			=> 'home-ctas',
	'name'			=> __( 'Home CTAs', 'stella' ),
	'description'	=> __( 'This is the home page CTAs area.', 'stella' ),
) );

add_action( 'genesis_after_header', 'stella_home_ctas' );

function stella_home_ctas() {
	if ( is_home() || is_front_page() ) {
		genesis_widget_area( 'home-ctas', array(
			'before' => '<div class="home-ctas"><div class="wrap">',
			'after' => '</div></div>',
		) );
	}
}

//* Customize the entry meta in the entry header (requires HTML5 theme support)
add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
	$post_info = '[post_date] | [post_categories before=""]';
	return $post_info;
}

//* Remove the entry meta in the entry footer (requires HTML5 theme support)
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

//* Modify the WordPress read more link
add_filter( 'the_content_more_link', 'sp_read_more_link' );
add_filter( 'get_the_content_more_link', 'sp_read_more_link' );
add_filter('excerpt_more', 'sp_read_more_link');
function sp_read_more_link() {
	return '... <p class="more-paragraph"><a class="more-link" href="' . get_permalink() . '">VIEW <em>the</em> POST</a></p>';
}

//* Customize search form input box text
add_filter( 'genesis_search_text', 'sp_search_text' );
function sp_search_text( $text ) {
	return esc_attr( 'Search...' );
}

//* Register category page widget
genesis_register_sidebar( array(
	'id'		=> 'category-index',
	'name'		=> __( 'Category Index', 'stella' ),
	'description'	=> __( 'This is the widget area for the category page.', 'stella' ),
) );

//* Add Excerpt Support to Pages
add_post_type_support('page', 'excerpt');

//* Adds custom excerpt field for the shop the post
add_post_type_support('post', 'excerpt');

//* Add 'Shop the Post' to home page
add_action ( 'genesis_entry_footer', 'scarlett_show_page_excerpt_home' );
function scarlett_show_page_excerpt_home() {
	if ( is_home() || is_front_page() ) {
	    $post = get_post( get_the_ID() );
	    $the_excerpt = $post->post_excerpt;
	    if ( is_page() || empty( $the_excerpt ) )
	        return;
	    echo "<div class='post-affiliate'>";
	    echo $the_excerpt;
	    echo "</div>";
	}
}

//* Add 'Shop the Post' to post page
add_action ( 'genesis_entry_footer', 'scarlett_show_page_excerpt_post' );
function scarlett_show_page_excerpt_post() {
	if ( is_single() ) {
	    $post = get_post( get_the_ID() );
	    $the_excerpt = $post->post_excerpt;
	    if ( is_page() || empty( $the_excerpt ) )
	        return;
	    echo "<div class='post-affiliate'>";
	    echo "<h4>Shop the Post</h4>";
	    echo $the_excerpt;
	    echo "</div>";
	}
}

//* Change footer text
add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');
function custom_footer_creds_text($creds) {
	$creds = 'Copyright [footer_copyright] &middot; ' . get_bloginfo(' name') . ' &middot; Theme by <a href="http://www.exempel.se" target="_blank">Exempel</a>';
 	return  $creds;
}

//* Add Image Sizes
add_image_size( 'thumbnail-horizontal', 425, 275, true );
add_image_size( 'thumbnail-vertical', 425, 575, true );
add_image_size( 'thumbnail-square', 425, 425, true );
add_image_size( 'featured-vertical', 1200, 1800, true );
add_image_size( 'featured-horizontal', 1200, 800, true );
add_image_size( 'featured-square', 1200, 1200, true );