<?php	
include_once( get_template_directory() . '/lib/init.php' );

add_action( 'genesis_before', 'hd_css_dinamico' );
function hd_css_dinamico() {
	require_once( get_stylesheet_directory() . '/inc/hd-css.php' );
}


load_child_theme_textdomain( 'flamingo_theme', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/languages' ) );


define( 'CHILD_THEME_NAME', 'Flamingo Theme' );
define( 'CHILD_THEME_VERSION', '1.0.0' );


add_filter('acf/settings/path', 'hd_acf_settings_path');
function hd_acf_settings_path( $path ) {
	$path = get_stylesheet_directory() . '/inc/acf-pro/';
	return $path;
}

add_filter('acf/settings/dir', 'hd_acf_settings_dir');
function hd_acf_settings_dir( $dir ) {
	$dir = get_stylesheet_directory_uri() . '/inc/acf-pro/';
	return $dir;
}

include_once( get_stylesheet_directory() . '/inc/acf-pro/acf.php' );
require_once( get_stylesheet_directory() . '/inc/hd-acf-config.php' );
add_filter('acf/settings/show_admin', '__return_false');


add_action('admin_head', 'hd_admin_style');
function hd_admin_style() {
	echo '<style>
		.acf-input P.description {
			margin-top: 7px;
			color: #9e9e9e;
			font-size: 0.85em;
			line-height: 1.45em;
			font-style: italic;
		}
		.acf-required {
			color: #aaa;
		}
		#licencia .acf-input-wrap,
		#licencia .acf-label {
			display: none;
		}
		#licencia P.description {
			margin-top: 0px;
			font-size: 1em;
		}
	</style>';
}


require_once( get_stylesheet_directory() . '/inc/hd-plugin-activation.php' );

add_action( 'tgmpa_register', 'hd_register_required_plugins' );
function hd_register_required_plugins() {
	$plugins = array(
		array(
			'name'				=> 'WPBakery Visual Composer',
			'slug'				=> 'js_composer',
			'source'				=> 'descargables/plugins-premium/js_composer.zip',
			'required'			=> false,
			'version'			=> '5.1',
			'force_activation'	=> false,
		),
		array(
			'name'				=> 'Contact Form 7',
			'slug'				=> 'contact-form-7',
			'required'			=> false,
		),
		array(
			'name'				=> 'Instagram Slider Widget',
			'slug'				=> 'instagram-slider-widget',
			'required'			=> false,
		),
		array(
			'name'				=> 'MailChimp for WordPress',
			'slug'				=> 'mailchimp-for-wp',
			'required'			=> false,
		),
		array(
			'name'				=> 'One Click Demo Import',
			'slug'				=> 'one-click-demo-import',
			'required'			=> false,
		),
		array(
			'name'				=> 'Yoast SEO',
			'slug'				=> 'wordpress-seo',
			'required'			=> false,
		),
		array(
			'name'				=> 'Akismet',
			'slug'				=> 'akismet',
			'required'			=> false,
		),
		array(
			'name'				=> 'BackWPup',
			'slug'				=> 'backwpup',
			'required'			=> false,
		),
	);
	
	$config = array(
		'id'					=> 'flamingo_theme',
		'default_path'		=> '',
		'menu'				=> 'tgmpa-install-plugins',
		'parent_slug'		=> 'themes.php',
		'capability'			=> 'edit_theme_options',
		'has_notices'		=> true,
		'dismissable'		=> true,
		'dismiss_msg'		=> '',
		'is_automatic'		=> false,
		'message'			=> '',
		'strings'			=> array(
			'page_title' => __( 'Install Required Plugins', 'flamingo_theme' ),
			'menu_title' => __( 'Install Plugins', 'flamingo_theme' ),
			'installing' => __( 'Installing Plugin: %s', 'flamingo_theme' ),
			'updating' => __( 'Updating Plugin: %s', 'flamingo_theme' ),
			'oops' => __( 'Something went wrong with the plugin API.', 'flamingo_theme' ),
			'notice_can_install_required' => _n_noop(
				'This theme requires the following plugin: %1$s.',
				'This theme requires the following plugins: %1$s.',
				'flamingo_theme'
			),
			'notice_can_install_recommended' => _n_noop(
				'This theme recommends the following plugin: %1$s.',
				'This theme recommends the following plugins: %1$s.',
				'flamingo_theme'
			),
			'notice_ask_to_update' => _n_noop(
				'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.',
				'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.',
				'flamingo_theme'
			),
			'notice_ask_to_update_maybe' => _n_noop(
				'There is an update available for: %1$s.',
				'There are updates available for the following plugins: %1$s.',
				'flamingo_theme'
			),
			'notice_can_activate_required' => _n_noop(
				'The following required plugin is currently inactive: %1$s.',
				'The following required plugins are currently inactive: %1$s.',
				'flamingo_theme'
			),
			'notice_can_activate_recommended' => _n_noop(
				'The following recommended plugin is currently inactive: %1$s.',
				'The following recommended plugins are currently inactive: %1$s.',
				'flamingo_theme'
			),
			'install_link' => _n_noop(
				'Begin installing plugin',
				'Begin installing plugins',
				'flamingo_theme'
			),
			'update_link' => _n_noop(
				'Begin updating plugin',
				'Begin updating plugins',
				'flamingo_theme'
			),
			'activate_link' => _n_noop(
				'Begin activating plugin',
				'Begin activating plugins',
				'flamingo_theme'
			),
			'return' => __( 'Return to Required Plugins Installer', 'flamingo_theme' ),
			'plugin_activated' => __( 'Plugin activated successfully.', 'flamingo_theme' ),
			'activated_successfully' => __( 'The following plugin was activated successfully:', 'flamingo_theme' ),
			'plugin_already_active' => __( 'No action taken. Plugin %1$s was already active.', 'flamingo_theme' ),
			'plugin_needs_higher_version' => __( 'Plugin not activated. A higher version of %s is needed for this theme. Please update the plugin.', 'flamingo_theme' ),
			'complete' => __( 'All plugins installed and activated successfully. %1$s', 'flamingo_theme' ),
			'dismiss' => __( 'Dismiss this notice', 'flamingo_theme' ),
			'notice_cannot_install_activate' => __( 'There are one or more required or recommended plugins to install, update or activate.', 'flamingo_theme' ),
			'contact_admin' => __( 'Please contact the administrator of this site for help.', 'flamingo_theme' ),
			'nag_type' => '',
		),
	);
	tgmpa( $plugins, $config );
}




function hd_ocdi_import_files() {
	return array(
		array(
			'import_file_name'           => '(Castellano) Contenido Demo',
			'import_file_url'            => 'descargables/themes/flamingo-theme/es/content.xml',
			'import_widget_file_url'     => 'descargables/themes/flamingo-theme/es/widgets.wie',
			'import_customizer_file_url' => 'descargables/themes/flamingo-theme/es/customizer.dat',
								),
		array(
			'import_file_name'           => '(English) Demo Content',
			'import_file_url'            => 'descargables/themes/flamingo-theme/en/content.xml',
			'import_widget_file_url'     => 'descargables/themes/flamingo-theme/en/widgets.wie',
			'import_customizer_file_url' => 'descargables/themes/flamingo-theme/en/customizer.dat',
								),
	);
}
add_filter( 'pt-ocdi/import_files', 'hd_ocdi_import_files' );


add_action( 'wp_enqueue_scripts', 'hd_genesis_sample_google_fonts' );
function hd_genesis_sample_google_fonts() {
	wp_enqueue_style( 'google-font-raleway', '//fonts.googleapis.com/css?family=Raleway:200,300,300italic,400,400italic,500,500italic', array(), CHILD_THEME_VERSION );
}


add_action( 'admin_enqueue_scripts', 'hd_campo_color' );
function hd_campo_color($hook) {
	if( is_admin() ) { 
		wp_enqueue_style( 'wp-color-picker' ); 
		wp_enqueue_script( 'color-picker', get_stylesheet_directory_uri() . '/js/color-picker.js', array( 'wp-color-picker' ), false, true );
	}
}


add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );


add_theme_support( 'genesis-responsive-viewport' );


require_once( dirname( __FILE__ ) . '/inc/hd-modulo-portafolio.php');


$mostrar_genesis = get_field('mostrar_genesis', 'option');
if(empty($mostrar_genesis)){
	$mostrar_genesis = 'si';
	update_field('mostrar_genesis', $mostrar_genesis, 'options');
}
if($mostrar_genesis == 'no')
	remove_theme_support( 'genesis-admin-menu' );
	

unregister_sidebar( 'header-right' );
unregister_sidebar( 'sidebar-alt' );


add_action( 'wp_before_admin_bar_render', 'hd_remove_admin_bar_links', 999);
function hd_remove_admin_bar_links() {
	global $wp_admin_bar;
	$wp_admin_bar->remove_menu('wp-logo');
	$wp_admin_bar->remove_menu('feedback');
	$wp_admin_bar->remove_menu('comments');
	$wp_admin_bar->remove_menu( 'customize' );
}


add_action( 'admin_bar_menu', 'hd_remove_admin_customizer', 999 );
function hd_remove_admin_customizer( $wp_admin_bar ) {
	$wp_admin_bar->remove_menu( 'customize' );
}
add_action('admin_menu', 'remove_customize', 999);
function remove_customize() {
	global $submenu;
       unset($submenu['themes.php'][6]);
}


add_action( 'widgets_init', 'unregister_genesis_widgets', 20 );
function unregister_genesis_widgets() {
	unregister_widget( 'Genesis_Featured_Page' );
	unregister_widget( 'Genesis_Featured_Post' );
	unregister_widget( 'Genesis_User_Profile_Widget' );
}


remove_theme_support( 'genesis-inpost-layouts' );
genesis_unregister_layout( 'sidebar-content' );
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );


add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );


add_action( 'wp_enqueue_scripts', 'hd_google_analytics' );
function hd_google_analytics() {	
	$google = get_field('google_analytics', 'option');
	if($google){
		echo "<script>
			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
			
			ga('create', '". $google ."', 'auto');
			ga('send', 'pageview');
			
		</script>";
	}
}


add_action('admin_init', 'hd_licencia_vc');
function hd_licencia_vc(){
	if(is_admin()) {
		setcookie('vchideactivationmsg', '1', strtotime('+3 years'), '/');
		setcookie('vchideactivationmsg_vc11', (defined('WPB_VC_VERSION') ? WPB_VC_VERSION : '1'), strtotime('+3 years'), '/');
	}
}


function hd_hex2rgb($hex) {
	$hex = str_replace("#", "", $hex);
	if(strlen($hex) == 3) {
		$r = hexdec(substr($hex,0,1).substr($hex,0,1));
		$g = hexdec(substr($hex,1,1).substr($hex,1,1));
		$b = hexdec(substr($hex,2,1).substr($hex,2,1));
	} else {
		$r = hexdec(substr($hex,0,2));
		$g = hexdec(substr($hex,2,2));
		$b = hexdec(substr($hex,4,2));
	}
	$rgb = array($r, $g, $b);
	return implode(",", $rgb);
}


add_filter( 'edit_post_link', '__return_false' );


add_filter( 'theme_page_templates', 'hd_remove_genesis_page_templates' );
function hd_remove_genesis_page_templates( $page_templates ) {
	unset( $page_templates['page_archive.php'] );
	unset( $page_templates['page_blog.php'] );
	return $page_templates;
}	


define( 'WP_AUTO_UPDATE_CORE', false );


define('WP_POST_REVISIONS', 5);


define('AUTOSAVE_INTERVAL', 300);


define( 'DISALLOW_FILE_EDIT', true);


add_filter('the_generator','hd_killVersion');
function hd_killVersion() {
	return '';
}
remove_action('wp_head', 'wp_generator');


add_filter('upload_mimes', 'cc_mime_types');
function cc_mime_types($mimes) {
	$mimes['svg'] = 'image/svg+xml';
	return $mimes;
}




add_action( 'after_setup_theme', 'hd_theme_updater' );
function hd_theme_updater() {
    require( get_stylesheet_directory() . '/inc/updater/theme-updater.php' );
}






genesis_register_sidebar( array(
	'id' => 'pie-instagram',
	'name' => __('Footer Instagram', 'flamingo_theme'),
	'before_widget' => '<div id="%1$s" class="widget %2$s instagram">',
	'after_widget' => '</div>'
));


add_action( 'widgets_init', 'hd_cambiar_nombres_sidebar', 20 );
function hd_cambiar_nombres_sidebar() {
	global $wp_registered_sidebars;
	$wp_registered_sidebars['sidebar']['name'] = __('Sidebar right', 'flamingo_theme');
		$wp_registered_sidebars['footer-1']['name'] = __('Footer 1', 'flamingo_theme');
	$wp_registered_sidebars['footer-2']['name'] = __('Footer 2', 'flamingo_theme');
	$wp_registered_sidebars['footer-3']['name'] = __('Footer 3', 'flamingo_theme');
	$wp_registered_sidebars['footer-4']['name'] = __('Footer 4', 'flamingo_theme');
}


add_filter('widget_text', 'do_shortcode');


add_action( 'wp_enqueue_scripts', 'hd_sticky_menu_scripts' );
function hd_sticky_menu_scripts() {
	wp_enqueue_script( 'hd-stickey-menu', get_bloginfo( 'stylesheet_directory' ) . '/js/sticky-menu.js', array( 'jquery' ), '1.0.0' );
}


add_action('set_current_user', 'cc_hide_admin_bar');
function cc_hide_admin_bar() {
	if (!current_user_can('edit_posts'))
		show_admin_bar(false);
}






remove_action( 'genesis_site_title', 'genesis_seo_site_title' );
add_action( 'genesis_site_title', 'hd_logo' );
function hd_logo () {
	$my_theme = wp_get_theme();
	$logo = get_field('logo', 'option');
	$altura = get_field('altura_logo', 'option');
	$logo_echo = '<a href="'. get_home_url() .'"><img src="';
	$logo_echo .= $logo;
	$logo_echo .= '" alt="'. get_bloginfo('name') .'"';
	if(empty($altura)){
		$altura = 160;
		update_field('altura_logo', $altura, 'options');
	}
	$logo_echo .= ' style="height: '. $altura .'px"';
	$logo_echo .= ' /></a>';
	if($logo)
		echo $logo_echo;
}


remove_action( 'genesis_site_description', 'genesis_seo_site_description' );


add_filter( 'genesis_pre_load_favicon', 'hd_favicon' );
function hd_favicon() {
	$favicon = get_field('favicon', 'option');
	if($favicon)
		return $favicon;
}


add_action( 'wp_enqueue_scripts', 'custom_scripts_styles_mobile_responsive' );
function custom_scripts_styles_mobile_responsive() {
	wp_enqueue_script( 'beautiful-responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0' );
	wp_enqueue_style( 'dashicons' );
}


remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action('genesis_header', 'hd_area_superior', 1);
function hd_area_superior() {
	$redes = get_field('redes_sociales_cabecera', 'option');
	if(empty($redes)){
		$redes = 'no';
		update_field('redes_sociales_cabecera', $redes, 'options');
	}
	if((has_nav_menu( 'secondary' ) || $redes == 'si') && !is_page_template( 'landing.php' )) {
		echo '<div class="area-superior"><div class="wrap">';
		if(has_nav_menu( 'secondary' )){
			genesis_do_subnav();
			$menu_secundario = 'si';
		}else
			$menu_secundario = 'no';
		
		if($redes == 'si'){
			$listado = array(
				'menu-secundario' => $menu_secundario,
				'facebook' => 'https://www.facebook.com/'.get_field('facebook_url', 'option'),
				'twitter' => 'https://www.twitter.com/'.get_field('twitter_url', 'option'),
				'pinterest' => 'https://www.pinterest.com/'.get_field('pinterest_url', 'option'),
				'instagram' => 'https://www.instagram.com/'.get_field('instagram_url', 'option'),
				'youtube' => get_field('youtube_url', 'option'),
				'google' => get_field('google_url', 'option'),
			);
			echo hd_pie_redes_sociales($listado);
		}
		echo '</div></div>';
	}
}
	




add_action( 'genesis_before_content_sidebar_wrap', 'hd_config_titulo' );
function hd_config_titulo() {
	if(is_front_page() && !is_home()) {
		remove_action( 'genesis_entry_header', 'genesis_entry_header_markup_open', 5 );
		remove_action( 'genesis_entry_header', 'genesis_entry_header_markup_close', 15 );
		remove_action( 'genesis_entry_header', 'genesis_do_post_title' );
	}
}


add_filter( 'body_class', 'hd_body_class' );
function hd_body_class( $classes ) {
	$estilo_blog = get_field('estilo_blog', 'option');
	if(empty($estilo_blog)){
		$estilo_blog = 3;
		update_field('estilo_blog', $estilo_blog, 'options');
	}
	if(is_home()) {
		if($estilo_blog == 2)
			$classes[] = 'col2';
		if($estilo_blog == 3)
			$classes[] = 'col2 dest';
	}
	return $classes;
}


add_action( 'get_header', 'hd_barra_lateral' );
function hd_barra_lateral(){
	if (is_home() || is_archive() || is_singular('post') || is_search())
		add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_content_sidebar' );
}


remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );
add_action( 'genesis_entry_header', 'genesis_post_info', 5 );
add_filter( 'genesis_post_info', 'hd_post_info_filter' );
function hd_post_info_filter() {
	return '[post_categories before="" sep="&nbsp;·"]';
}


add_action( 'genesis_entry_header', 'hd_post_date', 11 );
function hd_post_date() {
	if (is_home() || is_archive() || is_singular('post') || is_search())
		echo '<div class="fecha"><span>'. get_the_date() .'</span></div>';
}


add_action( 'genesis_entry_header', 'single_post_featured_image', 15 );
function single_post_featured_image() {
	if(has_post_thumbnail()){
		$img = genesis_get_image( array( 'format' => 'html', 'size' => 'large', 'attr' => array( 'class' => 'post-image' ) ) );
		if (!is_singular( 'post' ))
			return $img;
		printf( '%s', $img );
	}
}


add_filter( 'post_class', 'hd_post_con_imagenes' );
function hd_post_con_imagenes( $classes ) {
	if(has_post_thumbnail())
		array_push($classes, 'con-imagen');
	else
		array_push($classes, 'sin-imagen');
	return $classes;
}


add_filter('excerpt_more', 'hd_boton_leer_mas');
add_filter( 'the_content_more_link', 'hd_boton_leer_mas' );
function hd_boton_leer_mas() {
	return '... <a class="more-link" href="' . get_permalink() . '">'.__('Continue reading', 'flamingo_theme').'</a>';
}


add_filter( 'excerpt_length', 'hd_largura_excerpt' );
function hd_largura_excerpt( $length ) {
	return 70;
}


add_filter( 'genesis_post_meta', 'sp_post_meta_filter' );
function sp_post_meta_filter($post_meta) {
	$post_meta = '';
	return $post_meta;
}

add_action('genesis_entry_footer', 'hd_etiquetas', 1);
function hd_etiquetas(){
	if(is_singular('post')) {
		$posttags = get_the_tags();
		if ($posttags) {
			echo '<div class="etiquetas">';
			foreach($posttags as $tag)
				echo '<a href="'. get_home_url() . '/tag/'. $tag->slug .'">'. $tag->name .'</a>';
			echo '</div>';
		}
	}
}


add_filter('genesis_prev_link_text', 'hd_boton_anterior');
function hd_boton_anterior(){
	$link_text = '<span>‹ </span>' . __('Previous', 'flamingo_theme');
	return $link_text;
}

add_filter('genesis_next_link_text', 'hd_boton_siguiente');
function hd_boton_siguiente(){
	$link_text = __('Next', 'flamingo_theme'). '<span> ›</span>';
	return $link_text;
}


function hd_buscar_en_post() {
	$formu = '<form id="searchform" class="search-form" action="'. get_home_url() .'/" method="get">';
	$formu .= '<input itemprop="query-input" type="search" name="s" placeholder="'. __('Search the blog...', 'flamingo_theme') .'">';
	$formu .= '<input type="hidden" name="post_type" value="post" />';
	$formu .= '</form>';
	return $formu;
}
add_shortcode('buscar', 'hd_buscar_en_post');


add_action( 'wp_enqueue_scripts', 'hd_script_addthis' );
function hd_script_addthis() {
	$script_addthis = get_field('script_addthis', 'option');
	$redes_compartir = get_field('redes_compartir', 'option');
	if(empty($redes_compartir)){
		$redes_compartir = 'no';
		update_field('redes_compartir', $redes_compartir, 'options');
	}
	if($redes_compartir == 'si')
		echo $script_addthis;
}

add_action('genesis_entry_footer','hd_pie_post');
function hd_pie_post(){
	$redes_compartir = get_field('redes_compartir', 'option');
	if(empty($redes_compartir)){
		$redes_compartir = 'no';
		update_field('redes_compartir', $redes_compartir, 'options');
	}
	if(is_singular('post')){
		$num_comments = get_comments_number(get_the_ID());
		if ( comments_open() ) {
			if ( $num_comments == 0 )
				$comments = __('Leave a comment', 'flamingo_theme');
			elseif ( $num_comments > 1 )
				$comments = $num_comments . __(' comments', 'flamingo_theme');
			else
				$comments = __('1 comment', 'flamingo_theme');
			$write_comments = '<a href="' . get_comments_link() .'" class="comentarios">'. $comments.' ›</a>';
		} else
			$write_comments =  __('Comments are closed.', 'flamingo_theme');
		echo $write_comments;
		if($redes_compartir == 'si')
			echo '<div class="addthis_toolbox"><div class="addthis_sharing_toolbox"></div></div>';
	}
}


add_action( 'wp_enqueue_scripts', 'hd_script_fontawesome' );
function hd_script_fontawesome() {
	echo '<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">';
}

add_shortcode( 'redes', 'hd_pie_redes_sociales' );
function hd_pie_redes_sociales($atts) {
	if($atts['menu-secundario'] == 'no')
		$anchura = ' style="width: 100%"';
	$cadena = '<span class="redes"'. $anchura .'>';
	while (current($atts)) {
		$red = str_replace('_', '-', key($atts));
		$ruta = $atts[key($atts)];
		if($red != 'titulo' && $red != 'sin-menu' && $ruta != 'https://www.facebook.com/' && $ruta != 'https://www.twitter.com/' && $ruta != 'https://www.instagram.com/' && $ruta != 'https://www.pinterest.com/'){
			if($atts['titulo'])
				$cadena .= '<a href="'.$ruta.'" target="_blank"><i class="fa fa-'. $red .'"></i> '. $red .'</a>';
			else
				$cadena .= '<a href="'.$ruta.'" target="_blank"><i class="fa fa-'. $red .'"></i></a>';
		}
		next($atts);
	}
	$cadena .= '</span>';
	return $cadena;
}


$autor = get_field('autor_blog', 'option');
if(empty($autor)){
	$autor = 'no';
	update_field('autor_blog', $autor, 'options');
}
if($autor == 'si')
	add_filter( 'get_the_author_genesis_author_box_single', '__return_true' );


add_filter( 'genesis_author_box_title', 'hd_nombre_autor' );
function hd_nombre_autor() {
	return get_the_author();
}


add_filter( 'genesis_title_comments', 'sp_genesis_title_comments' );
function sp_genesis_title_comments() {
	$title = '<h3>'. __('Comments') .'</h3>';
	return $title;
}


add_filter( 'genesis_author_box_gravatar_size', 'hd_author_box_gravatar_size' );
function hd_author_box_gravatar_size( $size ) {
	return '100';
}


add_filter( 'genesis_comment_list_args', 'hd_childtheme_comment_list_args' );
function hd_childtheme_comment_list_args( $args ) {
	$args['avatar_size'] = 60;
	return $args;
}


add_filter( 'comment_form_defaults', 'hd_custom_comment_form' );
function hd_custom_comment_form($fields) {
	$fields['comment_notes_before'] = '';
	$fields['title_reply'] = __( 'Leave a comment', 'flamingo_theme' );
	$fields['label_submit'] = __( 'Send', 'flamingo_theme' );
	$fields['fields'] =  array(
		'author' => '<input id="author" name="author" type="text" placeholder="'. __( 'Name', 'flamingo_theme' ) .'" value="' . esc_attr( $commenter['comment_author'] ) .'" '. $aria_req .'/>',
		'email' => '<input id="email" name="email" type="text" placeholder="'. __( 'Email', 'flamingo_theme' ) .'" value="' . esc_attr(  $commenter['comment_author_email'] ) .'" ' . $aria_req . '/>',
		'url' => '<input id="url" name="url" type="text" placeholder="'. __( 'Website', 'flamingo_theme' ) .'" value="' . esc_attr( $commenter['comment_author_url'] ) .'" />'
	);
	$fields['comment_field'] = '<textarea id="comment" name="comment" cols="45" rows="8" aria-required="true" placeholder="'. __( 'Leave a comment on this field...', 'flamingo_theme' ) .'"></textarea>';
	$fields['comment_notes_after'] = '';
	
	return $fields;
}


add_filter( 'comment_form_fields', 'wpb_move_comment_field_to_bottom' );
function wpb_move_comment_field_to_bottom( $fields ) {
	$comment_field = $fields['comment'];
	unset( $fields['comment'] );
	$fields['comment'] = $comment_field;
	return $fields;
}


add_action( 'genesis_entry_footer', 'hd_navegacion_portafolio' );
function hd_navegacion_portafolio() {
	if (is_singular('portafolio')){
		echo '<div class="navegacion">';
		echo '<div class="anterior">';
		if(get_the_term_list($post->ID, 'cat-portafolio', '', '', ''))
			echo next_post_link('%link', '&lsaquo; '.__( 'Previous', 'flamingo_theme' ).' <p>%title</p>' , FALSE);
		echo '</div>';
		echo '<div class="siguiente">';
		if(get_the_term_list($post->ID, 'cat-portafolio', '', '', ''))
			echo previous_post_link('%link', __('Next', 'flamingo_theme').' &rsaquo; <p>%title</p>', FALSE);
		echo '</div>';
		echo '</div>';
	}
}


function hd_mostrar_mailchimp($args, $content) {
	$formu = '<div class="'. $args['pos'] .'">';
	$formu .= do_shortcode('[mc4wp_form id="'. $args['id'] .'"]');
	$formu .= '</div>';
	return $formu;
}
add_shortcode('mailchimp', 'hd_mostrar_mailchimp');





add_action('genesis_before_footer', 'hd_sidebar_extra_pie', 1);
function hd_sidebar_extra_pie() {
	$pie_instagram = get_field('pie_instagram', 'option');
	if(empty($pie_instagram)){
		$pie_instagram = 'no';
		update_field('pie_instagram', $pie_instagram, 'options');
	}
	if(is_active_sidebar( 'pie-instagram' ) && $pie_instagram == 'si')
		dynamic_sidebar('pie-instagram');
	$pie_redes = get_field('pie_redes', 'option');
	if(empty($pie_redes)){
		$pie_redes = 'no';
		update_field('pie_redes', $pie_redes, 'options');
	}
	if($pie_redes == 'si'){
		echo '<div class="pie-redes">';
		$listado = array(
			'titulo' => 'si',
			'facebook' => 'https://www.facebook.com/'.get_field('facebook_url', 'option'),
			'twitter' => 'https://www.twitter.com/'.get_field('twitter_url', 'option'),
			'pinterest' => 'https://www.pinterest.com/'.get_field('pinterest_url', 'option'),
			'instagram' => 'https://www.instagram.com/'.get_field('instagram_url', 'option'),
			'youtube' => get_field('youtube_url', 'option'),
			'google' => get_field('google_url', 'option'),
		);
		echo hd_pie_redes_sociales($listado);
		echo '</div>';
	}
}


$columnas_pie = get_field('columnas_pie', 'option');
if(empty($columnas_pie)){
	$columnas_pie = 4;
	update_field('columnas_pie', $columnas_pie, 'options');
}
if($columnas_pie != 0) 
	add_theme_support( 'genesis-footer-widgets', 4 );

add_filter( 'genesis_attr_footer-widgets', 'hd_columnas_pie' );
function hd_columnas_pie( $attributes ) {
	$columnas_pie = get_field('columnas_pie', 'option');
	if(empty($columnas_pie)){
		$columnas_pie = 4;
		update_field('columnas_pie', $columnas_pie, 'options');
	}
	$attributes['class'] .= ' wcol'.$columnas_pie;
	return $attributes;
}


add_filter( 'genesis_footer_creds_text', 'copyright' );
function copyright() {
	echo '<div class="creds">';
	echo '<p>© '. date("Y") . ' ' . get_bloginfo('name').' · '. base64_decode('RGlzZSZudGlsZGU7byAmcnNhcXVvOyA8YSBocmVmPSJodHRwOi8vd3d3LmhvZGVpZGVzaWduLmNvbSIgdGFyZ2V0PSJfYmxhbmsiPkhvZGVpIERlc2lnbjwvYT4=') .'</p>';
	echo '</div>';
}


add_action('wp_footer', 'go_to_top');
function go_to_top() {
	echo '<script type="text/javascript">
        jQuery(function($) {
		$("a.top").click(function() {
            		$("html, body").animate({scrollTop:0}, "slow");
				return false;
			});
        });
	</script>';
}

add_filter('genesis_footer_creds_text', 'sp_footer_creds_filter');
function sp_footer_creds_filter() {
	$creds = '<a href="#" class="top"><img src="'. get_stylesheet_directory_uri() .'/images/i-top.svg" alt="'. __('Go top', 'flamingo_theme') .'" /></a></div>';
	return $creds;
}

?>