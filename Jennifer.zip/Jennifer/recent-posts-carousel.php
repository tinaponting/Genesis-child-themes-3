<?php
function ll_main_carousel($atts, $content = null) {
	global $post;
	$randomid = rand();
	extract(shortcode_atts(array(
		'title' => '',
		'visible' => '3',
		'posts' => '3',
		'category' => ''
	), $atts));
	ob_start();
	
function new_excerpt_more( $more ) {
	return '<a class="read-more" href="' . get_permalink( get_the_ID() ) . '">' . __( 'Read More', 'your-text-domain' ) . '</a>';
}

add_filter( 'excerpt_more', 'new_excerpt_more' );

function the_excerpt_max_charlength($charlength) {
	$excerpt = get_the_excerpt();
	$charlength++;

	if ( mb_strlen( $excerpt ) > $charlength ) {
		$subex = mb_substr( $excerpt, 0, $charlength - 5 );
		$exwords = explode( ' ', $subex );
		$excut = - ( mb_strlen( $exwords[ count( $exwords ) - 1 ] ) );
		if ( $excut < 0 ) {
			echo mb_substr( $subex, 0, $excut );
		} else {
			echo $subex;
		}
		echo '... </div>' . new_excerpt_more( $more );
	} else {
		echo new_excerpt_more( $more );
	}
}

?>
						  
<div class="container">
	<div class="owl-carousel">
		<?php
			$args = array(
			'post_status' => 'publish',
			'post_type' => 'post',
			'category_name' => $category,
			'posts_per_page' => $posts
			);
			 
			$recentPosts = new WP_Query( $args );
			
			if ( $recentPosts->have_posts() ) : ?>
			
			
		<?php while ( $recentPosts->have_posts() ) : $recentPosts->the_post(); ?>
		
		
		
			<div class="slider-content">

				<?php if (has_post_thumbnail( $post->ID ) ): ?>
				<?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' ); ?>
					<div class="sldr-img" style="background-image: url('<?php echo $image[0]; ?>');"></div>
				<?php endif; ?>

				<div class="sldr-post-cntnt-algnr">
				<div class="sldr-post-cntnt"><div class="sldr-post-cntnt-brdr">
					<div class="sldr-ttl">
						<span class="excrpt-date"><?php echo get_the_date(); ?></span>
						<a href="<?php echo esc_url( the_permalink() ); ?>" title="<?php echo esc_attr( the_title() ); ?>">
							<h1 class="sldr-ttl-h1"><?php echo wp_trim_words( get_the_title(), 5 ); ?></h1>	
						</a>
					</div>
					<div class="sldr-cntnt"><div class="sldr-excrpt">
						<?php echo wp_trim_words( the_excerpt_max_charlength(100) ); ?>
					</div>
				</div></div>
				</div>
			</div><!-- .slider-content -->
			
		<?php endwhile; // end of the loop. ?>
                        
		<?php      
			endif; 
			wp_reset_query();                   
		?>
	</div><!-- .owl-carousel -->
</div><!-- .container -->

<div class="clearfix"></div>
	<?php
		$content = ob_get_contents();
		ob_end_clean();
		return $content;
}
 
add_shortcode("ll_main_carousel", "ll_main_carousel");