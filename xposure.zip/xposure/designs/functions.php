<?php
/******** Place all your wp/php tweaks here ****************/
/******** This is your theme's master functions.php file ******/

/**
 * Unregister all three-column layouts for the theme
 */
 
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );

/**
 * Remove Landing Section post type support
 */

remove_post_type_support( 'page', 'lander-landing-sections' );
remove_post_type_support( 'post', 'lander-landing-sections' );

/**
 * Unregister the Before Header and After Header sidebars
 */
 
add_action( 'widgets_init', 'xpos_unregister_sidebars' );

function xpos_unregister_sidebars() {
	unregister_sidebar( 'sidebar-alt' );
	unregister_sidebar( 'before-header' );
	unregister_sidebar( 'after-header' );
	unregister_sidebar( 'lander-woo-primary-sb' );
	unregister_sidebar( 'lander-woo-secondary-sb' );
}

/**
 * Set the default layout for the site to full-width
 */

add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );


/**
 * Declare theme menus — Primary & Footer menu
 */
 
remove_theme_support( 'genesis-menus', array(
	'primary' => 'Primary Navigation Menu',
	'secondary' => 'Secondary Navigation Menu',
	'footer_menu' => 'Footer Menu'
) );

add_theme_support( 'genesis-menus', array(
	'primary' => 'Primary Navigation Menu',
	'footer_menu' => 'Footer Menu'
) );


/**
 * Unhook the theme widget areas that are not being used
 */

remove_action( 'wp_head', 'lander_widgetize', 5 );
add_action( 'wp_head', 'xpos_widget_areas', 5 );

function xpos_widget_areas() {
	add_action( 'genesis_before_footer', 'lander_sidebar_above_footer', 5 );
}

add_image_size( 'landscape-widescreen', 1920, 1080, true );

/**
 * Filter the Genesis theme defaults to use excerpts for archives and change the default image size
 */
 
add_filter( 'genesis_theme_settings_defaults', 'xpos_genesis_theme_defaults' );

function xpos_genesis_theme_defaults( $defaults ) {
	$img_sizes = genesis_get_image_sizes();
	
	$defaults['site_layout']				= 'full-width-content';
	$defaults['content_archive']			= 'full';
	$defaults['content_archive_limit']		= 150;
	$defaults['content_archive_thumbnail']	= 1;
	$defaults['image_alignment']			= '';
	if( array_key_exists( 'landscape-widescreen', $img_sizes ) )
		$defaults['image_size']	= 'landscape-widescreen';
	
	return $defaults;
}


/**
 * Enqueue theme specific scripts
 */

add_action( 'wp_enqueue_scripts', 'xpos_header_scripts' );

function xpos_header_scripts() {
	wp_enqueue_style( 'xposure-google-fonts', '//fonts.googleapis.com/css?family=Lora:400,400italic,700,700italic|Raleway:400,500,600', array(), false, false );
	wp_enqueue_script( 'xposure-base-scripts', LANDER_CORE_DESIGNS_URL . '/scripts/xposure-scripts.js', array(), false, false );
	wp_enqueue_script( 'xposure-lightbox', CHILD_LIB . '/uikit/js/components/lightbox.min.js', array( 'jquery' ), false, true );
	wp_enqueue_script( 'xposure-parallax', CHILD_LIB . '/uikit/js/components/parallax.min.js', array( 'jquery' ), false, true );
	wp_enqueue_script( 'xposure-isotope-grid', CHILD_LIB . '/uikit/js/components/grid.min.js', array( 'jquery' ), false, true );
	wp_enqueue_script( 'xposure-jquery-easing', LANDER_CORE_DESIGNS_URL . '/scripts/jquery.easing.1.3.js', array(), false, false );
}

/**
 * Reposition primary nav to header right
 */

remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_header_right', 'genesis_do_nav' );


/**
 * Add a menu toggle button to show/hide menu
 */
 
add_action( 'genesis_header_right', 'xpos_primary_menu_toggle' );

function xpos_primary_menu_toggle() {
	if( has_nav_menu( 'primary' ) ) {
		echo '<div class="primary-menu-button"><i class="fa fa-bars"></i></div>';
	}
}


/**
 * Additional styles/scripts to be dynamically added to <head>
 */

add_action( 'wp_head', 'xpos_header_scripts_styles' );

function xpos_header_scripts_styles() {
	/* Do not position header absolute if tagline and image are not set */
	$header_img = xpos_fetch_single_post_featimg();
	$header_tagline = xpos_fetch_post_tagline();
	
	if( !$header_img ) {
		echo '
			<style type="text/css">
				.xposure.single .site-inner,
				.xposure.page .site-inner {
					margin-top: 100px;
				}
				.xposure.single .entry-header,
				.xposure.page .entry-header {
					text-align: left;
					margin-bottom: 2.618em;
				}
				@media only screen and (max-width: 540px) {
					.xposure.single .site-inner,
					.xposure.page .site-inner {
						margin-top: 0;
					}
					.xposure.single .entry-header,
					.xposure.page .entry-header {
						text-align: left;
						margin-bottom: 1.618em;
					}
				}
			</style>
		';
	}
	else {
		if( !$header_tagline ) {
			echo '
				<style type="text/css">
					.xposure .featured-image-banner .wrap {
						padding-top: 310px;						
						padding-bottom: 310px;						
					}
					@media only screen and (max-width: 800px) {
						.xposure .featured-image-banner .wrap {
							padding-top: 260px;						
							padding-bottom: 260px;
						}
					}
					@media only screen and (max-width: 600px) {
						.xposure .featured-image-banner .wrap {
							padding-top: 240px;						
							padding-bottom: 240px;
						}
					}
					@media only screen and (max-width: 540px) {
						.xposure .featured-image-banner .wrap {
							padding-top: 160px;						
							padding-bottom: 160px;
						}
					}
					@media only screen and (max-width: 360px) {
						.xposure .featured-image-banner .wrap {
							padding-top: 120px;						
							padding-bottom: 120px;
						}
					}
				</style>
			';	
		}
	}
	
	/* Style tweaks for page using the portfolio template */
	if( is_page_template('xposure_portfolio.php') ) {
		$content = get_post()->post_content;
		if( empty( $content ) ) {
			echo '
				<style type="text/css">
					.xposure.fullscreen-portfolio .site-inner .wrap {
						padding-top: 0;						
						padding-bottom: 0;
					}
					.xposure.fullscreen-portfolio .entry,
					.xposure.fullscreen-portfolio .entry-content {
						margin: 0;
					}
					.xposure.fullscreen-portfolio .entry-header .entry-title {
						border-bottom: 0 none;
						margin: 0;
						padding: 0;
					}
					.xposure.fullscreen-portfolio .content .entry-header {
						margin: 0;
					}
					.xposure.fullscreen-portfolio .content .entry-header .entry-title {	
						text-indent: -9999px;
						height: 0;
					}
					.xposure.fullscreen-portfolio .site-inner {
						margin-top: 0;
					}
					.xposure.fullscreen-portfolio .site-inner .wrap {
						background-color: transparent;
						box-shadow: none;
						border-top: 0 none;
					}
				</style>
			';
		}
	}
}


/**
 * Add a custom field to Posts edit screen to allow users to add a custom tagline
 * This tagline shows up on the big header image for single posts
 */
 
add_action( 'edit_form_after_title', 'xpos_post_tagline_field' );

function xpos_post_tagline_field( $post ) {
	
	global $typenow;
	
	$current_page_template = get_post_meta( $post->ID, '_wp_page_template', true );
	
	if( ( $typenow != 'post' && $typenow != 'page' ) || $current_page_template == 'xposure_portfolio.php' )
		return;
	
	wp_nonce_field( 'xpos_post_tagline_nonce', 'xpos_post_tagline_nonce_field' );
	
	$secondary_title = get_post_meta( $post->ID, '_xpos_post_subtitle', TRUE );
	
	?>
		<div class="post-tagline postbox">
		<h3><?php printf( __( '%s %s Tagline', CHILD_DOMAIN ), CHILD_THEME_NAME, ucfirst( $typenow ) ); ?></h3>
		<p><label class="post-tagline-label" for="xpos_post_tagline"><?php printf( __( 'Use this field to add a tagline or few words that describe this %s.%s%s Tip:%s Try to limit this tagline to a few words or a very short sentence to make sure it shows up elegantly on your site%s.', CHILD_DOMAIN ), $typenow, '<br /><em>', '<strong>' . CHILD_THEME_NAME, '</strong>', '</em>' ) ?></label></p>
		<p><input class="tagline" type="text" name="xpos_post_tagline" size="30" value="<?php echo esc_attr( $secondary_title ); ?>" spellcheck="true" autocomplete="off" /></p>
		</div>
	<?php
	
}

function xpos_tagline_disallowed_notice() {
	echo '<div class="notice notice-warning inline"><p>' . __( 'Post Tagline is not available for the posts page.', CHILD_DOMAIN ) . '</p></div>';
}


/** Validate and save the custom field input for secondary title **/

add_action( 'save_post', 'xpos_post_tagline_save' );

function xpos_post_tagline_save( $post_id ) {
	
	// Check if our nonce is set.
	if ( !isset( $_POST['xpos_post_tagline_nonce_field'] ) ) {
		return;
	}

	// Verify that the nonce is valid.
	if ( !wp_verify_nonce( $_POST['xpos_post_tagline_nonce_field'], 'xpos_post_tagline_nonce' ) ) {
		return;
	}

	// If this is an autosave, our form has not been submitted, so we don't want to do anything.
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	// Check the user's permissions.
	if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {

		if ( !current_user_can( 'edit_page', $post_id ) ) {
			return;
		}

	} else {

		if ( !current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
	}

	/* OK, it's safe for us to save the data now. */

	// Make sure that it is set.
	if ( !isset( $_POST['xpos_post_tagline'] ) ) {
		return;
	}

	// Sanitize user input.
	$xpos_post_tagline = isset( $_POST['xpos_post_tagline'] ) ? $_POST['xpos_post_tagline'] : '';

	update_post_meta( $post_id, '_xpos_post_subtitle', $xpos_post_tagline );
	
}


/**
 * Check if a page / post has a tagline set
 * Output the tagline on the singular posts/pages over the featurde image banner
 */

function xpos_fetch_post_tagline() {
	
	$wrapper_open = '<div class="post-tagline"><h3 class="title">';
	$wrapper_close = '</h3></div>';
	
	$default_tagline = genesis_get_option( 'xpos_default_tagline', CHILD_SETTINGS_FIELD_EXTRAS, false );
	
	$is_portfolio_jetpack_post_type = ( post_type_exists( 'jetpack-portfolio' ) && is_post_type_archive( 'jetpack-portfolio' ) ) ? true : false;
	
	$is_woocommerce_active = ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) ? true : false;
	
	if( get_option( 'show_on_front' ) == 'posts' ) {
		if ( is_home() ) {
			$user_tagline = genesis_get_option( 'xpos_homepage_tagline', CHILD_SETTINGS_FIELD_EXTRAS, false );
			$tagline = !empty( $user_tagline ) ? $user_tagline : ( !empty( $default_tagline ) ? $default_tagline : '' );
			if( empty( $tagline ) )
				return;
		}
		else {
			$page_id = get_the_ID();
		}
	}
	else {
		if( get_option( 'show_on_front' ) == 'page' ) {
			if( is_home() ) {
				$page_id = get_option( 'page_for_posts' );
			}
			else {
				$page_id = get_the_ID();
			}
		}
	}
	
	if( empty( $tagline ) ) {
	
		if( is_archive() ) {
			if( $is_portfolio_jetpack_post_type ) {
				$tagline = sprintf( __( '%s Showcase', CHILD_DOMAIN ), get_bloginfo( 'name' ) );
				$tagline = apply_filters( 'xposure_archives_jp_portfolio_tagline', $tagline );
			}
			else {
				if( $is_woocommerce_active && ( is_shop() || is_product() || is_product_category() ) ) {
					$tagline = sprintf( __( '%s Store', CHILD_DOMAIN ), get_bloginfo( 'name' ) );
					$tagline = apply_filters( 'xposure_woostore_tagline', $tagline );
				}
				else {
					$tagline = sprintf( __( '%s Archives', CHILD_DOMAIN ), get_bloginfo( 'name' ) );
					$tagline = apply_filters( 'xposure_archives_tagline', $tagline );
				}
			}
		}
		else {
			if( is_search() ) {
				$tagline = sprintf( __( 'Search %s', CHILD_DOMAIN ), get_bloginfo( 'name' ) );
				$tagline = apply_filters( 'xposure_search_tagline', $tagline );
			}
			else {
				if( is_404() ) {
					$tagline = __( 'Oh! That\'s a 404', CHILD_DOMAIN );
					$tagline = apply_filters( 'xposure_fourohfour_tagline', $tagline );
				}
				else {					
					// Fetch the secondary title and display if set
					$user_input = get_post_meta( $page_id, '_xpos_post_subtitle', true );
					$tagline = !empty( $user_input ) ? $user_input : ( !empty( $default_tagline ) ? $default_tagline : '' );
					
					if( empty( $tagline ) )
						return;
				}
			}
		}
		
	}
	
	if( !empty( $tagline ) )
		return $wrapper_open . do_shortcode( $tagline ) . $wrapper_close;

}


/**
 * Setup the hero shot on single posts.
 * The featured image for the post will display after header as fulll-width image.
 * The title displays as an overlay on the title.
 */

function xpos_fetch_single_post_featimg() {
	
	$default_img = genesis_get_option( 'xpos_default_featimg_url', CHILD_SETTINGS_FIELD_EXTRAS, false );
	
	$is_portfolio_jetpack_post_type = ( post_type_exists( 'jetpack-portfolio' ) && is_post_type_archive( 'jetpack-portfolio' ) ) ? true : false;
	
	if( get_option( 'show_on_front' ) == 'posts' ) {
		if ( is_home() || $is_portfolio_jetpack_post_type ) {
			$user_img = genesis_get_option( 'xpos_homepage_featimg', CHILD_SETTINGS_FIELD_EXTRAS, false );
			$img = !empty( $user_img ) ? $user_img : ( !empty($default_img) ? $default_img : '' );
		}
		else {
			$page_id = get_the_ID();
		}
	}
	else {
		if( get_option( 'show_on_front' ) == 'page' ) {
			if( is_home() ) {
				$page_id = get_option( 'page_for_posts' );
			}
			else {
				$page_id = get_the_ID();
			}
		}
	}
	
	if ( is_archive() || is_search() || is_404() ) {
		$page_id = get_option( 'page_for_posts' );
	}
	else {
		$page_id = get_the_ID();
	}
	
	if( empty( $img ) ) {
	
		$img_url = genesis_get_image( array(
			'post_id'	=> $page_id,
			'format'	=> 'url',
			'size'		=> 'full',
			'attr'    => genesis_parse_attr( 'entry-image', array ( 'alt' => get_the_title(), 'class' => 'alignnone' ) ),
		) );

		if ( !empty( $img_url ) )
			$img = $img_url;
		else
			$img = empty( $default_img ) ? '' : $default_img;
	
	}
	
	return $img;
	
}

/**
 * Add the featured image banner to single posts along with the tagline input by the user
 */
 
add_action( 'genesis_after_header', 'xpos_single_hero_image', 10 );

function xpos_single_hero_image() {
	
	$img = xpos_fetch_single_post_featimg();
	
	if( is_page_template( 'xposure_portfolio.php' ) )
		return;
	
	// If no featured image is set, nothing will be displayed
	if( empty( $img ) )
		return;
	
	$tagline = xpos_fetch_post_tagline();
	
	?>
		<div class="featured-image-banner" style="background-image: url(<?php echo $img; ?>); background-repeat: no-repeat; background-attachment: fixed; background-position: center center; background-size: 1920px 1080px">
		<div class="inner-overlay">
		<div class="wrap">
		<?php echo $tagline; ?>
		</div>
		</div>
		</div>
	<?php
	
}


/**
 * Modify the read more link on archives
 */

add_filter( 'get_the_content_more_link', 'xpos_archives_read_more_link' );

function xpos_archives_read_more_link() {
	return '&hellip;<a class="more-link" href="' . get_permalink() . '">' . __( 'Continue Reading' ) . '</a>';
}


/**
 * Modify the Read More on excrepts
 */

remove_action( 'genesis_entry_content', 'show_read_more_on_excerpt' );
add_filter( 'excerpt_more', 'xpos_excerpt_read_more' );

function xpos_excerpt_read_more( $more ) {
    global $post;
	return '&hellip;<a class="more-link" href="'. get_permalink( $post->ID ) . '">' . __( 'Continue Reading' ) . '</a>';
}

/**
 * Filter the default excerpt length
 */
 
add_filter( 'excerpt_length', 'xpos_set_excerpt_length' );

function xpos_set_excerpt_length( $length ) {
	return 24;
}


/**
 * Modify the post meta info on single posts in the entry header (below the post title)
 */

add_filter( 'genesis_post_info', 'xpos_single_entry_header_meta' );

function xpos_single_entry_header_meta( $meta ) {
	if( is_single() )
		$meta = '[post_date] [post_categories before=""] [post_edit before=" | "]';
	else
		$meta = '[post_date] [post_comments before=""] [post_edit before=" | "]';
	return $meta;
}


/**
 * Modify the post meta info on single posts in the entry footer (below the post content)
 */

add_filter( 'genesis_post_meta', 'xpos_single_entry_footer_meta' );

function xpos_single_entry_footer_meta( $meta ) {
	if( !is_single() )
		return;
	$meta = '';
	
	return $meta;
}


/**
 * Append an additional element to the entry header markup for single posts
 */
 
add_action( 'genesis_entry_header', 'xpos_single_entry_header_element', 10 );

function xpos_single_entry_header_element() {
	if( ( !is_singular( 'post' ) && !is_singular( 'page' ) ) )
		return;
	echo '<div class="horizontal-bar"></div>';
}


/**
 * Reposition Jetpack Sharing to display in the entry footer on single posts
 */
 
add_action( 'genesis_before', 'xpos_reposition_jetpack_sharing' );

function xpos_reposition_jetpack_sharing() {
	if( !is_single() && !function_exists( 'sharing_display' ) )
		return;

	// Remove the sharing icons from the default lcocations
	remove_filter( 'the_content', 'sharing_display', 19 );
	remove_filter( 'the_excerpt', 'sharing_display', 19 );
	
	// Add the sharing icons to display in the entry footer
	add_action( 'genesis_entry_footer', 'xpos_relocate_jetpack_sharing', 8 );
}

function xpos_relocate_jetpack_sharing() {
	global $post;
	 
	if( !function_exists( 'sharing_display' ) )
		return;

	// Fetch the sharing icons output
	$sharedaddy_content = sharing_display();
	if( empty( $sharedaddy_content ) )
		return;
	
	$output = '<div class="sharedaddy-box">' . $sharedaddy_content . '</div>';
	
	echo apply_filters( 'xpos_jetpack_sharing_output', $output, $sharedaddy_content );
}


/**
 * WordPress does need a themes support to specify the content width. Jetpack galleries only extend to the content column, otherwise
 */

$current_layout_width = genesis_get_option( 'column-content-1col', CHILD_SETTINGS_FIELD, false );
$current_content_padding = genesis_get_option( 'col-spacing', CHILD_SETTINGS_FIELD, false );
$max_width = (int) ( $current_layout_width + ( $current_content_padding * 2 ) ); 

if ( !isset( $content_width ) )
    $content_width = $max_width;


/**
 * Isotope Masonry type grid to display portfolio
 */

add_shortcode( 'portfolio-isotope', 'xpos_portfolio_isotope' );

function xpos_portfolio_isotope( $atts ) {
	extract( shortcode_atts(
		array(
			'categories'	=> '',
			'grid_gutter'	=> 3,
		), $atts )
	);
	//$categories = 'bokeh,creative';
	if( !$categories )
		return;
	
	$categories = explode( ',', $categories );	
	$all_categories_obj = get_categories();
	foreach( $all_categories_obj as $allcats ) {
		$cat_names[$allcats->name] = $allcats->slug;
	}
	
	foreach( $categories as $category ) {
		$post_ids = array();
		$post_images = array();
		foreach( $cat_names as $cat_name => $cat_slug ) {
			if( strcasecmp( $category, $cat_name ) == 0 ) {
				$category = $cat_slug;
				$category_name = $cat_name;
				$args = array(
					'category_name' => $category,
				);
				$catposts = get_posts( $args );
				if( empty( $catposts ) ) {
					return;
				}
				else {
					foreach ( $catposts as $catpost ) : setup_postdata( $catpost );
						$post_ids[] = $catpost->ID;
					endforeach;
					wp_reset_postdata();
				}
				foreach( $post_ids as $post_id ) {
					$image_ids = get_post_thumbnail_id( $post_id );
					$image_src = wp_get_attachment_image_src( $image_ids, 'landscape-widescreen' );
					$post_images[$category_name][$post_id] = $image_src[0];
				}
			}
		}
		$category_featimg_data[] = $post_images;
	}
	
	foreach( $category_featimg_data as $category_featimg_single_data ) {
		foreach( $category_featimg_single_data as $category_featimg_catname => $category_featimg_catdata ) {
			$filter_name_list[] = htmlentities( '<li class="filter-list" data-uk-filter="filter-' . $category_featimg_catname . '"><a href="#">' . $category_featimg_catname . '</a></li>' );
			foreach($category_featimg_catdata as $category_featimg_catdata_id => $category_featimg_catdata_imgsrc ) {
				$filter_data_list[] = htmlentities( '<div class="filter-data" data-uk-filter="filter-' . $category_featimg_catname . '"><a class="image-wrapper" href="' . $category_featimg_catdata_imgsrc . '" data-uk-lightbox><img src="' . $category_featimg_catdata_imgsrc . '" alt="Portfolio Image" /></a></div>' );
			}
			$filter_tab_head_data = $filter_name_list;
			$filter_tab_content_data = $filter_data_list;
		}
		
	}

	$tab_head_markup_open = htmlentities( '<ul id="portfolio-isotope" class="uk-subnav portfolio-categories-nav"><li class="default filter-list uk-active" data-uk-filter=""><a href="#">All</a></li>' );
	$tab_head_markup_close = htmlentities( '</ul>' );
	
	ob_start();
		echo $tab_head_markup_open;
		foreach( $filter_tab_head_data as $filter_tab_head ) {
			echo $filter_tab_head;
		}
		echo $tab_head_markup_close;
	$output_tab_head = ob_get_clean();
	
	$tab_content_markup_open = htmlentities( '<div class="uk-grid-width-small-1-2 uk-grid-width-medium-1-3 uk-grid-width-large-1-3 tm-grid-heights portfolio-categories-content" data-uk-grid="{gutter:' . $grid_gutter . ', controls:\'#portfolio-isotope\', duration: \'600\'}">' );
	$tab_content_markup_close = htmlentities( '</div>' );
	
	ob_start();
		echo $tab_content_markup_open;
		foreach( $filter_tab_content_data as $filter_tab_content ) {
			echo $filter_tab_content;
		}
		echo $tab_content_markup_close;
	$output_tab_content = ob_get_clean();

	return html_entity_decode( $output_tab_head ) . html_entity_decode( $output_tab_content );
}

/* Disable the Envoke Supersized slider on all the other pages; we need just for the portfolio template */

if ( in_array( 'envoke-supersized/envoke_supersized.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	add_filter( 'enss-enabled', '__return_false' );
}


/* Remove the post editor if using this template. Full-width slider does not need content on the page */

add_action( 'init', 'xpos_portfolio_template_remove_content_editor' );

function xpos_portfolio_template_remove_content_editor() {
	if( !is_admin() ) {
	   return;
	}

	// Get the post ID on edit post with filter_input super global inspection.
	$current_post_id = filter_input( INPUT_GET, 'post', FILTER_SANITIZE_NUMBER_INT );
	// Get the post ID on update post with filter_input super global inspection.
	$update_post_id = filter_input( INPUT_POST, 'post_ID', FILTER_SANITIZE_NUMBER_INT );

	// Check to see if the post ID is set, else return.
	if( isset( $current_post_id ) ) {
	   $post_id = absint( $current_post_id );
	} else if ( isset( $update_post_id ) ) {
	   $post_id = absint( $update_post_id );
	} else {
	   return;
	}

	// Don't do anything unless there is a post_id.
	if( isset( $post_id ) ) {
		// Get the template of the current post.
		$template_file = get_post_meta( $post_id, '_wp_page_template', true );

		// Example of removing page editor for page-your-template.php template.
		if(  'xposure_portfolio.php' === $template_file ) {
			remove_post_type_support( 'page', 'editor' );
			remove_post_type_support( 'page', 'lander-schema' );
			remove_post_type_support( 'page', 'lander-landing-page-experience' );
			remove_post_type_support( 'page', 'lander-mobile-experience' );
			remove_post_type_support( 'page', 'lander-custom-menu-locations' );
			remove_post_type_support( 'page', 'lander-landing-sections' );
			remove_post_type_support( 'page', 'thumbnail' );
			add_action( 'edit_form_after_title', 'xpos_editor_disallowed_notice' );
		}
	}
}

function xpos_editor_disallowed_notice() {
	echo '<div class="notice notice-warning inline"><p>' . sprintf( __( 'You cannot add content to this page with %sXposure Portfolio%s template in use.', CHILD_DOMAIN ), '<strong>', '</strong>' ) . '</p></div>';
}