<?php
/**
 * Highlight default theme setting
 *
 * @package Sora by SkyandStars
 * @author  SkyandStars
 * @license GPL-2.0-or-later
 * @link    https://www.skyandstars.co
 */

add_action( 'after_switch_theme', 'highlight_genesis_default_settings' );
/**
* Update settings on theme switch (activation)
*/
function highlight_genesis_default_settings() {
 if( ! function_exists( 'genesis_update_settings' ) )
   return;
 $settings = array(
   'update'                    => 0,  
   'update_email_address'      => '', 
   'site_layout'               => 'content-sidebar', 
   'blog_title'                => 'text', // select ( text, image )
   'content_archive'           => 'excerpts', // select ( full, excerpts )
   'content_archive_limit'     => '300', // int only applicable when using excerpts on content_archive
   'content_archive_thumbnail' => 1, 
   'image_size'                => 'autoreadmore', 
   'image_alignment'           => 'aligncenter', // select ( alignleft, alignright )
   'posts_nav'                 => 'numeric', // select ( prev-next, numeric )
   'footer_text'			       => '[footer_copyright before="Copyright " after="."] Blog Name'
 );
 genesis_update_settings( $settings );
}