<?php
//* this will bring in the Genesis Parent files needed:
include_once( get_template_directory() . '/lib/init.php' );
//* Child theme
define( 'CHILD_THEME_NAME', 'LoveYourself' );
define( 'CHILD_THEME_URL', 'http://skyandstars.etsy.com' );
define( 'CHILD_THEME_VERSION', '1.3' );
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );
add_theme_support( 'genesis-responsive-viewport' );
add_theme_support( 'genesis-menus', array( 'primary' => __( 'Primary Navigation Menu', 'genesis' ) ) );

/*========================== INCLUDES OTHER FILES ========================== */
require_once('lib/customizer_setting.php');
require_once('lib/customizer_output.php'); 
require_once('lib/skystars_widget.php');

/*muplugin*/ 
require_once dirname( __FILE__ ) . '/lib/class-tgm-plugin-activation.php';
add_action( 'tgmpa_register', 'skyandstars_required_plugins' );
function skyandstars_required_plugins() {
    $plugins = array(
		array(
			'name'      => 'Genesis Responsive Slider',
			'slug'      => 'genesis-responsive-slider',
			'required'  => true, // this plugin is recommended
		),
		array(
			'name'      => 'Simple Social Icons',
			'slug'      => 'simple-social-icons',
			'required'  => true, // this plugin is recommended
		),
		array(
			'name'      => 'Instagram Slider Widget',
			'slug'      => 'instagram-slider-widget',
			'required'  => true, // this plugin is recommended
		),
		array(
			'name'      => 'Regenerate Thumbnails',
			'slug'      => 'regenerate-thumbnails',
			'required'  => false, // this plugin is optional
		),
		array(
			'name'      => 'jQuery Pin It Button for Images',
			'slug'      => 'jquery-pin-it-button-for-images',
			'required'  => false, // this plugin is recommended
		),
	);
	
    $config = array( /* The array to configure TGM Plugin Activation */ );
    tgmpa( $plugins, $config );
 
}
/* end muplugin*/

/*========================== SCRIPT AND STYLES ========================== */
add_action( 'wp_enqueue_scripts', 'skyandstars_enqueue_scripts' );
function skyandstars_enqueue_scripts() {
	wp_enqueue_script( 'fitvids', get_stylesheet_directory_uri() . '/js/jquery.fitvids.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_script( 'prefix-responsive-menu', get_stylesheet_directory_uri() . '/js/responsivemenu.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_script( 'site-script', get_stylesheet_directory_uri() . '/js/script.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_style( 'google-font', 'https://fonts.googleapis.com/css?family=Lato:300,300i,400,700,700i|Lora:400,700', array(), CHILD_THEME_VERSION );
	wp_enqueue_style( 'fontawesome', '//maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css' );
	wp_enqueue_style( 'dashicons' );
	wp_enqueue_style( 'mobile', get_stylesheet_directory_uri() . '/css/mobile.css', '1.0.0');
}


/*========================== LAYOUT ========================== */
/** Define a default post thumbnail */
add_filter('genesis_get_image', 'default_image_fallback', 10, 2);
function default_image_fallback($output, $args) {
    global $post;
    if( $output || $args['size'] == 'full' )
        return $output;
 
    $thumbnail = CHILD_URL.'/images/thumb.jpg';
 
    switch($args['format']) {
 
        case 'html' :
            return '<img src="'.$thumbnail.'" class="attachment-'. $args['size'] .'" alt="'. get_the_title($post->ID) .'" />';
            break;
        case 'url' :
            return $thumbnail;
            break;
       default :
           return $output;
            break;
    }
}

//new thumb sizes
add_image_size('sidebar-featured', 300, 250, TRUE);
add_image_size('autoreadmore', 1024, 768, TRUE);
add_image_size('cat_image', 1200, 640, TRUE);
add_image_size('widgetbox-header', 950, 640, TRUE);

/*========================== HEADER AREA ========================== */
//Tambahin class default ke body
add_filter( 'body_class', 'add_body_class' ); 
function add_body_class( $classes ) {

	$sky_home_layout = get_theme_mod( 'sky_home_layout', true );
	
	if ( $sky_home_layout =='default' ) {
        $classes[] = 'skyfull-layout';
    } else {
		$classes[] = 'skygrid-layout';
		//Pindahin foto sebelum post title
		remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
		add_action( 'genesis_entry_header', 'genesis_do_post_image', 1 );
	}
    return $classes;
	
}
//notes: sky_home_layout == 'skyfull-layout' else 'skygrid-layout'


/** menu utama diatas header */
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before_header', 'genesis_do_nav' );

//* Add support for custom header
add_theme_support( 'genesis-custom-header');
add_theme_support( 'custom-header', array(
	'header-selector' => '.site-title a',
	'header-text'     => false,
	'height'      => 380,
    'width'       => 960,
    'flex-height' => true,
    'flex-width'  => true,
) );
/** Unregister other site layouts */
unregister_sidebar( 'header-right' );

/*========================== POSTING AREA ========================== */

//Ganti kata-kata RM
add_filter( 'the_content_more_link', 'sp_read_more_link' );
function sp_read_more_link() {
	return '<a class="more-link" href="' . get_permalink() . '">View Post</a>';
}
 
// Tulisan RM yg Automatis dipotong
add_filter('excerpt_more', 'auto_excerpt_more');
function auto_excerpt_more($more) {
    return ' ... <a class="autoreadmore" href="'.get_permalink().'" rel="nofollow">View Post</a>';
}

//* Remove the post meta function
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

//* Gutenberg full width image
function mytheme_setup() {
  add_theme_support( 'align-wide' );
}
add_action( 'after_setup_theme', 'mytheme_setup' );

// Entry Footer Modif
add_action( 'genesis_entry_footer', 'new_genesis_post_footer' );
function new_genesis_post_footer() {
if(!is_feed() && !is_page()) { ?>
	<?php if ( comments_open() ) : ?>
    <span class="comments-link">
      <?php comments_popup_link( '<span class="leave-reply">' . __( 'Leave a Comment', 'twentytwelve' ) . '</span>', __( '1 Comment', 'twentytwelve' ), __( '% Comments', 'twentytwelve' ) ); ?>
    </span>
    <!-- .comments-link -->
    
    <?php endif; // comments_open() ?>
    
    <span class="catlinkwrap"> Categories: <?php the_category(', '); ?></span>
    
<?php }
}

//* Entry Meta header
add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
    $post_info = '[post_date] [post_categories before=""] [post_edit]';
    return $post_info;
}

/*========================== SHOP WIDGET ========================== */
add_action( 'genesis_entry_content', 'custom_field_after_content', 10 );
/**
* @author Brad Dalton - WP Sites
* @link http://wp.me/p1lTu0-9WF
*/
function custom_field_after_content() {

	if ( ! is_category() ) {
		echo '<div id="shopthelook" class="stl">'; 
		echo '<h4 class="stl_title">';
		echo genesis_custom_field('shopthelook_title');
		echo '</h4>';
		echo genesis_custom_field('shopthelook_code');
		echo '</div>';
	}
}


/*========================== social media under post ========================== */
add_action( 'genesis_entry_footer', 'child_social_media_icons', 15 );
/**
 * @author Greg Rickaby
 * @since  1.0.0
 * @link   http://codex.wordpress.org/Conditional_Tags
 * @return html  official social media icons
 */
function child_social_media_icons() {
    // Display on single posts only
    /*if ( is_single() ) { */?>

        <div class="social-media-icons">
		Share :
		<div class="social-media-items">
<a class="icon-fb" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>"
             onclick="window.open(this.href, \'facebook-share\',\'width=580,height=296\');return false;">
            <span><i class="fa fa-facebook" aria-hidden="true"></i></span>
        </a>
		
            <a class="icon-twitter" href="http://twitter.com/share?text=<?php the_title(); ?>&url=<?php the_permalink(); ?>&via=your_twitter_usernamehere"
            onclick="window.open(this.href, \'twitter-share\', \'width=550,height=235\');return false;">
            <span><i class="fa fa-twitter"></i></span>
        </a>   

        <a href="//pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&amp;media=<?php echo genesis_get_image( array( 'format' => 'url' ) ); ?>&amp;description=<?php the_title(); ?>" data-pin-do="buttonPin" data-pin-custom="true" data-pin-config="beside"><span><i class="fa fa-pinterest-p"></i></span></a>
		</div>
		<div style="clear:both"> </div>
        </div><!-- .social-media-icons -->

	<?php }


/*========================== FOOTER AREA ========================== */
//CREDITS
function genesischild_footer_creds_text () {
  echo '<div class="creds">'. get_theme_mod('sky_copyright') .'Design by <a href="http://skyandstars.co/" target="_blank">SkyandStars.co</a></div> <div id="back-top"><a href="#top"><span>Back Top</span></a></div>';
}
add_filter( 'genesis_footer_creds_text', 'genesischild_footer_creds_text' ); 


//Instagram Widget
function genesischild_footerwidgetheader() {
	genesis_register_sidebar( array(
	'id' => 'footerwidgetheader',
	'name' => __( 'Instagram Widget', 'genesis' ),
	'description' => __( 'This is for full width instagram widget', 'genesis' ),
	) );
}
add_action ('widgets_init','genesischild_footerwidgetheader');
function genesischild_footerwidgetheader_position ()  {
	echo '<div class="instagramwidget"><div class="wrap">';
	genesis_widget_area ('footerwidgetheader');
	echo '</div></div>';

}
add_action ('genesis_before_footer','genesischild_footerwidgetheader_position');

/*========================== WIDGET ========================== */
//search
add_filter( 'genesis_search_button_text', 'ss_genesis_search_button_text' );
function ss_genesis_search_button_text( $text ) {
  return esc_attr( 'Go' );
}

/*========================== SLIDER SETTING ========================== */
//SLIDER WIDGET
genesis_register_sidebar( array(
	'id'          => 'homesliderarea',
	'name'        => __( 'Slider Widget - Home', 'theme-name' ),
	'description' => __( 'Install Genesis Responsive Slider first, then drag a genesis slideshow widget from the left and drop it here', 'honjewp' ),
) );
add_action( 'genesis_after_header', 'add_genesis_widget_area' );
function add_genesis_widget_area() {
		if ( ! is_home() ) //only muncul di home
		return;
        genesis_widget_area( 'homesliderarea', array(
		'before' => '<div class="sliderpost widget-area">',
		'after'  => '</div>',
    ) );

}

/*========================== WIDGET AFTER SLIDER ========================== */
genesis_register_sidebar( array(
    'id'                => 'cta-1',
    'name'          => __( 'Featured Items - Under header', 'loveyourself' ),
    'description'   => __( 'Featured Pages or Posts under Header - 3 items only. ', 'loveyourself' ),
) );
add_action( 'genesis_after_header', 'bts_cta_genesis' );

function bts_cta_genesis() {
  // Don't display the CTA on the home page, since it's built into the MP theme
  if ( is_home() ) {
        genesis_widget_area( 'cta-1', array(
            'before' => '<div id="home-featured"><div class="wrap">',
            'after' => '</div></div>',
        ) );
    }

}