<?php
/**
 * BloomBlogShop
 * @package      BloomBlogShop
 */

/**
 * Set up the content width value based on the theme's design.
 *
 */
if ( ! isset( $content_width ) )
    $content_width = 740;

/**
 * Theme setup.
 *
 * Attach all of the site-wide functions to the correct hooks and filters. All
 * the functions themselves are defined below this setup function.
 *
 * @since 1.0.0
 */

function jt_child_theme_setup() {

    // Genesis & Sensei Specific Changes
    include_once( get_stylesheet_directory() . '/inc/genesis-changes.php' );

    // Editor Styles
    add_editor_style( 'css/editor-style.css' );

    // Set comment area defaults
    add_filter( 'comment_form_defaults', 'jt_comment_text' );

    // Global enqueues
    add_action( 'wp_enqueue_scripts', 'jt_global_enqueues' );

    // Archive Template
    // add_filter( 'template_include', 'jt_search_template' );
    add_filter( 'excerpt_length', 'jt_archive_excerpt_length' );

    // Home Widget
    add_action( 'genesis_before_content', 'jt_home_widget', 5 );

    // Footer
    remove_action( 'genesis_footer', 'genesis_do_footer' );
    add_action( 'genesis_footer', 'jt_footer' );

}
add_action( 'genesis_setup', 'jt_child_theme_setup', 15 );


/* ==========================================================================
 * Backend Functions
 * ========================================================================== */

/**
 * Change the comment area text
 *
 * @since  1.0.0
 * @param  array $args
 * @return array
 */
function jt_comment_text( $args ) {
    $args['title_reply']          = __( 'Leave A Reply', 'jt_genesis_child' );
    $args['label_submit']         = __( 'Post Comment',  'jt_genesis_child' );
    $args['comment_notes_before'] = '';
    $args['comment_notes_after']  = '';

    // Remove labels and add placeholders
    $args['fields']['author'] = '<p class="comment-form-author"><input id="author" name="author" type="text" value="" size="30" aria-required="true" placeholder="Your Name"></p>';
    $args['fields']['email'] = '<p class="comment-form-email"><input id="email" name="email" type="email" value="" size="30" aria-describedby="email-notes" aria-required="true" placeholder="Your Email"></p>';
    $args['fields']['url'] = '<p class="comment-form-url"><input id="url" name="url" type="url" value="" size="30" placeholder="Website URL"></p>';
    $args['comment_field'] = '<p class="comment-form-comment"><textarea id="comment" name="comment" cols="45" rows="8" aria-describedby="form-allowed-tags" aria-required="true" placeholder="Your Comment"></textarea></p>';
    return $args;
}

/**
 * Global enqueues
 *
 * @since  1.0.0
 * @global array $wp_styles
 */
function jt_global_enqueues() {

    // javascript
    wp_enqueue_script( 'fitvids', get_stylesheet_directory_uri() . '/js/jquery.fitvids.js', array( 'jquery' ), '1.1', true );
    wp_enqueue_script( 'jt-global', get_stylesheet_directory_uri() . '/js/global.js', array( 'jquery', 'fitvids' ), '1.0', true );
    wp_enqueue_script( 'jt-responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0', true );

    // css
    wp_enqueue_style( 'dashicons' );
    wp_enqueue_style( 'fonts', 'http://fonts.googleapis.com/css?family=Karla:400,400italic,700,700italic' );
}


/* ==========================================================================
 * Frontend Functions
 * ========================================================================== */

/**
 * Custom Header
 *
 */

add_theme_support( 'custom-header', array(
    'header-selector' => '.site-title a',
    'height'          => 120,
    'width'           => 320
) );

/**
 * Home Page Slider
 *
 */

// Home Page Widget

register_sidebar( array(
    'id'            => 'homewidget',
    'name'          => 'Full Width Home Widget',
    'description'   => 'This is the full-width widget area under the site header on the home page.',
));

function jt_home_widget() {
    if ( is_home() && is_front_page() ) {
        genesis_widget_area ( 'homewidget', [
            'before' => '<div class="home-widget">',
            'after'  => '</div>',
        ]);
    }
}


/**
 * Footer
 *
 */

// Copyright

function jt_footer() {
    echo '<p class="site-creds">&copy; Copyright ' . date("Y") . '. ' . get_bloginfo( 'name' ) . '. All Rights Reserved. Made by <a href="https://exempel.se">Exempel/a>.</p>';
}