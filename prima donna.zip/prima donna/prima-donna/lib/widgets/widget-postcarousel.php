<?php
/**
 * Post Carousel Widget
 *
 * Register the widget for use in Appearance -> Widgets
 *
 * @package Prima Donna
 */
add_action( 'widgets_init', 'primadonna_postcarousel_widget_init' );

function primadonna_postcarousel_widget_init() {
	register_widget( 'Prima_Donna_Postcarousel_Widget' );
}

/**
 * Post Carousel widget class
 */
class Prima_Donna_Postcarousel_Widget extends WP_Widget {

	/**
	 * Registers the widget with WordPress.
	 */
	function __construct() {

		parent::__construct(
			'postcarousel-primadonna',
			apply_filters( 'primadonna_widget_name', __( 'Prima Donna: Sidebar Posts Carousel', 'primadonna' ) ),
			array(
				'classname'   => 'widget-postcarousel-primadonna',
				'description' => __( 'Display a post carousel.', 'primadonna' )
			)
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	function widget( $args, $instance ) {

		// Defaults
		$defaults = $this->defaults();

		// Merge the user-selected arguments with the defaults.
		$instance = wp_parse_args( (array) $instance, $defaults );

		// Open the output of the widget.
		echo $args['before_widget'];

?>
		<?php if( ! empty( $instance['title'] ) ) : ?>
			<?php echo $args['before_title'] . apply_filters( 'widget_title',  $instance['title'], $instance, $this->id_base ) . $args['after_title']; ?>
		<?php endif; ?>

		<?php
		// Query Args
		$query_args = array( 'ignore_sticky_posts' => 1, 'posts_per_page' => $instance['postcarousel_limit'] );

		// Post Category
		if( $instance['postcarousel_category'] > 0 ) {
			$query_args['cat'] = $instance['postcarousel_category'];
		}

		// Post Order
		if( 2 == $instance['postcarousel_orderby'] ) {
			$query_args['orderby'] = 'comment_count';
		}

		// WP Query
		$postcarousel_query = new WP_Query( $query_args );
		if ( $postcarousel_query->have_posts() ) :
		?>
		<div class="primadonna-postcarousel-wrapper postcarousel-loader">

			<div class="primadonna-postcarousel">

				<?php while( $postcarousel_query->have_posts() ) : $postcarousel_query->the_post(); ?>
				<div class="item">

					<a href="<?php the_permalink(); ?>" >
						<?php if( has_post_thumbnail() ) : ?>
							<?php the_post_thumbnail( 'square-entry-image', array( 'class' => 'img-postcarousel img-responsive' ) ); ?>
						<?php else: ?>
							<img width="700" height="700" src="<?php echo get_template_directory_uri(); ?>/images/placeholder-postcarousel.png" class="img-postcarousel img-responsive" alt="<?php esc_attr_e( 'Post Carousel Image Placeholder', 'primadonna' ); ?>">
						<?php endif; ?>
					</a>
					<header class="entry-header-postcarousel">
						<span class="side-meta"><?php the_category(', '); ?></span>
						<?php the_title( '<h3 class="entry-title-postcarousel"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' ); ?>
					</header><!-- .entry-header -->

				</div>
			<?php endwhile; ?>

			</div><!-- .primadonna-postcarousel -->
		</div><!-- .primadonna-postcarousel-wrapper -->
		<?php
		endif;
		// Reset Post Data
		wp_reset_postdata();
		?>

<?php

		/** Close the output of the widget. */
		echo $args['after_widget'];

	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	function update( $new_instance, $old_instance ) {

		// Instance
		$instance = $old_instance;

		// Sanitization
		$instance['title']                                = strip_tags( $new_instance['title'] );
		$instance['postcarousel_category']                = absint( $new_instance['postcarousel_category'] );
		$instance['postcarousel_orderby']                 = absint( $new_instance['postcarousel_orderby'] );
		$instance['postcarousel_limit']                   = absint( $new_instance['postcarousel_limit'] );

		return $instance;

	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	function form( $instance ) {

		// Defaults
		$defaults = $this->defaults();

		// Merge the user-selected arguments with the defaults.
		$instance = wp_parse_args( (array) $instance, $defaults );

		// Controls
		$postcarousel_orderby = array (
			1 => __( 'Recent Posts',  'primadonna'),
			2 => __( 'Popular Posts', 'primadonna'),
		);
		$postcarousel_boolean = array (
			0 => __( 'No',  'primadonna'),
			1 => __( 'Yes', 'primadonna'),
		);
		$postcarousel_limit                = range ( 1, 20 );
?>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>">
				<?php esc_html_e( 'Title:', 'primadonna' ); ?>
				<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo esc_attr( $instance['title'] ); ?>" />
			</label>
		</p>

        <p>
			<label for="<?php echo $this->get_field_id( 'postcarousel_category' ); ?>">
				<?php esc_html_e( 'Select Category:', 'primadonna' ); ?>
				<?php
				$args = array(
					'show_option_all'  => __( 'All Categories', 'primadonna' ),
					'selected'         => $instance['postcarousel_category'],
					'name'             => $this->get_field_name( 'postcarousel_category' ),
					'class'            => 'widefat',
				);
				wp_dropdown_categories( $args );
				?>
			</label>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'postcarousel_orderby' ); ?>">
				<?php esc_html_e( 'Post Order:', 'primadonna' ); ?>
	            <select class="widefat" id="<?php echo $this->get_field_id( 'postcarousel_orderby' ); ?>" name="<?php echo $this->get_field_name( 'postcarousel_orderby' ); ?>">
	              <?php foreach ( $postcarousel_orderby as $key => $val ): ?>
				    <option value="<?php echo esc_attr( $key ); ?>" <?php selected( $instance['postcarousel_orderby'], $key ); ?>><?php echo esc_html( $val ); ?></option>
				  <?php endforeach; ?>
	            </select>
            </label>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'postcarousel_limit' ); ?>">
				<?php esc_html_e( 'Number of posts to display:', 'primadonna' ); ?>
	            <select class="widefat" id="<?php echo $this->get_field_id( 'postcarousel_limit' ); ?>" name="<?php echo $this->get_field_name( 'postcarousel_limit' ); ?>">
	              <?php foreach ( $postcarousel_limit as $key => $val ): ?>
				    <option value="<?php echo esc_attr( $val ); ?>" <?php selected( $instance['postcarousel_limit'], $val ); ?>><?php echo esc_html( $val ); ?></option>
				  <?php endforeach; ?>
	            </select>
            </label>
		</p>

<?php
	}

	// Defaults
	function defaults() {

		$defaults = array(
			'title'                              => __( 'Post Carousel', 'primadonna'),
			'postcarousel_category'              => 0,
			'postcarousel_orderby'               => 1,
			'postcarousel_limit'                 => 5,
		);

		return $defaults;

	}

}