<?php
/**
 * Ellie Jane.
 * @package Ellie Jane
 */

add_filter( 'genesis_theme_settings_defaults', 'ellie_theme_defaults' );
/**
 * Updates theme settings on reset.
 *
 * @since 3.0.2
 */
function ellie_theme_defaults( $defaults ) {

	$defaults['blog_cat_num']              = 4;
	$defaults['content_archive']           = 'full';
	$defaults['content_archive_limit']     = 260;
	$defaults['content_archive_thumbnail'] = 1;
	$defaults['image_size']                = 'square-entry-image';
	$defaults['image_alignment']           = 'alignleft';
	$defaults['posts_nav']                 = 'numeric';
	$defaults['site_layout']               = 'content-sidebar';

	return $defaults;

}

add_action( 'after_switch_theme', 'ellie_theme_setting_defaults' );
/**
 * Updates theme settings on activation.
 *
 * @since 3.0.2
 */
function ellie_theme_setting_defaults() {

	if( function_exists( 'genesis_update_settings' ) ) {

		genesis_update_settings( array(
			'blog_cat_num'              => 4,
			'content_archive'           => 'full',
			'content_archive_limit'     => 260,
			'content_archive_thumbnail' => 1,
			'image_size'                => 'square-entry-image',
			'image_alignment'           => 'alignleft',
			'posts_nav'                 => 'numeric',
			'site_layout'               => 'content-sidebar',
		) );

	}

	update_option( 'posts_per_page', 4 );

}

add_filter( 'simple_social_default_styles', 'ellie_social_default_styles' );
/**
 * Updates Simple Social Icon settings on activation.
 *
 * @since 3.0.2
 */
function ellie_social_default_styles( $defaults ) {

	$args = array(
		'alignment'              => 'aligncenter',
		'background_color'       => '#000000',
		'background_color_hover' => '#d7ad63',
		'border_radius'          => 50,
		'icon_color'             => '#ffffff',
		'icon_color_hover'       => '#ffffff',
		'size'                   => 36,
		);

	$args = wp_parse_args( $args, $defaults );

	return $args;

}