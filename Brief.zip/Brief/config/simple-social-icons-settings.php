<?php
/**
 * Brief Simple Social Icons default settings.
 * @package Brief
 */

return [
	'alignment'              => 'aligncenter',
	'background_color'       => '#ffffff',
	'background_color_hover' => '#ffffff',
	'border_radius'          => 0,
	'border_width'           => 0,
	'icon_color'             => '#333333',
	'icon_color_hover'       => '#666666',
	'size'                   => 40,
];
