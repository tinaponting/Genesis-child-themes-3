<?php
/**
 * This file adds the Home Page to the Beyond Madison Theme.
 * @package Beyond Madison
 * @subpackage Customizations
 */

add_action( 'genesis_meta', 'beyond_home_genesis_meta' );
/**
 * Add widget support for homepage. If no widgets active, display the default loop.
 *
 */
function beyond_home_genesis_meta() {

	if ( is_active_sidebar( 'home-slider' ) || is_active_sidebar( 'subscribe-bar' ) || is_active_sidebar( 'featured-flex-posts' )) {
		
		add_action( 'genesis_before', 'beyond_home_sections', 25 );
		add_filter( 'body_class', 'beyond_add_home_body_class' );

		//* Remove default loop & sidebar (remove the // symbols in front of the next two lines to remove the default blog loop and sidebar from the home page of Beyond Madison.)
		remove_action( 'genesis_loop', 'genesis_do_loop' );
		remove_action( 'genesis_sidebar', 'genesis_do_sidebar' ); 

//* Add body class to home page
function beyond_add_home_body_class( $classes ) {

	$classes[] = 'beyond-home';
	return $classes;
	
		}

	}

}

function beyond_home_sections() {

if( !is_paged()) {

	echo '<div class="home-top">';

	genesis_widget_area( 'home-slider', array(
		'before' => '<div class="home-slider widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );

	echo '</div>';

	genesis_widget_area( 'subscribe-bar', array(
		'before' => '<div class="subscribe-bar widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );

	genesis_widget_area( 'featured-flex-posts', array(
		'before' => '<div class="featured-flex-posts widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );

	}
}

genesis();