<?php 
/*
Template Name: Recipe Index
*/ 

//* Recipe Index Page Layout
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_sidebar_content' );

//* Designates Alternate Sidebar for Recipe Index Page
add_action( 'genesis_sidebar', 'genesis_do_sidebar_alt' );
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );

//* Recipe Index CSS Class
add_filter( 'body_class', 'meringue_body_class' );
function meringue_body_class( $classes ) {
	
	$classes[] = 'recipe-index';
	return $classes;
	
}

//* Adds Widget Area Above Recipe Index Content
add_action( 'genesis_loop', 'recipe_index_top', 1  ); 
function recipe_index_top() {
    genesis_widget_area( 'recipe-index-top', array(
		'before' => '<div class="recipe-index-top widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );
}

//* Recipe Index Custom Loop
remove_action ('genesis_loop', 'genesis_do_loop');
add_action( 'genesis_loop', 'meringue_do_loop' );

 
function meringue_do_loop() {

  // Intro Text (from page content)
	echo '<div class="page hentry entry">';
	echo '<div class="entry-content">';
		the_content();
	echo '</div><!-- end .entry-content -->';
 
global $post;
 
	// arguments, adjust as needed
	$args = wp_parse_args(
		genesis_get_custom_field( 'query_args' ),
		array(
		'post_type'      => 'post',
		'posts_per_page' => 21,
		'post_status'    => 'publish',
		'cat'		 	 => $include,
		'paged'          => get_query_var( 'paged' ) )
	);
 
	global $wp_query;
	$wp_query = new WP_Query( $args );
 
	if ( have_posts() ) : 
		while ( have_posts() ) : the_post(); 
 
			echo '<div class="one-third"><div class="meringue-featured-image">';
				echo '<a href="' . get_permalink() .'" title="' . the_title_attribute( 'echo=0' ) . '">';
				echo get_the_post_thumbnail($thumbnail->ID, 'vertical-thumbnail' );
				echo '</a>';
			echo '</div></div>';
 
		endwhile;
		do_action( 'genesis_after_endwhile' );
	endif;
 
	wp_reset_query();
}

function custom_trim_my_title( $title ) {
	if ( strlen( $title ) >= 50 && ! is_singular() ) {
		$title = substr( $title, 0, 50 ) . '...';
		return $title;
	}
	return $title;
}
add_filter( 'the_title', 'custom_trim_my_title' );

genesis();