<?php
/**
 * sweets Custom Archives.
 * @package      Hello Sweets
 */

//* Do not show Featured image if set in Theme Settings > Content Archives
add_filter( 'genesis_pre_get_option_content_archive_thumbnail', '__return_false' );

//* Add the featured image before post title
add_action( 'genesis_entry_header', 'sweets_archive_grid', 9 );
function sweets_archive_grid() {

    if ( $image = genesis_get_image( 'format=url&size=large-featured' ) ) {
        printf( '<div class="sweets-featured-image"><a href="%s" rel="bookmark"><img src="%s" alt="%s" /></a></div>', get_permalink(), $image, the_title_attribute( 'echo=0' ) );

    }

}

//* Force Excerpts
add_filter( 'genesis_pre_get_option_content_archive', 'sweets_show_excerpts' );
function sweets_show_excerpts() {
	return 'excerpts';
}

//* Modify the length of post excerpts
add_filter( 'excerpt_length', 'sweets_excerpt_length' );
function sweets_excerpt_length( $length ) {
	return 50; // pull first 10 words
}


genesis();
