<?php
/**
 * Ellie Jane.
 * @package Ellie Jane
 */

/**
 * Get default color for Customizer.
 * Abstracted here since at least two functions use it.
 *
 * @return string Hex color code.
 */
function ellie_customizer_get_default_link_color() {
	return '#d7ad63';
}

function ellie_customizer_get_default_accent_color() {
	return '#d7ad63';
}

function ellie_customizer_get_default_main_color() {
	return '#000000';
}

function ellie_customizer_get_default_white_color() {
	return '#ffffff';
}

function ellie_customizer_get_default_white_color_hover() {
	return '#d7ad63';
}

function ellie_customizer_get_default_title_color() {
	return '#000000';
}


function ellie_customizer_get_default_description_color() {
	return '#000000';
}

function ellie_customizer_get_default_body_font_color() {
	return '#333333';
}

function ellie_customizer_get_default_entry_title_color() {
	return '#000000';
}