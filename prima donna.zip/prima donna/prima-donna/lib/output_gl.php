<?php

/**
 * This file adds the required CSS for the Customizer to the Prima Donna Theme.
 * @package      Prima Donna+
 */
 
//////////////////////////////////////////////////////////////////
// Customizer - Add CSS
//////////////////////////////////////////////////////////////////
function georgialou_customizer_css() {

    ?>

    <style type="text/css">

		/* Promo Box Height */
		.home.blog .promo-item {
    		height:<?php echo get_theme_mod( 'georgialou_promo_height_setting' ); ?>px;
    	}
  


    </style>


    <?php
}
add_action( 'wp_head', 'georgialou_customizer_css' );

?>
