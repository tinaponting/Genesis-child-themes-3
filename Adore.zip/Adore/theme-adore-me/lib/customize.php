<?php
/**
 * Adore Me.
 * @package Adore Me
 */

add_action( 'customize_register', 'adore_customizer_register' );
/**
 * Register settings and controls with the Customizer.
 *
 * @since 3.2.0
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function adore_customizer_register( $wp_customize ) {
	
	$images = apply_filters( 'adore_images', array( '2', '6' ) );

	$wp_customize->add_section(
		'adore-settings', array(
			'description' => __( 'Use the included default images or personalize your site by uploading your own images.<br /><br />The default images are <strong>1600 pixels wide and 1050 pixels tall</strong>.', 'adore-me' ),
			'title'       => __( 'Front Page Background Images', 'adore-me' ),
			'priority'    => 35,
		)
	);

	foreach( $images as $image ) {

		$wp_customize->add_setting(
			$image .'-adore-image',
			array(
				'default'           => sprintf( '%s/images/bg-%s.jpg', get_stylesheet_directory_uri(), $image ),
				'sanitize_callback' => 'esc_url_raw',
				'type'              => 'option',
			)
		);

		$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				$image .'-adore-image',
				array(
					'label'    => sprintf( __( 'Featured Section %s Image:', 'adore-me' ), $image ),
					'section'  => 'adore-settings',
					'settings' => $image .'-adore-image',
					'priority' => $image+1,
				)
			)
		);

	}

	// Add the link color picker.
	$wp_customize->add_setting(
		'adore_link_color',
		array(
			'default'           => adore_customizer_get_default_link_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'adore_link_color',
			array(
				'description' => __( 'Change the color for links, the color of post info links, the hover color of linked titles, and more.', 'adore-me' ),
				'label'       => __( 'Link Color', 'adore-me' ),
				'section'     => 'colors',
				'settings'    => 'adore_link_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'adore_body_font',
		array(
			'default'           => adore_customizer_get_default_body_font(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'adore_body_font',
			array(
				'description' => __( 'Change the body font color.', 'adore-me' ),
				'label'       => __( 'Body Font Color', 'adore-me' ),
				'section'     => 'colors',
				'settings'    => 'adore_body_font',
			)
		)
	);
	
	$wp_customize->add_setting(
		'adore_headings_font',
		array(
			'default'           => adore_customizer_get_default_headings_font(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'adore_headings_font',
			array(
				'description' => __( 'Change the font color for headings, post titles, widget titles, and more.', 'adore-me' ),
				'label'       => __( 'Post Title Font Color', 'adore-me' ),
				'section'     => 'colors',
				'settings'    => 'adore_headings_font',
			)
		)
	);
	
	$wp_customize->add_setting(
		'adore_site_title_color',
		array(
			'default'           => adore_customizer_get_default_site_title_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'adore_site_title_color',
			array(
				'description' => __( 'Change the font color for the Site Title.', 'adore-me' ),
				'label'       => __( 'Site Title', 'adore-me' ),
				'section'     => 'colors',
				'settings'    => 'adore_site_title_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'adore_site_description_color',
		array(
			'default'           => adore_customizer_get_default_site_description_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'adore_site_description_color',
			array(
				'description' => __( 'Change the font color for the Site Description.', 'adore-me' ),
				'label'       => __( 'Site Description', 'adore-me' ),
				'section'     => 'colors',
				'settings'    => 'adore_site_description_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'adore_header_menu',
		array(
			'default'           => adore_customizer_get_default_header_menu(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'adore_header_menu',
			array(
				'description' => __( 'Change the background color for the Menu before the header and WooCommerce buttons. To change the social media icons... change its settings directly in the widget.', 'adore-me' ),
				'label'       => __( 'Menu Before Header - Background Color', 'adore-me' ),
				'section'     => 'colors',
				'settings'    => 'adore_header_menu',
			)
		)
	);

	$wp_customize->add_setting(
		'adore_header_menu_font',
		array(
			'default'           => adore_customizer_get_default_header_menu_font(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'adore_header_menu_font',
			array(
				'description' => __( 'Change the font color for the Menu before the header and WooCommrece buttons. To change the social media icons... change its settings directly in the widget.', 'adore-me' ),
				'label'       => __( 'Menu Before Header - Font Color', 'adore-me' ),
				'section'     => 'colors',
				'settings'    => 'adore_header_menu_font',
			)
		)
	);
	
	$wp_customize->add_setting(
		'adore_header_after_menu_font',
		array(
			'default'           => adore_customizer_get_default_header_after_menu_font(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'adore_header_after_menu_font',
			array(
				'description' => __( 'Change the font color for the Menu after the header.', 'adore-me' ),
				'label'       => __( 'Menu After Header - Font Color', 'adore-me' ),
				'section'     => 'colors',
				'settings'    => 'adore_header_after_menu_font',
			)
		)
	);

	$wp_customize->add_setting(
		'adore_textbox_one',
		array(
			'default'           => adore_customizer_get_default_textbox_one(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'adore_textbox_one',
			array(
				'description' => __( 'Change the background color for Textbox 1.', 'adore-me' ),
				'label'       => __( 'Textbox 1 - Background Color', 'adore-me' ),
				'section'     => 'colors',
				'settings'    => 'adore_textbox_one',
			)
		)
	);
	
	$wp_customize->add_setting(
		'adore_textbox_one_font',
		array(
			'default'           => adore_customizer_get_default_textbox_one_font(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'adore_textbox_one_font',
			array(
				'description' => __( 'Change the font color for Textbox 1.', 'adore-me' ),
				'label'       => __( 'Textbox 1 - Font Color', 'adore-me' ),
				'section'     => 'colors',
				'settings'    => 'adore_textbox_one_font',
			)
		)
	);
	
	$wp_customize->add_setting(
		'adore_textbox_two',
		array(
			'default'           => adore_customizer_get_default_textbox_two(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'adore_textbox_two',
			array(
				'description' => __( 'Change the background color for Textbox 2.', 'adore-me' ),
				'label'       => __( 'Textbox 2 - Background Color', 'adore-me' ),
				'section'     => 'colors',
				'settings'    => 'adore_textbox_two',
			)
		)
	);
	
	$wp_customize->add_setting(
		'adore_textbox_two_font',
		array(
			'default'           => adore_customizer_get_default_textbox_two_font(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'adore_textbox_two_font',
			array(
				'description' => __( 'Change the font color for Textbox 2.', 'adore-me' ),
				'label'       => __( 'Textbox 2 - Font Color', 'adore-me' ),
				'section'     => 'colors',
				'settings'    => 'adore_textbox_two_font',
			)
		)
	);
	
	$wp_customize->add_setting(
		'adore_featured_image_bg',
		array(
			'default'           => adore_customizer_get_default_featured_image_bg(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'adore_featured_image_bg',
			array(
				'description' => __( 'Change the background for the blog post featured image, after entry widget section, and pagination.', 'adore-me' ),
				'label'       => __( 'Blog Post - Featured Image', 'adore-me' ),
				'section'     => 'colors',
				'settings'    => 'adore_featured_image_bg',
			)
		)
	);
	
	$wp_customize->add_setting(
		'adore_featured_image_entry',
		array(
			'default'           => adore_customizer_get_default_featured_image_entry(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'adore_featured_image_entry',
			array(
				'description' => __( 'Change the font color for the blog post entry title, date on blog page, and after entry font.', 'adore-me' ),
				'label'       => __( 'Blog Post - Entry Font', 'adore-me' ),
				'section'     => 'colors',
				'settings'    => 'adore_featured_image_entry',
			)
		)
	);
	
	$wp_customize->add_setting(
		'adore_sidebar_border',
		array(
			'default'           => adore_customizer_get_default_sidebar_border(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'adore_sidebar_border',
			array(
				'description' => __( 'Change the thin border color for the sidebar, homepage popular posts, comments, post divider and more.', 'adore-me' ),
				'label'       => __( 'Borders', 'adore-me' ),
				'section'     => 'colors',
				'settings'    => 'adore_sidebar_border',
			)
		)
	);
	
	$wp_customize->add_setting(
		'adore_frontpage_four',
		array(
			'default'           => adore_customizer_get_default_frontpage_four(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'adore_frontpage_four',
			array(
				'description' => __( 'Change the widget setion Front Page 4 background color.', 'adore-me' ),
				'label'       => __( 'Front Page 4 - Background Color', 'adore-me' ),
				'section'     => 'colors',
				'settings'    => 'adore_frontpage_four',
			)
		)
	);
	
	$wp_customize->add_setting(
		'adore_frontpage_four_font',
		array(
			'default'           => adore_customizer_get_default_frontpage_four_font(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'adore_frontpage_four_font',
			array(
				'description' => __( 'Change font color in Front Page 4.', 'adore-me' ),
				'label'       => __( 'Front Page 4 - Font Color', 'adore-me' ),
				'section'     => 'colors',
				'settings'    => 'adore_frontpage_four_font',
			)
		)
	);
	
}